# Kai Protocol package v0.4 / wire `kai/0.2`

## 1. Identity

- Human-facing name: `Kai Protocol — by Solo`
- Stable wire identity: `kai/0.2`
- Language layer: `kai-lang/0.1`
- Governing layer: `MASTER/1.0`

The package version advances independently from the stable wire identity. This avoids breaking existing message consumers while adding the language/security layers.

## 2. Core dialogue

Kai treats software components as protocol participants. The fundamental dialogue is not natural-language chat; it is typed machine discourse:

`CONTRACT → OBSERVATION → CLAIM → EVIDENCE → OBJECTION → COUNTEREXAMPLE → TEST → RESULT → REVISION → REBUTTAL → RECONSTRUCTION → VERDICT → PROMOTE`

`REOPEN` and `BLOCK` are first-class control messages.

## 3. Message contract

Every wire message contains:

- `protocol`
- `version`
- `message_id`
- `unit_id`
- `round`
- `layer`
- `direction` (`down`, `horizontal`, `up`)
- `type`
- `payload`
- `parents`
- `provenance`
- `integrity`

Message IDs are content-addressed by the deterministic factory. SHA-256 is used for canonical integrity verification.

## 4. Kai Language

`kai-lang/0.1` is a deterministic text representation over `kai/0.2`. It exists for machine transport, debugging, developer inspection, and long-lived protocol fixtures. See `docs/KAI-LANGUAGE-SPEC.md`.

A `KaiChannel` establishes one global contract and keeps an independent dialogue state for each `unit_id`, allowing interleaved code-to-code conversations.

## 5. Units and state

A unit is the smallest independently adjudicable proposition/component. The nominal lifecycle is:

`RAW → PARSED → CLAIMED → EVIDENCED → TESTING → SUPPORTED|CONTESTED → REVISED → RETESTING → VERIFIED|REJECTED|UNRESOLVED`

`BLOCKED` may occur when a required prerequisite is unavailable.

## 6. Assurance

Promotion requires native Kai assurance plus the governing MASTER gate. The native gates are:

1. decomposition integrity
2. horizontal consistency
3. vertical consistency
4. test validity
5. reconstruction preservation
6. provenance completeness
7. criterion satisfaction

Then:

8. `master_governance`

The governing gate remains engine-level so wire compatibility is preserved.

## 7. Secrets and authority

Confidentiality is not provided by “semi-encrypted” formatting. Kai makes the boundary explicit:

- SHA-256 — integrity/content identity.
- Ed25519 — optional authority signatures and public verification.
- AES-256-GCM — confidential secret envelopes.

Master decryption keys are generated and stored outside the repository. The source distribution must not contain production keys.

See `docs/SECURITY-MODEL.md`.

## 8. Verdicts

- `ACCEPTED` — declared criterion satisfied under declared scope.
- `REJECTED` — disqualifying condition failed.
- `UNRESOLVED` — evidence/tests insufficient for safe adjudication.
- `BLOCKED` — required prerequisite missing.

`VERIFIED` is scope-qualified assurance, not absolute truth.

## 9. MASTER relation

MASTER remains the process-governor control plane:

`UNDERSTAND → FIRST_PRINCIPLES → EXPERT → SKEPTIC → ALTERNATIVES → COMPARE → VERIFY → DECIDE → OPTIMIZE → EXECUTE → DEBUG → REALITY_CHECK → OUTPUT → CONTINUOUS_IMPROVEMENT`

## 10. Merge and convergence

Where domain semantics permit concurrent safe merge, merge operations must explicitly declare their laws. Kai does not assume all knowledge artifacts are CRDT-compatible. Unsupported or conflicting merges are rejected rather than silently resolved.
