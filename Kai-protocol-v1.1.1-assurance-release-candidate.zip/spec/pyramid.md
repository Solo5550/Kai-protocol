# Two-pyramid architecture

```text
                    ORIGINAL KNOWLEDGE / SYSTEM
                              ▲
                              │
                     [L0 CONTRACT / OBS]
                          /       \\
                         /         \\
                [L1 / L2 DECOMPOSED UNITS]
                     /      |       \\
                    /       |        \\
             [L3..L8 TESTED RELATIONS]
                    \\       |       /
                     \\      |      /
                      [L9..L11 SYNTHESIS]
                             │
                             ▼
                       ANALYSIS BASE
                             │
                             ▼
                      RECONSTRUCTION BASE
                             │
                    [R1..R10 REBUILD]
                             │
                             ▼
                  RECONSTRUCTED WHOLE
                             │
                             ▼
                 COMPARE AGAINST ORIGINAL
                             │
                PASS / FAIL / UNRESOLVED
```

The forward pyramid is decomposition and validation. The inverted pyramid is reconstruction and falsification.

A high-quality result must survive both directions.
