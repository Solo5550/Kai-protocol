# State machine

| From | Event | To | Preconditions |
|---|---|---|---|
| RAW | parse | PARSED | structural payload valid |
| PARSED | claim | CLAIMED | claim present |
| CLAIMED | evidence | EVIDENCED | at least one evidence item |
| EVIDENCED | test | TESTING | test defined |
| TESTING | result-pass | SUPPORTED | result is pass |
| TESTING | result-fail | CONTESTED | result is fail |
| CONTESTED | revise | REVISED | revision references parent |
| REVISED | retest | RETESTING | new test references revision |
| RETESTING | result-pass | VERIFIED | retest passes and gates pass |
| RETESTING | result-fail | REJECTED | disqualifying failure |
| any testing state | unresolved | UNRESOLVED | evidence or test cannot resolve |
| any active state | block | BLOCKED | prerequisite unavailable |
