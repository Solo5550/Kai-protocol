# MASTER Governance Layer — v1.0

MASTER is integrated into Kai as a **governing control layer**, not as a prose checklist and not as a replacement for domain reasoning.

Its purpose is to control progression through the Kai lifecycle and to make hidden assumptions, skipped reasoning, unverified conclusions, and operational gaps visible.

## Governing position

```text
CONTRACT
   ↓
MASTER PREFLIGHT
   ↓
FORWARD PYRAMID / KAI DIALOGUE
   ↓
ASSURANCE GATES
   ↓
MASTER POSTFLIGHT
   ↓
RECONSTRUCTION / REALITY CHECK
   ↓
MASTER PROMOTION GATE
   ↓
OUTPUT / REOPEN
```

MASTER therefore controls **promotion**, while the existing Kai protocol controls the evidence-bearing dialogue.

## Fourteen stages

`UNDERSTAND → FIRST_PRINCIPLES → EXPERT → SKEPTIC → ALTERNATIVES → COMPARE → VERIFY → DECIDE → OPTIMIZE → EXECUTE → DEBUG → REALITY_CHECK → OUTPUT → CONTINUOUS_IMPROVEMENT`

Each stage emits a typed result: `PASS`, `FAIL`, `BLOCKED`, `UNRESOLVED`, or explicit `NOT_APPLICABLE`.

`NOT_APPLICABLE` is allowed only when the contract makes the stage genuinely irrelevant. It is not a synonym for "forgotten".

## Integration law

The implementation applies two fail-closed checkpoints:

1. **Preflight**: execution cannot start when the contract is missing a required criterion declaration or contains structurally invalid inputs.
2. **Postflight**: the final Kai assurance result is not promotable unless the MASTER review also passes.

The governing gate is exported into the synthesis unit as `master_governance`, while preserving the original seven assurance gates. This keeps the wire identity `kai/0.2` compatible while strengthening promotion semantics at the engine level.

## Separation of concerns

MASTER is not a hidden second "truth engine". It evaluates the **quality and completeness of the reasoning process** and the evidence required to advance. Domain-specific expert reasoning remains an adapter concern.

The SKEPTIC stage is a process obligation: adverse findings are first-class artifacts. A finding does not become a failure merely because it exists; a critical finding becomes promotion-blocking when it remains unresolved.

## Decision stages

`ALTERNATIVES` and `COMPARE` are conditionally applicable. They become required when a decision-options set is declared or when a strict policy explicitly requires alternatives. This prevents the framework from manufacturing fake choices for problems that are purely verification problems.

## Score semantics

MASTER scores are **process-assurance indicators**, not probabilities and not truth values. They are weighted summaries of stage status. Promotion is never based on a score threshold: it is gate based.

## Improvement loop

Failures, bottlenecks, gaps, drift and skeptical findings generate deterministic improvement actions. The expected operational loop is:

`FAIL → CENSUS → ROOT_CAUSE → SOLUTION → IMPLEMENT → ASSURE → RECONSTRUCT → REOPEN/PROMOTE`
