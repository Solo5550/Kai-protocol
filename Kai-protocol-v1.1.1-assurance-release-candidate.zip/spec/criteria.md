# Assurance criteria

## Native Kai criteria

C1 — decomposition integrity: all child units required by the decomposition contract exist, are linked to the intended parent, and preserve required semantics.

C2 — horizontal consistency: sibling units do not contain unresolved contradictions that invalidate the parent synthesis.

C3 — vertical consistency: parent/child claims and derivations are mutually coherent under declared transformations.

C4 — test validity: tests have explicit inputs/preconditions, expected properties, observed outcomes, and executor metadata.

C5 — reconstruction preservation: the inverted pyramid reconstructs the original structure within the declared preservation metric.

C6 — provenance completeness: substantive artifacts have sufficient provenance to replay the derivation within scope.

C7 — criterion satisfaction: the final claim satisfies the domain-specific criterion declared in the contract.

## Governing MASTER criterion

C8 — master governance: MASTER preflight passed before execution, postflight passed after execution, all required MASTER stages are `PASS`, and no unresolved critical MASTER finding remains.

## Default promotion rule

A governed synthesis unit is promotable only when C1–C8 are `PASS` and its final state is `VERIFIED`.

For legacy/non-governed units, the original C1–C7 set remains evaluable for backward compatibility.
