# Kai — Proof Layer for Machines

> **Machines that cannot prove must not act.**

Kai is the **trust layer** between agents and the real world: governed runtime, portable proof receipts, fail-closed gate.

```python
from kai import KaiProductRuntime, KaiGate

rt = KaiProductRuntime(data_dir="./.kai")
rt.install("math.double", lambda p: {"value": p["value"] * 2})
proven = rt.act(capability_id="math.double", objective="double", input_data={"value": 21}, expected_outcome={"value": 42})
KaiGate().require(proven.receipt)  # no proof → no act
```

Product docs: [PRODUCT.md](PRODUCT.md) · Version **1.0.0**

---

# Kai Protocol — by Solo

Kai is a deterministic protocol and language for **machine-to-machine discourse, knowledge exchange, evidence, adversarial testing, provenance, bidirectional reconstruction, and governed promotion**.

A Kai participant does not need to speak natural language. It exchanges typed speech acts:

`CONTRACT → OBSERVATION → CLAIM → EVIDENCE → OBJECTION → COUNTEREXAMPLE → TEST → RESULT → REVISION → REBUTTAL → RECONSTRUCTION → VERDICT`

## What was added in v0.4

### 1. Kai Language v0.1

`kai-lang/0.1` is a stable text representation on top of the existing `kai/0.2` wire message contract. It uses a fixed field order and canonical JSON encoded as base64url inside the frame.

```text
KAI-LANG/0.1
TYPE CLAIM
MSG <content-address>
UNIT u1
ROUND 1
LAYER 1
DIRECTION horizontal
PARENTS -
PAYLOAD <base64url(canonical-json)>
PROVENANCE <base64url(canonical-json)>
INTEGRITY sha256:<digest>
END
```

### 2. Code-to-code dialogue

`KaiChannel` creates one global contract and independent unit-level dialogue state, so several programs can argue/test/revise in an interleaved stream without relying on a human transcript.

### 3. Confidentiality and authority

Kai does **not** pretend that encoding is encryption.

- SHA-256: message integrity and content identity.
- Ed25519: optional authority signatures with public verification.
- AES-256-GCM: encrypted secret envelopes.
- Master decryption keys are generated locally and are **never stored in the repository**.

The secret layer is explicit: confidential knowledge goes into a `Kai Secret Envelope`; ordinary protocol messages remain inspectable.

### 4. High-volume transport and retention

`KAI-BIN/1` is the compact machine-to-machine transport path. `MessageJournal` stores authenticated frames on disk with batched append, lazy replay, and checkpoint-assisted reopen. The journal is an explicit high-volume retention backend; it is not silently substituted for every in-memory session.

Run the independent lab with:

```bash
python -m pip install ".[performance]"
PYTHONPATH=src python -m performance_lab.run --stage message-create-throughput --messages 1000000
PYTHONPATH=src python -m performance_lab.run --stage compact-stream-throughput --compact-messages 1000000 --batch-size 50000
PYTHONPATH=src python -m performance_lab.run --stage journal-checkpoint-recovery --checkpoint-messages 250000
PYTHONPATH=src python -m performance_lab.run --stage stability-throughput --stability-messages 100000 --stability-repeats 5
```

See `docs/KAI-PERFORMANCE-LAB.md` and `docs/FINAL-PERFORMANCE-ASSURANCE.md`.

### 5. Determinism

Default message IDs are content-addressed, not random UUIDs. Repeating the same message creation inputs with the same actor/provenance yields the same ID and digest.

## Governing layer: MASTER v1.0

The `/MASTER` methodology remains the control plane above Kai execution:

`MASTER PREFLIGHT → KAI EXECUTION → NATIVE ASSURANCE → MASTER POSTFLIGHT → MASTER GOVERNANCE GATE → PROMOTE/REJECT/BLOCK/UNRESOLVED`

MASTER remains a process governor. It does not manufacture domain truth.

## Assurance architecture

```text
MASTER
  ↓
KAI CONTRACT
  ↓
FORWARD PYRAMID
  ↓
CODE DIALOGUE
  ├─ CLAIM
  ├─ EVIDENCE
  ├─ OBJECTION
  ├─ TEST
  ├─ RESULT
  └─ REVISION
  ↓
NATIVE ASSURANCE GATES
  ↓
RECONSTRUCTION / REVERSE CHECK
  ↓
MASTER POSTFLIGHT
  ↓
PROMOTE / REJECT / BLOCK / UNRESOLVED
```

## Installation

Python 3.10+ and the `cryptography` package are required.

```bash
python -m pip install .
```

For offline/local development where the build dependencies are already installed:

```bash
python -m pip install --no-build-isolation .
```

## Commands

```bash
kai validate examples/minimal_session.json
kai run examples/minimal_session.json

kai keygen kai.master
kai authority-keygen authority.private authority.public
kai secret-seal --key kai.master --in secrets.txt --out secrets.kai.json
kai secret-open --key kai.master --in secrets.kai.json --out secrets.recovered.txt

kai encode message.json message.kai
kai decode message.kai
```

## Testing

The repository contains unit, integration, adversarial, mutation, language, channel, security, CLI, and reproducibility checks. The documented final sequence is:

`COMPILE → UNIT → CONTRACT → INTEGRATION → REVERSE → ADVERSARIAL → MUTATION → FAILURE-INJECTION → SECURITY → REPRODUCIBILITY → PERFORMANCE → PACKAGE → REGRESSION`

See `docs/KAI-LANGUAGE-SPEC.md`, `docs/SECURITY-MODEL.md`, and `docs/MASTER-INTEGRATION-AUDIT.md`.

## Limits

Kai is a reference implementation of the architecture. It does not claim that arbitrary historical or empirical propositions become mathematical proofs. “Verified” means that a declared criterion passed under the declared scope, assumptions, artifacts, and tests.

It also does not claim global naming uniqueness; the repository intentionally identifies itself as **Kai Protocol — by Solo** because unrelated public projects use the word “Kai”.

## Kai Protocol SKILL — v0.5.0

The new `kai.skill` layer turns Kai into a governed capability lifecycle: absorb → decompose → gap analysis → specialize → propose child → MASTER governance → sandbox → build/test/repair/rebuild → evidence → promotion.

Run the reference:

```bash
kai skill-run examples/skill_pipeline.json
```

L5 autonomous execution and L6 structural/root change are fail-closed by default. The protocol core does not execute arbitrary child source code; production deployments should add OS/container/VM isolation for untrusted handlers.

## v1.1.1 — Assurance Control Plane

The current release candidate adds a deterministic assurance control plane, process-lifecycle cleanup, differential validation against the semantic schema oracle, targeted fuzzing, measured performance gating, CycloneDX SBOM generation, and local SLSA-shaped provenance. Production qualification remains an evidence gate requiring independent/external attestations.

## v0.6.1 — Global Red-Team Maintenance

The `kai.maintenance` control plane provides an independent maintenance and requalification protocol. It does not add a runtime execution capability or bypass runtime authorization. The protocol implements the closed loop `INSPECT → TEST → BREAK → MEASURE → RECONSTRUCT → DIAGNOSE → ROOT CAUSE → REDESIGN → REPAIR → REBUILD → RETEST → REQUALIFY → OBSERVE → CERTIFY`, with explicit `PASS`, `FAIL`, `BLOCKED`, `UNRESOLVED`, and `N/A` semantics.

Two v0.7.0 defects were found and repaired by the red-team pass: capability invocation could be supplied with a handler different from the qualified registry implementation, and shared `RuntimeStore` read paths lacked the store lock under concurrency. Both repairs have permanent regression tests.

The current environment qualifies the local reference runtime conditionally; live canary/SLO, multi-node failover/chaos, external supply-chain attestation, and independent high-risk qualification remain blocked until the corresponding infrastructure is connected.

## v0.7.0 — Worldwide Execution Runtime

The v0.6 reference implementation adds one canonical governed execution path:

`INTENT → CONTRACT → EVIDENCE → PLAN → CAPABILITY → ADMISSION → PLACEMENT → EXECUTION → OBSERVATION → VERIFICATION → PROOF → PROVENANCE → PERSISTENCE → FAILURE/RECOVERY → EXPERIENCE → CALIBRATION → NEXT DECISION`

It includes a minimal execution kernel, authoritative state transitions, process-isolated execution, SQLite durable state, capability qualification/resolution, signed policy primitives, evidence gates, artifact lineage, proof ledger, effect/idempotency semantics, regional placement and sovereignty checks, safe-mode/federation primitives, experience reuse gates, calibration, operational projections, conformance/fitness checks, and release qualification.

The implementation is a **reference runtime**, not production certification. The process boundary is OS-level process isolation rather than a hostile-code sandbox/VM, and multi-node worldwide production evidence still requires deployment-specific validation.

See `docs/RUNTIME-IMPLEMENTATION-REPORT.md` for the phase-by-phase implementation and test evidence.

## v0.7.0 — P0 Hard Runtime Execution Fabric

The 0.7 line moves the standard `KaiRuntime.execute()` path from generic OS-process execution to a mandatory Linux hard-isolation boundary. A governed execution now follows:

`Capability → Signed Manifest → Policy Evaluation → Isolated Worker → Resource Quota → Permission Boundary → Execution → Attested Result`

The isolation boundary uses Linux user/mount/network/PID namespaces, a chroot root filesystem with read-only runtime mounts, writable temporary/work directories, resource limits, a parent-death guard, and seccomp denial of process creation unless `process.spawn` is explicitly part of the capability permission set. Network egress is intentionally unavailable until a managed proxy boundary is implemented.

L5 and L6 autonomous execution remain blocked.

The runtime also includes a real multi-process TCP node model with global→region→node→cell→capability identity, leases, heartbeats, failure detection, durable idempotency/replay protection, restart/recovery, attestor identity persistence, storage corruption detection, backup/restore, and distributed execution provenance.

The P0 chaos suite exercises real process/storage failures plus deterministic TCP transport faults: node kill, network partition, packet loss, delay, duplicate delivery, clock skew, dependency disappearance, and partial completion. In the current CI/container environment, kernel-level `tc/netem` injection is unavailable because `CAP_NET_ADMIN` is not present; therefore those network cases are explicitly classified as transport-layer fault injection rather than OS-level netem certification.

Full regression status for the current tree: **172/172 PASS**. P0 targeted validation covers the hard isolation, runtime execution path, multi-node, recovery, and chaos suites.

## v0.8.1 Semantic Conformance Stack

The v0.8 line now provides a transport-independent semantic protocol for trustworthy code-to-code discourse. Canonical frames are `KAI-LANG/0.8` with schema id `kai/semantic/0.8`. The reference endpoint can consume and emit those frames through `KaiEndpoint.handle_frame()`.

The repository ships language-neutral golden vectors plus an independent Go verifier. The conformance boundary covers deterministic identity, integrity, schema closure, causality/replay safety, authority/tenant enforcement, effect idempotency, and round-trip reconstruction.

See `docs/KAI-PROTOCOL-V0.8-CONFORMANCE.md` and `docs/maintenance/evidence/v08/FINAL-REQUALIFICATION-V0.8.1.md`.
