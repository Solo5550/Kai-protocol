# Kai — Proof Layer for Machines

**Machines that cannot prove must not act.**

Kai is not a chatbot framework and not a model. It is the **trust layer** between non-deterministic agents and the real world.

## Product surface (three verbs)

| Layer | Role |
|-------|------|
| **Runtime** | Governed execute under contract, policy, evidence, isolation |
| **Proof** | Portable receipt (`ProofReceipt`) — independently verifiable |
| **Gate** | Fail-closed admission: no valid proof → no side effect |

## 30-second use

```python
from kai import KaiProductRuntime, KaiGate, GateDenial

rt = KaiProductRuntime(data_dir="./.kai")
rt.install("payments.transfer", transfer_handler)

proven = rt.act(
    capability_id="payments.transfer",
    objective="transfer",
    input_data={"amount": 100, "to": "acct_2"},
)

# External system / bank core / plant PLC:
gate = KaiGate()
gate.require(proven.receipt)   # raises GateDenial if invalid
# only then commit the real-world side effect
```

## Competitive position

- **MCP / A2A** move messages and tools.
- **Kai** answers: *did the machine act within contract, with evidence, under isolation — and can anyone re-verify that?*

Integrate as a layer **above** tool protocols, not as a replacement.

## Invariants

1. No proof → no act (`KaiGate`)
2. Proof integrity is content-addressed and independently checkable
3. Governed path: contract → evidence → execute → verify → decide → receipt
4. External production gates stay BLOCKED until live evidence exists (no false certification)

## Version

`1.1.1` — product surface stable for integration and release-assurance hardening.


## v1.1.1 Security remediation + SSDF absorption + assurance control plane

- ProofReceipt: Ed25519 signature, nonce, expiry, tenant/actor/audience
- KaiGate: trust store, single-use replay shield, contract allowlist, ACCEPTED-only
- kai.ssdf: SSDF-One v1.3.0 evaluator, profiles, DSSE connector, runtime guard
