## 1.1.1 — Assurance Control Plane + Release Hardening

- Introduced a deterministic, fail-closed assurance control plane with explicit stage ordering and root-cause reroute semantics.
- Unified release version metadata at `1.1.1`.
- Hardened process lifecycle cleanup with deterministic child reaping and explicit executor close/context-manager support.
- Added differential validation against the JSON Schema oracle and deterministic targeted fuzzing.
- Added measured performance targets, CycloneDX SBOM generation, and unsigned SLSA-shaped local provenance generation.
- Added release assurance operating model, architectural decision, solution matrix, and external P2 gate contract.
- Preserved the existing runtime/protocol contracts instead of performing a blind repository-wide rewrite.

## 1.0.0 — Proof Layer for Machines (Product Surface)

**Invariant:** Machines that cannot prove must not act.

### Product
- `kai.product` — Runtime · Proof · Gate
- `KaiProductRuntime.act()` → `ProvenAction` + portable `ProofReceipt`
- `KaiGate` fail-closed admission / `guard()` for side effects
- Independent `verify_receipt()` (content-addressed integrity)

### Positioning
Not a chatbot SDK. Trust layer above tool/agent protocols (MCP/A2A complementary).

### Qualification
Local battery PASS; external production gates remain BLOCKED (no false certification).

## 1.0.0rc1+maint — Red-Team Maintenance Requalification (KAI-RC-0006)

### Protocol executed
Optional Global Red-Team Maintenance closed-loop:
INSPECT → TEST → BREAK → MEASURE → ROOT CAUSE → REDESIGN → REPAIR → REBUILD → RETEST → REQUALIFY

### Finding
- **KAI-RC-0006**: ProcessExecutor defaulted to `spawn`, causing non-deterministic
  concurrent worker exit-code-1 under ThreadPool submission. CONCURRENCY gate FAIL.

### Radical repair
- ProcessExecutor: POSIX default `fork`; explicit `spawn` only when requested.
- Concurrency probe measures store/kernel invariants under stable start method.
- Evidence: `docs/maintenance/ROOT-CAUSE-0006.md`
- Requalification: CONDITIONALLY_QUALIFIED (all local applicable gates PASS;
  external canary/SLO/failover/chaos/attestation/independent-qualifier remain BLOCKED)

### No false certification
`production_certification` remains false. External gates are BLOCKED, not PASS.

## 1.0.0rc1 — Worldwide Execution Runtime Normative Acceptance

### Mandate
Implemented the GLOBAL WORLDWIDE EXECUTION RUNTIME normative architecture specification as an evidence-bound acceptance gate over the existing Kai runtime — without inventing parallel systems.

### Root principle applied
**DO NOT BUILD MORE PIECES. MAKE THE EXISTING PIECES BECOME ONE EXECUTION SYSTEM.**

### What was added
- `kai.runtime.worldwide` — automated evaluation of the 30 FINAL ARCHITECTURE ACCEPTANCE CRITERIA (Section 118) + Golden Path E2E
- `production_qualification_gate()` — evidence-bound report; `production_certification=false` until external gates clear
- Golden Path live exercise: Intent→Contract→Evidence→Plan→Capability→Admit→Execute→Observe→Verify→Prove→Persist→Decide

### Blind local result
- 31/31 criteria PASS (30 MUST/SHOULD + Golden Path)
- `all_must_passed=true`
- `golden_path_executed=true`
- Status: **CONDITIONALLY_QUALIFIED**
- Production certification remains false (external gates blocked by design)

### Cumulative contents
Includes prior 0.8.2 packaging completeness, 0.9.0 multi-language semantic SDK (Python/Go/Rust peer oracles), and this worldwide acceptance gate.

## 0.9.0 — Multi-Language Semantic SDK Contract (Radical)

### Root cause closed: KAI-RC-0005 Language asymmetry
- Symptom: Go existed only as an independent digest verifier; Rust did not exist; the semantic contract was Python-centric.
- First invalid state: `SEMANTIC_CONTRACT ⊄ MULTI_LANG_SDK`
- Root: Conformance stack treated non-Python languages as external checkers rather than peer implementations of the same contract and oracle.
- Radical repair: Introduced `sdk/` with a normative multi-language contract (`sdk/contract/ORACLE.md` + shared vectors + schema). Python, Go, and pure-std Rust are now peer implementations that must produce identical `message_id` and `integrity.digest` under a blind cross-language oracle.

### What is now true
- Shared golden vectors under `sdk/contract/vectors/`
- Go: full semantic package (`sdk/go/kai`) — closed-schema, identity, integrity, round-trip, oracle CLI
- Rust: pure-std peer (`sdk/rust`) — zero external crates, offline build, same digests
- Python: peer oracle wrapper (`sdk/python/oracle.py`)
- Blind gate: `sdk/run_multilang_oracle.py` — fails closed on any cross-language digest divergence

### Blind evaluation result
- Python: PASS (2/2)
- Go: PASS (2/2) — digests match Python
- Rust: PASS (2/2) — digests match Python and Go
- Cross-check: **PASSED** (no divergence)

### Cumulative guarantee
Release trees from 0.9.0 include the full multi-language SDK surface as a first-class part of the project A-to-Z fusion.

## 0.8.2 — Cumulative Completeness & Packaging Integrity (Radical, No-Patch)

### Root-cause findings closed
- **KAI-RC-0004 Packaging incompleteness**: Release and source trees omitted `examples/` (and package-data paths were not enforced). Tests, README, CONTRIBUTING and maintenance baseline referenced missing assets → CLI tests failed, user walkthroughs broken, baseline digests incomplete.
  - First invalid state: `REFERENCED_ASSET ∉ RELEASE_TREE`
  - Root: release process lacked a closed-loop completeness oracle; historical evidence and package-data declarations were not verified against the actual tree.
  - Radical repair: restored full examples (minimal_session.json + skill_pipeline.json), added `tools/completeness_oracle.py` that fails closed on any live referenced asset missing from the tree. Oracle is now part of the release gate.
- **Test-system vibration**: Monolithic pytest retained child-process state from hard-isolation / multiprocessing tests. Isolated per-file runs remain the authoritative regression method (already documented). Completeness + example restoration removes one class of false failures.

### Cumulative guarantee
From this version forward every release tree is required to be a complete A-to-Z fusion of:
src + tests + examples + spec (under src/kai/protocol/spec) + docs + tools + evidence + pyproject + manifests.
No partial or "release-only" truncation is accepted.

### Verification
- completeness_oracle: PASS
- CLI example path: PASS
- Isolated regression remains the certification oracle.

# Changelog

## v0.8.1 — v0.8 Conformance Hardening

- Added the normative `kai/semantic/0.8` schema registry and machine-readable JSON Schema companion.
- Added `SemanticMessage.from_dict()` and canonical frame handling via `KaiEndpoint.handle_frame()`.
- Added strict closed-schema validation, bounds, non-finite-number rejection, exact tenant scoping, and fail-closed custom authorization.
- Added Python golden-vector conformance and an independent Go verifier/test suite.
- Packaged schema and vectors inside the Python wheel.
- Requalified the repository with 192/192 isolated regression tests passing.
- Production certification remains blocked on external governance, independent qualification, live rollout/SLO, failover/chaos, and external supply-chain evidence.

# Changelog

## 0.7.0 - 2026-10-01

- Implemented P0 Hard Execution Isolation on the standard KaiRuntime execution path using Linux user/mount/network/PID namespaces, chroot, resource limits, parent-death termination, and seccomp process-spawn denial.
- Added signed capability manifests bound to real contract identity, least-privilege permission boundaries, and signed attested execution results.
- Added real multi-process TCP nodes with registration, leases, heartbeats, failure detection, durable idempotency, state reconciliation, node restart, durable attestor identity, and storage backup/restore.
- Added deterministic chaos/recovery coverage for node kill, network partition, packet loss, delay, duplicate delivery, storage corruption, clock skew, dependency disappearance, and partial completion.
- L5/L6 autonomous execution remains blocked.
- Full regression: 172/172 PASS before final manifest/attestation hardening; P0 targeted suite revalidated after hardening.

## 0.6.1 - 2026-10-01

- Added Optional Global Red-Team Maintenance, Root-Cause Repair, Rebuild & Requalification Protocol (`maintenance/1.0`).
- Added baseline, archaeology, adversarial, differential, performance, recovery, provenance, security, concurrency, resource-leak and maintainability gates.
- Added 47-section normative coverage matrix, CAPA, blast-radius, waiver, SLO/progressive deployment policy models, frozen test oracles, and conservative qualification/closure rules.
- Repaired two v0.6.0 root causes found by red-team inspection: capability handler substitution and unprotected RuntimeStore read paths.
- Promoted both fixes to permanent regression shields.
- Runtime wire/contract compatibility remains `runtime/0.6`; package release is `0.6.1`.

# Kai Protocol Changelog

## 0.4.2

- Added independent Kai Performance Lab with stage isolation and million-message measurements.
- Added KAI-BIN/1 compact and streaming transport.
- Added disk-backed MessageJournal with batched append, lazy replay, and atomic checkpoint recovery.
- Reduced derived dialogue memory by disabling redundant evidence/test history in channel indexes.
- Added transport-record slots, repeated stability/CI performance gates, and root-cause census artifacts.
- Preserved KAI-LANG/0.1 and kai/0.2 semantic compatibility.

## 0.4.1

- Added independent Performance Lab with million-message throughput, latency, memory, codec, parallelism, and failure-injection stages.
- Added KAI-BIN/1 compact binary transport and streaming/batch helpers.
- Reduced derived dialogue memory by disabling full message-id history in channel indexes while retaining authoritative session logs.
- Added slots to transport record dataclasses.
- Added CI performance workflow and root-cause analysis report generation.

# Changelog

## 0.4.1

- Performance hardening of `KaiSession` language projection updates.
- Replaced repeated full `KaiChannel` replay on every message mutation with incremental ingestion.
- Added fail-safe projection rebuild when incremental ingestion unexpectedly fails.
- Preserved authoritative append-only message log semantics.
- Measured ~18.4% improvement on the representative session-mutation benchmark versus the pre-optimization v0.4 implementation.
- Regression suite remains 38/38 PASS.

## 0.4.0

- Added **Kai Language v0.1** text encoding above the stable `kai/0.2` wire identity.
- Added deterministic per-unit dialogue semantics and `KaiChannel` for interleaved code-to-code discussions.
- Added semantic payload validation for typed speech acts.
- Added authenticated **Kai Secret Envelope** using AES-256-GCM with random nonces.
- Added operator-local 256-bit master-key generation with restrictive filesystem permissions on POSIX.
- Added separate Ed25519 authority key generation, signing, verification, and public-key verification workflow.
- Changed default message identifiers from random UUIDs to deterministic content-addressed IDs.
- Added language, channel, and security test suites.
- Kept promotion fail-closed under native Kai gates and MASTER governance.

## 0.3.0

- Integrated MASTER as the governing control plane.

## 0.5.0 — Kai Protocol SKILL

- Added executable `kai.skill` capability layer.
- Added forensic cortex, reasoning matrix, solution engine, execution engine, evolution cortex, reproduction engine.
- Added capability gaps, child-skill contracts, proposal IDs, event history, and lifecycle L0–L6.
- Added fail-closed sandbox and explicit L5/L6 governance boundaries.
- Integrated `/MASTER` through `SkillGovernance` promotion review.
- Added `kai skill-run <json>` reference runner and `examples/skill_pipeline.json`.
- Added SKILL specifications, impact review, and MASTER mapping documentation.
- Extended tests for deterministic proposals, sandbox enforcement, reproduction gates, lifecycle transitions, and full governed pipeline.
## 1.1.0 — Signed Proof + SSDF-One absorption

### Radical gap closure
- G8/G13: Ed25519 signed receipts; unsigned mint impossible by default
- G2/G14: single-use Gate registry (replay blocked)
- G3: expiry enforced
- G4: decision enum ACCEPTED/REJECTED/DENIED only
- G7: tenant_id, actor_id, audience, nonce, expires_at
- G10: optional allowed_contracts on Gate

### SSDF-One v1.3.0
Absorbed under `kai.ssdf` (ssdfx engine, catalog, profiles, DSSE, runtime_guard).
Evaluate/verify plane only — no alternate execution path.

