# Contributing to Kai Protocol

## Change discipline

1. Preserve the protocol identity and version semantics unless the change intentionally increments the wire protocol.
2. Treat MASTER as a governing layer, not a documentation checklist.
3. Add or update tests before claiming a behavior is implemented.
4. Do not weaken a gate to make an example pass.
5. Keep deterministic behavior explicit; avoid hidden global state and random ordering.
6. New message fields must be reflected in the protocol schema and validator.
7. Changes to state transitions require updates to `spec/state-machine.md` and tests.
8. New assurance gates require a documented criterion and fail-closed behavior.
9. Any new top-level execution path must go through `AssurancePipeline`; bypassing MASTER requires an explicit low-level/internal API designation.
10. Keep `MASTER-INTEGRATION-AUDIT.md` current when governance semantics change.

## Local verification

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
python -m kai validate examples/minimal_session.json
python -m kai run examples/minimal_session.json
```

A clean environment should be able to install the package and run the complete suite without relying on `PYTHONPATH`.
