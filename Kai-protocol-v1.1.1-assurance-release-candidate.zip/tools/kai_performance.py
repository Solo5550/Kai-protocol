#!/usr/bin/env python3
"""Measured performance gate using the recorded local baseline."""
from __future__ import annotations

import json
import statistics
import time
from pathlib import Path

from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction, MessageType

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "docs/engineering-assurance/PERFORMANCE-COMPARISON-2026-10-03.json"
TARGETS = ROOT / "spec/assurance/performance-targets.json"


def measure(runs: int = 7, messages: int = 20000) -> dict:
    factory = MessageFactory(actor="perf-gate")
    elapsed_ms = []
    checksums = []
    for r in range(runs):
        start = time.perf_counter()
        digest = 0
        for i in range(messages):
            m = factory.create(unit_id=f"u-{r}-{i}", round=1, layer=1, direction=Direction.DOWN,
                               type=MessageType.OBSERVATION, payload={"x": i, "run": r})
            digest ^= int(m.integrity["digest"][:16], 16)
        elapsed = time.perf_counter() - start
        elapsed_ms.append(elapsed * 1000.0)
        checksums.append(digest)
    seconds = [x / 1000.0 for x in elapsed_ms]
    throughputs = [messages / s for s in seconds]
    sorted_ms = sorted(elapsed_ms)
    def pct(p: float) -> float:
        idx = (len(sorted_ms) - 1) * p
        lo, hi = int(idx), min(int(idx) + 1, len(sorted_ms) - 1)
        frac = idx - lo
        return sorted_ms[lo] * (1 - frac) + sorted_ms[hi] * frac
    baseline = json.loads(BASELINE.read_text())
    targets = json.loads(TARGETS.read_text())
    baseline_mean = float(baseline["candidate_vs_original_mean_throughput_delta_pct"])
    # Candidate historical mean is stored explicitly under candidate.
    historical_candidate = float(baseline["candidate"]["mean_throughput_msg_s"])
    ratio = statistics.mean(throughputs) / historical_candidate if historical_candidate else 0.0
    return {
        "runs": runs,
        "messages_per_run": messages,
        "mean_msg_s": statistics.mean(throughputs),
        "stdev_msg_s": statistics.pstdev(throughputs),
        "p50_ms": pct(0.50),
        "p95_ms": pct(0.95),
        "p99_ms": pct(0.99),
        "historical_candidate_msg_s": historical_candidate,
        "throughput_ratio_to_historical_candidate": ratio,
        "throughput_ratio_min": float(targets["comparison"]["throughput_ratio_min"]),
        "historical_baseline_delta_pct": baseline_mean,
        "checksums_consistent": len(set(checksums)) == runs,
        "status": "PASS" if ratio >= float(targets["comparison"]["throughput_ratio_min"]) and len(set(checksums)) == runs else "FAIL",
    }


if __name__ == "__main__":
    print(json.dumps(measure(), indent=2, sort_keys=True))
