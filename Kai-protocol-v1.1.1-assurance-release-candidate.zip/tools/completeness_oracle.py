#!/usr/bin/env python3
"""Radical completeness oracle for Kai Protocol cumulative releases.
Fails closed if any *live* referenced asset required by code, tests, CLI, or package-data is missing.
Historical evidence docs may reference past paths; they are reported as warnings only.
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Live critical patterns (must exist relative to ROOT or under src/)
CRITICAL = [
    (r"examples/[a-zA-Z0-9_\-./]+\.(json|py)", ROOT),
    (r"spec/0\.8/[a-zA-Z0-9_\-./]+", ROOT / "src" / "kai" / "protocol"),
]

def main() -> int:
    missing = []
    warnings = []
    scanned = 0
    for p in ROOT.rglob("*"):
        if "pycache" in str(p) or p.suffix not in {".md", ".py", ".json", ".toml", ".txt"}:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        scanned += 1
        rel = str(p.relative_to(ROOT))
        for pat, base in CRITICAL:
            for m in re.finditer(pat, text):
                ref = m.group(0)
                # normalize package-data style
                if ref.startswith("spec/0.8"):
                    target = base / ref
                else:
                    target = ROOT / ref
                if not target.exists():
                    item = (rel, ref, str(target))
                    if "docs/maintenance/evidence" in rel or "egg-info" in rel:
                        warnings.append(item)
                    else:
                        missing.append(item)
    if missing:
        print("COMPLETENESS_ORACLE: FAIL")
        for src, ref, tgt in sorted(set(missing)):
            print(f"  MISSING {ref}  (from {src}) -> expected {tgt}")
        return 1
    print(f"COMPLETENESS_ORACLE: PASS (scanned {scanned} files)")
    if warnings:
        print(f"  ({len(set(warnings))} historical/evidence warnings suppressed)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
