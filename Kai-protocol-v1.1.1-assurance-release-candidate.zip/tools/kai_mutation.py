#!/usr/bin/env python3
"""Small, deterministic mutation campaign over security-critical code paths.

This is intentionally selective: broad mutation suites are expensive. The selected
mutants correspond directly to recently remediated controls and must be killed by
regression tests.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

MUTANTS = [
    {
        "id": "MUT-SHELL-001",
        "file": "src/kai/ssdf/ssdfx.py",
        "needle": "argv, shell=False,",
        "replacement": "argv, shell=True,",
        "tests": ["tests/test_ssdf_command_execution.py"],
    },
    {
        "id": "MUT-EMPTY-001",
        "file": "src/kai/ssdf/ssdfx.py",
        "needle": 'if not argv:\n        raise ValueError("verification command must not be empty")',
        "replacement": 'if False:\n        raise ValueError("verification command must not be empty")',
        "tests": ["tests/test_ssdf_command_execution.py"],
    },
]


def run_mutant(m: dict) -> dict:
    with tempfile.TemporaryDirectory(prefix="kai-mutant-") as td:
        dst = Path(td) / "repo"
        shutil.copytree(ROOT, dst, ignore=shutil.ignore_patterns(".pytest_cache", "__pycache__", "*.egg-info", "build", "dist"))
        target = dst / m["file"]
        text = target.read_text(encoding="utf-8")
        if m["needle"] not in text:
            return {"id": m["id"], "status": "ERROR", "reason": "mutation_needle_not_found"}
        target.write_text(text.replace(m["needle"], m["replacement"], 1), encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = str(dst / "src")
        proc = subprocess.run([sys.executable, "-m", "pytest", "-q", *m["tests"]], cwd=dst, env=env, text=True, capture_output=True, timeout=120)
        killed = proc.returncode != 0
        return {"id": m["id"], "status": "KILLED" if killed else "SURVIVED", "returncode": proc.returncode, "output": (proc.stdout + proc.stderr)[-2500:]}


def main() -> None:
    results = [run_mutant(m) for m in MUTANTS]
    doc = {"mutants": results, "killed": sum(r["status"] == "KILLED" for r in results), "survived": sum(r["status"] == "SURVIVED" for r in results), "status": "PASS" if all(r["status"] == "KILLED" for r in results) else "FAIL"}
    out = ROOT / "docs/engineering-assurance/MUTATION-CAMPAIGN.json"
    out.write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n")
    print(json.dumps(doc, indent=2))
    raise SystemExit(0 if doc["status"] == "PASS" else 1)

if __name__ == "__main__":
    main()
