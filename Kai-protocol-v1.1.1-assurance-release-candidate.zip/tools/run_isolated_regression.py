from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "tests"
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))
TIMEOUT = 90


def run(target: str) -> dict[str, object]:
    cmd = [sys.executable, "-m", "pytest", "-q", target, "--disable-warnings"]
    try:
        p = subprocess.run(cmd, cwd=ROOT, env=ENV, text=True, capture_output=True, timeout=TIMEOUT)
    except subprocess.TimeoutExpired as exc:
        return {"target": target, "passed": False, "timeout": True, "returncode": None, "stdout": (exc.stdout or "")[-4000:], "stderr": (exc.stderr or "")[-4000:]}
    return {"target": target, "passed": p.returncode == 0, "timeout": False, "returncode": p.returncode, "stdout": p.stdout[-4000:], "stderr": p.stderr[-4000:]}


def main() -> int:
    files = sorted(TESTS.glob("test_*.py"))
    results: list[dict[str, object]] = []
    for path in files:
        target = str(path.relative_to(ROOT))
        if path.name == "test_runtime_p0_recovery.py":
            subprocess_text = subprocess.run(
                [sys.executable, "-m", "pytest", "--collect-only", "-q", target],
                cwd=ROOT, env=ENV, text=True, capture_output=True, timeout=TIMEOUT,
            ).stdout.splitlines()
            nodeids = [line.strip() for line in subprocess_text if line.strip().startswith("tests/test_runtime_p0_recovery.py::")]
            for nodeid in nodeids:
                results.append(run(nodeid))
        else:
            results.append(run(target))
        if not results[-1]["passed"]:
            break
    payload = {"passed": all(bool(r["passed"]) for r in results) and len(results) > 0, "runs": len(results), "results": results}
    out = ROOT / "docs" / "maintenance" / "evidence" / "v08" / "ISOLATED-REGRESSION-FINAL.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed":payload["passed"],"runs":payload["runs"]}, ensure_ascii=False, indent=2))
    if not payload["passed"]:
        for r in results:
            if not r["passed"]:
                print(f"FAILED: {r['target']}\n{r['stdout']}\n{r['stderr']}")
    return 0 if payload["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
