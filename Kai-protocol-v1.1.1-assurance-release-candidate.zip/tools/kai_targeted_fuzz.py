#!/usr/bin/env python3
"""Deterministic targeted fuzzing for semantic boundary handling."""
from __future__ import annotations

import json
import random
from copy import deepcopy
from typing import Any

from kai.protocol.interop import Causality, SemanticMessage, SpeechAct, validate_semantic_message

MAX_STRING = 4096

def seed_message(i: int) -> dict[str, Any]:
    return SemanticMessage.build(
        conversation_id=f"fuzz-{i}", sender="fuzzer", recipient="runtime", act=SpeechAct.EVENT,
        intent="probe", causality=Causality(f"fuzz-{i}", "corr", i), input={"i": i},
    ).to_dict()


def mutate(data: dict[str, Any], rng: random.Random, i: int) -> dict[str, Any]:
    out = deepcopy(data)
    mode = i % 12
    if mode == 0:
        out["intent"] = "x" * (MAX_STRING + 1)
    elif mode == 1:
        out["input"] = {"x": float("inf")}
    elif mode == 2:
        out["input"] = {str(j): j for j in range(10000)}
    elif mode == 3:
        out["extensions"] = {str(j): j for j in range(100)}
    elif mode == 4:
        out["causality"]["sequence"] = -1
    elif mode == 5:
        out["causality"]["parent_ids"] = ["bad"] * 129
    elif mode == 6:
        out["unknown"] = "field"
    elif mode == 7:
        out["integrity"]["digest"] = rng.choice(["", "0" * 64, "deadbeef"])
    elif mode == 8:
        out["act"] = None
    elif mode == 9:
        out["input"] = None
    elif mode == 10:
        out["provenance"] = {"blob": "x" * 100000}
    else:
        out["message_id"] = "x" * 64
    return out


def run(cases: int = 1000, seed: int = 20261003) -> dict[str, Any]:
    rng = random.Random(seed)
    crashes: list[str] = []
    rejected = 0
    accepted = 0
    for i in range(cases):
        try:
            errors = validate_semantic_message(mutate(seed_message(i), rng, i))
            if errors:
                rejected += 1
            else:
                accepted += 1
        except BaseException as exc:
            crashes.append(f"case={i}: {type(exc).__name__}: {exc}")
            if len(crashes) >= 20:
                break
    return {
        "seed": seed,
        "cases": cases,
        "rejected": rejected,
        "accepted": accepted,
        "crashes": crashes,
        "crash_count": len(crashes),
        "status": "PASS" if not crashes else "FAIL",
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
