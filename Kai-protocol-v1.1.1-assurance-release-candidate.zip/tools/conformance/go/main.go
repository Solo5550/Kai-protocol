package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"sort"
	"strings"
)

type Vector struct {
	Name    string                 `json:"name"`
	Message map[string]interface{} `json:"message"`
}

func canonical(v interface{}) ([]byte, error) {
	switch x := v.(type) {
	case nil:
		return []byte("null"), nil
	case bool:
		if x {
			return []byte("true"), nil
		}
		return []byte("false"), nil
	case string:
		return json.Marshal(x)
	case json.Number:
		return []byte(string(x)), nil
	case float64:
		return nil, fmt.Errorf("float64 encountered; decoder must use UseNumber")
	case []interface{}:
		parts := make([]string, 0, len(x))
		for _, item := range x {
			b, err := canonical(item)
			if err != nil {
				return nil, err
			}
			parts = append(parts, string(b))
		}
		return []byte("[" + strings.Join(parts, ",") + "]"), nil
	case map[string]interface{}:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		var b strings.Builder
		b.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				b.WriteByte(',')
			}
			kb, _ := json.Marshal(k)
			vb, err := canonical(x[k])
			if err != nil {
				return nil, err
			}
			b.Write(kb)
			b.WriteByte(':')
			b.Write(vb)
		}
		b.WriteByte('}')
		return []byte(b.String()), nil
	default:
		return nil, fmt.Errorf("unsupported JSON type %T", v)
	}
}

func cloneMap(m map[string]interface{}) map[string]interface{} {
	out := make(map[string]interface{}, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}

func digestForMessage(m map[string]interface{}, emptyID bool) (string, error) {
	body := cloneMap(m)
	delete(body, "integrity")
	if auth, ok := body["authority"].(map[string]interface{}); ok {
		a := cloneMap(auth)
		delete(a, "signature")
		body["authority"] = a
	}
	if emptyID {
		body["message_id"] = ""
	}
	b, err := canonical(body)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

func main() {
	path := flag.String("vector", "", "path to Kai v0.8 conformance vector")
	flag.Parse()
	if *path == "" {
		fmt.Fprintln(os.Stderr, "--vector is required")
		os.Exit(2)
	}
	data, err := os.ReadFile(*path)
	if err != nil {
		panic(err)
	}
	dec := json.NewDecoder(strings.NewReader(string(data)))
	dec.UseNumber()
	var v Vector
	if err := dec.Decode(&v); err != nil {
		panic(err)
	}
	expectedID, err := digestForMessage(v.Message, true)
	if err != nil {
		panic(err)
	}
	expectedIntegrity, err := digestForMessage(v.Message, false)
	if err != nil {
		panic(err)
	}
	actualID, _ := v.Message["message_id"].(string)
	actualIntegrity, _ := v.Message["integrity"].(map[string]interface{})
	actualDigest, _ := actualIntegrity["digest"].(string)
	pass := expectedID == actualID && expectedIntegrity == actualDigest
	out := map[string]interface{}{"name": v.Name, "passed": pass, "message_id": actualID, "expected_message_id": expectedID, "integrity_digest": actualDigest, "expected_integrity_digest": expectedIntegrity}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(out)
	if !pass {
		os.Exit(1)
	}
}
