module kai-conformance

go 1.22
