package main

import (
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"testing"
)

func TestGoldenVectors(t *testing.T) {
	root, err := filepath.Abs("../../../spec/kai/0.8/vectors")
	if err != nil {
		t.Fatal(err)
	}
	entries, err := os.ReadDir(root)
	if err != nil {
		t.Fatal(err)
	}
	for _, entry := range entries {
		if filepath.Ext(entry.Name()) != ".json" {
			continue
		}
		path := filepath.Join(root, entry.Name())
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		var v Vector
		dec := json.NewDecoder(bytesReader(data))
		dec.UseNumber()
		if err := dec.Decode(&v); err != nil {
			t.Fatalf("%s: %v", entry.Name(), err)
		}
		id, err := digestForMessage(v.Message, true)
		if err != nil {
			t.Fatalf("%s: %v", entry.Name(), err)
		}
		integ, err := digestForMessage(v.Message, false)
		if err != nil {
			t.Fatalf("%s: %v", entry.Name(), err)
		}
		gotID, _ := v.Message["message_id"].(string)
		gotIntegrityMap, _ := v.Message["integrity"].(map[string]interface{})
		gotIntegrity, _ := gotIntegrityMap["digest"].(string)
		if gotID != id || gotIntegrity != integ {
			t.Fatalf("%s: digest mismatch", entry.Name())
		}
	}
}

// tiny adapter keeps the test independent of deprecated ioutil helpers.
type byteReader struct {
	b []byte
	i int
}

func (r *byteReader) Read(p []byte) (int, error) {
	if r.i >= len(r.b) {
		return 0, io.EOF
	}
	n := copy(p, r.b[r.i:])
	r.i += n
	return n, nil
}
func bytesReader(b []byte) *byteReader { return &byteReader{b: b} }
