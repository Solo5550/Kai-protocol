from __future__ import annotations

import copy
import json
import math
from pathlib import Path
from kai.protocol.interop import Causality, CapabilityRef, SemanticMessage, SpeechAct, validate_semantic_message


def base_message() -> dict:
    cap = CapabilityRef("math.add", "1.0", contract_id="math", contract_version="1", side_effect_class="read_only")
    return SemanticMessage.build(
        conversation_id="mutation-c", sender="client", recipient="service", act=SpeechAct.REQUEST,
        intent="add", causality=Causality("mutation-c", "corr", 0), capability=cap,
        contract={"id":"math","version":"1"}, input={"a":2,"b":3}
    ).to_dict()


def main() -> int:
    original = base_message()
    mutations: dict[str, object] = {}
    def mutate(name, fn):
        data = copy.deepcopy(original)
        fn(data)
        mutations[name] = data
    mutate("protocol", lambda d: d.__setitem__("protocol", "other"))
    mutate("semantic_version", lambda d: d.__setitem__("semantic_version", "0.7"))
    mutate("schema_id", lambda d: d.__setitem__("schema_id", "kai/semantic/evil"))
    mutate("message_id", lambda d: d.__setitem__("message_id", "0" * 64))
    mutate("integrity", lambda d: d["integrity"].__setitem__("digest", "f" * 64))
    mutate("unknown_field", lambda d: d.__setitem__("unknown", True))
    mutate("sequence", lambda d: d["causality"].__setitem__("sequence", -1))
    mutate("non_finite", lambda d: d["input"].__setitem__("x", float("nan")))
    mutate("capability_missing", lambda d: d.__setitem__("capability", None))
    mutate("contract_missing", lambda d: d.__setitem__("contract", None))
    passed = 0
    failures = []
    for name, data in mutations.items():
        errors = validate_semantic_message(data)
        if errors:
            passed += 1
        else:
            failures.append(name)
    result = {"passed": not failures, "mutations": len(mutations), "rejected": passed, "unrejected": failures}
    out = Path("docs/maintenance/evidence/v08/MUTATION-PROBE.json")
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
