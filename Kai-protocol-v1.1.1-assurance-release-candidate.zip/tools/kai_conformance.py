from kai.protocol.conformance import main

if __name__ == "__main__":
    raise SystemExit(main())
