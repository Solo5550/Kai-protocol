#!/usr/bin/env python3
"""Emit a compact CycloneDX SBOM for the declared Kai runtime dependencies."""
from __future__ import annotations

import importlib.metadata as md
import json
import re
import tomllib
from pathlib import Path
from packaging.requirements import Requirement

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/engineering-assurance/SBOM.cdx.json"


def purl(name: str, version: str) -> str:
    return f"pkg:pypi/{re.sub(r'[-_.]+', '-', name).lower()}@{version}"


def main() -> None:
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]
    declared = list(project.get("dependencies", []))
    queue = [re.split(r"[<>=!~ ;]", dep, maxsplit=1)[0] for dep in declared]
    seen: set[str] = set()
    components: list[dict] = []
    relationships: list[dict] = []
    while queue:
        name = queue.pop(0)
        key = name.lower().replace("_", "-")
        if key in seen:
            continue
        seen.add(key)
        try:
            dist = md.distribution(name)
            version = dist.version
            reqs = list(dist.requires or [])
        except md.PackageNotFoundError:
            version = "UNRESOLVED"
            reqs = []
        ref = f"pkg:pypi/{re.sub(r'[-_.]+', '-', name).lower()}@{version}" if version != "UNRESOLVED" else None
        item = {"type": "library", "name": name, "version": version}
        if ref:
            item["bom-ref"] = ref
            item["purl"] = ref
        components.append(item)
        for req_text in reqs:
            req = Requirement(req_text)
            try:
                active = req.marker is None or req.marker.evaluate({"extra": ""})
            except Exception:
                active = False
            if not active:
                continue
            dep_name = req.name
            if dep_name:
                queue.append(dep_name)
                dep_key = dep_name.lower().replace("_", "-")
                if ref:
                    relationships.append({"ref": ref, "dependsOn": [dep_key]})
    # Normalize relationship targets after all components are known.
    by_key = {c["name"].lower().replace("_", "-"): c.get("bom-ref", c["name"]) for c in components}
    for rel in relationships:
        rel["dependsOn"] = [by_key.get(x, x) for x in rel["dependsOn"]]
    doc = {
        "bomFormat": "CycloneDX", "specVersion": "1.7", "serialNumber": "urn:kai:assurance-sbom:2026-10-03",
        "version": 1,
        "metadata": {"component": {"type": "application", "name": project["name"], "version": project["version"]}},
        "components": components,
        "dependencies": relationships,
    }
    OUT.write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"path": str(OUT), "project_version": project["version"], "component_count": len(components)}, indent=2))

if __name__ == "__main__":
    main()
