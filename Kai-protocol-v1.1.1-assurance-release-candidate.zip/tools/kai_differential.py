#!/usr/bin/env python3
"""Differential campaign: Kai semantic validator vs JSON-Schema oracle.

The production validator remains authoritative for semantic rules. The JSON Schema
validator is an independent implementation used to detect accidental acceptance
of structurally invalid messages and to quantify intentional stricter semantics.
"""
from __future__ import annotations

import json
import random
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from kai.protocol.interop import Causality, CapabilityRef, SemanticMessage, SpeechAct, validate_semantic_message

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "spec" / "kai" / "0.8" / "semantic.schema.json"


def base_message(seed: int) -> dict[str, Any]:
    cap = CapabilityRef("cap.calc", "1", contract_id="contract.calc", contract_version="1", side_effect_class="pure")
    m = SemanticMessage.build(
        conversation_id=f"c-{seed}", sender="a", recipient="b", act=SpeechAct.REQUEST,
        intent="calculate", causality=Causality(f"c-{seed}", f"corr-{seed}", seed),
        capability=cap, contract={"id": "contract.calc", "version": "1"}, input={"x": seed},
    )
    return m.to_dict()


def classify(data: dict[str, Any], oracle: Draft202012Validator) -> tuple[bool, bool, list[str]]:
    kai_errors = validate_semantic_message(data)
    schema_errors = [e.message for e in oracle.iter_errors(data)]
    return not kai_errors, not schema_errors, kai_errors


def mutate(valid: dict[str, Any], rng: random.Random, case: int) -> dict[str, Any]:
    d = deepcopy(valid)
    choices = [
        "drop", "bad_act", "bad_semantic_version", "nan_input", "unknown_top", "bad_digest",
        "bad_sequence", "too_long_intent", "bad_parent", "bad_extension_count",
    ]
    op = choices[case % len(choices)]
    if op == "drop":
        d.pop(rng.choice(list(d.keys())))
    elif op == "bad_act":
        d["act"] = "NOT_AN_ACT"
    elif op == "bad_semantic_version":
        d["semantic_version"] = "999"
    elif op == "nan_input":
        d["input"]["x"] = float("nan")
    elif op == "unknown_top":
        d["unexpected"] = True
    elif op == "bad_digest":
        d["integrity"]["digest"] = "0" * 64
    elif op == "bad_sequence":
        d["causality"]["sequence"] = -1
    elif op == "too_long_intent":
        d["intent"] = "x" * 5000
    elif op == "bad_parent":
        d["causality"]["parent_ids"] = ["not-a-digest"]
    elif op == "bad_extension_count":
        d["extensions"] = {str(i): i for i in range(100)}
    return d


def run(cases: int = 500, seed: int = 20261003) -> dict[str, Any]:
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    oracle = Draft202012Validator(schema)
    rng = random.Random(seed)
    valid_mismatches: list[str] = []
    false_accepts: list[str] = []
    schema_only_accepts = 0
    both_rejected = 0
    both_accepted = 0
    for i in range(cases):
        msg = base_message(i)
        data = msg if i == 0 else mutate(msg, rng, i)
        kai_ok, schema_ok, kai_errors = classify(data, oracle)
        if kai_ok and schema_ok:
            both_accepted += 1
        elif not kai_ok and not schema_ok:
            both_rejected += 1
        elif kai_ok and not schema_ok:
            false_accepts.append(f"case={i}: Kai accepted schema-invalid input; errors={kai_errors}")
        else:
            schema_only_accepts += 1
            if len(valid_mismatches) < 20:
                valid_mismatches.append(f"case={i}: Kai stricter than schema; errors={kai_errors}")
    return {
        "seed": seed,
        "cases": cases,
        "both_accepted": both_accepted,
        "both_rejected": both_rejected,
        "schema_only_accepts": schema_only_accepts,
        "false_accepts": false_accepts,
        "false_accept_count": len(false_accepts),
        "intentional_or_semantic_stricter_examples": valid_mismatches,
        "status": "PASS" if not false_accepts else "FAIL",
        "oracle": "JSON Schema draft 2020-12",
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
