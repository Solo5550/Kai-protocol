#!/usr/bin/env python3
"""Emit unsigned SLSA-compatible provenance-shaped metadata for the candidate."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/engineering-assurance/PROVENANCE.json"
ARTIFACT = ROOT / "dist" / "kai_protocol_artifact.whl"


def tree_digest() -> str:
    h = hashlib.sha256()
    excluded = {OUT, ROOT / "docs/engineering-assurance/SBOM.cdx.json", ROOT / "docs/engineering-assurance/SHA256SUMS.json"}
    for p in sorted(x for x in ROOT.rglob("*") if x.is_file() and ".git" not in x.parts and "dist" not in x.parts and x not in excluded):
        h.update(str(p.relative_to(ROOT)).encode()); h.update(b"\0"); h.update(p.read_bytes()); h.update(b"\0")
    return h.hexdigest()


def main() -> None:
    result = subprocess.run([sys.executable, "-m", "pip", "wheel", ".", "--no-deps", "--no-build-isolation", "-w", "dist"], cwd=ROOT, capture_output=True, text=True)
    if result.returncode != 0:
        raise SystemExit(result.stderr or result.stdout or "build_failed")
    wheels = sorted((ROOT / "dist").glob("*.whl"))
    if not wheels:
        raise SystemExit("wheel_not_found")
    artifact = wheels[-1]
    digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
    source_digest = tree_digest()
    git_sha = None
    try:
        git_sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        git_sha = None
    doc = {
        "_type": "https://in-toto.io/Statement/v1",
        "predicateType": "https://slsa.dev/provenance/v1",
        "subject": [{"name": artifact.name, "digest": {"sha256": digest}}],
        "predicate": {
            "buildDefinition": {
                "buildType": "https://github.com/Solo5550/Kai-protocol/.github/workflows/assurance.yml@v1.0",
                "resolvedDependencies": [{"uri": "https://github.com/Solo5550/Kai-protocol", "digest": {"sha256": source_digest}}],
                "externalParameters": {"python": platform.python_version(), "platform": platform.platform(), "git_revision": git_sha},
            },
            "runDetails": {"builder": {"id": "local-assurance-builder"}, "metadata": {"source_tree_sha256": source_digest}},
        },
        "attestation": {"signed": False, "note": "Unsigned local provenance; external/signed attestation remains a production gate."},
    }
    OUT.write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"artifact": artifact.name, "sha256": digest, "provenance": str(OUT)}, indent=2))

if __name__ == "__main__":
    main()
