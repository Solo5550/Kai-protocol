import json
import unittest

from kai.language import decode_semantic, encode_semantic
from kai.protocol.interop import (
    Authority,
    CapabilityRef,
    Causality,
    DialogueLedger,
    ReplayError,
    SemanticMessage,
    SemanticValidationError,
    SpeechAct,
    validate_semantic_message,
)


class ProtocolV08Tests(unittest.TestCase):
    def _causal(self, conversation="c1", correlation="corr-1", sequence=0, parents=(), causation=None):
        return Causality(conversation_id=conversation, correlation_id=correlation, sequence=sequence, parent_ids=tuple(parents), causation_id=causation)

    def test_request_is_content_addressed_and_deterministic(self):
        cap = CapabilityRef("payment.charge", "2.1.0", implementation_id="impl.payment", contract_id="payment", contract_version="2", side_effect_class="external_write")
        authority = Authority("issuer-a", "agent-a", scopes=("payment.charge",), tenant="acme", policy_ref="policy-7")
        kwargs = dict(conversation_id="c1", sender="agent-a", recipient="payment-service", act=SpeechAct.REQUEST,
                      intent="charge_customer", causality=self._causal(), authority=authority, capability=cap,
                      contract={"id":"payment","version":"2"}, input={"customer":"C1","amount":50},
                      expected={"status":"settled"}, extensions={"idempotency_key":"K1"})
        a = SemanticMessage.build(**kwargs)
        b = SemanticMessage.build(**kwargs)
        self.assertEqual(a.message_id, b.message_id)
        self.assertTrue(a.verify_integrity())
        self.assertEqual(validate_semantic_message(a), [])

    def test_effectful_request_without_authority_or_idempotency_is_rejected(self):
        cap = CapabilityRef("write", "1.0.0", side_effect_class="external_write")
        m = SemanticMessage.build(
            conversation_id="c1", sender="a", recipient="b", act=SpeechAct.REQUEST, intent="write",
            causality=self._causal(), capability=cap, contract={"id":"c","version":"1"}
        )
        errors = validate_semantic_message(m)
        self.assertIn("effectful capability requires authority", errors)
        self.assertIn("effectful capability requires idempotency_key", errors)
        with self.assertRaises(SemanticValidationError):
            DialogueLedger("c1").ingest(m)

    def test_result_requires_outcome(self):
        m = SemanticMessage.build(
            conversation_id="c1", sender="b", recipient="a", act=SpeechAct.RESULT, intent="charge_customer",
            causality=self._causal(), execution={"execution_id":"e1"}
        )
        self.assertIn("RESULT requires outcome.status", validate_semantic_message(m))

    def test_text_codec_round_trip_and_tamper_detection(self):
        m = SemanticMessage.build(
            conversation_id="c1", sender="a", recipient="b", act=SpeechAct.EVENT, intent="heartbeat",
            causality=self._causal(), provenance={"source":"node-a"}
        )
        text = encode_semantic(m)
        decoded = decode_semantic(text)
        self.assertEqual(decoded["message_id"], m.message_id)
        tampered = text.replace('"intent":"heartbeat"', '"intent":"tampered"')
        with self.assertRaises(ValueError):
            decode_semantic(tampered)

    def test_dialogue_enforces_causality_and_replay(self):
        ledger = DialogueLedger("c1")
        request = SemanticMessage.build(
            conversation_id="c1", sender="a", recipient="b", act=SpeechAct.REQUEST, intent="read",
            causality=self._causal(), capability=CapabilityRef("read", "1.0.0", side_effect_class="read_only"),
            contract={"id":"read","version":"1"}
        )
        accept = SemanticMessage.build(
            conversation_id="c1", sender="b", recipient="a", act=SpeechAct.ACCEPT, intent="read",
            causality=self._causal(sequence=1, parents=(request.message_id,), causation=request.message_id),
            execution={"execution_id":"e1"}
        )
        self.assertEqual(ledger.ingest(request), "ACCEPTED")
        self.assertEqual(ledger.ingest(accept), "ACCEPTED")
        with self.assertRaises(ReplayError):
            ledger.ingest(accept)

    def test_illegal_transition_rejected(self):
        ledger = DialogueLedger("c1")
        event = SemanticMessage.build(
            conversation_id="c1", sender="a", recipient="b", act=SpeechAct.EVENT, intent="heartbeat",
            causality=self._causal()
        )
        ledger.ingest(event)
        proof = SemanticMessage.build(
            conversation_id="c1", sender="b", recipient="a", act=SpeechAct.PROOF, intent="proof",
            causality=self._causal(sequence=1, parents=(event.message_id,), causation=event.message_id),
            proof={"proof_id":"p1"}
        )
        with self.assertRaises(Exception):
            ledger.ingest(proof)


if __name__ == "__main__":
    unittest.main()

class EndpointTests(unittest.TestCase):
    def test_python_to_python_request_accept_result_and_idempotency(self):
        from kai.protocol.endpoint import KaiEndpoint
        server = KaiEndpoint("service-b", tenant="acme")
        server.register(
            CapabilityRef("math.add", "1.0.0", contract_id="math", contract_version="1", side_effect_class="read_only"),
            contract={"id":"math","version":"1"}, handler=lambda payload: payload["a"] + payload["b"],
        )
        request = SemanticMessage.build(
            conversation_id="conv-1", sender="service-a", recipient="service-b", act=SpeechAct.REQUEST,
            intent="add", causality=Causality("conv-1", "corr-1", 0),
            capability=CapabilityRef("math.add", "1.0.0", contract_id="math", contract_version="1", side_effect_class="read_only"),
            contract={"id":"math","version":"1"}, input={"a":2,"b":3}, extensions={"idempotency_key":"idem-1"},
        )
        replies = server.handle(request)
        self.assertEqual([x.act for x in replies], [SpeechAct.ACCEPT, SpeechAct.RESULT])
        self.assertEqual(replies[-1].outcome["value"], 5)
        self.assertEqual(server.handle(request), replies)

    def test_effectful_endpoint_enforces_authority_scope(self):
        from kai.protocol.endpoint import EndpointError, KaiEndpoint
        server = KaiEndpoint("writer", tenant="acme")
        cap = CapabilityRef("db.write", "1.0.0", contract_id="db", contract_version="1", side_effect_class="external_write")
        server.register(cap, contract={"id":"db","version":"1"}, handler=lambda payload: {"ok": True})
        req = SemanticMessage.build(
            conversation_id="c", sender="a", recipient="writer", act=SpeechAct.REQUEST, intent="write",
            causality=Causality("c","corr",0), capability=cap, contract={"id":"db","version":"1"},
            input={"x":1}, authority=Authority("issuer","a",scopes=("db.read",),tenant="acme"), extensions={"idempotency_key":"k"},
        )
        with self.assertRaises(EndpointError):
            server.handle(req)

class SignatureTests(unittest.TestCase):
    def test_authority_signature_attests_without_changing_message_identity(self, tmp_path=None):
        import tempfile
        from pathlib import Path
        from kai.security.authority import generate_authority_keypair
        from kai.protocol.interop import sign_semantic_message, verify_semantic_signature
        with tempfile.TemporaryDirectory() as td:
            private = Path(td) / "private.key"
            public = Path(td) / "public.key"
            generate_authority_keypair(private, public)
            authority = Authority("issuer", "agent", scopes=("read",))
            message = SemanticMessage.build(
                conversation_id="c", sender="agent", recipient="service", act=SpeechAct.EVENT, intent="heartbeat",
                causality=Causality("c", "corr", 0), authority=authority,
            )
            signed = sign_semantic_message(message, str(private), key_id="k1")
            self.assertEqual(signed.message_id, message.message_id)
            self.assertEqual(signed.integrity, message.integrity)
            self.assertTrue(verify_semantic_signature(signed, str(public)))
            self.assertEqual(validate_semantic_message(signed), [])

class EndpointConcurrencyTests(unittest.TestCase):
    def test_same_idempotency_key_executes_once_under_concurrency(self):
        from concurrent.futures import ThreadPoolExecutor
        from kai.protocol.endpoint import KaiEndpoint
        calls = {"n": 0}
        from threading import Lock
        counter_lock = Lock()
        def handler(payload):
            with counter_lock:
                calls["n"] += 1
            return payload["x"] * 2
        server = KaiEndpoint("service")
        cap = CapabilityRef("calc", "1", contract_id="c", contract_version="1", side_effect_class="external_write")
        server.register(cap, contract={"id":"c","version":"1"}, handler=handler)
        req = SemanticMessage.build(
            conversation_id="cc", sender="client", recipient="service", act=SpeechAct.REQUEST, intent="calc",
            causality=Causality("cc","corr",0), authority=Authority("issuer","client",scopes=("calc",)), capability=cap,
            contract={"id":"c","version":"1"}, input={"x":21}, extensions={"idempotency_key":"same"},
        )
        with ThreadPoolExecutor(max_workers=12) as pool:
            replies = list(pool.map(lambda _: server.handle(req), range(12)))
        self.assertTrue(all(r == replies[0] for r in replies))
        self.assertEqual(calls["n"], 1)

class ProtocolHardeningTests(unittest.TestCase):
    def test_from_dict_and_frame_round_trip(self):
        from kai.protocol.endpoint import KaiEndpoint
        from kai.language.semantic_codec import encode_semantic
        cap = CapabilityRef("read", "1", contract_id="c", contract_version="1", side_effect_class="read_only")
        server = KaiEndpoint("server")
        server.register(cap, contract={"id": "c", "version": "1"}, handler=lambda payload: {"value": payload["x"]})
        request = SemanticMessage.build(
            conversation_id="frame-c", sender="client", recipient="server", act=SpeechAct.REQUEST, intent="read",
            causality=Causality("frame-c", "corr", 0), capability=cap, contract={"id": "c", "version": "1"}, input={"x": 7},
        )
        frames = server.handle_frame(encode_semantic(request))
        self.assertEqual(len(frames), 2)
        self.assertEqual([decode_semantic(f)["act"] for f in frames], ["ACCEPT", "RESULT"])

    def test_tenant_scoping_is_fail_closed(self):
        from kai.protocol.endpoint import EndpointError, KaiEndpoint
        server = KaiEndpoint("writer", tenant="acme")
        cap = CapabilityRef("db.write", "1", contract_id="db", contract_version="1", side_effect_class="external_write")
        server.register(cap, contract={"id": "db", "version": "1"}, handler=lambda payload: {"ok": True})
        request = SemanticMessage.build(
            conversation_id="tenant-c", sender="client", recipient="writer", act=SpeechAct.REQUEST, intent="write",
            causality=Causality("tenant-c", "corr", 0), capability=cap, contract={"id": "db", "version": "1"},
            authority=Authority("issuer", "client", scopes=("db.write",)), input={"x": 1}, extensions={"idempotency_key":"k"},
        )
        with self.assertRaises(EndpointError) as ctx:
            server.handle(request)
        self.assertEqual(str(ctx.exception), "tenant_scope_denied")

    def test_non_finite_json_values_are_rejected(self):
        m = SemanticMessage.build(
            conversation_id="c", sender="a", recipient="b", act=SpeechAct.EVENT, intent="measurement",
            causality=Causality("c", "corr", 0), input={"x": 1.0},
        )
        data = m.to_dict()
        data["input"]["x"] = float("nan")
        self.assertTrue(any("non-finite" in e for e in validate_semantic_message(data)))

class SchemaBoundaryTests(unittest.TestCase):
    def test_unknown_top_level_fields_are_rejected(self):
        m = SemanticMessage.build(
            conversation_id="c", sender="a", recipient="b", act=SpeechAct.EVENT, intent="heartbeat",
            causality=Causality("c", "corr", 0),
        )
        data = m.to_dict()
        data["forbidden"] = True
        self.assertIn("unknown top-level field: forbidden", validate_semantic_message(data))

    def test_schema_artifact_accepts_golden_vectors(self):
        import json
        from pathlib import Path
        import jsonschema
        schema = json.loads(Path("spec/kai/0.8/semantic.schema.json").read_text(encoding="utf-8"))
        for path in sorted(Path("spec/kai/0.8/vectors").glob("*.json")):
            vector = json.loads(path.read_text(encoding="utf-8"))
            jsonschema.validate(vector["message"], schema)

    def test_custom_authorizer_is_fail_closed(self):
        from kai.protocol.endpoint import EndpointError, KaiEndpoint
        cap = CapabilityRef("read", "1", contract_id="c", contract_version="1", side_effect_class="read_only")
        server = KaiEndpoint("service", authorizer=lambda request, capability: (_ for _ in ()).throw(RuntimeError("policy down")))
        server.register(cap, contract={"id":"c","version":"1"}, handler=lambda p: p)
        request = SemanticMessage.build(
            conversation_id="auth-c", sender="client", recipient="service", act=SpeechAct.REQUEST, intent="read",
            causality=Causality("auth-c","corr",0), capability=cap, contract={"id":"c","version":"1"}, input={"x":1},
        )
        with self.assertRaises(EndpointError) as ctx:
            server.handle(request)
        self.assertEqual(str(ctx.exception), "authorization_policy_error")
