import json
from pathlib import Path

from jsonschema import Draft202012Validator


def test_assurance_stage_contract_is_schema_valid():
    root = Path(__file__).resolve().parents[1]
    data = json.loads((root / 'spec/assurance/stage-contract.json').read_text())
    schema = json.loads((root / 'spec/assurance/stage-contract.schema.json').read_text())
    assert list(Draft202012Validator(schema).iter_errors(data)) == []
    ids = [x['id'] for x in data['stages']]
    assert ids[0] == 'STAGE_CONTRACT'
    assert ids[-1] == 'STAGE_EXIT'
