import unittest
from kai.protocol.state_machine import StateMachine, InvalidTransition

class StateMachineTests(unittest.TestCase):
    def test_nominal_path(self):
        sm=StateMachine()
        s=sm.transition('RAW','parse')
        s=sm.transition(s,'claim')
        s=sm.transition(s,'evidence')
        s=sm.transition(s,'test')
        s=sm.transition(s,'result-pass')
        self.assertEqual(s,'SUPPORTED')

    def test_invalid_path_rejected(self):
        with self.assertRaises(InvalidTransition):
            StateMachine().transition('RAW','result-pass')

if __name__ == '__main__':
    unittest.main()
