import pytest

from kai.assurance import AssuranceController, AssuranceStage, GateOutcome


def test_assurance_controller_walks_contract_and_exits():
    c = AssuranceController()
    stages = [g.stage for g in c.gates]
    for stage in stages[:-1]:
        c.record(GateOutcome(stage, "PASS", evidence=(stage.value,)))
    assert c.active_stage == AssuranceStage.STAGE_EXIT
    c.record(GateOutcome(AssuranceStage.STAGE_EXIT, "PASS", evidence=("release-exit",)))
    assert c.promotable


def test_critical_failure_reroutes_to_root_cause():
    c = AssuranceController()
    c.record(GateOutcome(AssuranceStage.STAGE_CONTRACT, "PASS"))
    c.record(GateOutcome(AssuranceStage.DEEP_FORENSIC_INSPECTION, "FAIL", evidence=("finding-1",)))
    assert c.active_stage == AssuranceStage.ROOT_CAUSE_ANALYSIS
    assert c.reroutes[-1]["to"] == AssuranceStage.ROOT_CAUSE_ANALYSIS.value
    assert not c.promotable


def test_unapproved_skip_is_rejected():
    c = AssuranceController()
    with pytest.raises(ValueError, match="stage_not_skippable"):
        c.record(GateOutcome(AssuranceStage.STAGE_CONTRACT, "SKIPPED"))
