import unittest

from kai.language import KaiChannel, DialogueError
from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction, MessageType


class ChannelTests(unittest.TestCase):
    def test_multi_unit_interleaving(self):
        f = MessageFactory(actor="test")
        make = lambda unit, typ, payload, rnd: f.create(unit_id=unit, round=rnd, layer=1, direction=Direction.HORIZONTAL, type=typ, payload=payload)
        messages = [
            make("root", MessageType.CONTRACT, {"scope": "x"}, 0),
            make("u1", MessageType.CLAIM, {"claim": "A"}, 1),
            make("u2", MessageType.CLAIM, {"claim": "B"}, 1),
            make("u1", MessageType.TEST, {"test_id": "t1", "kind": "property", "expected": True}, 2),
            make("u2", MessageType.TEST, {"test_id": "t2", "kind": "property", "expected": True}, 2),
            make("u1", MessageType.RESULT, {"test_id": "t1", "status": "PASS", "actual": True}, 3),
            make("u2", MessageType.RESULT, {"test_id": "t2", "status": "PASS", "actual": True}, 3),
        ]
        channel = KaiChannel()
        channel.ingest_many(messages)
        self.assertEqual(sorted(channel.units), ["u1", "u2"])

    def test_contract_required(self):
        f = MessageFactory(actor="test")
        m = f.create(unit_id="u1", round=1, layer=1, direction=Direction.HORIZONTAL, type=MessageType.CLAIM, payload={"claim": "A"})
        with self.assertRaises(DialogueError):
            KaiChannel().ingest(m)


if __name__ == "__main__":
    unittest.main()
