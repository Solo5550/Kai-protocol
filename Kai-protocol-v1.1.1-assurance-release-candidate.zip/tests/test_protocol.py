import unittest

from kai.protocol.messages import MessageFactory, sha256_hex
from kai.protocol.models import Direction, MessageType, Unit, Provenance, Evidence
from kai.protocol.validator import ProtocolValidator


class ProtocolTests(unittest.TestCase):
    def test_message_integrity(self):
        m = MessageFactory().create(unit_id="u1", round=1, layer=2, direction=Direction.DOWN, type=MessageType.CLAIM, payload={"x": 1})
        self.assertEqual(len(m.integrity["digest"]), 64)
        self.assertEqual(ProtocolValidator().validate_message(m), [])


    def test_message_identity_is_deterministic(self):
        kwargs = dict(unit_id="u1", round=1, layer=2, direction=Direction.DOWN, type=MessageType.CLAIM, payload={"x": 1})
        a = MessageFactory(actor="same").create(**kwargs)
        b = MessageFactory(actor="same").create(**kwargs)
        self.assertEqual(a.message_id, b.message_id)
        self.assertEqual(a.integrity["digest"], b.integrity["digest"])
        c = MessageFactory(actor="different").create(**kwargs)
        self.assertNotEqual(a.message_id, c.message_id)

    def test_tamper_is_detected(self):
        m = MessageFactory().create(unit_id="u1", round=1, layer=2, direction=Direction.DOWN, type=MessageType.CLAIM, payload={"x": 1})
        data = m.to_dict()
        data["payload"]["x"] = 9
        self.assertIn("integrity digest mismatch", ProtocolValidator().validate_message(data))

    def test_unit_provenance_and_evidence(self):
        u = Unit(unit_id="u", claim="c", provenance=[Provenance(source_id="s", extracted_by="x")], evidence=[Evidence("e", "obs", provenance=Provenance(source_id="e-src", extracted_by="x"))])
        self.assertEqual(ProtocolValidator().validate_unit(u), [])


if __name__ == "__main__":
    unittest.main()
