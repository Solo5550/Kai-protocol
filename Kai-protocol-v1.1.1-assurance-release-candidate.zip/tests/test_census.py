import unittest
from kai.engine.census import CensusEngine
from kai.protocol.models import Unit

class CensusTests(unittest.TestCase):
    def test_gap_detection(self):
        u=Unit(unit_id='u', claim='c')
        items=CensusEngine().gap_census([u])
        self.assertTrue(any(i.category == 'gap' for i in items))

if __name__ == '__main__':
    unittest.main()
