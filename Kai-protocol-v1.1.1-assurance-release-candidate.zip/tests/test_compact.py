import pytest

from kai.language.compact import CompactCodecError, decode_compact, decode_compact_stream, encode_compact, encode_compact_many
from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction, MessageType


def make_message():
    return MessageFactory(actor="test").create(
        unit_id="u1", round=1, layer=1, direction=Direction.HORIZONTAL,
        type=MessageType.CLAIM, payload={"claim": "x", "n": 1}, parents=["p"], provenance={"actor": "test"},
    )


def test_compact_roundtrip():
    m = make_message(); frame = encode_compact(m); out = decode_compact(frame)
    assert out["message_id"] == m.message_id
    assert out["payload"] == m.payload


def test_compact_deterministic():
    m = make_message()
    assert encode_compact(m) == encode_compact(m)


def test_compact_tamper_rejected():
    m = make_message(); frame = bytearray(encode_compact(m)); frame[-1] ^= 1
    with pytest.raises(CompactCodecError):
        decode_compact(bytes(frame))


def test_compact_length_mismatch_rejected():
    m = make_message(); frame = bytearray(encode_compact(m)); i = len(b"KAI-BIN/1\0")
    frame[i+3] ^= 1
    with pytest.raises(CompactCodecError):
        decode_compact(bytes(frame))


def test_compact_batch_stream_roundtrip():
    messages = [make_message() for _ in range(3)]
    stream = encode_compact_many(messages)
    decoded = list(decode_compact_stream(stream))
    assert [x["message_id"] for x in decoded] == [m.message_id for m in messages]


def test_compact_stream_truncation_rejected():
    stream = encode_compact_many([make_message()])
    with pytest.raises(CompactCodecError):
        list(decode_compact_stream(stream[:-1]))