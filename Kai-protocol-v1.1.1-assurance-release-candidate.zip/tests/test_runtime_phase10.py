from kai.runtime import CalibrationEngine, ExperienceEngine, RuntimeStore


def test_experience_is_candidate_until_validated():
    store = RuntimeStore(); engine = ExperienceEngine(store)
    x = engine.propose(statement="rollback after config spike", context={"service": "api"}, execution_refs=["e1"], verification_refs=["v1"], confidence=0.7)
    assert x.status == "CANDIDATE"
    x = engine.validate(x, success_rate=0.95, verifier_count=1)
    assert x.status == "QUALIFIED"
    decision = engine.eligible_for_reuse(x, context_signature=x.context_signature, policy={"min_success_rate": 0.8, "require_fresh": True})
    assert decision.eligible


def test_unvalidated_or_context_mismatch_experience_is_not_reused():
    store = RuntimeStore(); engine = ExperienceEngine(store)
    x = engine.propose(statement="x", context={"a": 1}, execution_refs=["e"], verification_refs=[])
    assert not engine.eligible_for_reuse(x, context_signature=x.context_signature, policy={}).eligible
    x = engine.validate(x, success_rate=0.95, verifier_count=1)
    assert not engine.eligible_for_reuse(x, context_signature="wrong", policy={}).eligible


def test_calibration_links_confidence_to_observed_error():
    ok = CalibrationEngine().calculate(expected=100, observed=102, prior_confidence=0.9)
    bad = CalibrationEngine().calculate(expected=100, observed=180, prior_confidence=0.9)
    assert ok.prediction_error < bad.prediction_error
    assert ok.updated_reliability > bad.updated_reliability
