import unittest
from kai.protocol.merge import MergeStrategy, MergeError


class MergeTests(unittest.TestCase):
    def test_set_union(self):
        s = MergeStrategy({"tags":"set-union"})
        self.assertEqual(s.merge({"tags":["a"]},{"tags":["b","a"]})["tags"],["a","b"])

    def test_conflict_is_rejected(self):
        s = MergeStrategy({"claim":"reject-on-conflict"})
        with self.assertRaises(MergeError):
            s.merge({"claim":"a"},{"claim":"b"})


if __name__ == "__main__":
    unittest.main()
