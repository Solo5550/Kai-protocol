import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENV = {"PYTHONPATH": str(ROOT / "src")}


class CLITests(unittest.TestCase):
    def run_cli(self, *args):
        import os
        env = os.environ.copy()
        env.update(ENV)
        return subprocess.run([sys.executable, "-m", "kai", *args], cwd=ROOT, env=env, capture_output=True, text=True)

    def test_validate_and_run_example(self):
        r1 = self.run_cli("validate", "examples/minimal_session.json")
        self.assertEqual(r1.returncode, 0, r1.stderr)
        r2 = self.run_cli("run", "examples/minimal_session.json")
        self.assertEqual(r2.returncode, 0, r2.stderr)
        data = json.loads(r2.stdout)
        self.assertEqual(data["verdict"], "ACCEPTED")
        self.assertTrue(data["exported_artifacts"]["language"]["valid"])

    def test_encode_decode_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src = td / "message.json"
            encoded = td / "message.kai"
            src.write_text(json.dumps({
                "unit_id": "u1", "round": 1, "layer": 1, "direction": "horizontal",
                "type": "CLAIM", "payload": {"claim": "A"}
            }), encoding="utf-8")
            self.assertEqual(self.run_cli("encode", str(src), str(encoded)).returncode, 0)
            out = self.run_cli("decode", str(encoded))
            self.assertEqual(out.returncode, 0, out.stderr)
            data = json.loads(out.stdout)
            self.assertEqual(data["payload"]["claim"], "A")
            self.assertEqual(data["language"], "KAI-LANG/0.1")

    def test_secret_cli_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            key = td / "kai.master"
            plain = td / "plain.txt"
            env = td / "secret.json"
            out = td / "out.txt"
            plain.write_text("private knowledge", encoding="utf-8")
            self.assertEqual(self.run_cli("keygen", str(key)).returncode, 0)
            self.assertEqual(self.run_cli("secret-seal", "--key", str(key), "--in", str(plain), "--out", str(env)).returncode, 0)
            self.assertEqual(self.run_cli("secret-open", "--key", str(key), "--in", str(env), "--out", str(out)).returncode, 0)
            self.assertEqual(out.read_text(encoding="utf-8"), "private knowledge")


if __name__ == "__main__":
    unittest.main()


def test_cli_semantic_round_trip(tmp_path):
    import json
    from kai.protocol import CapabilityRef, Causality, SemanticMessage, SpeechAct
    from kai.cli import main
    obj = SemanticMessage.build(conversation_id="c", sender="a", recipient="b", act=SpeechAct.EVENT, intent="ping", causality=Causality("c","corr",0)).to_dict()
    src = tmp_path / "msg.json"; out = tmp_path / "msg.kai"
    src.write_text(json.dumps(obj), encoding="utf-8")
    assert main(["semantic-encode", str(src), str(out)]) == 0
    assert main(["semantic-decode", str(out)]) == 0
