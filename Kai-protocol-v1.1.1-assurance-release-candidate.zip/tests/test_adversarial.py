import unittest

from kai.engine.session import KaiSession
from kai.protocol.models import GateStatus


class AdversarialTests(unittest.TestCase):
    def test_fail_result_contests_unit(self):
        s = KaiSession.from_parts("root", "Root claim", [{"unit_id":"u1","claim":"Child claim"}])
        s.attach_evidence("u1", "support", "e1")
        tid = s.attach_test("u1", "property", {}, True)
        s.record_result("u1", tid, GateStatus.FAIL, False, "counterexample")
        self.assertEqual(s.graph.get("u1").state, "CONTESTED")

    def test_tainted_reconstruction_does_not_promote(self):
        s = KaiSession.from_parts("root", "Root claim", [{"unit_id":"u1","claim":"Child claim"}])
        sy, rec = s.synthesize()
        self.assertFalse(rec.metadata["preserved"])


if __name__ == "__main__":
    unittest.main()
