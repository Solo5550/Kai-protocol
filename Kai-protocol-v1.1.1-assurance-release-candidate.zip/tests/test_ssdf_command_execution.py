from __future__ import annotations

import shlex
import sys
from pathlib import Path

import pytest

from kai.ssdf.ssdfx import run_verification_command


def test_verification_command_runs_without_shell(tmp_path: Path):
    code = "print('verification-ok')"
    command = f"{shlex.quote(sys.executable)} -c {shlex.quote(code)}"
    proc = run_verification_command(command, tmp_path)
    assert proc.returncode == 0
    assert proc.stdout.strip() == "verification-ok"


def test_shell_metacharacters_are_not_executed(tmp_path: Path):
    marker = tmp_path / "should-not-exist"
    first_code = "print('safe')"
    first = f"{shlex.quote(sys.executable)} -c {shlex.quote(first_code)}"
    second_code = f"from pathlib import Path; Path({str(marker)!r}).write_text('owned')"
    second = f"{shlex.quote(sys.executable)} -c {shlex.quote(second_code)}"
    payload = f"{first} && {second}"

    proc = run_verification_command(payload, tmp_path)

    assert proc.returncode == 0
    assert proc.stdout.strip() == "safe"
    assert not marker.exists()


def test_empty_verification_command_is_rejected(tmp_path: Path):
    with pytest.raises(ValueError, match="must not be empty"):
        run_verification_command("   ", tmp_path)
