import unittest

from kai.language import DialogueEngine, DialogueError, LanguageCodecError, decode_message, encode_message, validate_semantics
from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction, GateStatus, MessageType


class LanguageTests(unittest.TestCase):
    def setUp(self):
        self.factory = MessageFactory(actor="test")

    def _m(self, *, unit="u1", type=MessageType.CLAIM, payload=None, round=1):
        return self.factory.create(
            unit_id=unit,
            round=round,
            layer=1,
            direction=Direction.HORIZONTAL,
            type=type,
            payload=payload or {"claim": "A"},
        )

    def test_text_round_trip(self):
        message = self._m()
        encoded = encode_message(message)
        decoded = decode_message(encoded)
        self.assertEqual(decoded["message_id"], message.message_id)
        self.assertEqual(decoded["payload"], message.payload)
        self.assertEqual(decoded["integrity"], message.integrity)


    def test_text_tamper_is_rejected_during_decode(self):
        message = self._m()
        encoded = encode_message(message)
        tampered = encoded.replace("PAYLOAD ", "PAYLOAD A", 1) if False else encoded.replace("TYPE CLAIM", "TYPE EVIDENCE", 1)
        with self.assertRaises(LanguageCodecError):
            decode_message(tampered)

    def test_semantic_contract(self):
        message = self._m(payload={"claim": "A"})
        self.assertEqual(validate_semantics(message), [])
        bad = message.to_dict()
        bad["payload"] = {}
        self.assertIn("CLAIM: missing payload field claim", validate_semantics(bad))

    def test_dialogue_nominal(self):
        d = DialogueEngine()
        messages = [
            self._m(type=MessageType.CONTRACT, payload={"scope": "x"}, round=0),
            self._m(type=MessageType.CLAIM, payload={"claim": "A"}),
            self._m(type=MessageType.EVIDENCE, payload={"statement": "E", "evidence_id": "e1"}, round=2),
            self._m(type=MessageType.TEST, payload={"test_id": "t1", "kind": "property", "expected": True}, round=3),
            self._m(type=MessageType.RESULT, payload={"test_id": "t1", "status": "PASS", "actual": True}, round=4),
            self._m(type=MessageType.VERDICT, payload={"verdict": "ACCEPTED"}, round=5),
        ]
        d.accept_many(messages)
        self.assertTrue(d.state.closed)
        self.assertIn("t1", d.state.passed_tests)

    def test_dialogue_blocks_verdict_with_open_objection(self):
        d = DialogueEngine()
        d.accept(self._m(type=MessageType.CONTRACT, payload={"scope": "x"}, round=0))
        d.accept(self._m(type=MessageType.CLAIM, payload={"claim": "A"}, round=1))
        d.accept(self._m(type=MessageType.OBJECTION, payload={"target_id": "u1", "statement": "counter"}, round=2))
        d.accept(self._m(type=MessageType.TEST, payload={"test_id": "t1", "kind": "property", "expected": True}, round=3))
        d.accept(self._m(type=MessageType.RESULT, payload={"test_id": "t1", "status": "PASS", "actual": True}, round=4))
        with self.assertRaises(DialogueError):
            d.accept(self._m(type=MessageType.VERDICT, payload={"verdict": "ACCEPTED"}, round=5))


    def test_dialogue_cannot_start_with_verdict(self):
        d = DialogueEngine(require_local_pass_for_accept=False)
        with self.assertRaises(DialogueError):
            d.accept(self._m(type=MessageType.VERDICT, payload={"verdict": "ACCEPTED"}, round=0))

    def test_dialogue_reopen(self):
        d = DialogueEngine()
        d.accept(self._m(type=MessageType.CONTRACT, payload={"scope": "x"}, round=0))
        d.accept(self._m(type=MessageType.CLAIM, payload={"claim": "A"}, round=1))
        d.accept(self._m(type=MessageType.TEST, payload={"test_id": "t1", "kind": "property", "expected": True}, round=2))
        d.accept(self._m(type=MessageType.RESULT, payload={"test_id": "t1", "status": "FAIL", "actual": False}, round=3))
        d.accept(self._m(type=MessageType.VERDICT, payload={"verdict": "REJECTED"}, round=4))
        with self.assertRaises(DialogueError):
            d.accept(self._m(type=MessageType.CLAIM, payload={"claim": "B"}, round=5))
        d.accept(self._m(type=MessageType.REOPEN, payload={"reason": "new evidence"}, round=6))
        self.assertFalse(d.state.closed)


if __name__ == "__main__":
    unittest.main()

class DialogueEfficiencyTests(unittest.TestCase):
    def test_bounded_history_tracking(self):
        f = MessageFactory(actor="test")
        d = DialogueEngine(track_history=True, history_limit=2)
        d.accept(f.create(unit_id="u", round=0, layer=0, direction=Direction.DOWN, type=MessageType.CONTRACT, payload={"scope": "x"}))
        d.accept(f.create(unit_id="u", round=1, layer=1, direction=Direction.HORIZONTAL, type=MessageType.CLAIM, payload={"claim": "A"}))
        d.accept(f.create(unit_id="u", round=2, layer=1, direction=Direction.HORIZONTAL, type=MessageType.EVIDENCE, payload={"statement": "E", "evidence_id": "e"}))
        self.assertEqual(d.message_count, 3)
        self.assertEqual(len(d.state.message_ids), 2)

    def test_history_can_be_disabled_for_derived_index(self):
        f = MessageFactory(actor="test")
        d = DialogueEngine(track_history=False)
        d.accept(f.create(unit_id="u", round=0, layer=0, direction=Direction.DOWN, type=MessageType.CONTRACT, payload={"scope": "x"}))
        d.accept(f.create(unit_id="u", round=1, layer=1, direction=Direction.HORIZONTAL, type=MessageType.CLAIM, payload={"claim": "A"}))
        self.assertEqual(d.message_count, 2)
        self.assertEqual(d.state.message_ids, [])
