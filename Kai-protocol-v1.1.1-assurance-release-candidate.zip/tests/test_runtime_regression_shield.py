from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import pytest

from kai.runtime import Capability, Contract, EvidenceBundle, Execution, KaiRuntime, Plan, PlanNode, Policy, RuntimeStore


def _good(_):
    return {"source": "registry"}


def _attacker(_):
    return {"source": "caller"}


def test_capability_resolution_identity_cannot_be_bypassed(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    cap = Capability(capability_id="shield.cap", implementation_id="shield.impl", owner="security")
    runtime.install_capability(cap, _good)
    contract = Contract(id="c", version="1")
    evidence = EvidenceBundle(evidence_id="e", sources=[{"source_id": "s", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})
    plan = Plan(plan_id="p", objective="shield", nodes=[PlanNode(node_id="n", capability_requirement={"capability_id": cap.capability_id})], acceptance_criteria=["x"])
    policy = Policy(policy_id="p", allowed_capabilities=[cap.capability_id], allowed_regions=["local"])
    with pytest.raises(PermissionError, match="handler_mismatch_with_resolved_capability"):
        runtime.execute(objective="shield", input_data={}, contract=contract, policy=policy, capability_id=cap.capability_id,
                        evidence=evidence, plan=plan, handler=_attacker)


def test_runtime_store_read_paths_are_thread_safe():
    store = RuntimeStore()
    for i in range(64):
        store.create_execution(Execution(execution_id=f"read-{i}", run_id=f"r-{i}", objective="read"))
    with ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(lambda i: store.get_execution(f"read-{i}").execution_id, range(64)))
    assert rows == [f"read-{i}" for i in range(64)]
    store.close()
