from pathlib import Path
import os
import subprocess
import sys
import time
import pytest

from kai.runtime import Capability, CapabilityLifecycle, Execution, HardIsolationExecutor, IsolationBlocked, IsolationViolation, ResourceQuota


def cap():
    c = Capability(capability_id="p0.echo", implementation_id="impl.p0.echo", owner="p0", purpose="isolation")
    c.lifecycle = CapabilityLifecycle.AVAILABLE
    return c


def test_hard_isolation_platform_and_manifest():
    iso = HardIsolationExecutor(timeout=4)
    if not iso.available:
        pytest.skip(iso.block_reason or "hard isolation unavailable")
    manifest = iso.build_manifest(cap(), "1.0", permissions=set())
    assert manifest.signature
    assert manifest.verify(iso.authority.public_key)
    tampered = type(manifest)(**{**manifest.__dict__, "capability_version": "9.9.9"})
    assert not tampered.verify(iso.authority.public_key)


def test_host_filesystem_and_network_are_isolated():
    iso = HardIsolationExecutor(timeout=5)
    if not iso.available:
        pytest.skip(iso.block_reason or "hard isolation unavailable")
    secret = Path("/tmp/kai-host-secret-p0")
    secret.write_text("DO-NOT-READ")
    c = cap(); manifest = iso.build_manifest(c, "1.0", permissions=set())
    ex = Execution(execution_id="exec-p0-fs", input_data={})
    def hostile(_):
        import socket
        try: fs = Path('/tmp/kai-host-secret-p0').read_text()
        except Exception as e: fs = type(e).__name__
        try:
            s = socket.create_connection(('127.0.0.1', 9), timeout=0.2); net = 'CONNECTED'; s.close()
        except Exception as e: net = type(e).__name__
        return {"fs": fs, "net": net}
    try:
        result = iso.execute(execution=ex, capability=c, handler=hostile, payload={}, manifest=manifest)
        assert result.status == "SUCCESS", result.error
        assert result.output["fs"] != "DO-NOT-READ"
        assert result.output["net"] != "CONNECTED"
        assert iso.attestor.verify(result)
    finally:
        secret.unlink(missing_ok=True)


def test_resource_quota_timeout_is_enforced():
    iso = HardIsolationExecutor(timeout=1.5)
    if not iso.available:
        pytest.skip(iso.block_reason or "hard isolation unavailable")
    c = cap(); manifest = iso.build_manifest(c, "1.0", permissions=set(), quota=ResourceQuota(cpu_seconds=1))
    ex = Execution(execution_id="exec-p0-timeout", input_data={})
    result = iso.execute(execution=ex, capability=c, handler=lambda _: (time.sleep(3), {"bad": True})[1], payload={}, manifest=manifest, timeout=1.5)
    assert result.status in {"TIMEOUT", "FAILURE"}


def test_permission_boundary_is_non_bypassable():
    iso = HardIsolationExecutor()
    c = cap(); c.required_permissions = ["network.egress"]
    with pytest.raises((IsolationViolation, IsolationBlocked)):
        iso.build_manifest(c, "1.0", permissions={"network.egress"})


def test_permission_boundary_denies_process_spawn(tmp_path):
    runtime = HardIsolationExecutor()
    cap = Capability(capability_id="p0.spawn", implementation_id="impl.p0.spawn", owner="test")
    cap.lifecycle = CapabilityLifecycle.AVAILABLE
    def handler(_):
        subprocess.run(["true"], check=True)
        return {"spawned": True}
    from kai.runtime import Execution
    manifest = runtime.build_manifest(cap, "1.0", permissions=set(), handler=handler)
    result = runtime.execute(execution=Execution(execution_id="spawn-e", input_data={}), capability=cap, handler=handler, payload={}, manifest=manifest, timeout=3)
    assert result.status == "FAILURE"
    assert "operation not permitted" in (result.error or "").lower()



def test_bootstrap_mounts_installed_purelib_inside_chroot(tmp_path):
    iso = HardIsolationExecutor(timeout=5)
    if not iso.available:
        pytest.skip(iso.block_reason or "hard isolation unavailable")
    purelib = tmp_path / "site-packages"
    purelib.mkdir()
    (purelib / "kai_p0_probe.py").write_text("VALUE = 'PURELIB_VISIBLE'\n", encoding="utf-8")
    root = tmp_path / "root"
    work = tmp_path / "work"
    root.mkdir(); work.mkdir()
    iso._prepare_rootfs(root)
    (work / "runner.py").write_text(
        "import kai_p0_probe\nfrom pathlib import Path\nPath('/work/result.txt').write_text(kai_p0_probe.VALUE)\n",
        encoding="utf-8",
    )
    script = tmp_path / "bootstrap.sh"
    script.write_text(
        iso._bootstrap_script(root, work, os.path.realpath(sys.executable), str(purelib)),
        encoding="utf-8",
    )
    script.chmod(0o700)
    proc = subprocess.run(
        ["unshare", "--user", "--map-root-user", "--mount", "--net", "--ipc", "--uts", "--pid", "--fork", "--kill-child", str(script)],
        capture_output=True, text=True, timeout=10,
    )
    assert proc.returncode == 0, proc.stderr
    assert (work / "result.txt").read_text(encoding="utf-8") == "PURELIB_VISIBLE"
