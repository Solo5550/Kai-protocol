from kai.runtime import (
    ArchitectureDriftScanner, Cell, Execution, KaiRuntime, Policy, Region, RuntimeConformance,
    RuntimeAPI, qualify_reference_runtime,
)
from kai.runtime.conformance import architecture_fitness


def test_reference_qualification_gate_passes(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    report = qualify_reference_runtime(runtime)
    assert report.passed
    assert all(report.checks.values())


def test_architecture_fitness_confirms_single_canonical_store(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    checks = architecture_fitness(runtime)
    assert checks["single_store"] and checks["no_shadow_runtime"]


def test_runtime_api_projection_reads_authoritative_state(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    execution = Execution(execution_id="api-e", run_id="api-r", objective="api")
    runtime.store.create_execution(execution)
    api = RuntimeAPI(runtime)
    assert api.get_execution("api-e")["execution"]["state"] == "CREATED"
