import time
from pathlib import Path

import pytest

from kai.runtime import Capability, CapabilityLifecycle, GlobalControlPlane, HardIsolationExecutor, JsonLineNode, ChaosController, serialize_handler


def node_handler(payload):
    return {"ok": True, "value": payload.get("value", 0)}


def slow_handler(payload):
    time.sleep(float(payload.get("sleep", 3)))
    return {"ok": True}


def make_cap():
    cap = Capability(capability_id="p0.node.echo", implementation_id="impl.p0.node.echo", owner="p0", purpose="node execution")
    cap.lifecycle = CapabilityLifecycle.AVAILABLE
    return cap


def make_node(tmp_path, control, node_id, port, handler=node_handler):
    cap = make_cap()
    iso = HardIsolationExecutor(authority=control.manifest_authority)
    manifest = iso.build_manifest(cap, "1.0", permissions=set(), handler=handler)
    import base64
    blob = base64.urlsafe_b64encode(serialize_handler(handler)).decode().rstrip("=")
    spec = {"manifest": __import__('dataclasses').asdict(manifest), "handler_blob": blob}
    node = JsonLineNode(node_id=node_id, region_id="r1", cell_id=f"cell-{node_id}", host="127.0.0.1", port=port,
                        capability_specs={cap.capability_id: spec}, store_path=str(tmp_path / f"{node_id}.db"),
                        manifest_public_key=control.manifest_authority.public_key)
    control.register_process_node(node, node_id, "r1", f"cell-{node_id}", f"127.0.0.1:{port}", {cap.capability_id})
    return cap, manifest, handler, node


def exec_factory(control, node_id, cap, manifest, handler, **kw):
    resp = control.execute_capability(node_id=node_id, capability=cap, handler=handler, manifest=manifest, payload=kw.pop("payload", {"value": 7}),
                                      execution_id=kw.pop("execution_id", None), idempotency_key=kw.pop("idempotency_key", None),
                                      command_id=kw.pop("command_id", None), dependencies=kw.pop("dependencies", None),
                                      partial=kw.pop("partial", False), timeout=kw.pop("timeout", 5))
    if resp.get("result"):
        resp["idempotency_key"] = resp["result"].get("idempotency_key", kw.get("idempotency_key"))
    return resp


def test_real_multi_node_registration_and_execution(tmp_path):
    control = GlobalControlPlane()
    c1, m1, h1, n1 = make_node(tmp_path, control, "node-a", 18861)
    c2, m2, h2, n2 = make_node(tmp_path, control, "node-b", 18862)
    try:
        assert n1.is_alive() and n2.is_alive()
        assert control.registry.nodes["node-a"].region_id == "r1"
        assert control.registry.nodes["node-a"].cell_id == "cell-node-a"
        assert control.heartbeat("node-a")["ok"]
        r1 = exec_factory(control, "node-a", c1, m1, h1)
        r2 = exec_factory(control, "node-b", c2, m2, h2, payload={"value": 9})
        assert r1["ok"] and r2["ok"]
        assert r1["result"]["status"] == "SUCCESS"
        assert r2["result"]["status"] == "SUCCESS"
        assert r1["attestation_verified"] and r2["attestation_verified"]
        assert control.provenance[r1["result"]["execution_id"]]["node_id"] == "node-a"
    finally:
        control.stop_all()


def test_lease_expiry_blocks_execution(tmp_path):
    control = GlobalControlPlane()
    c, m, h, node = make_node(tmp_path, control, "node-lease", 18863)
    try:
        control.leases.expire("node-lease")
        with pytest.raises(RuntimeError, match="lease_invalid"):
            exec_factory(control, "node-lease", c, m, h)
    finally:
        control.stop_all()


def test_idempotency_deduplicates_new_command_id(tmp_path):
    control = GlobalControlPlane()
    c, m, h, node = make_node(tmp_path, control, "node-idem", 18864)
    try:
        idem = "fixed-idem"
        first = control.execute_capability(node_id="node-idem", capability=c, handler=h, manifest=m, payload={"value": 3}, idempotency_key=idem, command_id="cmd-1")
        second = control.execute_capability(node_id="node-idem", capability=c, handler=h, manifest=m, payload={"value": 999}, idempotency_key=idem, command_id="cmd-2")
        assert first["result"]["output"] == {"ok": True, "value": 3}
        assert second["duplicate"] is True
        assert second["result"]["output"] == {"ok": True, "value": 3}
    finally:
        control.stop_all()


def test_kill_running_node_marks_execution_recovery_pending(tmp_path):
    control = GlobalControlPlane()
    c, m, h, node = make_node(tmp_path, control, "node-kill", 18865, handler=slow_handler)
    import threading
    result_box = {}
    def run():
        try:
            result_box["response"] = control.execute_capability(node_id="node-kill", capability=c, handler=h, manifest=m,
                payload={"sleep": 4}, execution_id="exec-kill", idempotency_key="idem-kill", timeout=10)
        except Exception as exc:
            result_box["error"] = str(exc)
    t = threading.Thread(target=run, daemon=True); t.start(); time.sleep(0.4)
    try:
        while control.desired.get("exec-kill", {}).get("state") != "RUNNING": time.sleep(0.05)
        affected = control.kill_node("node-kill")
        t.join(timeout=2)
        assert "exec-kill" in affected
        assert control.observed["exec-kill"]["state"] == "RECOVERY_PENDING"
        assert control.reconcile("exec-kill")["status"] == "IN_SYNC"
    finally:
        control.stop_all()


def test_failure_detector_after_heartbeat_expiry(tmp_path):
    control = GlobalControlPlane()
    c, m, h, node = make_node(tmp_path, control, "node-fd", 18866)
    try:
        control.leases.ttl = 0.1
        control.leases.expire("node-fd")
        assert "node-fd" in control.detector.scan()
    finally:
        control.stop_all()


def test_full_chaos_faults_except_terminal_kill_and_partial(tmp_path):
    control = GlobalControlPlane()
    c, m, h, node = make_node(tmp_path, control, "node-chaos", 18867)
    chaos = ChaosController(control)
    try:
        cases = [
            chaos.run("network_partition", node_id="node-chaos", case_id="partition"),
            chaos.run("packet_loss", node_id="node-chaos", case_id="loss"),
            chaos.run("packet_delay", node_id="node-chaos", case_id="delay"),
            chaos.run("delayed_delivery", node_id="node-chaos", case_id="delayed"),
            chaos.run("duplicate_delivery", node_id="node-chaos", case_id="duplicate", execution_factory=lambda **kw: control.execute_capability(
                node_id="node-chaos", capability=c, handler=h, manifest=m, payload={"value": 1}, idempotency_key=kw.get("idempotency_key", "chaos-idem"), command_id=kw.get("command_id", "chaos-cmd"))),
            chaos.run("dependency_disappearance", node_id="node-chaos", case_id="dep", execution_factory=lambda **kw: control.execute_capability(
                node_id="node-chaos", capability=c, handler=h, manifest=m, payload={"value": 1}, dependencies=kw.get("dependencies"))),
            chaos.run("clock_skew", node_id="node-chaos", case_id="clock"),
        ]
        assert all(c.result == "PASS" for c in cases)
        storage = chaos.run("storage_corruption", node_id="node-chaos", case_id="storage")
        assert storage.result == "PASS"
    finally:
        control.stop_all()
