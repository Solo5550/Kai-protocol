import time
from pathlib import Path

import pytest

from kai.runtime import Capability, CapabilityLifecycle, ChaosController, GlobalControlPlane, HardIsolationExecutor, JsonLineNode, serialize_handler


def echo(payload):
    return {"value": payload.get("value", 0) + 1}


def slow(payload):
    time.sleep(float(payload.get("sleep", 3)))
    return {"done": True}


def make_node(tmp_path, control, node_id, port, handler=echo):
    cap = Capability(capability_id=f"chaos.{node_id}", implementation_id=f"impl.chaos.{node_id}", owner="chaos")
    cap.lifecycle = CapabilityLifecycle.AVAILABLE
    iso = HardIsolationExecutor(authority=control.manifest_authority)
    manifest = iso.build_manifest(cap, "1.0", permissions=set(), handler=handler)
    import base64, dataclasses
    spec = {"manifest": dataclasses.asdict(manifest), "handler_blob": base64.urlsafe_b64encode(serialize_handler(handler)).decode().rstrip("=")}
    node = JsonLineNode(node_id=node_id, region_id="r1", cell_id=f"cell-{node_id}", host="127.0.0.1", port=port,
                        capability_specs={cap.capability_id: spec}, store_path=str(tmp_path / f"{node_id}.db"),
                        manifest_public_key=control.manifest_authority.public_key)
    control.register_process_node(node, node_id, "r1", f"cell-{node_id}", f"127.0.0.1:{port}", {cap.capability_id})
    return cap, manifest


def factory(control, node_id, cap, manifest, **kw):
    return control.execute_capability(node_id=node_id, capability=cap, handler=echo, manifest=manifest,
                                      payload=kw.pop("payload", {"value": 1}), execution_id=kw.pop("execution_id", None),
                                      idempotency_key=kw.pop("idempotency_key", None), command_id=kw.pop("command_id", None),
                                      dependencies=kw.pop("dependencies", None), partial=kw.pop("partial", False), timeout=kw.pop("timeout", 5))


def test_real_kill_and_recovery_cycle(tmp_path):
    control = GlobalControlPlane()
    cap, manifest = make_node(tmp_path, control, "kill", 19011, slow)
    import threading
    box = {}
    def run():
        try:
            box["resp"] = control.execute_capability(node_id="kill", capability=cap, handler=slow, manifest=manifest,
                                                      payload={"sleep": 4}, execution_id="kill-exec", idempotency_key="kill-idem", timeout=10)
        except Exception as exc:
            box["error"] = repr(exc)
    t = threading.Thread(target=run, daemon=True); t.start()
    for _ in range(30):
        if control.desired.get("kill-exec", {}).get("state") == "RUNNING": break
        time.sleep(.05)
    affected = control.kill_node("kill")
    t.join(2)
    assert "kill-exec" in affected
    assert control.observed["kill-exec"]["state"] == "RECOVERY_PENDING"
    control.restart_node("kill")
    rec = control.reconcile("kill-exec")
    assert rec["status"] in {"IN_SYNC", "DRIFT"}
    control.stop_all()


def test_transport_fault_matrix_is_observable_and_reversible(tmp_path):
    control = GlobalControlPlane()
    cap, manifest = make_node(tmp_path, control, "net", 19012)
    chaos = ChaosController(control)
    try:
        cases = [
            chaos.run("network_partition", node_id="net", case_id="partition"),
            chaos.run("packet_loss", node_id="net", case_id="loss"),
            chaos.run("packet_delay", node_id="net", case_id="delay"),
            chaos.run("delayed_delivery", node_id="net", case_id="delayed"),
            chaos.run("duplicate_delivery", node_id="net", case_id="duplicate",
                      execution_factory=lambda **kw: factory(control, "net", cap, manifest, **kw)),
            chaos.run("clock_skew", node_id="net", case_id="clock"),
            chaos.run("dependency_disappearance", node_id="net", case_id="dependency",
                      execution_factory=lambda **kw: factory(control, "net", cap, manifest, **kw)),
        ]
        assert all(c.result == "PASS" for c in cases)
        assert control.transport.partitioned == set()
        assert control.transport.drop_rate.get("net", 0.0) == 0.0
        assert control.transport.delay.get("net", 0.0) == 0.0
    finally:
        control.stop_all()


def test_storage_corruption_quarantines_and_restores(tmp_path):
    control = GlobalControlPlane()
    cap, manifest = make_node(tmp_path, control, "storage", 19013)
    try:
        first = factory(control, "storage", cap, manifest, idempotency_key="storage-idem", command_id="storage-cmd")
        assert first["result"]["status"] == "SUCCESS"
        control.corrupt_node_storage("storage")
        hb = control.heartbeat("storage")
        assert hb["storage_status"] == "CORRUPT" and hb["status"] == "QUARANTINED"
        restore = control.restore_node_storage("storage")
        assert restore["ok"]
        hb2 = control.heartbeat("storage")
        assert hb2["storage_status"] == "OK" and hb2["status"] == "HEALTHY"
    finally:
        control.stop_all()


def test_partial_completion_recovery_never_retries_implicitly(tmp_path):
    control = GlobalControlPlane()
    cap, manifest = make_node(tmp_path, control, "partial", 19014)
    try:
        with pytest.raises((ConnectionResetError, ConnectionError, OSError, TimeoutError)):
            factory(control, "partial", cap, manifest, partial=True, idempotency_key="partial-idem", command_id="partial-cmd")
        execution_id = next(e for e, v in control.desired.items() if v["idempotency_key"] == "partial-idem")
        assert control.desired[execution_id]["state"] == "RECOVERY_PENDING"
        control.restart_node("partial")
        rec = control.recover_execution(execution_id)
        assert rec["status"] == "RECOVERY_REQUIRED"
        assert rec["action"] == "COMPENSATE_OR_REVIEW"
    finally:
        control.stop_all()
