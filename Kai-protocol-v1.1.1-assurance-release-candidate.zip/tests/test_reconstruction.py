import unittest

from kai.pyramid.decomposition import ForwardPyramid
from kai.pyramid.reconstruction import ReconstructionEngine
from kai.pyramid.synthesis import Synthesizer


class ReconstructionTests(unittest.TestCase):
    def test_preserves_parts_but_flags_nonidentical_source_claim(self):
        f = ForwardPyramid.from_parts("root", "A and B", [{"unit_id":"a","claim":"A"},{"unit_id":"b","claim":"B"}])
        r = Synthesizer(f.graph).synthesize()
        s = Synthesizer(f.graph).add_synthesis_unit(r)
        report = ReconstructionEngine(f.graph).reconstruct(s.unit_id, "root")
        self.assertEqual(set(report.missing_units), set())
        self.assertEqual(set(report.extra_units), set())
        self.assertFalse(report.preserved)


if __name__ == "__main__":
    unittest.main()
