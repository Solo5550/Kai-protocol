import pytest

from kai.runtime import EvolutionProposal


def test_canary_gate_requires_health_and_evidence():
    p = EvolutionProposal("r1", "kai", "1.1.0", "1.1.1", risk=0.4)
    for stage in ("PROPOSAL", "CONTRACT_IMPACT", "COMPATIBILITY", "CONFORMANCE", "SHADOW"):
        p.advance(stage)
    with pytest.raises(ValueError, match="health_or_evidence_gate_failed"):
        p.advance("CANARY", health_ok=False, evidence_ok=True)
    assert p.status == "PROPOSAL"


def test_rollback_drill_reaches_rolled_back_terminal_state():
    p = EvolutionProposal("r2", "kai", "1.1.0", "1.1.1", risk=0.4)
    for stage in ("PROPOSAL", "CONTRACT_IMPACT", "COMPATIBILITY", "CONFORMANCE", "SHADOW", "CANARY", "LIMITED_ROLLOUT", "OBSERVATION", "VERIFICATION"):
        p.advance(stage, health_ok=True, evidence_ok=True)
    with pytest.raises(ValueError, match="health_or_evidence_gate_failed"):
        p.advance("PROMOTED", health_ok=False, evidence_ok=True)
    assert p.status == "ROLLED_BACK"
