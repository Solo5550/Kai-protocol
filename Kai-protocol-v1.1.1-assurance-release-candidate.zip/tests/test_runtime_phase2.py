import pytest

from kai.runtime.envelope import build_envelope, envelope_fingerprint, propagate_envelope
from kai.runtime.identity import IdentityContext, execution_from_identity


def test_root_identity_and_child_propagate_correlation():
    root = IdentityContext.root(tenant_id="t", namespace_id="n", actor_id="a")
    child = root.child(region_id="r2", cell_id="c2")
    assert child.run_id == root.run_id
    assert child.root_execution_id == root.execution_id
    assert child.parent_execution_id == root.execution_id
    assert child.trace_id == root.trace_id
    assert child.execution_id != root.execution_id
    assert child.region_id == "r2"


def test_execution_created_from_identity_preserves_root_lineage():
    root = IdentityContext.root()
    child = root.child()
    e = execution_from_identity(child, objective="x")
    assert e.execution_id == child.execution_id
    assert e.root_execution_id == root.execution_id
    assert e.parent_execution_id == root.execution_id


def test_envelope_propagation_cannot_drop_semantic_context():
    root = IdentityContext.root()
    env = build_envelope(identity=root, message_type="ExecutionCommand", idempotency_key="i", policy_snapshot_ref="p@1")
    with pytest.raises(ValueError):
        propagate_envelope(env, policy_snapshot_ref="other")
    child = propagate_envelope(env, status="RUNNING", attempt=2)
    assert child.execution_id == env.execution_id
    assert child.trace_id == env.trace_id
    assert child.policy_snapshot_ref == env.policy_snapshot_ref


def test_envelope_fingerprint_is_stable():
    root = IdentityContext.root()
    env = build_envelope(identity=root, message_type="ExecutionCommand", idempotency_key="i")
    assert envelope_fingerprint(env) == envelope_fingerprint(env)
