from __future__ import annotations

import pytest

from kai.skill import (
    Capability,
    EvolutionCortex,
    GateStatus,
    LifecycleController,
    LifecycleLevel,
    LifecycleViolation,
    KaiSkill,
    ProposalStatus,
    ReproductionEngine,
    SkillContract,
    SkillPipeline,
    SkillSandbox,
    SandboxPolicy,
)


def root() -> SkillContract:
    return SkillContract(
        skill_id="root",
        name="root",
        objective="test",
        capabilities=("base",),
        inputs=("x",),
        outputs=("y",),
        resource_budget={"cpu": 1.0},
        permission_boundary=("kai-dialogue",),
    )


def cap(name="base", *, risk=0.1, obs=1.0):
    return Capability("cap-" + name, name, "do " + name, ("x",), ("y",), risk_level=risk, observability=obs)


def test_skill_absorption_decomposition_and_gap():
    s = KaiSkill(root())
    s.absorb([cap()])
    assert [x.name for x in s.functional_decomposition()] == ["base"]
    gaps = s.gap_analysis(["base", "specialized"])
    assert len(gaps) == 1
    assert gaps[0].recommended_specialization == "specialized"


def test_forensic_reasoning_and_mutation_are_deterministic():
    s = KaiSkill(root())
    s.absorb([cap(obs=0.2)])
    a1 = s.analyze(["specialized"])
    a2 = s.analyze(["specialized"])
    assert a1 == a2
    assert any(x["category"] == "observability" for x in a1["stages"]["forensic_findings"])
    assert any(x.change == "raise-observability" for x in EvolutionCortex().propose_mutations(s.functional_decomposition(), s.gap_analysis(["specialized"])))


def test_reproduction_proposal_is_content_deterministic():
    s = KaiSkill(root())
    s.absorb([cap()])
    p1 = s.propose_reproduction("project", ["specialized"], "specialized", resources={"cpu": 0.25})
    p2 = s.propose_reproduction("project", ["specialized"], "specialized", resources={"cpu": 0.25})
    assert p1.to_dict() == p2.to_dict()
    assert p1.child_skill_id != p1.parent_skill_id


def test_reproduction_full_supervised_path_passes():
    pipeline = SkillPipeline(root())
    report = pipeline.run(
        project="demo",
        capabilities=[cap()],
        required_capabilities=["specialized"],
        specialization="specialized",
        handler=lambda payload: {"ok": True, "specialization": payload["specialization"]},
        requested_level=LifecycleLevel.L2_SANDBOX,
        resources={"cpu": 0.1},
        available_resources={"cpu": 1.0},
    )
    assert report.status == GateStatus.PASS
    assert report.cell is not None
    assert report.cell["status"] == ProposalStatus.ACTIVE.value
    assert report.cell["lifecycle_level"] == LifecycleLevel.L2_SANDBOX.value
    assert report.cell["review_history"][-1]["status"] == GateStatus.PASS.value


def test_l5_and_l6_are_fail_closed():
    pipeline = SkillPipeline(root())
    for level in (LifecycleLevel.L5_AUTONOMOUS_EXECUTION, LifecycleLevel.L6_ROOT_CHANGE):
        report = pipeline.run(
            project="demo",
            capabilities=[cap()],
            required_capabilities=["specialized"],
            specialization="specialized",
            handler=lambda _: {"ok": True},
            requested_level=level,
            resources={"cpu": 0.1},
        )
        assert report.status == GateStatus.BLOCKED
        assert report.cell is None


def test_sandbox_permission_and_output_limits_fail_closed():
    sandbox = SkillSandbox(SandboxPolicy(max_output_bytes=4))
    sandbox.register("small", lambda _: "ok")
    assert sandbox.run("small", {}, level=LifecycleLevel.L2_SANDBOX).status == "PASS"
    blocked = sandbox.run("missing", {}, level=LifecycleLevel.L2_SANDBOX)
    assert blocked.status == "BLOCKED"
    sandbox.register("large", lambda _: "12345")
    assert sandbox.run("large", {}, level=LifecycleLevel.L2_SANDBOX).status == "FAIL"
    with pytest.raises(Exception):
        sandbox.run("small", {}, level=LifecycleLevel.L0_OBSERVE)


def test_lifecycle_advances_and_rolls_back_safely():
    from kai.skill.models import SkillCell
    from kai.skill.models import ProposalStatus
    contract = SkillContract("child", "child", "x", ("x",), ("i",), ("o",), lifecycle_max=LifecycleLevel.L4_SUPERVISED_PROMOTION)
    cell = SkillCell(contract, "root", status=ProposalStatus.VALIDATED)
    controller = LifecycleController()
    assert controller.advance(cell, LifecycleLevel.L2_SANDBOX, approved=False).status == "ADVANCED"
    with pytest.raises(LifecycleViolation):
        controller.advance(cell, LifecycleLevel.L5_AUTONOMOUS_EXECUTION, approved=False)
    tr = controller.advance(cell, LifecycleLevel.L1_SIMULATE, approved=False)
    assert tr.status == "ROLLBACK_ALLOWED"
    assert cell.lifecycle_level == LifecycleLevel.L1_SIMULATE


def test_reproduction_cannot_birth_on_failed_checks():
    from kai.skill.models import CapabilityGap, ReproductionProposal
    from kai.skill.reproduction import ReproductionChecks
    e = ReproductionEngine()
    p = ReproductionProposal("p", "root", "child", "obj", "reason", "spec", (), ("g",), LifecycleLevel.L2_SANDBOX)
    checks = ReproductionChecks(False, True, True, True, True)
    with pytest.raises(PermissionError):
        e.birth(p, checks=checks, parent=root())


def test_evolution_mutations_never_authorize_l5_l6():
    assert EvolutionCortex.mutation_allowed(LifecycleLevel.L4_SUPERVISED_PROMOTION)
    assert not EvolutionCortex.mutation_allowed(LifecycleLevel.L5_AUTONOMOUS_EXECUTION)
    assert not EvolutionCortex.mutation_allowed(LifecycleLevel.L6_ROOT_CHANGE)

def test_l0_l1_do_not_create_child_cells():
    for level in (LifecycleLevel.L0_OBSERVE, LifecycleLevel.L1_SIMULATE):
        report = SkillPipeline(root()).run(
            project="observe",
            capabilities=[cap()],
            required_capabilities=["specialized"],
            specialization="specialized",
            handler=lambda _: {"ok": True},
            requested_level=level,
            resources={"cpu": 0.1},
        )
        assert report.status == GateStatus.PASS
        assert report.cell is None
        assert report.lifecycle_level == level


def test_l3_l4_are_bounded_active_levels():
    for level in (LifecycleLevel.L3_LIMITED_EXECUTION, LifecycleLevel.L4_SUPERVISED_PROMOTION):
        report = SkillPipeline(root()).run(
            project="bounded",
            capabilities=[cap()],
            required_capabilities=["specialized"],
            specialization="specialized",
            handler=lambda _: {"ok": True},
            requested_level=level,
            resources={"cpu": 0.1},
        )
        assert report.status == GateStatus.PASS
        assert report.cell["status"] == ProposalStatus.ACTIVE.value
        assert report.cell["lifecycle_level"] == level.value
