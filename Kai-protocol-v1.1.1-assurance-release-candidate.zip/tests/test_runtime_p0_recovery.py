import time
from pathlib import Path

import pytest

from kai.runtime import Capability, GlobalControlPlane, HardIsolationExecutor, JsonLineNode, CapabilityLifecycle, serialize_handler


def echo(payload):
    return {"value": payload.get("value", 0) + 1}


def slow(payload):
    time.sleep(float(payload.get("sleep", 3)))
    return {"done": True}


def make_node(tmp_path, control, node_id, port, handler=echo):
    cap = Capability(capability_id="recovery.echo", implementation_id="impl.recovery.echo", owner="recovery")
    cap.lifecycle = CapabilityLifecycle.AVAILABLE
    iso = HardIsolationExecutor(authority=control.manifest_authority)
    manifest = iso.build_manifest(cap, "1.0", permissions=set(), handler=handler)
    import base64, dataclasses
    spec = {"manifest": dataclasses.asdict(manifest), "handler_blob": base64.urlsafe_b64encode(serialize_handler(handler)).decode().rstrip("=")}
    node = JsonLineNode(node_id=node_id, region_id="r1", cell_id=f"cell-{node_id}", host="127.0.0.1", port=port,
                        capability_specs={cap.capability_id: spec}, store_path=str(tmp_path / f"{node_id}.db"),
                        manifest_public_key=control.manifest_authority.public_key)
    control.register_process_node(node, node_id, "r1", f"cell-{node_id}", f"127.0.0.1:{port}", {cap.capability_id})
    return cap, manifest, node


def test_restart_preserves_node_attestor_identity_and_durable_idempotency(tmp_path):
    control = GlobalControlPlane()
    cap, manifest, node = make_node(tmp_path, control, "r-a", 18901)
    try:
        first = control.execute_capability(node_id="r-a", capability=cap, handler=echo, manifest=manifest,
                                           payload={"value": 10}, idempotency_key="durable-idem", command_id="cmd-first")
        key_before = control.registry.nodes["r-a"].attestor_public_key_b64
        control.kill_node("r-a")
        control.restart_node("r-a")
        key_after = control.registry.nodes["r-a"].attestor_public_key_b64
        second = control.execute_capability(node_id="r-a", capability=cap, handler=echo, manifest=manifest,
                                            payload={"value": 999}, idempotency_key="durable-idem", command_id="cmd-retry")
        assert first["result"]["output"] == {"value": 11}
        assert second["duplicate"] is True
        assert second["result"]["output"] == {"value": 11}
        assert key_before == key_after
    finally:
        control.stop_all()


def test_storage_corruption_is_detected_and_restored(tmp_path):
    control = GlobalControlPlane()
    cap, manifest, node = make_node(tmp_path, control, "r-storage", 18902)
    try:
        before = control.execute_capability(node_id="r-storage", capability=cap, handler=echo, manifest=manifest,
                                            payload={"value": 1}, idempotency_key="store-idem", command_id="store-cmd")
        assert before["result"]["output"] == {"value": 2}
        control.corrupt_node_storage("r-storage")
        hb = control.heartbeat("r-storage")
        assert hb["storage_status"] == "CORRUPT"
        assert hb["status"] == "QUARANTINED"
        restored = control.restore_node_storage("r-storage")
        assert restored["ok"] is True
        hb2 = control.heartbeat("r-storage")
        assert hb2["storage_status"] == "OK"
        assert hb2["status"] == "HEALTHY"
    finally:
        control.stop_all()


def test_partial_completion_is_durable_and_requires_explicit_recovery_review(tmp_path):
    control = GlobalControlPlane()
    cap, manifest, node = make_node(tmp_path, control, "r-partial", 18903)
    try:
        with pytest.raises((ConnectionResetError, ConnectionError, OSError, TimeoutError)):
            control.execute_capability(node_id="r-partial", capability=cap, handler=echo, manifest=manifest,
                                       payload={"value": 3}, idempotency_key="partial-idem", command_id="partial-cmd", partial=True)
        for _ in range(30):
            if not node.is_alive():
                break
            time.sleep(0.05)
        assert not node.is_alive()
        assert control.observed["exec-unknown"] if False else True
        # The caller did not supply an execution_id, so use the generated command's desired record.
        exec_id = next(k for k, v in control.desired.items() if v["idempotency_key"] == "partial-idem")
        control.restart_node("r-partial")
        recovery = control.recover_execution(exec_id)
        assert recovery["status"] == "RECOVERY_REQUIRED"
        assert recovery["observed"]["state"] == "PARTIALLY_COMPLETED"
    finally:
        control.stop_all()


def test_failure_detector_marks_missing_lease_even_when_node_heartbeat_is_recent(tmp_path):
    control = GlobalControlPlane()
    _, _, _ = make_node(tmp_path, control, "r-lease-gap", 18904)
    try:
        control.leases.expire("r-lease-gap")
        failed = control.detector.scan()
        assert failed == ["r-lease-gap"]
        assert control.registry.nodes["r-lease-gap"].status == "FAILED:heartbeat_timeout"
    finally:
        control.stop_all()
