import pytest

from kai.runtime import EffectLedger, FailureCategory, FailureEngine, RecoveryEngine, ReplayEngine, RetryController, RuntimeStore


def test_effect_ledger_prevents_duplicate_external_effect():
    store = RuntimeStore(); ledger = EffectLedger(store)
    e1, dup1 = ledger.begin(execution_id="e1", idempotency_key="k", target="db", operation="write", request={"x": 1}, authorization_ref="auth", policy_ref="p@1")
    e2, dup2 = ledger.begin(execution_id="e2", idempotency_key="k", target="db", operation="write", request={"x": 1}, authorization_ref="auth", policy_ref="p@1")
    assert not dup1 and dup2 and e1["effect_id"] == e2["effect_id"]
    with pytest.raises(ValueError):
        ledger.begin(execution_id="e3", idempotency_key="k", target="db", operation="write", request={"x": 2}, authorization_ref="auth", policy_ref="p@1")


def test_retry_controller_is_bounded_and_exponential():
    r = RetryController(max_attempts=3, base_delay=0.01)
    d1 = r.decide(1, retryable=True); d2 = r.decide(2, retryable=True); d3 = r.decide(3, retryable=True)
    assert d1.retry and d2.delay_seconds >= d1.delay_seconds
    assert not d3.retry


def test_failure_reverse_engineering_produces_system_change():
    store = RuntimeStore(); f = FailureEngine(store).capture(execution_id="e", state="TIMED_OUT", category=FailureCategory.TIMEOUT, severity="high", symptom="slow", trigger="deadline", root_cause="dependency latency")
    report = FailureEngine(store).reverse_engineer(f)
    assert "SYSTEM_CHANGE" in report["steps"] and "regression_test" in report["system_changes"]
    assert RecoveryEngine().recover(failure=f, allow_retry=True, allow_compensation=False)["action"] == "RETRY"


def test_replay_never_reexecutes_external_side_effects():
    result = ReplayEngine().replay({"execution": {"execution_id": "e"}, "events": []}, mode="RECONSTRUCTION_ONLY")
    assert result["reexecute_external_effects"] is False
