from __future__ import annotations

import json
from pathlib import Path

import pytest

from kai.maintenance import (
    FailureClass, GateStatus, MaintenanceMode, MaintenancePolicyError, MaintenanceProtocol,
    RootCauseStatus, RepairStatus, QualificationStatus, analyze_alternatives, freeze_oracle, validate_oracle_integrity,
)
from kai.maintenance.archaeology import ArchaeologyScanner


def test_protocol_is_independent_from_execution_capability_surface():
    import kai.maintenance.protocol as protocol
    names = [n for n in dir(protocol.MaintenanceProtocol) if not n.startswith("_")]
    assert "execute" not in names and "submit" not in names
    assert FailureClass.ARCHITECTURE.value == "ARCHITECTURE"


def test_no_patching_rule_rejects_symptom_masking(tmp_path):
    p = MaintenanceProtocol(tmp_path)
    with pytest.raises(MaintenancePolicyError):
        p.reject_patch("increase timeout inflation to conceal error")


def test_oracle_is_frozen_and_tamper_evident():
    oracle = freeze_oracle(oracle_id="o", expected_result="PASS", invariants=["x"], thresholds={"p99": 10})
    assert validate_oracle_integrity(oracle)
    assert not validate_oracle_integrity(type(oracle)(oracle.oracle_id, "FAIL", oracle.invariants, oracle.thresholds, oracle.frozen_digest))


def test_alternative_analysis_returns_pareto_sets():
    result = analyze_alternatives([
        __import__("kai.maintenance", fromlist=["Alternative"]).Alternative("a", "a", {"correctness": 1, "complexity": 0.2}),
        __import__("kai.maintenance", fromlist=["Alternative"]).Alternative("b", "b", {"correctness": 0.8, "complexity": 0.8}),
        __import__("kai.maintenance", fromlist=["Alternative"]).Alternative("c", "c", {"correctness": 1, "complexity": 0.9}),
    ])
    assert "a" in result.nondominated and "c" in result.dominated


def test_archaeology_runs_without_execution(tmp_path):
    src = tmp_path / "src" / "x"
    src.mkdir(parents=True)
    (src / "a.py").write_text("def a():\n    return 1\n", encoding="utf-8")
    report = ArchaeologyScanner().scan(tmp_path)
    assert report.drift_count >= 0


def test_detect_and_reconstruct_handler_bypass_finding(tmp_path):
    src = tmp_path / "src" / "kai" / "runtime"
    src.mkdir(parents=True)
    (src / "runtime.py").write_text(
        "binding = self.resolver.resolve(...)\nself.kernel.run_authorized(execution=execution, contract=contract, handler=handler, timeout=timeout)\n",
        encoding="utf-8",
    )
    p = MaintenanceProtocol(tmp_path)
    p.baseline()
    p.inspect()
    finding = next(f for f in p.findings if f.finding_id == "KAI-RC-0001")
    assert finding.severity == "CRITICAL"
    p.create_cases()
    case_id = p.cases[0].case_id
    reconstruction = p.reconstruct_root_cause(case_id, evidence_refs=["adversarial:handler-substitution"])
    assert reconstruction["status"] == RootCauseStatus.IDENTIFIED.value
    assert p.cases[0].root_cause_status is RootCauseStatus.IDENTIFIED


def test_maintenance_local_battery_passes_after_authority_repair():
    root = Path(__file__).parents[1]
    p = MaintenanceProtocol(root)
    p.baseline()
    p.inspect()
    assert all(f.finding_id != "KAI-RC-0001" for f in p.findings)



def test_report_contains_all_protocol_sections_and_formal_acceptance_is_conservative():
    from kai.maintenance import GateResult, MaintenanceReport, QualificationStatus, coverage
    root = Path(__file__).parents[1]
    p = MaintenanceProtocol(root)
    baseline = p.baseline()
    required = ["STATIC", "REGRESSION", "FORWARD", "REVERSE", "ADVERSARIAL", "DIFFERENTIAL", "PERFORMANCE", "RECOVERY", "SECURITY", "PROVENANCE", "INTEGRATION_COMPATIBILITY", "REPRODUCIBILITY", "TEST_ORACLE", "CHANGE_GOVERNANCE", "STABILITY_OBSERVATION", "CONCURRENCY", "RESOURCE_LEAK", "MAINTAINABILITY"]
    gates = tuple(GateResult(g, GateStatus.PASS, "synthetic", evidence_refs=(f"e:{g}",)) for g in required) + (GateResult("INDEPENDENT_QUALIFICATION", GateStatus.BLOCKED, "no independent verifier", evidence_refs=("qualification:independent",)),)
    report = MaintenanceReport(protocol_version="maintenance/1.0", system="Kai", mode=MaintenanceMode.TARGETED, baseline=baseline, findings=tuple(), cases=tuple(), gates=gates, test_results=tuple(), capa_actions=tuple(), knowledge_updates=tuple(), qualification=QualificationStatus.CONDITIONALLY_QUALIFIED, evidence_bundle_complete=True, observation_window_complete=True, limitations=tuple(), coverage=tuple(c.__dict__ for c in coverage()))
    assert len(report.coverage) == 47
    assert not p.stage_accepted(report)



def test_historical_case_cannot_close_without_independent_qualification():
    from kai.maintenance import GateResult, MaintenanceReport, QualificationStatus, coverage
    root = Path(__file__).parents[1]
    p = MaintenanceProtocol(root)
    p.baseline()
    case = p.import_historical_finding(finding_id="KAI-RC-TEST", title="historic critical", component="fixture", severity="CRITICAL", failure_class=FailureClass.CODE, symptom="x", trigger="y", evidence_refs=["before:test"])
    p.repair_record(case.case_id, evidence_refs=["after:test"])
    required = ["STATIC", "REGRESSION", "FORWARD", "REVERSE", "ADVERSARIAL", "DIFFERENTIAL", "PERFORMANCE", "RECOVERY", "SECURITY", "PROVENANCE", "INTEGRATION_COMPATIBILITY", "REPRODUCIBILITY", "STABILITY_OBSERVATION", "CONCURRENCY", "RESOURCE_LEAK", "MAINTAINABILITY"]
    gates = tuple(GateResult(g, GateStatus.PASS, "synthetic", evidence_refs=(f"e:{g}",)) for g in required) + (GateResult("INDEPENDENT_QUALIFICATION", GateStatus.BLOCKED, "no independent verifier", evidence_refs=("qualification:independent",)),)
    report = MaintenanceReport(protocol_version="maintenance/1.0", system="Kai", mode=MaintenanceMode.FULL_RED_TEAM, baseline=p._baseline, findings=tuple(p.findings), cases=(case,), gates=gates, test_results=tuple(), capa_actions=tuple(p.capa), knowledge_updates=tuple(), qualification=QualificationStatus.CONDITIONALLY_QUALIFIED, evidence_bundle_complete=True, observation_window_complete=True, limitations=tuple(), coverage=tuple(c.__dict__ for c in coverage()))
    assert not p.close_case(case.case_id, report)





def test_repair_record_updates_finding_and_case_status(tmp_path):
    p = MaintenanceProtocol(tmp_path)
    p.baseline()
    case = p.import_historical_finding(
        finding_id="KAI-RC-TEST-REPAIR",
        title="historic repair",
        component="fixture",
        severity="HIGH",
        failure_class=FailureClass.CODE,
        symptom="x",
        trigger="y",
        evidence_refs=["before:test"],
    )
    p.repair_record(case.case_id, evidence_refs=["after:repair"])
    assert p.findings[0].repair_status is RepairStatus.ROOT_CAUSE_REMEDIATION
    assert case.repair_status is RepairStatus.ROOT_CAUSE_REMEDIATION
    assert "after:repair" in p.findings[0].evidence_refs
    assert "after:repair" in case.evidence_refs


def test_report_materializes_test_results_for_every_gate(tmp_path):
    from kai.maintenance.models import Baseline
    p = MaintenanceProtocol(tmp_path)
    baseline = p.baseline()
    gates = (
        __import__("kai.maintenance", fromlist=["GateResult"]).GateResult("STATIC", GateStatus.PASS, "ok", evidence_refs=("e:static",)),
        __import__("kai.maintenance", fromlist=["GateResult"]).GateResult("INDEPENDENT_QUALIFICATION", GateStatus.BLOCKED, "blocked", evidence_refs=("e:ind",)),
    )
    # Exercise the serialization contract through the real report type.
    report = __import__("kai.maintenance", fromlist=["MaintenanceReport"]).MaintenanceReport(
        protocol_version="maintenance/1.0", system="Kai", mode=MaintenanceMode.TARGETED,
        baseline=baseline, findings=tuple(), cases=tuple(), gates=gates,
        test_results=tuple(__import__("kai.maintenance", fromlist=["TestResult"]).TestResult(
            test_id=f"gate:{g.gate_id}", category=g.gate_id, status=g.status,
            expected="PASS_OR_BLOCKED", actual=g.status.value, evidence_refs=g.evidence_refs,
        ) for g in gates), capa_actions=tuple(), knowledge_updates=tuple(),
        qualification=QualificationStatus.CONDITIONALLY_QUALIFIED, evidence_bundle_complete=True,
        observation_window_complete=False, limitations=tuple(), coverage=tuple(c.__dict__ for c in p.coverage()),
    )
    data = report.to_dict()
    assert len(data["test_results"]) == len(gates)
    assert [x["category"] for x in data["test_results"]] == ["STATIC", "INDEPENDENT_QUALIFICATION"]
