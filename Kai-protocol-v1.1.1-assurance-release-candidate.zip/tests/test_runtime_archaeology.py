from pathlib import Path


def test_phase0_inventory_exists_and_names_baseline_domains():
    doc = Path(__file__).parents[1] / "docs" / "RUNTIME-ARCHAEOLOGY.md"
    text = doc.read_text(encoding="utf-8")
    for token in ("kai.protocol", "kai.language", "kai.security", "kai.skill", "kai.master", "kai.pyramid", "kai.storage"):
        assert token in text
    assert "single authoritative execution runtime" in text
