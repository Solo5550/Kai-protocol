import pytest

from kai.runtime import Execution, ExecutionKernel, ExecutionState, RuntimeStore


def persist_at(store, execution, target_state):
    from kai.runtime.contracts import TRANSITIONS, TransitionEngine
    # Drive only via TransitionEngine/authoritative store.
    engine = TransitionEngine()
    paths = {
        ExecutionState.ADMITTED: [("CONTRACT_VALIDATED"), ("ADMIT")],
        ExecutionState.TIMED_OUT: [("CONTRACT_VALIDATED"), ("ADMIT"), ("EXECUTION_STARTED"), ("EXECUTION_TIMED_OUT")],
        ExecutionState.FAILED: [("CONTRACT_VALIDATED"), ("ADMIT"), ("EXECUTION_STARTED"), ("EXECUTION_FAILED")],
    }
    store.create_execution(execution)
    for event in paths[target_state]:
        expected = execution.state_version
        engine.transition(execution, event, required_state_version=expected)
        store.transition_persist(execution, expected_state_version=expected, event_type=event)
    return execution


def test_cancel_transitions_are_explicit():
    store = RuntimeStore(); ex = persist_at(store, Execution(execution_id="e", run_id="r", objective="x"), ExecutionState.ADMITTED)
    ex = ExecutionKernel(store=store).cancel(ex)
    assert ex.state is ExecutionState.CANCELLED
    states = [e["payload"].get("state") for e in store.events("e")]
    assert "CANCEL_REQUESTED" in states and "CANCELLED" in states


def test_recovery_and_retry_are_state_governed():
    store = RuntimeStore(); kernel = ExecutionKernel(store=store)
    ex = persist_at(store, Execution(execution_id="e", run_id="r", objective="x"), ExecutionState.FAILED)
    recovered = kernel.recover(ex)
    assert recovered.state is ExecutionState.RECOVERED
    retried = kernel.retry(recovered)
    assert retried.state is ExecutionState.ADMITTED
    assert retried.attempt == 2


def test_recover_rejects_non_failure_state():
    store = RuntimeStore(); ex = Execution(execution_id="e", run_id="r", objective="x")
    store.create_execution(ex)
    with pytest.raises(Exception):
        ExecutionKernel(store=store).recover(ex)
