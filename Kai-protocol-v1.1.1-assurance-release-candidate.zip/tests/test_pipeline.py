import unittest
from kai.engine.pipeline import AssurancePipeline

class PipelineTests(unittest.TestCase):
    def test_end_to_end(self):
        report = AssurancePipeline().run(
            source_id='root',
            source_claim='(A) AND (B)',
            parts=[
                {'unit_id':'a','claim':'A','evidence':{'statement':'EA','source_id':'sa'},'test':{'kind':'property','expected':True,'result':{'status':'PASS','actual':True}}},
                {'unit_id':'b','claim':'B','evidence':{'statement':'EB','source_id':'sb'},'test':{'kind':'property','expected':True,'result':{'status':'PASS','actual':True}}}
            ],
            criterion_ok=True,
            criterion_name='component_property_preservation'
        )
        self.assertEqual(report.verdict.value, 'ACCEPTED')
        self.assertEqual(report.reconstruction_fidelity, 1.0)

if __name__ == '__main__':
    unittest.main()
