from __future__ import annotations

from kai.skill import Capability, LifecycleLevel, SkillContract, SkillPipeline


def test_skill_contract_serialization_preserves_lifecycle_boundary():
    c = SkillContract("s", "s", "o", ("a",), ("i",), ("o",), lifecycle_max=LifecycleLevel.L4_SUPERVISED_PROMOTION)
    d = c.to_dict()
    assert d["lifecycle_max"] == "L4_SUPERVISED_PROMOTION"
    assert "root-source-mutation" not in d["capabilities"]


def test_reference_pipeline_is_repeatable():
    def run():
        p = SkillPipeline()
        return p.run(
            project="reference",
            capabilities=[Capability("c1", "base", "base", ("x",), ("y",))],
            required_capabilities=["specialized"],
            specialization="specialized",
            handler=lambda _: {"value": 7},
            resources={"cpu": 0.1},
        ).to_dict()
    assert run() == run()
