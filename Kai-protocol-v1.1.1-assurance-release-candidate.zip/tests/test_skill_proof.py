from kai.skill import GateStatus, SkillProofEngine


def test_proof_engine_requires_all_declared_tests():
    engine = SkillProofEngine()
    results = {name: True for name in engine.TESTS}
    checks = engine.review(results)
    assert len(checks) == 12
    assert engine.promotable(checks)


def test_proof_engine_unresolved_missing_required_test():
    engine = SkillProofEngine()
    checks = engine.review({"unit": True}, required=["unit", "security"])
    by_name = {c.name: c for c in checks}
    assert by_name["unit"].status == GateStatus.PASS
    assert by_name["security"].status == GateStatus.UNRESOLVED
    assert not engine.promotable(checks)
