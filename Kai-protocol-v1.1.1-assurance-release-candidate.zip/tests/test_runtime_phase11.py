import pytest

from kai.runtime import Cell, FederationManager, PlacementEngine, PlacementRequest, PolicyDriftGuard, Region, SafeModeController, SafeModePolicy, Scheduler, SovereigntyError


def regions():
    r1 = Region("eu"); r1.add_cell(Cell("eu-1", "eu", capacity_units=10, capability_ids={"inspect"}))
    r2 = Region("us"); r2.add_cell(Cell("us-1", "us", capacity_units=10, capability_ids={"inspect"}))
    return {"eu": r1, "us": r2}


def test_placement_is_capability_aware_and_policy_constrained():
    rs = regions(); p = PlacementEngine(rs)
    d = p.select(PlacementRequest("e", "inspect", allowed_regions=("eu",), data_region="eu"), policy_ref="p@1", capability_ref="inspect@1")
    assert (d.selected_region, d.selected_cell) == ("eu", "eu-1")


def test_placement_rejects_forbidden_cross_region_processing():
    rs = regions()
    with pytest.raises(SovereigntyError):
        PlacementEngine(rs).select(PlacementRequest("e", "inspect", allowed_regions=("us",), data_region="eu", processing_regions=("eu",)), policy_ref="p@1", capability_ref="inspect@1")


def test_scheduler_reconciles_desired_and_actual_state():
    rs = regions(); d = PlacementEngine(rs).select(PlacementRequest("e", "inspect"), policy_ref="p", capability_ref="c")
    s = Scheduler(rs); s.set_desired(d); s.observe_actual("e", "us", "us-1")
    assert s.reconcile("e") == (d.selected_region, d.selected_cell)


def test_policy_drift_blocks_affected_operations():
    g = PolicyDriftGuard()
    assert g.ensure(local_version="1", required_version="2") == "BLOCKED_DRIFT"
    assert g.ensure(local_version="1", required_version="2", affected=False) == "IN_SYNC"


def test_regional_autonomy_is_bounded_by_signed_snapshot_intent():
    rs = regions(); f = FederationManager(rs)
    f.publish_snapshot("eu", {"version": "2", "allowed_capabilities": ["inspect"], "safe_mode": True})
    f.set_global_available(False)
    assert f.can_continue(region_id="eu", capability_id="inspect", side_effect=False)
    assert not f.can_continue(region_id="eu", capability_id="inspect", side_effect=True)


def test_safe_mode_does_not_become_normal_mode():
    c = SafeModeController(SafeModePolicy(allowed_operations={"inspect"}, forbidden_operations={"write"}, max_execution_duration=5, allowed_capabilities={"inspect"}))
    c.enter()
    assert c.authorize(operation="inspect", capability_id="inspect")
    assert not c.authorize(operation="write", capability_id="inspect")
