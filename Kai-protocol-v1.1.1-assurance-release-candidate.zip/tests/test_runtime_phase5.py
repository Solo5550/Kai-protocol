import os

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from kai.runtime import Capability, CapabilityLifecycle, CapabilityRegistry, CapabilityResolver, Contract, Execution, IdentityContext, PolicyEngine, Policy, sign_policy, verify_policy


def handler(payload):
    return {"ok": True, "value": payload.get("value", 0)}


def make_cap(**kw):
    return Capability(capability_id="inspect.metrics", implementation_id="impl.local", owner="ops", purpose="inspect", **kw)


def test_capability_registration_qualification_and_resolution():
    reg = CapabilityRegistry()
    cap = make_cap()
    reg.discover(cap, handler)
    assert cap.lifecycle is CapabilityLifecycle.DISCOVERED
    reg.register(cap.capability_id)
    q = reg.qualify(cap.capability_id)
    assert q["passed"]
    assert cap.lifecycle is CapabilityLifecycle.AVAILABLE
    binding = CapabilityResolver(reg).resolve(requirement={"capability_id": "inspect.metrics"}, contract=Contract(id="c", version="1"), region_id="r1", cell_id="c1")
    assert binding.implementation_id == "impl.local"


def test_quarantined_capability_is_not_resolved():
    reg = CapabilityRegistry()
    cap = make_cap()
    reg.discover(cap, handler); reg.register(cap.capability_id); reg.qualify(cap.capability_id)
    reg.quarantine(cap.capability_id, reason="bad verification")
    with pytest.raises(LookupError):
        CapabilityResolver(reg).resolve(requirement={"capability_id": "inspect.metrics"}, contract=Contract(id="c", version="1"), region_id="r", cell_id="c")


def test_policy_explicit_permission_and_external_effect_gate():
    engine = PolicyEngine()
    cap = Capability(capability_id="write", implementation_id="i", owner="o", side_effect_class="external_write", required_permissions=["effect:write"])
    ex = Execution(execution_id="e", objective="x", region_id="r")
    pol = Policy(policy_id="p", allowed_capabilities=["write"], allowed_regions=["r"], required_permissions=[], side_effect_policy={"execute": False})
    d = engine.decide(execution=ex, capability=cap, policy=pol, permissions={"effect:write"})
    assert not d.allowed
    assert d.reason == "external_effect_not_authorized"
    pol.side_effect_policy["execute"] = True
    d2 = engine.decide(execution=ex, capability=cap, policy=pol, permissions={"effect:write"})
    assert d2.allowed and d2.effect_authorized


def test_signed_policy_snapshot_detects_tampering():
    private = Ed25519PrivateKey.generate()
    private_raw = private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    public_raw = private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    signed = sign_policy(Policy(policy_id="p", allowed_capabilities=["x"]), private_raw, issuer="authority")
    assert verify_policy(signed, public_raw)
    signed.allowed_capabilities.append("tampered")
    assert not verify_policy(signed, public_raw)
