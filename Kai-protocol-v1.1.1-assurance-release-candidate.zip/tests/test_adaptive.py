import unittest
from kai.engine.adaptive import AdaptiveDepthController, DepthSignals

class AdaptiveTests(unittest.TestCase):
    def test_high_risk_gets_more_depth(self):
        low = AdaptiveDepthController().choose(DepthSignals())
        high = AdaptiveDepthController().choose(DepthSignals(1,1,1,1,1,1,1,1,1))
        self.assertLess(low.depth, high.depth)

if __name__ == '__main__':
    unittest.main()
