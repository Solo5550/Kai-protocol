from pathlib import Path

import pytest

from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction, MessageType
from kai.storage import MessageJournal, JournalError


def make_messages(n=3):
    factory = MessageFactory(actor="journal-test")
    return [factory.create(
        unit_id=f"u-{i}", round=1, layer=1, direction=Direction.HORIZONTAL,
        type=MessageType.CLAIM,
        payload={"claim": f"c-{i}"}, parents=["root"],
        provenance={"actor": "test"}) for i in range(n)]


def test_journal_roundtrip_and_checkpoint(tmp_path: Path):
    path = tmp_path / "messages.kj1"
    msgs = make_messages(10)
    with MessageJournal(path, checkpoint_interval_messages=2) as journal:
        assert journal.extend(msgs, batch_size=4) == 10
        assert journal.count == 10
        assert journal.bytes_written > 0
    assert path.with_suffix(path.suffix + ".cp").exists()
    with MessageJournal(path, checkpoint_interval_messages=2) as reopened:
        assert reopened.count == 10
        ids = [d["message_id"] for d in reopened.iter_messages()]
    assert ids == [m.message_id for m in msgs]


def test_journal_stale_checkpoint_replays_tail(tmp_path: Path):
    path = tmp_path / "messages.kj1"
    msgs = make_messages(5)
    with MessageJournal(path, checkpoint_interval_messages=2) as journal:
        journal.extend(msgs[:2], batch_size=2)
        journal.checkpoint()
    # Simulate a crash after journal bytes landed but before the next checkpoint.
    with MessageJournal(path, checkpoint_interval_messages=1000) as journal:
        journal.extend(msgs[2:], batch_size=3)
        journal.flush()
        assert journal.count == 5
        # Do not close cleanly in this simulated stale-checkpoint window.
        journal._fh.close()
        journal._fh = None
    with MessageJournal(path, checkpoint_interval_messages=1000) as reopened:
        assert reopened.count == 5


def test_journal_rejects_bad_header(tmp_path: Path):
    path = tmp_path / "bad.kj1"
    path.write_bytes(b"NOPE")
    with pytest.raises(JournalError):
        MessageJournal(path)

def test_journal_invalid_checkpoint_falls_back_safely(tmp_path: Path):
    path = tmp_path / "messages.kj1"
    msgs = make_messages(4)
    with MessageJournal(path, checkpoint_interval_messages=2) as journal:
        journal.extend(msgs, batch_size=4)
    cp = path.with_suffix(path.suffix + ".cp")
    cp.write_text('{"magic":"KAI-JOURNAL-CP/1","journal_name":"messages.kj1","offset":999999,"count":4,"bytes":4}', encoding="utf-8")
    with MessageJournal(path, checkpoint_interval_messages=2) as reopened:
        assert reopened.count == 4


def test_journal_truncated_tail_fails_closed(tmp_path: Path):
    path = tmp_path / "messages.kj1"
    msgs = make_messages(2)
    with MessageJournal(path, checkpoint_interval_messages=2) as journal:
        journal.extend(msgs, batch_size=2)
    raw = path.read_bytes()
    path.write_bytes(raw[:-3])
    with pytest.raises(JournalError):
        MessageJournal(path, checkpoint_interval_messages=2)
