from kai.runtime import ArtifactStore, ObservationBus, ProvenanceEngine, RuntimeStore
from kai.runtime.observability import ObservabilityRecord


def test_artifact_store_is_content_addressed_and_immutable(tmp_path):
    store = RuntimeStore(); artifacts = ArtifactStore(tmp_path / "artifacts", store)
    a1 = artifacts.put(b"hello", artifact_type="text", producer_execution_id="e1")
    a2 = artifacts.put(b"hello", artifact_type="text", producer_execution_id="e2")
    assert a1.artifact_id == a2.artifact_id
    assert artifacts.read(a1) == b"hello"


def test_provenance_records_derivation_and_lineage():
    store = RuntimeStore(); prov = ProvenanceEngine(store)
    edge = prov.derive("source-1", "artifact-1", activity_id="exec-1", agent_id="agent-1")
    assert edge.from_id == "source-1" and edge.to_id == "artifact-1"
    assert prov.lineage("artifact-1")


def test_observation_bus_provides_golden_path_query():
    store = RuntimeStore(); store.create_execution(__import__("kai.runtime", fromlist=["Execution"]).Execution(execution_id="e", run_id="r"))
    bus = ObservationBus(store)
    bus.emit("e", "TEST", ObservabilityRecord(execution_id="e", trace_id="t", span_id="s", state="RUNNING", event="TEST", attempt=1))
    gp = bus.golden_path("e")
    assert gp["event_count"] >= 2
