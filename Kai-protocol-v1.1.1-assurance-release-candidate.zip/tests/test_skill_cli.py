import json
from pathlib import Path

from kai.cli import main


def test_skill_cli_reference_run(capsys):
    path = Path(__file__).parents[1] / "examples" / "skill_pipeline.json"
    assert main(["skill-run", str(path)]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["status"] == "PASS"
    assert out["cell"]["status"] == "ACTIVE"


def test_skill_cli_blocks_l5(tmp_path, capsys):
    path = tmp_path / "l5.json"
    data = {
        "project": "demo",
        "capabilities": [{"capability_id": "c", "name": "base", "objective": "x", "inputs": ["i"], "outputs": ["o"]}],
        "required_capabilities": ["specialized"],
        "specialization": "specialized",
        "requested_level": "L5_AUTONOMOUS_EXECUTION",
        "resources": {"cpu": 0.1},
        "available_resources": {"cpu": 1.0},
    }
    path.write_text(json.dumps(data), encoding="utf-8")
    assert main(["skill-run", str(path)]) == 2
    out = json.loads(capsys.readouterr().out)
    assert out["status"] == "BLOCKED"
