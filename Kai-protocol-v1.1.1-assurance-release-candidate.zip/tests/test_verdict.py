import unittest

from kai.protocol.models import GateResult, GateStatus, Unit, Verdict
from kai.protocol.verdict import REQUIRED_GATES, VerdictEngine


class VerdictTests(unittest.TestCase):
    def _unit(self, state="VERIFIED", statuses=None):
        statuses = statuses or [GateStatus.PASS] * len(REQUIRED_GATES)
        u = Unit(unit_id="u", claim="c", state=state)
        u.gates = [GateResult(g, s) for g, s in zip(REQUIRED_GATES, statuses)]
        return u

    def test_accept(self):
        self.assertEqual(VerdictEngine().evaluate(self._unit()), Verdict.ACCEPTED)

    def test_fail_closed(self):
        statuses = [GateStatus.PASS] * len(REQUIRED_GATES)
        statuses[0] = GateStatus.FAIL
        self.assertEqual(VerdictEngine().evaluate(self._unit(statuses=statuses)), Verdict.REJECTED)

    def test_unresolved(self):
        statuses = [GateStatus.PASS] * len(REQUIRED_GATES)
        statuses[-1] = GateStatus.UNRESOLVED
        self.assertEqual(VerdictEngine().evaluate(self._unit(statuses=statuses)), Verdict.UNRESOLVED)


if __name__ == "__main__":
    unittest.main()
