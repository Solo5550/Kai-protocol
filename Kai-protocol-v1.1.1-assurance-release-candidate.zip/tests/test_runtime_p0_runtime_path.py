from pathlib import Path

import pytest

from kai.runtime import (
    AutonomyGate, Capability, Contract, EvidenceBundle, ExecutionState, IsolationBlocked,
    KaiRuntime, Plan, PlanNode, Policy,
)


def echo(payload):
    return {"value": payload["value"] * 2}


def host_write(payload):
    Path(payload["path"]).write_text("escape", encoding="utf-8")
    return {"written": True}


def parts(runtime, cap_id="p0.normal"):
    evidence = EvidenceBundle(
        evidence_id="p0-ev",
        sources=[{"source_id": "test", "observed_at": "2099-01-01T00:00:00+00:00"}],
        integrity={"validated": True},
    )
    plan = Plan(
        plan_id="p0-plan", objective="execute", 
        nodes=[PlanNode(node_id="node", capability_requirement={"capability_id": cap_id})],
        acceptance_criteria=["output is correct"],
    )
    contract = Contract(id="p0-contract", version="1")
    policy = Policy(policy_id="p0-policy", allowed_capabilities=[cap_id], allowed_regions=["local"])
    return contract, policy, evidence, plan


def test_kairuntime_standard_path_uses_hard_isolation_and_attestation(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    cap = Capability(capability_id="p0.normal", implementation_id="impl.p0.normal", owner="p0")
    runtime.install_capability(cap, echo)
    contract, policy, evidence, plan = parts(runtime)
    out = runtime.execute(
        objective="execute", input_data={"value": 4}, contract=contract, policy=policy,
        capability_id=cap.capability_id, evidence=evidence, plan=plan, handler=echo,
        expected_outcome={"value": 8},
    )
    assert out.kernel.status == "SUCCESS"
    assert out.execution.state is ExecutionState.CLOSED
    events = runtime.store.events(out.execution.execution_id)
    assert any(e["event_type"] == "CAPABILITY_MANIFEST_SIGNED" for e in events)
    assert any(e["event_type"] == "EXECUTION_ATTESTED" for e in events)
    assert runtime.kernel.executor.__class__.__name__ == "HardIsolationKernelExecutor"


def test_l5_and_l6_are_blocked_before_runnable_execution(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    cap = Capability(capability_id="p0.block", implementation_id="impl.p0.block", owner="p0")
    runtime.install_capability(cap, echo)
    contract, policy, evidence, plan = parts(runtime, cap.capability_id)
    for level in ("L5", "L6"):
        with pytest.raises(IsolationBlocked, match="autonomy_level_blocked"):
            runtime.execute(objective="execute", input_data={"value": 1}, contract=contract, policy=policy,
                            capability_id=cap.capability_id, evidence=evidence, plan=plan, handler=echo,
                            expected_outcome={"value": 2}, autonomy_level=level)


def test_autonomy_gate_rejects_invalid_levels():
    for level in ("L-1", "L7", "garbage"):
        with pytest.raises(IsolationBlocked):
            AutonomyGate.authorize(level)


def test_standard_runtime_cannot_write_to_host_from_capability(tmp_path):
    runtime = KaiRuntime(data_dir=tmp_path)
    cap = Capability(capability_id="p0.nohost", implementation_id="impl.p0.nohost", owner="p0")
    runtime.install_capability(cap, host_write)
    contract, policy, evidence, plan = parts(runtime, cap.capability_id)
    target = tmp_path / "escape.txt"
    out = runtime.execute(objective="host escape test", input_data={"path": str(target)}, contract=contract,
                          policy=policy, capability_id=cap.capability_id, evidence=evidence, plan=plan,
                          handler=host_write, expected_outcome={"written": True})
    assert out.kernel.status == "FAILURE"
    assert not target.exists()
    assert out.execution.state is ExecutionState.FAILED
