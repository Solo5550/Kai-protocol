from __future__ import annotations

import json
from pathlib import Path

import pytest

from kai.runtime import (
    Capability, Cell, ClaimStatus, Contract, EvidenceBundle, ExecutionState, KaiRuntime, Policy, Region,
    RuntimeConformance, RuntimeStore, SovereigntyError,
)


def latency_remediation(payload):
    # v0.7 P0: capability execution is hard-isolated; external writes are mediated by the runtime effect ledger.
    return payload.get("post_latency_ms", 95)


def failing_handler(payload):
    raise RuntimeError("dependency unavailable")


def make_runtime(tmp_path):
    region = Region("local")
    region.add_cell(Cell("cell-local", "local", capacity_units=100, capability_ids=set()))
    runtime = KaiRuntime(data_dir=tmp_path, regions={"local": region})
    cap = Capability(capability_id="execute.remediation", implementation_id="impl.remediation", owner="ops", purpose="apply verified remediation", side_effect_class="external_write", required_permissions=["effect:remediate"])
    runtime.install_capability(cap, latency_remediation)
    return runtime


def make_contract():
    return Contract(id="contract.runtime", version="1.0", input_schema={"required": ["post_latency_ms"]})


def make_evidence():
    return EvidenceBundle(evidence_id="evidence-latency", sources=[{"source_id": "metrics", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})


def make_plan():
    from kai.runtime import Plan, PlanNode
    return Plan(plan_id="plan-latency", objective="investigate and remediate latency", nodes=[PlanNode(node_id="remediate", capability_requirement={"capability_id": "execute.remediation"})], acceptance_criteria=["latency <= 100ms"])


def test_golden_path_is_one_execution_semantics_end_to_end(tmp_path):
    runtime = make_runtime(tmp_path)
    policy = Policy(policy_id="policy.ops", semantic_version="1.0.0", allowed_capabilities=["execute.remediation"], allowed_regions=["local"], required_permissions=["effect:remediate"], side_effect_policy={"execute": True})
    out = runtime.execute(objective="remediate high latency", input_data={"post_latency_ms": 95, "target_path": str(tmp_path / "effect.txt")},
                          contract=make_contract(), policy=policy, capability_id="execute.remediation", evidence=make_evidence(), plan=make_plan(),
                          handler=latency_remediation, expected_outcome=95, claim_statement="latency remediation restored target", permissions={"effect:remediate"}, side_effect=True,
                          effect_request={"target": "runtime-file", "operation": "execute", "path": str(tmp_path / "effect.txt")})
    assert out.execution.state is ExecutionState.CLOSED
    assert out.execution.root_execution_id == out.execution.execution_id
    assert out.proof is not None and out.proof.status is ClaimStatus.SUPPORTED
    assert out.decision.status == "VERIFIED"
    effect = runtime.store.get_effect_by_idempotency(out.execution.idempotency_key)
    assert effect is not None and effect["status"] == "COMPLETED"
    events = runtime.store.events(out.execution.execution_id)
    event_names = [e["event_type"] for e in events]
    assert "EXECUTION_STARTED" in event_names and "EXECUTION_COMPLETED" in event_names
    states = [e.get("payload", {}).get("state") for e in events]
    for expected_state in ("VERIFICATION_PENDING", "VERIFIED", "PROVEN", "PERSISTING", "PERSISTED", "LEARNING_PENDING", "LEARNED", "CALIBRATING", "CLOSED"):
        assert expected_state in states
    reconstruction = runtime.reconstruct(out.execution.execution_id)
    assert reconstruction["execution"]["state"] == "CLOSED"


def test_golden_path_rejects_missing_permission_before_side_effect(tmp_path):
    runtime = make_runtime(tmp_path)
    policy = Policy(policy_id="p", allowed_capabilities=["execute.remediation"], allowed_regions=["local"], required_permissions=["effect:remediate"], side_effect_policy={"execute": True})
    with pytest.raises(PermissionError):
        runtime.execute(objective="x", input_data={"post_latency_ms": 95}, contract=make_contract(), policy=policy,
                        capability_id="execute.remediation", evidence=make_evidence(), plan=make_plan(), handler=latency_remediation,
                        expected_outcome=95, permissions=set(), side_effect=True)


def test_golden_path_keeps_execution_success_separate_from_verification(tmp_path):
    runtime = make_runtime(tmp_path)
    # Make remediation capability read-only for this negative proof case.
    cap = runtime.registry.get("execute.remediation"); cap.side_effect_class = "pure"; cap.required_permissions = []
    policy = Policy(policy_id="p", allowed_capabilities=["execute.remediation"], allowed_regions=["local"])
    out = runtime.execute(objective="x", input_data={"post_latency_ms": 95}, contract=make_contract(), policy=policy,
                          capability_id="execute.remediation", evidence=make_evidence(), plan=make_plan(), handler=latency_remediation,
                          expected_outcome=100, permissions=set(), side_effect=False)
    assert out.kernel.status == "SUCCESS"
    assert out.proof is None
    assert out.decision.status == "UNVERIFIED"
    assert out.execution.state is ExecutionState.CLOSED


def test_conformance_suite_has_essential_fitness_checks():
    result = RuntimeConformance().run()
    assert result.passed
    assert all(result.checks.values())


def test_failure_injection_core_scenarios():
    store = RuntimeStore()
    from kai.runtime import EffectLedger, FailureEngine, RetryController, ReplayEngine
    ledger = EffectLedger(store)
    first, duplicate = ledger.begin(execution_id="e1", idempotency_key="same", target="x", operation="write", request={"v": 1}, authorization_ref="a", policy_ref="p")
    second, duplicate2 = ledger.begin(execution_id="e2", idempotency_key="same", target="x", operation="write", request={"v": 1}, authorization_ref="a", policy_ref="p")
    assert not duplicate and duplicate2 and first["effect_id"] == second["effect_id"]
    f = FailureEngine(store).capture(execution_id="e", state="TIMED_OUT", category=__import__("kai.runtime", fromlist=["FailureCategory"]).FailureCategory.TIMEOUT, severity="high", symptom="slow", trigger="deadline")
    assert RetryController(max_attempts=2).decide(1, retryable=True).retry
    replay = ReplayEngine().replay({"execution": {"execution_id": "e"}, "events": []}, mode="RECONSTRUCTION_ONLY")
    assert not replay["reexecute_external_effects"]


def test_api_projection_can_reconstruct_execution(tmp_path):
    runtime = make_runtime(tmp_path)
    # Exercise the projection with a stored minimal execution.
    ex = __import__("kai.runtime", fromlist=["Execution"]).Execution(execution_id="api-e", run_id="api-r", objective="api")
    runtime.store.create_execution(ex)
    payload = runtime.reconstruct("api-e")
    assert payload["execution"]["execution_id"] == "api-e"


def test_effect_begin_is_atomic_under_concurrency(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from kai.runtime.failure import EffectLedger
    from kai.runtime.store import RuntimeStore
    store = RuntimeStore(tmp_path / "effects.db")
    ledger = EffectLedger(store)
    def one(i):
        return ledger.begin(execution_id=f"e-{i}", idempotency_key="same", target="db", operation="write", request={"x":1}, authorization_ref="a", policy_ref="p")
    with ThreadPoolExecutor(max_workers=12) as pool:
        results = list(pool.map(one, range(12)))
    assert sum(1 for _, duplicate in results if not duplicate) == 1
    assert sum(1 for _, duplicate in results if duplicate) == 11
    store.close()
