import pytest

from kai.assurance import RootCause, Solution, solution_portfolio


def test_root_cause_confidence_is_bounded():
    with pytest.raises(ValueError):
        RootCause("rc", (), "mechanism", 1.1)


def test_solution_portfolio_is_deterministic():
    opts = [
        Solution("b", ("rc",), "b", .8, .4, .8, .9),
        Solution("a", ("rc",), "a", .8, .4, .9, .9),
    ]
    assert [x.id for x in solution_portfolio(opts)] == ["a", "b"]
