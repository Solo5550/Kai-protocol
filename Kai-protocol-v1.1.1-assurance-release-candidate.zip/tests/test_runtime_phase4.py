import time

import pytest

from kai.runtime import ContractEngine, ContractEngine, ExecutionKernel, ExecutionState, IdentityContext, Contract, RuntimeStore


def ok_handler(payload):
    return {"value": payload["value"] * 2}


def slow_handler(payload):
    time.sleep(payload.get("sleep", 1.0))
    return {"done": True}


def test_kernel_runs_canonical_process_execution_and_persists_state():
    kernel = ExecutionKernel(store=RuntimeStore())
    identity = IdentityContext.root(actor_id="tester")
    result = kernel.submit(identity=identity, objective="double", input_data={"value": 21},
                           contract=Contract(id="contract.execution", version="1.0"), handler=ok_handler)
    assert result.status == "SUCCESS"
    assert result.output == {"value": 42}
    assert result.execution.state is ExecutionState.VERIFICATION_PENDING
    reconstructed = kernel.reconstruct(result.execution.execution_id)
    assert reconstructed["execution"]["execution_id"] == result.execution.execution_id
    assert any(e["event_type"] == "EXECUTION_STARTED" for e in reconstructed["events"])


def test_kernel_blocks_on_quota_before_execution():
    from kai.runtime import AdmissionController
    kernel = ExecutionKernel(store=RuntimeStore(), admission=AdmissionController(quota_units=0.5))
    identity = IdentityContext.root()
    result = kernel.submit(identity=identity, objective="x", input_data={}, contract=Contract(id="c", version="1"), handler=ok_handler)
    assert result.status == "BLOCKED"
    assert result.execution.state is ExecutionState.BLOCKED


def test_kernel_timeout_is_structured():
    kernel = ExecutionKernel(store=RuntimeStore())
    identity = IdentityContext.root()
    result = kernel.submit(identity=identity, objective="slow", input_data={"sleep": 0.2}, contract=Contract(id="c", version="1"), handler=slow_handler, timeout=0.02)
    assert result.status == "TIMEOUT"
    assert result.execution.state is ExecutionState.TIMED_OUT


def test_store_idempotency_record_deduplicates_repeat_effect():
    store = RuntimeStore()
    assert store.remember_idempotency("k1", "exec-1", {"ok": True}, "fp")
    assert not store.remember_idempotency("k1", "exec-2", {"ok": True}, "fp")
    assert store.get_idempotency("k1")["execution_id"] == "exec-1"
