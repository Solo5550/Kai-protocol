from __future__ import annotations

from kai.maintenance import (
    ChangeRecord, DebtItem, GateStatus, SLOSpec, Waiver, build_blast_radius, change_record_complete,
    coverage, debt_item_valid, evaluate_slo, progressive_step, validate_waiver,
)


def test_all_47_sections_are_registered():
    rows = coverage()
    assert len(rows) == 47
    assert [r.section for r in rows] == list(range(1, 48))
    assert all(r.implementation and r.evidence for r in rows)


def test_slo_gate_and_progressive_policy_are_predeclared():
    spec = SLOSpec("availability", "availability", 0.99, 3600, 2.0)
    assert evaluate_slo(spec, success_rate=0.999, observed_burn_rate=1.0).status is GateStatus.PASS
    assert progressive_step("CANARY", error_rate=0.01, max_error_rate=0.02).action == "EXPAND"
    assert progressive_step("CANARY", error_rate=0.03, max_error_rate=0.02).action == "HOLD"
    assert progressive_step("CANARY", error_rate=0.0, max_error_rate=0.02, rollback_signal=True).action == "ROLLBACK"


def test_blast_radius_has_all_dimensions():
    impact = build_blast_radius(direct=["runtime"], indirect=[], dependencies=["crypto"], contracts=["c"], states=["RUNNING"], data=["payload"], security=["authz"], performance=["p99"], regional=["local"], global_=["none"])
    assert set(impact) == {"DIRECT_IMPACT", "INDIRECT_IMPACT", "DEPENDENCY_IMPACT", "CONTRACT_IMPACT", "STATE_IMPACT", "DATA_IMPACT", "SECURITY_IMPACT", "PERFORMANCE_IMPACT", "REGIONAL_IMPACT", "GLOBAL_IMPACT"}


def test_change_debt_waiver_controls():
    change = ChangeRecord("chg", "HIGH", {}, ("c",), ("RUNNING",), ("full",), "rollback", "rollforward", "owner", "REVIEWED", "APPROVED", "observe")
    debt = DebtItem("d", "TEMPORARY", "known risk", "owner", "medium", "2099-01-01", "repair")
    waiver = Waiver("w", "noncritical", "temporary exception", "low", "owner", "2099-01-01", "reviewer")
    assert change_record_complete(change)
    assert debt_item_valid(debt)
    assert validate_waiver(waiver, critical_failure=False, critical_security_gap=False, provenance_broken=False).status is GateStatus.PASS
    assert validate_waiver(waiver, critical_failure=True, critical_security_gap=False, provenance_broken=False).status is GateStatus.FAIL
