import unittest

from kai.engine.adaptive import DepthSignals
from kai.engine.pipeline import AssurancePipeline
from kai.master import MasterGovernor, MasterStatus
from kai.protocol.models import Verdict


class MasterGovernanceTests(unittest.TestCase):
    def setUp(self):
        self.parts = [
            {
                "unit_id": "u1",
                "claim": "A",
                "evidence": {"statement": "EA", "source_id": "sa"},
                "test": {"kind": "property", "expected": True, "result": {"status": "PASS", "actual": True}},
            }
        ]

    def test_preflight_blocks_undeclared_criterion(self):
        review = MasterGovernor().preflight(
            source_id="root",
            source_claim="A",
            parts=self.parts,
            criterion_name=None,
            criterion_ok=True,
            signals=DepthSignals(),
        )
        self.assertFalse(review.promotable)
        self.assertTrue(any(r.stage.value == "UNDERSTAND" and r.status == MasterStatus.BLOCKED for r in review.stage_results))

    def test_master_governs_pipeline_promotion(self):
        report = AssurancePipeline().run(
            source_id="root",
            source_claim="A",
            parts=self.parts,
            criterion_name="property_preservation",
            criterion_ok=True,
        )
        self.assertEqual(report.verdict, Verdict.ACCEPTED)
        self.assertTrue(report.master_postflight)
        self.assertTrue(report.master_postflight.promotable)
        final_unit = next(u for u in report.exported_artifacts["units"] if u["unit_id"] == "synthesis.base")
        self.assertEqual(final_unit["metadata"]["master_governance_required"], True)
        self.assertEqual(final_unit["gates"][-1]["gate"], "master_governance")
        self.assertEqual(final_unit["gates"][-1]["status"], "PASS")

    def test_missing_criterion_is_not_silently_accepted(self):
        report = AssurancePipeline().run(
            source_id="root",
            source_claim="A",
            parts=self.parts,
            criterion_ok=True,
        )
        self.assertEqual(report.verdict, Verdict.BLOCKED)
        self.assertFalse(report.exported_artifacts["units"])


if __name__ == "__main__":
    unittest.main()

class MasterFailureGovernanceTests(unittest.TestCase):
    def test_failed_test_blocks_promotion(self):
        report = AssurancePipeline().run(
            source_id="root",
            source_claim="A",
            parts=[{
                "unit_id": "u1",
                "claim": "A",
                "evidence": {"statement": "EA", "source_id": "sa"},
                "test": {"kind": "property", "expected": True, "result": {"status": "FAIL", "actual": False, "notes": "counterexample"}},
            }],
            criterion_name="property_preservation",
            criterion_ok=True,
        )
        self.assertEqual(report.verdict, Verdict.REJECTED)
        self.assertFalse(report.master_postflight.promotable)
        self.assertTrue(any(f.severity == "critical" for f in report.master_postflight.critical_findings))


if __name__ == "__main__":
    unittest.main()
