import pytest

from kai.runtime.contracts import ContractEngine, TransitionEngine, TransitionRejected
from kai.runtime.models import Contract, Execution, ExecutionState


def test_contract_engine_blocks_missing_contract():
    result = ContractEngine().validate_execution(Execution(execution_id="e", objective="x"), None)
    assert not result.ok and "contract_missing" in result.errors


def test_contract_engine_accepts_matching_execution_contract():
    result = ContractEngine().validate_execution(
        Execution(execution_id="e", objective="x", input_data={"value": 1}),
        Contract(id="contract.execution", version="1.0", input_schema={"required": ["value"]}),
    )
    assert result.ok


def test_transition_engine_rejects_illegal_direct_verification():
    ex = Execution(execution_id="e")
    with pytest.raises(TransitionRejected):
        TransitionEngine().transition(ex, "VERIFIED")


def test_transition_engine_rejects_stale_and_accepts_ordered_transition():
    ex = Execution(execution_id="e")
    engine = TransitionEngine()
    with pytest.raises(TransitionRejected):
        engine.transition(ex, "CONTRACT_VALIDATED", required_state_version=1)
    assert ex.state is ExecutionState.CREATED
    engine.transition(ex, "CONTRACT_VALIDATED", required_state_version=0, event_id="evt-1")
    assert ex.state is ExecutionState.READY
    assert ex.state_version == 1


def test_state_is_not_directly_mutated_by_transition_engine_in_tests():
    ex = Execution(execution_id="e")
    engine = TransitionEngine()
    engine.transition(ex, "CONTRACT_VALIDATED")
    with pytest.raises(TransitionRejected):
        engine.transition(ex, "VERIFIED")
