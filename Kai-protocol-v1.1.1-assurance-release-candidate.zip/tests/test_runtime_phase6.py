from datetime import datetime, timedelta, timezone

import pytest

from kai.runtime import EvidenceBundle, EvidenceGate, GateStatus, Plan, PlanNode, PlanValidationError, alternatives_for, hypothesis_from_evidence, validate_plan


def test_evidence_gate_accepts_fresh_integrity_validated_lineage():
    ts = datetime.now(timezone.utc).isoformat()
    bundle = EvidenceBundle(evidence_id="ev-1", sources=[{"source_id": "metrics", "observed_at": ts}], integrity={"validated": True})
    decision = EvidenceGate().evaluate(bundle)
    assert decision.status is GateStatus.PASS
    assert bundle.status == "EVIDENCE_ACCEPTED"


def test_evidence_gate_rejects_stale_or_conflicted_data():
    stale = (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
    b = EvidenceBundle(evidence_id="e", sources=[{"source_id": "s", "observed_at": stale}], integrity={"validated": True})
    assert EvidenceGate().evaluate(b, max_age_seconds=60).status is GateStatus.FAIL
    b2 = EvidenceBundle(evidence_id="e2", sources=[{"source_id": "s", "observed_at": datetime.now(timezone.utc).isoformat()}], integrity={"validated": True}, conflict_status="UNRESOLVED")
    assert EvidenceGate().evaluate(b2).status is GateStatus.UNRESOLVED


def test_plan_graph_rejects_cycles():
    plan = Plan(plan_id="p", objective="x", nodes=[PlanNode(node_id="a"), PlanNode(node_id="b")], dependencies=[{"from": "a", "to": "b"}, {"from": "b", "to": "a"}])
    with pytest.raises(PlanValidationError):
        validate_plan(plan)


def test_hypothesis_and_alternatives_are_first_class_objects():
    h = hypothesis_from_evidence("cache miss increased", supporting=["obs-1"], confidence=0.7)
    assert h.status == "TESTABLE"
    alts = alternatives_for("d1", [{"approach": "rollback", "assumptions": [], "expected_outcome": "latency down", "risks": [], "evidence_refs": []}])
    assert alts[0].alternative_id == "d1:alt-1"
