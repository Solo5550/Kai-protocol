import pytest

from kai.runtime import Claim, ClaimStatus, DecisionEngine, ProofEngine, ProofLedger, RuntimeStore, VerificationEngine, VerificationStatus
from kai.runtime.analysis import AnalysisRecord, validate_causal_claim


def test_execution_success_does_not_equal_verification_success():
    store = RuntimeStore()
    vr = VerificationEngine(store).verify(execution_id="e", target="metric", expected=10, observed=12)
    assert vr.verification.status is VerificationStatus.NOT_VERIFIED


def test_verification_and_proof_are_separate_records():
    store = RuntimeStore(); verifier = VerificationEngine(store)
    vr = verifier.verify(execution_id="e", target="metric", expected=10, observed=10, independent_observation=True)
    assert vr.verification.status is VerificationStatus.VERIFIED
    claim = Claim(claim_id="c1", statement="metric returned to baseline", status=ClaimStatus.SUPPORTED, verification_refs=[vr.verification.verification_id])
    ledger = ProofLedger(store)
    proof = ProofEngine(ledger, store).prove(claim=claim, verification=vr.verification.verification_id, evidence_refs=["ev1"], observation_refs=["obs1"], execution_refs=["e"], source_refs=["metrics"])
    assert proof.status is ClaimStatus.SUPPORTED
    assert ledger.verify_chain()


def test_supported_claim_without_verification_is_rejected():
    store = RuntimeStore(); ledger = ProofLedger(store)
    claim = Claim(claim_id="c2", statement="x", status=ClaimStatus.SUPPORTED)
    with pytest.raises(ValueError):
        ProofEngine(ledger, store).prove(claim=claim, verification=None, evidence_refs=[], observation_refs=[], execution_refs=[], source_refs=[])


def test_proof_chain_is_tamper_evident():
    store = RuntimeStore(); ledger = ProofLedger(store)
    claim = Claim(claim_id="c3", statement="x", status=ClaimStatus.UNRESOLVED)
    ProofEngine(ledger, store).prove(claim=claim, verification=None, evidence_refs=[], observation_refs=[], execution_refs=[], source_refs=[])
    assert ledger.verify_chain()
    store._conn.execute("UPDATE proof_ledger SET payload='{}'")
    assert not ledger.verify_chain()


def test_causal_inference_requires_assumptions_and_estimand():
    with pytest.raises(ValueError):
        validate_causal_claim(AnalysisRecord("a", "Causal Inference", "x"))
    validate_causal_claim(AnalysisRecord("a", "Causal Inference", "x", assumptions=["parallel trends"], estimand="ATT"))


def test_decision_is_next_decision_context_not_plain_return_value():
    d = DecisionEngine().decide(run_id="r", objective="x", selected_action={"action": "noop"}, evidence_refs=["e"], verification_refs=["v"], proof_refs=["p"], expected_outcome=1, observed_outcome=1)
    assert d.status == "VERIFIED"
    assert d.run_id == "r"
