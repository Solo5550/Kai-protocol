import json
import tempfile
import unittest
from pathlib import Path

from kai.security import generate_authority_keypair, open_seal, read_master_key, seal, write_master_key
from kai.security.authority import sign, verify
from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction
from kai.language import validate_semantics
from kai.security.envelope import SecretEnvelopeError


class SecurityTests(unittest.TestCase):
    def test_secret_round_trip_and_authentication(self):
        with tempfile.TemporaryDirectory() as td:
            key_path = Path(td) / "kai.master"
            write_master_key(key_path)
            key = read_master_key(key_path)
            envelope = seal("classified kai knowledge", key, key_id="root")
            self.assertEqual(open_seal(envelope, key).decode(), "classified kai knowledge")
            tampered = dict(envelope)
            tampered["ciphertext"] = ("A" if envelope["ciphertext"][0] != "A" else "B") + envelope["ciphertext"][1:]
            with self.assertRaises(SecretEnvelopeError):
                open_seal(tampered, key)
            with self.assertRaises(SecretEnvelopeError):
                open_seal(envelope, read_master_key(Path(td) / "other.master") if False else bytes(32))


    def test_secret_message_uses_authenticated_envelope(self):
        key = bytes(range(32))
        message = MessageFactory(actor="security-test").create_secret(
            unit_id="u1", round=1, layer=1, direction=Direction.HORIZONTAL, plaintext="hidden", key=key, key_id="root"
        )
        self.assertEqual(validate_semantics(message), [])
        envelope = message.payload["envelope"]
        self.assertEqual(open_seal(envelope, key).decode(), "hidden")

    def test_authority_sign_and_verify(self):
        with tempfile.TemporaryDirectory() as td:
            private_path = Path(td) / "authority.private"
            public_path = Path(td) / "authority.public"
            generate_authority_keypair(private_path, public_path)
            value = {"protocol": "kai", "verdict": "ACCEPTED", "x": [1, 2, 3]}
            signature = sign(value, private_path)
            self.assertTrue(verify(value, signature, public_path))
            value["verdict"] = "REJECTED"
            self.assertFalse(verify(value, signature, public_path))

    def test_key_permissions_best_effort(self):
        with tempfile.TemporaryDirectory() as td:
            key_path = Path(td) / "kai.master"
            write_master_key(key_path)
            self.assertEqual(key_path.stat().st_mode & 0o777, 0o600)

    def test_unique_nonces(self):
        with tempfile.TemporaryDirectory() as td:
            key_path = Path(td) / "kai.master"
            write_master_key(key_path)
            key = read_master_key(key_path)
            nonces = {seal(f"m{i}", key)["nonce"] for i in range(256)}
            self.assertEqual(len(nonces), 256)


if __name__ == "__main__":
    unittest.main()
