import pytest
from kai.runtime import ArchitectureDriftScanner, Cell, ConsistencyClass, EvolutionProposal, OperationalDashboard, Region, RuntimeConformance, get_policy
from kai.runtime.compression import compress_with_provenance


def test_consistency_classes_are_explicit():
    p = get_policy(ConsistencyClass.A_SAFETY_SECURITY_AUTH)
    assert p.model == "strong-authoritative" and p.failure_behavior == "block"


def test_compression_preserves_provenance_refs():
    c = compress_with_provenance("a" * 500, source_refs=["s1"], original_artifact_refs=["a1"], max_chars=20)
    assert c.source_refs == ["s1"] and c.original_artifact_refs == ["a1"] and c.omissions


def test_evolution_is_ordered_and_gated():
    e = EvolutionProposal("p", "cap", "1", "2", 0.1)
    e.advance("PROPOSAL"); e.advance("CONTRACT_IMPACT"); e.advance("COMPATIBILITY"); e.advance("CONFORMANCE"); e.advance("SHADOW"); e.advance("CANARY"); e.advance("LIMITED_ROLLOUT"); e.advance("OBSERVATION"); e.advance("VERIFICATION"); e.advance("PROMOTED", health_ok=True, evidence_ok=True)
    assert e.status == "PROMOTED"


def test_operational_dashboard_answers_core_questions(tmp_path):
    from kai.runtime import KaiRuntime, Execution
    r = KaiRuntime(data_dir=tmp_path)
    r.store.create_execution(Execution(execution_id="e", run_id="r", objective="x"))
    q = OperationalDashboard(r).questions()
    assert "what_is_running" in q and q["proof_chain_valid"]


def test_drift_scanner_is_clean_for_runtime_installed_capabilities(tmp_path):
    from kai.runtime import KaiRuntime, Capability
    r = KaiRuntime(data_dir=tmp_path)
    c = Capability(capability_id="c", implementation_id="i", owner="o")
    def h(p): return True
    r.install_capability(c, h)
    assert ArchitectureDriftScanner().clean(r)
