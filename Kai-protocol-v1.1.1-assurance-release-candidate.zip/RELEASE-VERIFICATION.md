# Release Verification — Kai Protocol v1.1.1

## Current artifact status

**Release state:** Release Candidate candidate (internal assurance complete locally); **not a production certification**.

## Mandatory local verification

```bash
python -m compileall -q src tests
python -m pytest -q
python tools/kai_conformance.py
python tools/completeness_oracle.py
python tools/kai_differential.py
python tools/kai_targeted_fuzz.py
python tools/kai_performance.py
python tools/kai_sbom.py
python tools/kai_provenance.py
```

## Production-only evidence

Independent security review, signed/external provenance attestation, production canary evidence, scaled chaos/node-loss evidence, rollback drill evidence, and external qualification remain separate gates.

## Non-negotiable rule

A failing critical gate routes the release attempt back to root-cause analysis. A passing test suite alone does not override an unresolved critical assurance finding.
