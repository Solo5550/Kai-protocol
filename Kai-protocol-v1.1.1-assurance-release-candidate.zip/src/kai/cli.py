from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from kai.engine.pipeline import AssurancePipeline
from kai.language import DialogueEngine, decode_message, encode_message, validate_semantics, decode_semantic, encode_semantic
from kai.protocol.models import Direction, MessageType
from kai.protocol.messages import MessageFactory
from kai.protocol.validator import ProtocolValidator
from kai.security import dump_envelope, open_seal, read_master_key, write_master_key
from kai.security.authority import generate_authority_keypair
from kai.security.envelope import seal
from kai.skill import Capability, GateStatus, LifecycleLevel, SkillPipeline
from kai.runtime.conformance import RuntimeConformance


def _load(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write(path: str, text: str) -> None:
    Path(path).write_text(text, encoding="utf-8")


def cmd_validate(path: str) -> int:
    data = _load(path)
    validator = ProtocolValidator()
    errors: list[str] = []
    for message in data.get("messages", []):
        errors.extend(validator.validate_message(message))
        errors.extend(validate_semantics(message))
    for unit in data.get("units", []):
        if not unit.get("unit_id"):
            errors.append("unit_id missing")
    master = data.get("master")
    if master is not None:
        for mode in ("preflight", "postflight"):
            review = master.get(mode)
            if review is None:
                continue
            if not isinstance(review.get("score"), (int, float)):
                errors.append(f"master {mode} score missing")
            if not isinstance(review.get("stages"), list):
                errors.append(f"master {mode} stages missing")
    print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


def cmd_run(path: str) -> int:
    data = _load(path)
    src = data["source"]
    report = AssurancePipeline().run(
        source_id=src["id"],
        source_claim=src["claim"],
        parts=data.get("parts", []),
        criterion_ok=data.get("criterion_ok"),
        criterion_name=data.get("criterion_name"),
        decision_options=data.get("decision_options"),
        expert_methods=data.get("expert_methods"),
    )
    print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
    return 0 if report.verdict.value == "ACCEPTED" else 2


def cmd_keygen(path: str) -> int:
    key = write_master_key(path)
    print(json.dumps({"created": str(path), "key_fingerprint": __import__("hashlib").sha256(__import__("base64").urlsafe_b64decode(key + "=" * (-len(key) % 4))).hexdigest()[:16]}, indent=2))
    return 0


def cmd_authority_gen(private_path: str, public_path: str) -> int:
    generate_authority_keypair(private_path, public_path)
    print(json.dumps({"private_key": private_path, "public_key": public_path}, indent=2))
    return 0


def cmd_secret_seal(key_path: str, input_path: str, output_path: str, key_id: str) -> int:
    key = read_master_key(key_path)
    plaintext = Path(input_path).read_bytes()
    envelope = seal(plaintext, key, key_id=key_id)
    _write(output_path, dump_envelope(envelope))
    return 0


def cmd_secret_open(key_path: str, input_path: str, output_path: str) -> int:
    key = read_master_key(key_path)
    envelope = _load(input_path)
    plaintext = open_seal(envelope, key)
    Path(output_path).write_bytes(plaintext)
    return 0


def cmd_encode(args: argparse.Namespace) -> int:
    data = _load(args.input)
    m = MessageFactory(actor=args.actor).create(
        unit_id=data["unit_id"], round=int(data.get("round", 0)), layer=int(data.get("layer", 0)),
        direction=Direction(data.get("direction", "horizontal")), type=MessageType(data["type"]),
        payload=data.get("payload", {}), parents=data.get("parents", []), provenance=data.get("provenance"),
        message_id=data.get("message_id"),
    )
    _write(args.output, encode_message(m))
    return 0


def cmd_decode(path: str) -> int:
    data = decode_message(Path(path).read_text(encoding="utf-8"))
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0


def cmd_semantic_encode(args: argparse.Namespace) -> int:
    data = _load(args.input)
    _write(args.output, encode_semantic(data))
    return 0


def cmd_semantic_decode(path: str) -> int:
    data = decode_semantic(Path(path).read_text(encoding="utf-8"))
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0

def cmd_runtime_conformance() -> int:
    result = RuntimeConformance().run()
    print(json.dumps({"passed": result.passed, "checks": result.checks, "failures": result.failures}, ensure_ascii=False, indent=2))
    return 0 if result.passed else 2

def cmd_skill_run(path: str) -> int:
    data = _load(path)
    capabilities = [Capability(
        capability_id=str(c["capability_id"]), name=str(c["name"]), objective=str(c["objective"]),
        inputs=tuple(c.get("inputs", [])), outputs=tuple(c.get("outputs", [])),
        required_resources=tuple(c.get("required_resources", [])), risk_level=float(c.get("risk_level", 0.0)),
        coupling=float(c.get("coupling", 0.0)), observability=float(c.get("observability", 1.0)),
        metadata=dict(c.get("metadata", {})),
    ) for c in data.get("capabilities", [])]
    report = SkillPipeline().run(
        project=str(data["project"]), capabilities=capabilities,
        required_capabilities=list(data.get("required_capabilities", [])),
        specialization=str(data["specialization"]),
        handler=lambda payload: {"status": "validated", "specialization": payload.get("specialization")},
        requested_level=LifecycleLevel(data.get("requested_level", LifecycleLevel.L2_SANDBOX.value)),
        resources=dict(data.get("resources", {"cpu": 0.1})),
        available_resources=dict(data.get("available_resources", {"cpu": 1.0})),
    )
    print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
    return 0 if report.status == GateStatus.PASS else 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kai")
    sub = parser.add_subparsers(dest="command", required=True)

    p_validate = sub.add_parser("validate")
    p_validate.add_argument("path")

    p_run = sub.add_parser("run")
    p_run.add_argument("path")

    p_key = sub.add_parser("keygen", help="create a 256-bit master decryption key")
    p_key.add_argument("path")

    p_auth = sub.add_parser("authority-keygen", help="create an Ed25519 authority signing keypair")
    p_auth.add_argument("private_path")
    p_auth.add_argument("public_path")

    p_seal = sub.add_parser("secret-seal", help="encrypt a file for the holder of a Kai master key")
    p_seal.add_argument("--key", dest="key_path", required=True)
    p_seal.add_argument("--in", dest="input_path", required=True)
    p_seal.add_argument("--out", dest="output_path", required=True)
    p_seal.add_argument("--key-id", default="master")

    p_open = sub.add_parser("secret-open", help="decrypt a Kai secret envelope")
    p_open.add_argument("--key", dest="key_path", required=True)
    p_open.add_argument("--in", dest="input_path", required=True)
    p_open.add_argument("--out", dest="output_path", required=True)

    p_encode = sub.add_parser("encode", help="encode a JSON Kai message as KAI-LANG text")
    p_encode.add_argument("input")
    p_encode.add_argument("output")
    p_encode.add_argument("--actor", default="kai-cli")

    p_decode = sub.add_parser("decode", help="decode a KAI-LANG text message")
    p_decode.add_argument("path")

    p_sem_enc = sub.add_parser("semantic-encode", help="encode a Kai v0.8 semantic message")
    p_sem_enc.add_argument("input")
    p_sem_enc.add_argument("output")

    p_sem_dec = sub.add_parser("semantic-decode", help="decode a Kai v0.8 semantic message")
    p_sem_dec.add_argument("path")

    p_rc = sub.add_parser("runtime-conformance", help="run Kai Runtime conformance gate")
    p_skill = sub.add_parser("skill-run", help="run the governed Kai Protocol SKILL lifecycle")
    p_skill.add_argument("path")

    args = parser.parse_args(argv)
    if args.command == "validate":
        return cmd_validate(args.path)
    if args.command == "run":
        return cmd_run(args.path)
    if args.command == "keygen":
        return cmd_keygen(args.path)
    if args.command == "authority-keygen":
        return cmd_authority_gen(args.private_path, args.public_path)
    if args.command == "secret-seal":
        return cmd_secret_seal(args.key_path, args.input_path, args.output_path, args.key_id)
    if args.command == "secret-open":
        return cmd_secret_open(args.key_path, args.input_path, args.output_path)
    if args.command == "encode":
        return cmd_encode(args)
    if args.command == "decode":
        return cmd_decode(args.path)
    if args.command == "semantic-encode":
        return cmd_semantic_encode(args)
    if args.command == "semantic-decode":
        return cmd_semantic_decode(args.path)
    if args.command == "runtime-conformance":
        return cmd_runtime_conformance()
    if args.command == "skill-run":
        return cmd_skill_run(args.path)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
