"""Kai Product Surface — Runtime · Proof · Gate.

Invariant:
    Machines that cannot prove must not act.
"""

from .proof import (
    ProofReceipt,
    issue_receipt,
    verify_receipt,
    generate_issuer_keypair,
)
from .gate import KaiGate, GateDecision, GateDenial
from .runtime import KaiProductRuntime, ProvenAction

__all__ = [
    "KaiProductRuntime",
    "ProvenAction",
    "KaiGate",
    "GateDecision",
    "GateDenial",
    "ProofReceipt",
    "issue_receipt",
    "verify_receipt",
    "generate_issuer_keypair",
    "INVARIANT",
]

INVARIANT = "Machines that cannot prove must not act."
