"""Kai Proof — signed, bound, expiring, single-context receipts.

Radical remediation of G7/G8/G13:
- Ed25519 signature over canonical body (not hash-only)
- tenant_id, actor_id, audience, nonce, expires_at required for product-grade issue
- integrity digest retained for transport checks; signature is authoritative
"""

from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import asdict, dataclass, fields
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _digest(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj).encode("utf-8")).hexdigest()


def _b64e(data: bytes) -> str:
    import base64
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64d(value: str) -> bytes:
    import base64
    return base64.urlsafe_b64decode((value + "=" * (-len(value) % 4)).encode("ascii"))


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse_ts(value: str) -> datetime:
    # accept trailing Z
    v = value.replace("Z", "+00:00")
    return datetime.fromisoformat(v)


@dataclass(frozen=True)
class ProofReceipt:
    receipt_id: str
    protocol: str
    action: str
    contract_id: str
    contract_version: str
    execution_id: str
    run_id: str
    status: str
    output_digest: str
    evidence_digest: str
    decision: str
    issued_at: str
    integrity: str
    # product-grade binding (G7)
    tenant_id: str = ""
    actor_id: str = ""
    region_id: str = ""
    audience: str = ""
    nonce: str = ""
    expires_at: str = ""
    # cryptographic authority (G8/G13)
    key_id: str = ""
    signature: str = ""  # ed25519 over body excluding signature+integrity

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def body_for_signature(self) -> dict[str, Any]:
        d = self.to_dict()
        d.pop("signature", None)
        d.pop("integrity", None)
        return d

    def body_for_integrity(self) -> dict[str, Any]:
        d = self.to_dict()
        d.pop("integrity", None)
        return d


def generate_issuer_keypair() -> tuple[bytes, bytes, str]:
    """Return (private_raw, public_raw, key_id)."""
    private = Ed25519PrivateKey.generate()
    raw_private = private.private_bytes(
        serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()
    )
    raw_public = private.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw
    )
    key_id = hashlib.sha256(raw_public).hexdigest()[:16]
    return raw_private, raw_public, key_id


def _sign(body: dict[str, Any], private_raw: bytes) -> str:
    private = Ed25519PrivateKey.from_private_bytes(private_raw)
    return _b64e(private.sign(_canonical(body).encode("utf-8")))


def _verify_sig(body: dict[str, Any], signature: str, public_raw: bytes) -> bool:
    public = Ed25519PublicKey.from_public_bytes(public_raw)
    try:
        public.verify(_b64d(signature), _canonical(body).encode("utf-8"))
        return True
    except Exception:
        return False


def issue_receipt(
    *,
    action: str,
    contract_id: str,
    contract_version: str,
    execution_id: str,
    run_id: str,
    status: str,
    output: Any,
    evidence: Any,
    decision: str,
    issued_at: str | None = None,
    protocol: str = "kai/proof/1.1",
    tenant_id: str = "",
    actor_id: str = "",
    region_id: str = "local",
    audience: str = "",
    nonce: str | None = None,
    ttl_seconds: int = 3600,
    expires_at: str | None = None,
    private_key: bytes | None = None,
    key_id: str = "",
    require_signature: bool = True,
) -> ProofReceipt:
    """Issue a product-grade receipt. Signature required by default (G8 fix)."""
    if not action or not contract_id or not execution_id or not run_id:
        raise ValueError("proof_receipt_requires_action_contract_execution_run")
    if status not in {"SUCCESS", "FAILURE", "DENIED", "TIMEOUT"}:
        raise ValueError(f"invalid_receipt_status:{status}")
    if decision not in {"ACCEPTED", "REJECTED", "DENIED"}:
        raise ValueError(f"invalid_decision:{decision}")

    now = _utcnow()
    issued = issued_at or now.isoformat()
    if expires_at is None:
        # parse issued if provided
        try:
            base = _parse_ts(issued)
        except Exception:
            base = now
        expires_at = (base + timedelta(seconds=ttl_seconds)).isoformat()
    nonce = nonce or secrets.token_hex(16)
    output_digest = _digest(output)
    evidence_digest = _digest(evidence)

    receipt_id = _digest(
        {
            "action": action,
            "contract_id": contract_id,
            "execution_id": execution_id,
            "run_id": run_id,
            "status": status,
            "output_digest": output_digest,
            "evidence_digest": evidence_digest,
            "decision": decision,
            "issued_at": issued,
            "nonce": nonce,
            "tenant_id": tenant_id,
            "actor_id": actor_id,
        }
    )

    provisional = ProofReceipt(
        receipt_id=receipt_id,
        protocol=protocol,
        action=action,
        contract_id=contract_id,
        contract_version=contract_version,
        execution_id=execution_id,
        run_id=run_id,
        status=status,
        output_digest=output_digest,
        evidence_digest=evidence_digest,
        decision=decision,
        issued_at=issued,
        integrity="",
        tenant_id=tenant_id,
        actor_id=actor_id,
        region_id=region_id,
        audience=audience,
        nonce=nonce,
        expires_at=expires_at,
        key_id=key_id,
        signature="",
    )

    signature = ""
    kid = key_id
    if require_signature:
        if private_key is None:
            raise ValueError("signed_receipt_requires_private_key")
        if not kid:
            pub = Ed25519PrivateKey.from_private_bytes(private_key).public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            )
            kid = hashlib.sha256(pub).hexdigest()[:16]
        signature = _sign(provisional.body_for_signature(), private_key)

    signed = ProofReceipt(
        receipt_id=receipt_id,
        protocol=protocol,
        action=action,
        contract_id=contract_id,
        contract_version=contract_version,
        execution_id=execution_id,
        run_id=run_id,
        status=status,
        output_digest=output_digest,
        evidence_digest=evidence_digest,
        decision=decision,
        issued_at=issued,
        integrity="",
        tenant_id=tenant_id,
        actor_id=actor_id,
        region_id=region_id,
        audience=audience,
        nonce=nonce,
        expires_at=expires_at,
        key_id=kid,
        signature=signature,
    )
    integrity = _digest(signed.body_for_integrity())
    return ProofReceipt(
        **{**signed.to_dict(), "integrity": integrity}
    )


def verify_receipt(
    receipt: ProofReceipt | dict[str, Any],
    *,
    public_keys: dict[str, bytes] | None = None,
    require_signature: bool = True,
    now: datetime | None = None,
) -> bool:
    """Verify integrity + optional/required signature + expiry."""
    if isinstance(receipt, dict):
        try:
            allowed = {f.name for f in fields(ProofReceipt)}
            receipt = ProofReceipt(**{k: receipt[k] for k in receipt if k in allowed})
        except Exception:
            return False

    # integrity over full body except integrity field
    if _digest(receipt.body_for_integrity()) != receipt.integrity:
        return False
    if not receipt.receipt_id or not receipt.execution_id or not receipt.nonce:
        return False

    # expiry
    now = now or _utcnow()
    if receipt.expires_at:
        try:
            if now > _parse_ts(receipt.expires_at):
                return False
        except Exception:
            return False

    if require_signature:
        if not receipt.signature or not receipt.key_id:
            return False
        if not public_keys or receipt.key_id not in public_keys:
            return False
        return _verify_sig(receipt.body_for_signature(), receipt.signature, public_keys[receipt.key_id])

    # signature optional mode: if present, still verify when key known
    if receipt.signature and public_keys and receipt.key_id in public_keys:
        return _verify_sig(receipt.body_for_signature(), receipt.signature, public_keys[receipt.key_id])
    return True
