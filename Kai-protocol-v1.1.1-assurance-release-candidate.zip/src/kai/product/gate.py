"""Kai Gate — signed proof, replay-safe, contract-bound, fail-closed."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

from .proof import ProofReceipt, verify_receipt


@dataclass(frozen=True)
class GateDecision:
    allowed: bool
    reason: str
    receipt: ProofReceipt | None = None


class GateDenial(PermissionError):
    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class KaiGate:
    """Fail-closed admission.

    Remediation map:
    - G8/G13: require_signature + public key trust store
    - G2/G14: single-use nonce/receipt_id registry
    - G3: expiry enforced via verify_receipt
    - G4: only ACCEPTED decision admits side effects
    - G7: optional required tenant/actor/audience match
    - G10: optional allowed_contracts set
    """

    ACCEPTED_DECISIONS = frozenset({"ACCEPTED"})

    def __init__(
        self,
        *,
        require_success: bool = True,
        require_signature: bool = True,
        public_keys: dict[str, bytes] | None = None,
        allowed_contracts: set[str] | None = None,
        expected_tenant: str | None = None,
        expected_audience: str | None = None,
        single_use: bool = True,
    ) -> None:
        self.require_success = require_success
        self.require_signature = require_signature
        self.public_keys = dict(public_keys or {})
        self.allowed_contracts = allowed_contracts
        self.expected_tenant = expected_tenant
        self.expected_audience = expected_audience
        self.single_use = single_use
        self._used: set[str] = set()  # receipt_id or nonce
        self._denials: list[str] = []

    @property
    def denial_log(self) -> tuple[str, ...]:
        return tuple(self._denials)

    def trust(self, key_id: str, public_raw: bytes) -> None:
        self.public_keys[key_id] = public_raw

    def admit(self, receipt: ProofReceipt | dict[str, Any] | None) -> GateDecision:
        if receipt is None:
            self._denials.append("missing_proof")
            return GateDecision(False, "missing_proof")
        if isinstance(receipt, dict):
            try:
                from dataclasses import fields as _fields
                allowed = {f.name for f in _fields(ProofReceipt)}
                receipt = ProofReceipt(**{k: receipt[k] for k in receipt if k in allowed})
            except Exception:
                self._denials.append("malformed_proof")
                return GateDecision(False, "malformed_proof")

        if not verify_receipt(
            receipt,
            public_keys=self.public_keys,
            require_signature=self.require_signature,
        ):
            self._denials.append("integrity_or_signature_or_expiry_failed")
            return GateDecision(False, "integrity_or_signature_or_expiry_failed", receipt=receipt)

        if self.require_success and receipt.status != "SUCCESS":
            self._denials.append(f"status_{receipt.status}")
            return GateDecision(False, f"status_{receipt.status}", receipt=receipt)

        if receipt.decision not in self.ACCEPTED_DECISIONS:
            self._denials.append(f"decision_{receipt.decision}")
            return GateDecision(False, f"decision_{receipt.decision}", receipt=receipt)

        if self.allowed_contracts is not None and receipt.contract_id not in self.allowed_contracts:
            self._denials.append("contract_not_allowed")
            return GateDecision(False, "contract_not_allowed", receipt=receipt)

        if self.expected_tenant is not None and receipt.tenant_id != self.expected_tenant:
            self._denials.append("tenant_mismatch")
            return GateDecision(False, "tenant_mismatch", receipt=receipt)

        if self.expected_audience is not None and receipt.audience != self.expected_audience:
            self._denials.append("audience_mismatch")
            return GateDecision(False, "audience_mismatch", receipt=receipt)

        use_key = receipt.receipt_id or receipt.nonce
        if self.single_use:
            if use_key in self._used:
                self._denials.append("replay_detected")
                return GateDecision(False, "replay_detected", receipt=receipt)

        if self.single_use:
            self._used.add(use_key)
        return GateDecision(True, "admitted", receipt=receipt)

    def require(self, receipt: ProofReceipt | dict[str, Any] | None) -> ProofReceipt:
        decision = self.admit(receipt)
        if not decision.allowed or decision.receipt is None:
            raise GateDenial(decision.reason)
        return decision.receipt

    def guard(self, act: Callable[[], Any], *, receipt: ProofReceipt | dict[str, Any] | None) -> Any:
        self.require(receipt)
        return act()
