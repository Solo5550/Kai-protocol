"""Kai Product Runtime — governed act + signed proof."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from kai.runtime.models import Capability, Contract, EvidenceBundle, Plan, PlanNode, Policy, utcnow
from kai.runtime.runtime import KaiRuntime

from .gate import KaiGate, GateDenial
from .proof import ProofReceipt, generate_issuer_keypair, issue_receipt, verify_receipt


@dataclass(frozen=True)
class ProvenAction:
    status: str
    output: Any
    receipt: ProofReceipt
    execution_id: str
    run_id: str
    decision: str


class KaiProductRuntime:
    def __init__(self, *, data_dir: str | Path | None = None, issuer_private: bytes | None = None) -> None:
        self._rt = KaiRuntime(data_dir=data_dir)
        if issuer_private is None:
            priv, pub, kid = generate_issuer_keypair()
            self._private = priv
            self._public = pub
            self._key_id = kid
        else:
            self._private = issuer_private
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
            from cryptography.hazmat.primitives import serialization
            import hashlib
            pub = Ed25519PrivateKey.from_private_bytes(issuer_private).public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            )
            self._public = pub
            self._key_id = hashlib.sha256(pub).hexdigest()[:16]
        self.gate = KaiGate(
            require_signature=True,
            public_keys={self._key_id: self._public},
            single_use=True,
        )
        self._handlers: dict[str, Callable[[dict[str, Any]], Any]] = {}
        self._caps: dict[str, Capability] = {}

    @property
    def public_key(self) -> bytes:
        return self._public

    @property
    def key_id(self) -> str:
        return self._key_id

    def install(
        self,
        capability_id: str,
        handler: Callable[[dict[str, Any]], Any],
        *,
        owner: str = "product",
        implementation_id: str | None = None,
    ) -> None:
        impl = implementation_id or f"impl.{capability_id}"
        cap = Capability(capability_id=capability_id, implementation_id=impl, owner=owner)
        self._rt.install_capability(cap, handler)
        self._handlers[capability_id] = handler
        self._caps[capability_id] = cap

    def act(
        self,
        *,
        capability_id: str,
        objective: str,
        input_data: dict[str, Any],
        contract_id: str = "product.contract",
        contract_version: str = "1",
        expected_outcome: dict[str, Any] | None = None,
        evidence_source: str = "product",
        tenant_id: str = "default",
        actor_id: str = "runtime",
        audience: str = "kai.gate",
        ttl_seconds: int = 3600,
    ) -> ProvenAction:
        if capability_id not in self._handlers:
            raise GateDenial(f"capability_not_installed:{capability_id}")
        handler = self._handlers[capability_id]
        contract = Contract(id=contract_id, version=contract_version)
        policy = Policy(
            policy_id=f"policy.{capability_id}",
            allowed_capabilities=[capability_id],
            allowed_regions=["local"],
        )
        evidence = EvidenceBundle(
            evidence_id=f"ev-{capability_id}",
            sources=[{"source_id": evidence_source, "observed_at": "2099-01-01T00:00:00+00:00"}],
            integrity={"validated": True},
        )
        plan = Plan(
            plan_id=f"plan-{capability_id}",
            objective=objective,
            nodes=[PlanNode(node_id="n1", capability_requirement={"capability_id": capability_id})],
            acceptance_criteria=["ok"],
        )
        out = self._rt.execute(
            objective=objective,
            input_data=input_data,
            contract=contract,
            policy=policy,
            capability_id=capability_id,
            evidence=evidence,
            plan=plan,
            handler=handler,
            expected_outcome=expected_outcome,
        )
        status = out.kernel.status
        decision = "ACCEPTED" if status == "SUCCESS" else "REJECTED"
        receipt = issue_receipt(
            action=objective,
            contract_id=contract_id,
            contract_version=contract_version,
            execution_id=out.execution.execution_id,
            run_id=getattr(out.execution, "run_id", None) or out.execution.execution_id,
            status=status if status in {"SUCCESS", "FAILURE", "DENIED", "TIMEOUT"} else "FAILURE",
            output=out.kernel.output,
            evidence={"evidence_id": evidence.evidence_id, "validated": True},
            decision=decision,
            issued_at=utcnow(),
            tenant_id=tenant_id,
            actor_id=actor_id,
            audience=audience,
            ttl_seconds=ttl_seconds,
            private_key=self._private,
            key_id=self._key_id,
            require_signature=True,
        )
        return ProvenAction(
            status=status,
            output=out.kernel.output,
            receipt=receipt,
            execution_id=out.execution.execution_id,
            run_id=receipt.run_id,
            decision=decision,
        )

    def verify(self, receipt: ProofReceipt | dict[str, Any]) -> bool:
        return verify_receipt(receipt, public_keys={self._key_id: self._public}, require_signature=True)

    def admit(self, receipt: ProofReceipt | dict[str, Any] | None):
        return self.gate.admit(receipt)
