from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Iterable

from kai.protocol.models import GateStatus, Unit
from kai.pyramid.graph import KnowledgeGraph

from .models import MasterFinding, MasterReview, MasterStage, MasterStageResult, MasterStatus

if TYPE_CHECKING:
    from kai.engine.adaptive import DepthDecision, DepthSignals
    from kai.engine.assurance import AssuranceSummary


@dataclass(frozen=True)
class MasterConfig:
    """Policy for the governing layer."""

    strict: bool = True
    require_explicit_criterion_name: bool = True
    require_alternatives_for_decision: bool = False
    max_findings_per_stage: int = 32


_STAGE_WEIGHTS = {
    MasterStage.UNDERSTAND: 1.4,
    MasterStage.FIRST_PRINCIPLES: 1.2,
    MasterStage.EXPERT: 0.8,
    MasterStage.SKEPTIC: 1.4,
    MasterStage.ALTERNATIVES: 0.8,
    MasterStage.COMPARE: 0.8,
    MasterStage.VERIFY: 1.6,
    MasterStage.DECIDE: 1.2,
    MasterStage.OPTIMIZE: 0.9,
    MasterStage.EXECUTE: 1.0,
    MasterStage.DEBUG: 1.1,
    MasterStage.REALITY_CHECK: 1.4,
    MasterStage.OUTPUT: 1.0,
    MasterStage.CONTINUOUS_IMPROVEMENT: 1.0,
}


class MasterGovernor:
    """Executable implementation of the user-supplied MASTER protocol.

    MASTER is a governing/control layer. It does not replace domain reasoning;
    it decides whether the reasoning process has satisfied its declared contract,
    exposed its objections/failures, and earned permission to promote a result.
    """

    def __init__(self, config: MasterConfig | None = None) -> None:
        self.config = config or MasterConfig()

    def preflight(
        self,
        *,
        source_id: str,
        source_claim: str,
        parts: list[dict[str, Any]],
        criterion_name: str | None,
        criterion_ok: bool | None,
        signals: DepthSignals,
        expert_methods: Iterable[str] | None = None,
        alternatives: list[dict[str, Any]] | None = None,
    ) -> MasterReview:
        methods = tuple(expert_methods or ("deterministic-protocol-analysis",))
        has_decision_context = bool(alternatives)
        results: list[MasterStageResult] = []

        findings: list[MasterFinding] = []
        if not source_id:
            findings.append(self._finding(MasterStage.UNDERSTAND, "critical", "source_id is missing"))
        if not source_claim.strip():
            findings.append(self._finding(MasterStage.UNDERSTAND, "critical", "source claim is empty"))
        if self.config.require_explicit_criterion_name and not criterion_name:
            findings.append(self._finding(MasterStage.UNDERSTAND, "high", "criterion_name is not explicitly declared"))
        if criterion_ok is None:
            findings.append(self._finding(MasterStage.UNDERSTAND, "critical", "criterion result is not declared"))
        contract_complete = bool(source_id and source_claim.strip() and criterion_ok is not None)
        if self.config.require_explicit_criterion_name:
            contract_complete = contract_complete and bool((criterion_name or "").strip())
        status = MasterStatus.PASS if contract_complete else (MasterStatus.BLOCKED if self.config.strict else MasterStatus.UNRESOLVED)
        results.append(self._result(MasterStage.UNDERSTAND, status, "Contract inputs are explicit." if status == MasterStatus.PASS else "The contract is missing required declarations.", findings=findings))

        fp_findings: list[MasterFinding] = []
        if not parts:
            fp_findings.append(self._finding(MasterStage.FIRST_PRINCIPLES, "high", "no decomposed units were supplied"))
        for part in parts[: self.config.max_findings_per_stage]:
            uid = str(part.get("unit_id", "<unknown>"))
            if not part.get("unit_id"):
                fp_findings.append(self._finding(MasterStage.FIRST_PRINCIPLES, "high", "decomposed unit has no unit_id", uid))
            if not str(part.get("claim", "")).strip():
                fp_findings.append(self._finding(MasterStage.FIRST_PRINCIPLES, "high", f"unit {uid} has no claim", uid))
        results.append(self._result(MasterStage.FIRST_PRINCIPLES, MasterStatus.PASS if not fp_findings else MasterStatus.UNRESOLVED, "Input decomposition is structurally inspectable." if not fp_findings else "Decomposition contract is incomplete.", findings=fp_findings))

        results.append(self._result(MasterStage.EXPERT, MasterStatus.PASS if methods else MasterStatus.UNRESOLVED, f"Declared methods: {', '.join(methods) or 'none'}."))

        skeptic_findings: list[MasterFinding] = []
        for part in parts[: self.config.max_findings_per_stage]:
            uid = str(part.get("unit_id", "<unknown>"))
            if not part.get("evidence"):
                skeptic_findings.append(self._finding(MasterStage.SKEPTIC, "medium", f"unit {uid} has no evidence attached", uid))
            if not part.get("test"):
                skeptic_findings.append(self._finding(MasterStage.SKEPTIC, "medium", f"unit {uid} has no test specification", uid))
        results.append(self._result(MasterStage.SKEPTIC, MasterStatus.PASS, "Skeptical scan completed; findings do not become agreement merely by being recorded.", findings=skeptic_findings))

        if has_decision_context or self.config.require_alternatives_for_decision:
            alt_ok = bool(alternatives and len(alternatives) >= 2)
            status = MasterStatus.PASS if alt_ok else MasterStatus.UNRESOLVED
            rationale = "At least two decision alternatives are declared." if alt_ok else "A decision context needs at least two explicit alternatives."
            results.append(self._result(MasterStage.ALTERNATIVES, status, rationale))
            results.append(self._result(MasterStage.COMPARE, status, "Comparison set is available." if alt_ok else "Comparison cannot be grounded."))
        else:
            results.append(self._result(MasterStage.ALTERNATIVES, MasterStatus.NOT_APPLICABLE, "No option-selection problem was declared.", required=False))
            results.append(self._result(MasterStage.COMPARE, MasterStatus.NOT_APPLICABLE, "No option-selection problem was declared.", required=False))

        results.extend([
            self._result(MasterStage.VERIFY, MasterStatus.NOT_APPLICABLE, "Verification runs after execution.", required=False),
            self._result(MasterStage.DECIDE, MasterStatus.NOT_APPLICABLE, "Adjudication runs after execution.", required=False),
            self._result(MasterStage.OPTIMIZE, MasterStatus.PASS if self._depth_valid(signals) else MasterStatus.UNRESOLVED, "Adaptive depth inputs are within [0,1]." if self._depth_valid(signals) else "Adaptive depth inputs are outside [0,1]."),
            self._result(MasterStage.EXECUTE, MasterStatus.PASS, "Execution prerequisites are satisfied."),
            self._result(MasterStage.DEBUG, MasterStatus.NOT_APPLICABLE, "Runtime debug census is post-execution.", required=False),
            self._result(MasterStage.REALITY_CHECK, MasterStatus.NOT_APPLICABLE, "Runtime reality check is post-execution.", required=False),
            self._result(MasterStage.OUTPUT, MasterStatus.NOT_APPLICABLE, "Output validation is post-execution.", required=False),
            self._result(MasterStage.CONTINUOUS_IMPROVEMENT, MasterStatus.NOT_APPLICABLE, "Improvement actions are post-execution.", required=False),
        ])
        return self._review("preflight", results)

    def postflight(
        self,
        *,
        graph: KnowledgeGraph,
        source_id: str,
        source_claim: str,
        criterion_name: str | None,
        synthesis: Unit,
        reconstruction: Unit,
        assurance: AssuranceSummary,
        depth: DepthDecision,
        criterion_ok: bool | None,
        export_payload: dict[str, Any],
        census: dict[str, list[dict[str, Any]]],
        decision_options: list[dict[str, Any]] | None = None,
    ) -> MasterReview:
        results: list[MasterStageResult] = []
        contract_ok = bool(source_id and source_claim.strip() and criterion_ok is not None)
        if self.config.require_explicit_criterion_name:
            contract_ok = contract_ok and bool((criterion_name or "").strip())
        results.append(self._result(MasterStage.UNDERSTAND, MasterStatus.PASS if contract_ok else MasterStatus.BLOCKED, "Execution contract remained explicit." if contract_ok else "Execution contract lost a required declaration."))

        fp_findings = self._graph_findings(graph)
        results.append(self._result(MasterStage.FIRST_PRINCIPLES, MasterStatus.PASS if not fp_findings else MasterStatus.FAIL, "Graph topology and decomposition are internally consistent." if not fp_findings else "Decomposition integrity has structural findings.", findings=fp_findings))
        results.append(self._result(MasterStage.EXPERT, MasterStatus.PASS, "Expert-method registry is explicit; domain adapters remain external to the protocol core."))

        skeptic_findings = self._skeptic_findings(graph, synthesis, reconstruction)
        results.append(self._result(MasterStage.SKEPTIC, MasterStatus.PASS, "Skeptical scan executed; adverse findings remain visible.", findings=skeptic_findings))

        if decision_options or self.config.require_alternatives_for_decision:
            alt_ok = bool(decision_options and len(decision_options) >= 2)
            results.append(self._result(MasterStage.ALTERNATIVES, MasterStatus.PASS if alt_ok else MasterStatus.UNRESOLVED, "Decision alternatives are present." if alt_ok else "Decision context lacks two explicit alternatives."))
            results.append(self._result(MasterStage.COMPARE, MasterStatus.PASS if alt_ok else MasterStatus.UNRESOLVED, "Comparison set is present." if alt_ok else "Comparison lacks a grounded option set."))
        else:
            results.append(self._result(MasterStage.ALTERNATIVES, MasterStatus.NOT_APPLICABLE, "No option-selection problem was declared.", required=False))
            results.append(self._result(MasterStage.COMPARE, MasterStatus.NOT_APPLICABLE, "No option-selection problem was declared.", required=False))

        verify_ok = assurance.all_pass and bool(reconstruction.metadata.get("preserved"))
        results.append(self._result(MasterStage.VERIFY, MasterStatus.PASS if verify_ok else MasterStatus.FAIL, "Base assurance gates and reconstruction passed." if verify_ok else "Base assurance/reconstruction did not fully pass."))
        decision_ready = bool(criterion_ok is not None and assurance.all_pass)
        results.append(self._result(MasterStage.DECIDE, MasterStatus.PASS if decision_ready else MasterStatus.UNRESOLVED, "Adjudication inputs are ready." if decision_ready else "Adjudication is not justified because base assurance is incomplete."))
        results.append(self._result(MasterStage.OPTIMIZE, MasterStatus.PASS if 1 <= depth.depth <= 12 else MasterStatus.UNRESOLVED, "Adaptive depth is bounded and recorded."))
        execute_ok = bool(graph.units and export_payload)
        results.append(self._result(MasterStage.EXECUTE, MasterStatus.PASS if execute_ok else MasterStatus.FAIL, "Execution artifacts were materialized." if execute_ok else "Execution artifacts are incomplete."))

        census_findings = self._census_findings(census)
        results.append(self._result(MasterStage.DEBUG, MasterStatus.PASS, "Failure/bottleneck/gap/drift censuses were executed and persisted.", findings=census_findings))
        results.append(self._result(MasterStage.REALITY_CHECK, MasterStatus.PASS, "Observed failures, gaps and drift are surfaced rather than hidden.", findings=census_findings))
        output_ok = isinstance(export_payload.get("units"), list) and isinstance(export_payload.get("messages"), list)
        results.append(self._result(MasterStage.OUTPUT, MasterStatus.PASS if output_ok else MasterStatus.FAIL, "Session export is structurally present." if output_ok else "Session export is incomplete."))

        actions = self._improvement_actions(census, skeptic_findings)
        results.append(self._result(MasterStage.CONTINUOUS_IMPROVEMENT, MasterStatus.PASS, "Improvement actions were derived from observed findings."))

        critical = self._dedupe_findings(f for r in results for f in r.findings if f.severity == "critical" and not f.resolved)
        return self._review("postflight", results, critical_findings=critical, improvement_actions=actions)

    def master_gate(self, review: MasterReview) -> GateStatus:
        if review.promotable:
            return GateStatus.PASS
        if any(r.required and r.status == MasterStatus.BLOCKED for r in review.stage_results):
            return GateStatus.BLOCKED
        if any(r.required and r.status == MasterStatus.UNRESOLVED for r in review.stage_results):
            return GateStatus.UNRESOLVED
        return GateStatus.FAIL

    @staticmethod
    def _dedupe_findings(findings: Iterable[MasterFinding]) -> tuple[MasterFinding, ...]:
        seen: dict[str, MasterFinding] = {}
        for finding in findings:
            seen.setdefault(finding.id, finding)
        return tuple(seen.values())

    def _review(self, mode: str, results: list[MasterStageResult], *, critical_findings: tuple[MasterFinding, ...] = (), improvement_actions: tuple[str, ...] = ()) -> MasterReview:
        applicable = [r for r in results if r.status != MasterStatus.NOT_APPLICABLE]
        denom = sum(r.weight for r in applicable) or 1.0
        points = 0.0
        severity_penalty = {"critical": 0.50, "high": 0.20, "medium": 0.05, "low": 0.02}
        for r in applicable:
            stage_value = {MasterStatus.PASS: 1.0, MasterStatus.UNRESOLVED: 0.35}.get(r.status, 0.0)
            finding_factor = 1.0
            for finding in r.findings:
                if not finding.resolved:
                    finding_factor *= 1.0 - severity_penalty.get(finding.severity, 0.05)
            points += r.weight * stage_value * finding_factor
        score = 100.0 * max(0.0, points) / denom
        return MasterReview(mode=mode, score=score, stage_results=tuple(results), critical_findings=critical_findings, improvement_actions=tuple(improvement_actions))

    @staticmethod
    def _depth_valid(signals: DepthSignals) -> bool:
        return all(0.0 <= float(v) <= 1.0 for v in signals.__dict__.values())

    @staticmethod
    def _finding(stage: MasterStage, severity: str, statement: str, unit_id: str | None = None, evidence_refs: tuple[str, ...] = ()) -> MasterFinding:
        raw = f"{stage.value}|{severity}|{unit_id or ''}|{statement}|{'|'.join(evidence_refs)}".encode("utf-8")
        fid = "master-" + hashlib.sha256(raw).hexdigest()[:16]
        return MasterFinding(id=fid, stage=stage, severity=severity, statement=statement, unit_id=unit_id, evidence_refs=evidence_refs)

    @staticmethod
    def _result(stage: MasterStage, status: MasterStatus, rationale: str, *, required: bool = True, findings: list[MasterFinding] | None = None) -> MasterStageResult:
        return MasterStageResult(stage=stage, status=status, rationale=rationale, weight=_STAGE_WEIGHTS[stage], required=required, findings=tuple(findings or ()))

    @staticmethod
    def _graph_findings(graph: KnowledgeGraph) -> list[MasterFinding]:
        findings: list[MasterFinding] = []
        try:
            graph.topological()
        except ValueError as exc:
            findings.append(MasterGovernor._finding(MasterStage.FIRST_PRINCIPLES, "critical", str(exc)))
        roots = graph.roots()
        if len(roots) != 1:
            findings.append(MasterGovernor._finding(MasterStage.FIRST_PRINCIPLES, "high", f"expected exactly one root; found {len(roots)}"))
        for unit in graph.units.values():
            for parent_id in unit.parent_ids:
                if parent_id not in graph.units:
                    findings.append(MasterGovernor._finding(MasterStage.FIRST_PRINCIPLES, "critical", f"{unit.unit_id}: missing parent {parent_id}", unit.unit_id))
        return findings

    @staticmethod
    def _skeptic_findings(graph: KnowledgeGraph, synthesis: Unit, reconstruction: Unit) -> list[MasterFinding]:
        findings: list[MasterFinding] = []
        for unit in graph.units.values():
            if unit.unit_id in {synthesis.unit_id, reconstruction.unit_id}:
                continue
            # Source roots are decomposition containers; their direct evidence is
            # expected to be supplied by child units unless the contract says otherwise.
            if not unit.parent_ids and graph.children(unit.unit_id):
                continue
            if unit.claim and not unit.evidence:
                findings.append(MasterGovernor._finding(MasterStage.SKEPTIC, "medium", "claim has no evidence", unit.unit_id))
            if unit.tests and not unit.results:
                findings.append(MasterGovernor._finding(MasterStage.SKEPTIC, "high", "test specification has no observed result", unit.unit_id))
            for result in unit.results:
                if result.status == GateStatus.FAIL:
                    findings.append(MasterGovernor._finding(MasterStage.SKEPTIC, "critical", "a test produced FAIL", unit.unit_id, (result.test_id,)))
        if not reconstruction.metadata.get("preserved"):
            findings.append(MasterGovernor._finding(MasterStage.SKEPTIC, "critical", "reconstruction does not preserve the source structure"))
        return findings

    @staticmethod
    def _census_findings(census: dict[str, list[dict[str, Any]]]) -> list[MasterFinding]:
        out: list[MasterFinding] = []
        for category, items in census.items():
            for item in items:
                severity = str(item.get("severity", "medium"))
                if category == "failures" and severity in {"critical", "high"}:
                    out.append(MasterGovernor._finding(MasterStage.DEBUG, severity, str(item.get("statement", "failure census item")), item.get("unit_id")))
                elif category == "gaps" and severity == "critical":
                    out.append(MasterGovernor._finding(MasterStage.REALITY_CHECK, severity, str(item.get("statement", "critical gap")), item.get("unit_id")))
        return out

    @staticmethod
    def _improvement_actions(census: dict[str, list[dict[str, Any]]], skeptic_findings: list[MasterFinding]) -> list[str]:
        actions: list[str] = []
        for item in census.get("failures", [])[:8]:
            actions.append(f"Investigate failure {item.get('id', '<unknown>')} at root cause level before promotion.")
        for item in census.get("gaps", [])[:8]:
            actions.append(f"Close gap {item.get('id', '<unknown>')} or explicitly declare it non-applicable in the contract.")
        if skeptic_findings:
            actions.append("Review skeptical findings before the next promotion attempt.")
        return actions
