from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class MasterStage(str, Enum):
    UNDERSTAND = "UNDERSTAND"
    FIRST_PRINCIPLES = "FIRST_PRINCIPLES"
    EXPERT = "EXPERT"
    SKEPTIC = "SKEPTIC"
    ALTERNATIVES = "ALTERNATIVES"
    COMPARE = "COMPARE"
    VERIFY = "VERIFY"
    DECIDE = "DECIDE"
    OPTIMIZE = "OPTIMIZE"
    EXECUTE = "EXECUTE"
    DEBUG = "DEBUG"
    REALITY_CHECK = "REALITY_CHECK"
    OUTPUT = "OUTPUT"
    CONTINUOUS_IMPROVEMENT = "CONTINUOUS_IMPROVEMENT"


class MasterStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    BLOCKED = "BLOCKED"
    UNRESOLVED = "UNRESOLVED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True)
class MasterFinding:
    id: str
    stage: MasterStage
    severity: str
    statement: str
    unit_id: str | None = None
    evidence_refs: tuple[str, ...] = ()
    resolved: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"stage": self.stage.value}


@dataclass(frozen=True)
class MasterStageResult:
    stage: MasterStage
    status: MasterStatus
    rationale: str
    weight: float = 1.0
    required: bool = True
    findings: tuple[MasterFinding, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "stage": self.stage.value,
            "status": self.status.value,
            "rationale": self.rationale,
            "weight": self.weight,
            "required": self.required,
            "findings": [f.to_dict() for f in self.findings],
        }


@dataclass(frozen=True)
class MasterReview:
    mode: str
    score: float
    stage_results: tuple[MasterStageResult, ...]
    critical_findings: tuple[MasterFinding, ...] = ()
    improvement_actions: tuple[str, ...] = ()

    @property
    def required_pass(self) -> bool:
        return not any(
            r.required and r.status in {
                MasterStatus.FAIL,
                MasterStatus.BLOCKED,
                MasterStatus.UNRESOLVED,
            }
            for r in self.stage_results
        )

    @property
    def promotable(self) -> bool:
        return self.required_pass and not any(not f.resolved for f in self.critical_findings)

    @property
    def blockers(self) -> list[str]:
        return [
            f"{r.stage.value}: {r.rationale}"
            for r in self.stage_results
            if r.required and r.status in {MasterStatus.FAIL, MasterStatus.BLOCKED, MasterStatus.UNRESOLVED}
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "score": round(float(self.score), 2),
            "promotable": self.promotable,
            "required_pass": self.required_pass,
            "blockers": self.blockers,
            "stages": [r.to_dict() for r in self.stage_results],
            "critical_findings": [f.to_dict() for f in self.critical_findings],
            "improvement_actions": list(self.improvement_actions),
        }
