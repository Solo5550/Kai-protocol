from __future__ import annotations

import base64
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

SCHEME = "kai-secret/1"
SALT_BYTES = 16
NONCE_BYTES = 12
KEY_BYTES = 32


class SecretEnvelopeError(ValueError):
    pass


def _b64e(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def _b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode((value + "=" * (-len(value) % 4)).encode("ascii"))


def generate_master_key() -> str:
    return _b64e(os.urandom(KEY_BYTES))


def write_master_key(path: str | Path) -> str:
    key = generate_master_key()
    target = Path(path)
    target.write_text(key + "\n", encoding="utf-8")
    try:
        target.chmod(0o600)
    except OSError:
        pass
    return key


def read_master_key(path: str | Path) -> bytes:
    raw = Path(path).read_text(encoding="utf-8").strip()
    try:
        key = _b64d(raw)
    except Exception as exc:
        raise SecretEnvelopeError("invalid master key encoding") from exc
    if len(key) != KEY_BYTES:
        raise SecretEnvelopeError("master key must decode to 32 bytes")
    return key


def _aad(scheme: str, key_id: str, key_fingerprint: str, aead: str) -> bytes:
    return f"{scheme}|{key_id}|{key_fingerprint}|{aead}".encode("utf-8")


def seal(plaintext: str | bytes, key: bytes, *, key_id: str = "master") -> dict[str, Any]:
    if len(key) != KEY_BYTES:
        raise SecretEnvelopeError("master key must be 32 bytes")
    data = plaintext.encode("utf-8") if isinstance(plaintext, str) else bytes(plaintext)
    nonce = os.urandom(NONCE_BYTES)
    digest = hashlib.sha256(key).hexdigest()[:16]
    ciphertext = AESGCM(key).encrypt(nonce, data, _aad(SCHEME, key_id, digest, "AES-256-GCM"))
    return {
        "scheme": SCHEME,
        "key_id": key_id,
        "kdf": "none-random-256",
        "aead": "AES-256-GCM",
        "nonce": _b64e(nonce),
        "ciphertext": _b64e(ciphertext),
        "key_fingerprint": digest,
    }


def open_seal(envelope: dict[str, Any], key: bytes) -> bytes:
    if envelope.get("scheme") != SCHEME:
        raise SecretEnvelopeError("unsupported envelope scheme")
    if envelope.get("aead") != "AES-256-GCM":
        raise SecretEnvelopeError("unsupported AEAD")
    if len(key) != KEY_BYTES:
        raise SecretEnvelopeError("master key must be 32 bytes")
    try:
        nonce = _b64d(envelope["nonce"])
        ciphertext = _b64d(envelope["ciphertext"])
    except Exception as exc:
        raise SecretEnvelopeError("invalid envelope encoding") from exc
    if len(nonce) != NONCE_BYTES:
        raise SecretEnvelopeError("invalid nonce size")
    try:
        return AESGCM(key).decrypt(nonce, ciphertext, _aad(SCHEME, envelope["key_id"], envelope.get("key_fingerprint", ""), envelope["aead"]))
    except Exception as exc:
        raise SecretEnvelopeError("secret authentication failed") from exc


def dump_envelope(envelope: dict[str, Any]) -> str:
    return json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
