from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


def _b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode((value + "=" * (-len(value) % 4)).encode("ascii"))


def canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def generate_authority_keypair(private_path: str | Path, public_path: str | Path) -> None:
    private = Ed25519PrivateKey.generate()
    raw_private = private.private_bytes(
        serialization.Encoding.Raw,
        serialization.PrivateFormat.Raw,
        serialization.NoEncryption(),
    )
    raw_public = private.public_key().public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )
    p = Path(private_path)
    q = Path(public_path)
    p.write_text(_b64e(raw_private) + "\n", encoding="utf-8")
    q.write_text(_b64e(raw_public) + "\n", encoding="utf-8")
    try:
        p.chmod(0o600)
        q.chmod(0o644)
    except OSError:
        pass


def fingerprint(public_path: str | Path) -> str:
    raw_public = _b64d(Path(public_path).read_text(encoding="utf-8").strip())
    return hashlib.sha256(raw_public).hexdigest()[:16]


def sign(value: dict[str, Any], private_path: str | Path) -> str:
    raw_private = _b64d(Path(private_path).read_text(encoding="utf-8").strip())
    private = Ed25519PrivateKey.from_private_bytes(raw_private)
    return _b64e(private.sign(canonical_bytes(value)))


def verify(value: dict[str, Any], signature: str, public_path: str | Path) -> bool:
    raw_public = _b64d(Path(public_path).read_text(encoding="utf-8").strip())
    public = Ed25519PublicKey.from_public_bytes(raw_public)
    try:
        public.verify(_b64d(signature), canonical_bytes(value))
        return True
    except Exception:
        return False
