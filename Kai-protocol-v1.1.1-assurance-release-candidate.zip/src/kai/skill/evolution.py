from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable

from .models import Capability, CapabilityGap, LifecycleLevel


@dataclass(frozen=True, slots=True)
class Mutation:
    mutation_id: str
    target_capability: str
    change: str
    expected_effect: str
    reversible: bool = True

    def to_dict(self):
        return {
            "mutation_id": self.mutation_id,
            "target_capability": self.target_capability,
            "change": self.change,
            "expected_effect": self.expected_effect,
            "reversible": self.reversible,
        }


class EvolutionCortex:
    """Generate bounded, explicit mutations; never writes source code itself."""

    def propose_mutations(self, capabilities: Iterable[Capability], gaps: Iterable[CapabilityGap]) -> list[Mutation]:
        caps = list(capabilities)
        gap_list = list(gaps)
        out: list[Mutation] = []
        for gap in gap_list:
            target = gap.recommended_specialization or gap.capability_id or "unknown"
            raw = json.dumps([target, gap.statement], separators=(",", ":"), sort_keys=True)
            out.append(Mutation("mut-" + hashlib.sha256(raw.encode()).hexdigest()[:16], target, f"specialize:{target}", "close declared capability gap"))
        for cap in caps:
            if cap.observability < 0.5:
                out.append(Mutation("mut-" + hashlib.sha256((cap.capability_id + "|observability").encode()).hexdigest()[:16], cap.capability_id, "raise-observability", "increase diagnostic coverage"))
        return sorted(out, key=lambda m: m.mutation_id)

    @staticmethod
    def mutation_allowed(level: LifecycleLevel) -> bool:
        return level.rank <= LifecycleLevel.L4_SUPERVISED_PROMOTION.rank
