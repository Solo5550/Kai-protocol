from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Callable, Iterable

from .core import KaiSkill
from .evolution import EvolutionCortex
from .models import Capability, GateStatus, LifecycleLevel, ProposalStatus, SkillCell, SkillContract
from .solution import SolutionOption
from .execution import ExecutionEngine


@dataclass(frozen=True, slots=True)
class SkillPipelineReport:
    status: GateStatus
    lifecycle_level: LifecycleLevel
    analysis: dict[str, Any]
    mutations: list[dict[str, Any]]
    proposal: dict[str, Any] | None
    cell: dict[str, Any] | None
    root_change_allowed: bool
    actions: list[str]
    solution_matrix: list[dict[str, Any]] | None = None
    solution_portfolio: list[dict[str, Any]] | None = None
    execution_history: list[dict[str, Any]] | None = None

    def to_dict(self):
        return asdict(self) | {"status": self.status.value, "lifecycle_level": self.lifecycle_level.value}


class SkillPipeline:
    """Executes the supplied SKILL lifecycle with MASTER-controlled promotion."""

    def __init__(self, root_contract: SkillContract | None = None) -> None:
        self.root = root_contract or SkillContract(
            skill_id="kai-root",
            name="Kai Protocol SKILL",
            objective="govern capability analysis, evolution, execution and proof",
            capabilities=("forensics", "reasoning", "execution", "proof", "provenance", "evolution", "reproduction"),
            inputs=("project",),
            outputs=("verified-capability",),
            resource_budget={"cpu": 1.0, "memory_mb": 512.0},
            permission_boundary=("kai-dialogue",),
            lifecycle_max=LifecycleLevel.L4_SUPERVISED_PROMOTION,
        )
        self.skill = KaiSkill(self.root)
        self.evolution = EvolutionCortex()

    def run(
        self,
        *,
        project: str,
        capabilities: Iterable[Capability],
        required_capabilities: Iterable[str],
        specialization: str,
        handler: Callable[[dict[str, Any]], Any],
        requested_level: LifecycleLevel = LifecycleLevel.L2_SANDBOX,
        resources: dict[str, float] | None = None,
        available_resources: dict[str, float] | None = None,
    ) -> SkillPipelineReport:
        self.skill.absorb(capabilities)
        analysis = self.skill.analyze(required_capabilities)
        gaps = self.skill.gap_analysis(required_capabilities)
        mutations = [m.to_dict() for m in self.evolution.propose_mutations(self.skill.functional_decomposition(), gaps)]
        options = [
            SolutionOption("specialize-child", "Create a sandboxed specialized child cell for the declared gap", 1.0 if gaps else 0.2, 0.2, 0.1, 1.0),
            SolutionOption("defer-gap", "Keep the gap unresolved and collect more evidence", 0.4, 0.05, 0.05, 1.0),
        ]
        matrix = self.skill.solutions.matrix(options)
        portfolio = [x.to_dict() for x in self.skill.solutions.portfolio(options, budget=1.0)]
        if requested_level.rank > LifecycleLevel.L4_SUPERVISED_PROMOTION.rank:
            return SkillPipelineReport(GateStatus.BLOCKED, requested_level, analysis, mutations, None, None, False, ["L5/L6 disabled by default; independent deployment authorization required."], matrix, portfolio, [])
        if requested_level.rank < LifecycleLevel.L2_SANDBOX.rank:
            proposal = self.skill.propose_reproduction(project, required_capabilities, specialization, resources=resources, level=requested_level)
            return SkillPipelineReport(GateStatus.PASS, requested_level, analysis, mutations, proposal.to_dict(), None, False, ["L0/L1 are observation/simulation only; no child cell is created."], matrix, portfolio, [])
        proposal = self.skill.propose_reproduction(project, required_capabilities, specialization, resources=resources, level=requested_level)
        exec_engine = ExecutionEngine(self.skill.reproduction.sandbox)
        self.skill.reproduction.sandbox.register(specialization, handler)
        built = exec_engine.build(specialization)
        smoke = exec_engine.smoke_test(specialization, {"project": project, "specialization": specialization})
        if not built or smoke.status != "PASS":
            exec_engine.repair(specialization)
            exec_engine.rebuild(specialization)
            return SkillPipelineReport(GateStatus.FAIL, requested_level, analysis, mutations, proposal.to_dict(), None, False, ["BUILD/TEST failed; promotion blocked."], matrix, portfolio, exec_engine.history)
        cell = self.skill.reproduce(
            project,
            proposal,
            available_resources=available_resources or {"cpu": 1.0, "memory_mb": 512.0},
            capability_handler_name=specialization,
            capability_handler=handler,
            master_context={"criterion_name": "skill-promotion", "alternatives": []},
        )
        status = GateStatus.PASS if cell.status == ProposalStatus.ACTIVE else GateStatus.BLOCKED
        exec_engine.repair(specialization) if status != GateStatus.PASS else None
        exec_engine.rebuild(specialization)
        return SkillPipelineReport(status, cell.lifecycle_level, analysis, mutations, proposal.to_dict(), cell.to_dict(), False, ["L6 structural changes remain outside the protocol core."], matrix, portfolio, exec_engine.history)
