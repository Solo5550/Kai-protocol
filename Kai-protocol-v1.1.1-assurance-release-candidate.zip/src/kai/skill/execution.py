from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .models import LifecycleLevel


class SandboxViolation(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class SandboxPolicy:
    allowed_permissions: frozenset[str] = frozenset()
    max_steps: int = 1000
    max_output_bytes: int = 1_000_000
    network: bool = False
    subprocess: bool = False
    filesystem_write: bool = False


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    status: str
    output: Any
    steps: int
    output_bytes: int
    violations: tuple[str, ...] = ()

    def to_dict(self):
        return {"status": self.status, "output": self.output, "steps": self.steps, "output_bytes": self.output_bytes, "violations": list(self.violations)}


class SkillSandbox:
    """Capability sandbox: execute only explicitly registered handlers.

    It intentionally does not execute arbitrary child source code. L2-L4 are
    capability validation stages; real OS/container isolation belongs to a
    deployment boundary, not the protocol core.
    """

    def __init__(self, policy: SandboxPolicy | None = None) -> None:
        self.policy = policy or SandboxPolicy()
        self.handlers: dict[str, Callable[[dict[str, Any]], Any]] = {}

    def register(self, capability: str, handler: Callable[[dict[str, Any]], Any]) -> None:
        self.handlers[capability] = handler

    def run(self, capability: str, payload: dict[str, Any], *, level: LifecycleLevel, required_permission: str | None = None) -> ExecutionResult:
        if level.rank < LifecycleLevel.L2_SANDBOX.rank:
            raise SandboxViolation("execution requires at least L2_SANDBOX")
        if required_permission and required_permission not in self.policy.allowed_permissions:
            return ExecutionResult("BLOCKED", None, 0, 0, (f"permission-denied:{required_permission}",))
        if capability not in self.handlers:
            return ExecutionResult("BLOCKED", None, 0, 0, (f"capability-not-registered:{capability}",))
        try:
            output = self.handlers[capability](dict(payload))
            encoded = repr(output).encode("utf-8")
            if len(encoded) > self.policy.max_output_bytes:
                return ExecutionResult("FAIL", None, 1, len(encoded), ("output-limit",))
            return ExecutionResult("PASS", output, 1, len(encoded))
        except Exception as exc:
            return ExecutionResult("FAIL", {"error": type(exc).__name__, "message": str(exc)}, 1, len(str(exc).encode()), ("handler-failure",))


class ExecutionEngine:
    """Structured BUILD → TEST → REPAIR → REBUILD orchestration for registered skills."""

    def __init__(self, sandbox: SkillSandbox) -> None:
        self.sandbox = sandbox
        self.history: list[dict[str, Any]] = []

    def build(self, capability: str) -> bool:
        ok = capability in self.sandbox.handlers
        self.history.append({"stage": "BUILD", "capability": capability, "status": "PASS" if ok else "FAIL"})
        return ok

    def smoke_test(self, capability: str, payload: dict[str, Any]) -> ExecutionResult:
        result = self.sandbox.run(capability, payload, level=LifecycleLevel.L2_SANDBOX)
        self.history.append({"stage": "TEST", "capability": capability, "status": result.status})
        return result

    def test(self, capability: str, payload: dict[str, Any], expected: Any) -> ExecutionResult:
        result = self.sandbox.run(capability, payload, level=LifecycleLevel.L2_SANDBOX)
        actual = result.output
        passed = result.status == "PASS" and actual == expected
        final = ExecutionResult("PASS" if passed else ("FAIL" if result.status == "PASS" else result.status), actual, result.steps, result.output_bytes, result.violations)
        self.history.append({"stage": "TEST", "capability": capability, "status": final.status})
        return final

    def repair(self, capability: str) -> bool:
        # Core protocol does not mutate arbitrary source code. Repair is a controlled
        # registration replacement performed only by the embedding application.
        ok = capability in self.sandbox.handlers
        self.history.append({"stage": "REPAIR", "capability": capability, "status": "PASS" if ok else "BLOCKED"})
        return ok

    def rebuild(self, capability: str) -> bool:
        ok = self.build(capability)
        self.history.append({"stage": "REBUILD", "capability": capability, "status": "PASS" if ok else "FAIL"})
        return ok
