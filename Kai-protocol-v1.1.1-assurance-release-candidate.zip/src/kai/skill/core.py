from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from .forensics import ForensicCortex
from .governance import SkillGovernance
from .models import Capability, CapabilityGap, LifecycleLevel, ReproductionProposal, SkillCell, SkillContract
from .reasoning import ReasoningMatrix
from .reproduction import ReproductionEngine
from .solution import SolutionEngine, SolutionOption


@dataclass
class KaiSkill:
    """Composite executable SKILL layer above the Kai protocol."""

    root_contract: SkillContract
    capabilities: dict[str, Capability] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.forensics = ForensicCortex()
        self.reasoning = ReasoningMatrix()
        self.solutions = SolutionEngine()
        self.reproduction = ReproductionEngine()
        self.governance = SkillGovernance()

    def absorb(self, capabilities: Iterable[Capability]) -> None:
        for capability in capabilities:
            self.capabilities[capability.capability_id] = capability

    def functional_decomposition(self) -> list[Capability]:
        return [self.capabilities[k] for k in sorted(self.capabilities)]

    def gap_analysis(self, required_names: Iterable[str]) -> list[CapabilityGap]:
        return self.forensics.gap_census(self.capabilities.values(), required_names)

    def analyze(self, required_names: Iterable[str] = ()) -> dict[str, Any]:
        caps = self.functional_decomposition()
        gaps = self.gap_analysis(required_names)
        findings = self.forensics.inspect(caps)
        cells = self.reasoning.evaluate(caps, gaps)
        return {
            "stages": {
                "capability_absorption": len(caps),
                "functional_decomposition": [c.capability_id for c in caps],
                "capability_gap_analysis": [g.to_dict() for g in gaps],
                "forensic_findings": [f.to_dict() for f in findings],
                "reasoning_matrix": [c.to_dict() for c in cells],
                "reasoning_score": self.reasoning.aggregate(cells),
            }
        }

    def propose_reproduction(self, project: str, required_names: Iterable[str], specialization: str, *, resources: dict[str, float] | None = None, level: LifecycleLevel = LifecycleLevel.L2_SANDBOX) -> ReproductionProposal:
        gaps = self.gap_analysis(required_names)
        return self.reproduction.propose(parent=self.root_contract, project=project, capabilities=self.capabilities.values(), gaps=gaps, specialization=specialization, level=level, resources=resources)

    def reproduce(self, project: str, proposal: ReproductionProposal, *, available_resources: dict[str, float], capability_handler_name: str, capability_handler, master_context: dict[str, Any] | None = None) -> SkillCell:
        gaps = [CapabilityGap(g, None, g) for g in proposal.gap_ids]
        checks = self.reproduction.check(proposal, gaps=gaps, available_resources=available_resources, governance_passed=True)
        if not checks.passed:
            raise PermissionError(f"reproduction checks failed: {checks}")
        cell = self.reproduction.birth(proposal, checks=checks, parent=self.root_contract)
        self.reproduction.sandbox.register(capability_handler_name, capability_handler)
        result = self.reproduction.validate_capability(cell, capability_handler_name, {"project": project, "specialization": proposal.specialization})
        review = self.governance.review(cell, proposal, project=project, governance_context=master_context)
        cell.review_history.append(review)
        promoted = self.reproduction.promote(cell, reviewed=review.promotable, target_level=min((proposal.requested_level, cell.contract.lifecycle_max), key=lambda x: x.rank))
        cell.record("PROMOTION_RESULT", promoted=promoted, capability_result=result)
        return cell
