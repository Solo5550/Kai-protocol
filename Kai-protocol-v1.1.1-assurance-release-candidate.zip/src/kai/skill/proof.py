from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .models import GateStatus


@dataclass(frozen=True, slots=True)
class ProofCheck:
    name: str
    status: GateStatus
    evidence: str
    required: bool = True

    def to_dict(self):
        return {"name": self.name, "status": self.status.value, "evidence": self.evidence, "required": self.required}


class SkillProofEngine:
    """Unifies the SKILL proof/test taxonomy with Kai's assurance mindset."""

    TESTS = (
        "unit", "contract", "integration", "system", "reverse_engineering",
        "adversarial", "mutation", "chaos", "security", "performance",
        "reproducibility", "regression",
    )

    def review(self, results: dict[str, bool], *, required: Iterable[str] | None = None) -> list[ProofCheck]:
        required_set = set(required or self.TESTS)
        checks: list[ProofCheck] = []
        for name in self.TESTS:
            if name not in results:
                status = GateStatus.UNRESOLVED if name in required_set else GateStatus.NOT_APPLICABLE
                evidence = "no result supplied"
            else:
                status = GateStatus.PASS if results[name] else GateStatus.FAIL
                evidence = "observed pass" if results[name] else "observed failure"
            checks.append(ProofCheck(name, status, evidence, name in required_set))
        return checks

    @staticmethod
    def promotable(checks: Iterable[ProofCheck]) -> bool:
        return all((not c.required) or c.status == GateStatus.PASS for c in checks)

    @staticmethod
    def summary(checks: Iterable[ProofCheck]) -> dict[str, Any]:
        items = list(checks)
        return {
            "total": len(items),
            "required_pass": sum(c.required and c.status == GateStatus.PASS for c in items),
            "required_total": sum(c.required for c in items),
            "promotable": SkillProofEngine.promotable(items),
            "checks": [c.to_dict() for c in items],
        }
