from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from kai.master import MasterGovernor, MasterStatus

from .models import Gate, GateStatus, LifecycleLevel, ReproductionProposal, SkillCell, SkillReview


@dataclass(frozen=True, slots=True)
class SkillGovernanceConfig:
    allow_l5_autonomy: bool = False
    allow_l6_root_change: bool = False
    max_requested_level: LifecycleLevel = LifecycleLevel.L4_SUPERVISED_PROMOTION
    require_human_approval_for_l5: bool = True
    require_explicit_resource_budget: bool = True


class SkillGovernance:
    """MASTER-enforced governance boundary for skill evolution/reproduction."""

    def __init__(self, config: SkillGovernanceConfig | None = None) -> None:
        self.config = config or SkillGovernanceConfig()
        self.master = MasterGovernor()

    def review(self, cell: SkillCell, proposal: ReproductionProposal, *, project: str, governance_context: dict[str, Any] | None = None) -> SkillReview:
        context = governance_context or {}
        master_score = 100.0
        gates: list[Gate] = []

        gates.append(Gate("identity_contract", GateStatus.PASS if cell.contract.skill_id == proposal.child_skill_id else GateStatus.FAIL, "child contract matches proposal identity"))
        gates.append(Gate("necessity", GateStatus.PASS if proposal.gap_ids else GateStatus.FAIL, "proposal must cite at least one capability gap"))
        gates.append(Gate("specialization", GateStatus.PASS if proposal.specialization.strip() else GateStatus.FAIL, "specialization must be explicit"))
        gates.append(Gate("risk_boundary", GateStatus.PASS if proposal.requested_level.rank <= self.config.max_requested_level.rank else GateStatus.BLOCKED, "requested lifecycle level is inside policy boundary"))
        budget_ok = bool(proposal.requested_resources) if self.config.require_explicit_resource_budget else True
        gates.append(Gate("resource_governance", GateStatus.PASS if budget_ok else GateStatus.BLOCKED, "resource budget is explicit"))
        l5_ok = proposal.requested_level != LifecycleLevel.L5_AUTONOMOUS_EXECUTION or self.config.allow_l5_autonomy
        l6_ok = proposal.requested_level != LifecycleLevel.L6_ROOT_CHANGE or self.config.allow_l6_root_change
        gates.append(Gate("l5_boundary", GateStatus.PASS if l5_ok else GateStatus.BLOCKED, "L5 autonomy disabled by default" if not l5_ok else "L5 policy allows autonomy"))
        gates.append(Gate("l6_boundary", GateStatus.PASS if l6_ok else GateStatus.BLOCKED, "L6 root change disabled by default" if not l6_ok else "L6 policy allows root change"))
        # Invoke the actual MASTER stages over an explicit skill context.  We do not
        # invent a domain conclusion; we use MASTER to validate the process contract.
        parts = [{"unit_id": proposal.child_skill_id, "claim": proposal.objective, "evidence": True, "test": True}]
        criterion_name = str(context.get("criterion_name") or "skill-promotion-gates")
        criterion_ok = all(g.status == GateStatus.PASS for g in gates)
        review = self.master.preflight(
            source_id=cell.contract.parent_skill_id or cell.contract.skill_id,
            source_claim=project,
            parts=parts,
            criterion_name=criterion_name,
            criterion_ok=criterion_ok,
            signals=context.get("signals") if context.get("signals") is not None else __import__("kai.engine.adaptive", fromlist=["DepthSignals"]).DepthSignals(),
            expert_methods=["capability-contract-review", "sandbox-boundary-review", "adversarial-promotion-review"],
            alternatives=context.get("alternatives") or [
                {"option_id": "specialize-child", "description": "sandboxed specialized child"},
                {"option_id": "defer-gap", "description": "retain gap and collect evidence"},
            ],
        )
        if not review.promotable:
            master_score = min(master_score, float(review.score))
            gates.append(Gate("MASTER", GateStatus.BLOCKED, "MASTER preflight did not authorize promotion", severity="critical"))
            status = GateStatus.BLOCKED
        else:
            gates.append(Gate("MASTER", GateStatus.PASS, "MASTER preflight passed"))
            status = GateStatus.PASS if all(g.status == GateStatus.PASS for g in gates) else GateStatus.BLOCKED
        score = 100.0 * sum(g.status == GateStatus.PASS for g in gates) / len(gates)
        return SkillReview(cell.contract.skill_id, "promotion", proposal.requested_level, score, tuple(gates), master_score, status, ("Keep L5/L6 disabled until independent sandbox/authorization exists.",))
