from __future__ import annotations

from dataclasses import dataclass

from .models import LifecycleLevel, ProposalStatus, SkillCell


class LifecycleViolation(PermissionError):
    pass


@dataclass(frozen=True, slots=True)
class LifecycleTransition:
    old: LifecycleLevel
    new: LifecycleLevel
    status: str


class LifecycleController:
    """Monotonic lifecycle controller with explicit rollback to SAFE states only."""

    def advance(self, cell: SkillCell, target: LifecycleLevel, *, approved: bool) -> LifecycleTransition:
        if target.rank < cell.lifecycle_level.rank:
            old = cell.lifecycle_level
            cell.lifecycle_level = target
            cell.record("LIFECYCLE_ROLLBACK", level=target.value)
            return LifecycleTransition(old, target, "ROLLBACK_ALLOWED")
        if target == LifecycleLevel.L5_AUTONOMOUS_EXECUTION and not approved:
            raise LifecycleViolation("L5 requires explicit authorization")
        if target == LifecycleLevel.L6_ROOT_CHANGE and not approved:
            raise LifecycleViolation("L6 requires explicit authorization")
        if target.rank > cell.contract.lifecycle_max.rank:
            raise LifecycleViolation("target exceeds contract lifecycle boundary")
        old = cell.lifecycle_level
        cell.lifecycle_level = target
        if target.rank >= LifecycleLevel.L4_SUPERVISED_PROMOTION.rank and cell.status == ProposalStatus.VALIDATED:
            cell.status = ProposalStatus.ACTIVE
        cell.record("LIFECYCLE_ADVANCE", level=target.value)
        return LifecycleTransition(old, target, "ADVANCED")
