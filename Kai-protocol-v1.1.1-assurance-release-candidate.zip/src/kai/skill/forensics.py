from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .models import Capability, CapabilityGap


@dataclass(frozen=True, slots=True)
class ForensicFinding:
    category: str
    statement: str
    severity: str
    capability_id: str | None = None
    metric: str | None = None
    value: float | None = None
    threshold: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category,
            "statement": self.statement,
            "severity": self.severity,
            "capability_id": self.capability_id,
            "metric": self.metric,
            "value": self.value,
            "threshold": self.threshold,
        }


class ForensicCortex:
    """Deterministic census of capability health before a skill is changed."""

    def inspect(self, capabilities: Iterable[Capability]) -> list[ForensicFinding]:
        out: list[ForensicFinding] = []
        for cap in capabilities:
            if not cap.inputs or not cap.outputs:
                out.append(ForensicFinding("inspection", f"{cap.capability_id} has incomplete I/O contract", "high", cap.capability_id))
            if cap.observability < 0.5:
                out.append(ForensicFinding("observability", f"{cap.capability_id} has weak observability", "medium", cap.capability_id, "observability", cap.observability, 0.5))
        return out

    def failure_census(self, failures: Iterable[dict[str, Any]]) -> list[ForensicFinding]:
        return [ForensicFinding("failure", str(x.get("statement", x)), str(x.get("severity", "medium")), x.get("capability_id")) for x in failures]

    def bottleneck_census(self, metrics: dict[str, float], thresholds: dict[str, float]) -> list[ForensicFinding]:
        out: list[ForensicFinding] = []
        for name, threshold in thresholds.items():
            value = float(metrics.get(name, 0.0))
            if value > threshold:
                out.append(ForensicFinding("bottleneck", f"{name} exceeds threshold", "high", metric=name, value=value, threshold=threshold))
        return out

    def gap_census(self, capabilities: Iterable[Capability], required: Iterable[str]) -> list[CapabilityGap]:
        names = {c.name for c in capabilities}
        return [
            CapabilityGap(f"gap-{i+1}", None, f"Required capability '{req}' is absent", "high", (), req)
            for i, req in enumerate(required) if req not in names
        ]

    def drift_census(self, baseline: dict[str, float], current: dict[str, float], tolerance: float = 0.05) -> list[ForensicFinding]:
        out: list[ForensicFinding] = []
        for key, base in baseline.items():
            if key not in current or base == 0:
                continue
            ratio = abs(float(current[key]) - float(base)) / abs(float(base))
            if ratio > tolerance:
                out.append(ForensicFinding("drift", f"{key} drifted by {ratio:.2%}", "medium", metric=key, value=ratio, threshold=tolerance))
        return out

    def root_cause(self, findings: Iterable[ForensicFinding]) -> list[dict[str, Any]]:
        # A deterministic first-pass causal grouping; deeper causal proof belongs to Kai's Proof Engine.
        grouped: dict[str, list[ForensicFinding]] = {}
        for finding in findings:
            grouped.setdefault(finding.metric or finding.category, []).append(finding)
        return [
            {
                "cause_id": f"cause-{idx}",
                "key": key,
                "status": "HYPOTHESIZED",
                "evidence": [f.statement for f in items],
                "next_test": f"test:{key}",
            }
            for idx, (key, items) in enumerate(sorted(grouped.items()), 1)
        ]
