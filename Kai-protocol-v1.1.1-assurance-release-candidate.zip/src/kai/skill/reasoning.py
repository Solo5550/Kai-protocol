from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .models import Capability, CapabilityGap


@dataclass(frozen=True, slots=True)
class ReasoningCell:
    dimension: str
    score: float
    rationale: str

    def to_dict(self):
        return {"dimension": self.dimension, "score": round(self.score, 4), "rationale": self.rationale}


class ReasoningMatrix:
    dimensions = (
        "evidence", "causal", "architectural", "counterfactual", "adversarial",
        "risk", "cost_benefit", "uncertainty",
    )

    def evaluate(self, capabilities: Iterable[Capability], gaps: Iterable[CapabilityGap]) -> list[ReasoningCell]:
        caps = list(capabilities)
        gap_list = list(gaps)
        evidence = min(1.0, sum(1 for c in caps if c.metadata.get("evidence", True)) / max(1, len(caps)))
        causal = min(1.0, sum(1 for c in caps if c.coupling < 0.8) / max(1, len(caps)))
        architecture = 1.0 if all(c.inputs and c.outputs for c in caps) else 0.5
        counterfactual = 0.8 if gap_list else 1.0
        adversarial = min(1.0, sum(1 for c in caps if c.risk_level <= 0.5) / max(1, len(caps)))
        risk = 1.0 - min(1.0, sum(c.risk_level for c in caps) / max(1, len(caps)))
        cost_benefit = 1.0 if gap_list else 0.75
        uncertainty = 1.0 - min(1.0, len(gap_list) / max(1, len(caps) or 1))
        values = (evidence, causal, architecture, counterfactual, adversarial, risk, cost_benefit, uncertainty)
        return [ReasoningCell(d, v, "deterministic capability reasoning") for d, v in zip(self.dimensions, values)]

    @staticmethod
    def aggregate(cells: Iterable[ReasoningCell]) -> float:
        cells = list(cells)
        return sum(c.score for c in cells) / len(cells) if cells else 0.0
