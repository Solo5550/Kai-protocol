from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True, slots=True)
class SolutionOption:
    option_id: str
    description: str
    expected_gain: float
    cost: float
    risk: float
    reversibility: float = 1.0

    @property
    def utility(self) -> float:
        return (self.expected_gain * self.reversibility) - self.cost - self.risk

    def to_dict(self):
        return {"option_id": self.option_id, "description": self.description, "expected_gain": self.expected_gain, "cost": self.cost, "risk": self.risk, "reversibility": self.reversibility, "utility": self.utility}


class SolutionEngine:
    def matrix(self, options: Iterable[SolutionOption]) -> list[dict[str, Any]]:
        return [o.to_dict() for o in sorted(options, key=lambda x: (-x.utility, x.option_id))]

    def portfolio(self, options: Iterable[SolutionOption], budget: float) -> list[SolutionOption]:
        selected: list[SolutionOption] = []
        spent = 0.0
        for option in sorted(options, key=lambda x: (-x.utility, x.option_id)):
            if option.utility <= 0 or spent + option.cost > budget:
                continue
            selected.append(option)
            spent += option.cost
        return selected
