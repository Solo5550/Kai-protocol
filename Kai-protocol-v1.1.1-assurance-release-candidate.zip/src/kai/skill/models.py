from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class SkillStage(str, Enum):
    IDENTITY_CONTRACT = "IDENTITY / CONTRACT"
    FORENSIC_CORTEX = "FORENSIC CORTEX"
    REASONING_MATRIX = "REASONING MATRIX"
    SOLUTION_ENGINE = "SOLUTION ENGINE"
    EXECUTION_ENGINE = "EXECUTION ENGINE"
    PROOF_ENGINE = "PROOF ENGINE"
    EVIDENCE_PROVENANCE = "EVIDENCE / PROVENANCE"
    EVOLUTION_CORTEX = "EVOLUTION CORTEX"
    REPRODUCTION_ENGINE = "REPRODUCTION ENGINE"


class LifecycleLevel(str, Enum):
    L0_OBSERVE = "L0_OBSERVE"
    L1_SIMULATE = "L1_SIMULATE"
    L2_SANDBOX = "L2_SANDBOX"
    L3_LIMITED_EXECUTION = "L3_LIMITED_EXECUTION"
    L4_SUPERVISED_PROMOTION = "L4_SUPERVISED_PROMOTION"
    L5_AUTONOMOUS_EXECUTION = "L5_AUTONOMOUS_EXECUTION"
    L6_ROOT_CHANGE = "L6_STRUCTURAL_ROOT_CHANGE"

    @property
    def rank(self) -> int:
        return list(LifecycleLevel).index(self)


class ProposalStatus(str, Enum):
    PROPOSED = "PROPOSED"
    SIMULATED = "SIMULATED"
    SANDBOXED = "SANDBOXED"
    VALIDATED = "VALIDATED"
    ACTIVE = "ACTIVE"
    REJECTED = "REJECTED"
    BLOCKED = "BLOCKED"
    RETIRED = "RETIRED"


class GateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    BLOCKED = "BLOCKED"
    UNRESOLVED = "UNRESOLVED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True, slots=True)
class Capability:
    capability_id: str
    name: str
    objective: str
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()
    required_resources: tuple[str, ...] = ()
    risk_level: float = 0.0
    coupling: float = 0.0
    observability: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CapabilityGap:
    gap_id: str
    capability_id: str | None
    statement: str
    severity: str = "medium"
    evidence_refs: tuple[str, ...] = ()
    recommended_specialization: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class SkillContract:
    skill_id: str
    name: str
    objective: str
    capabilities: tuple[str, ...]
    inputs: tuple[str, ...]
    outputs: tuple[str, ...]
    forbidden_capabilities: tuple[str, ...] = ()
    resource_budget: dict[str, float] = field(default_factory=dict)
    permission_boundary: tuple[str, ...] = ()
    lifecycle_max: LifecycleLevel = LifecycleLevel.L4_SUPERVISED_PROMOTION
    parent_skill_id: str | None = None
    version: str = "1.0"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["lifecycle_max"] = self.lifecycle_max.value
        return d


@dataclass(frozen=True, slots=True)
class ReproductionProposal:
    proposal_id: str
    parent_skill_id: str
    child_skill_id: str
    objective: str
    reason: str
    specialization: str
    source_capability_ids: tuple[str, ...]
    gap_ids: tuple[str, ...]
    requested_level: LifecycleLevel
    requested_permissions: tuple[str, ...] = ()
    requested_resources: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["requested_level"] = self.requested_level.value
        return d


@dataclass(frozen=True, slots=True)
class Gate:
    name: str
    status: GateStatus
    rationale: str
    evidence_refs: tuple[str, ...] = ()
    severity: str = "medium"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"status": self.status.value}


@dataclass(frozen=True, slots=True)
class SkillReview:
    skill_id: str
    mode: str
    level: LifecycleLevel
    score: float
    gates: tuple[Gate, ...]
    master_score: float
    status: GateStatus
    actions: tuple[str, ...] = ()

    @property
    def promotable(self) -> bool:
        return self.status == GateStatus.PASS and all(g.status == GateStatus.PASS for g in self.gates)

    def to_dict(self) -> dict[str, Any]:
        return {
            "skill_id": self.skill_id,
            "mode": self.mode,
            "level": self.level.value,
            "score": round(self.score, 2),
            "master_score": round(self.master_score, 2),
            "status": self.status.value,
            "promotable": self.promotable,
            "gates": [g.to_dict() for g in self.gates],
            "actions": list(self.actions),
        }


@dataclass(slots=True)
class SkillCell:
    contract: SkillContract
    parent_skill_id: str | None
    status: ProposalStatus = ProposalStatus.PROPOSED
    lifecycle_level: LifecycleLevel = LifecycleLevel.L0_OBSERVE
    state: dict[str, Any] = field(default_factory=dict)
    review_history: list[SkillReview] = field(default_factory=list)
    event_log: list[dict[str, Any]] = field(default_factory=list)

    def record(self, event: str, **payload: Any) -> None:
        self.event_log.append({"event": event, **payload})

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract": self.contract.to_dict(),
            "parent_skill_id": self.parent_skill_id,
            "status": self.status.value,
            "lifecycle_level": self.lifecycle_level.value,
            "state": dict(self.state),
            "review_history": [r.to_dict() for r in self.review_history],
            "event_log": list(self.event_log),
        }
