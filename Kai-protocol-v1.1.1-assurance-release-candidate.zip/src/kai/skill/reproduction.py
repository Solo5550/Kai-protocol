from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable

from .execution import SkillSandbox
from .models import Capability, CapabilityGap, LifecycleLevel, ProposalStatus, ReproductionProposal, SkillCell, SkillContract


@dataclass(frozen=True, slots=True)
class ReproductionChecks:
    necessity: bool
    specialization: bool
    risk: bool
    resources: bool
    governance: bool

    @property
    def passed(self) -> bool:
        return all((self.necessity, self.specialization, self.risk, self.resources, self.governance))


class ReproductionEngine:
    """Controlled skill reproduction, not self-copying source code."""

    def __init__(self, sandbox: SkillSandbox | None = None) -> None:
        self.sandbox = sandbox or SkillSandbox()
        self.cells: dict[str, SkillCell] = {}

    @staticmethod
    def proposal_id(parent_skill_id: str, specialization: str, gap_ids: Iterable[str]) -> str:
        raw = json.dumps([parent_skill_id, specialization, sorted(gap_ids)], separators=(",", ":"), sort_keys=True)
        return "repro-" + hashlib.sha256(raw.encode()).hexdigest()[:16]

    def propose(self, *, parent: SkillContract, project: str, capabilities: Iterable[Capability], gaps: Iterable[CapabilityGap], specialization: str, level: LifecycleLevel = LifecycleLevel.L2_SANDBOX, resources: dict[str, float] | None = None) -> ReproductionProposal:
        caps = list(capabilities)
        gap_list = list(gaps)
        p_id = self.proposal_id(parent.skill_id, specialization, (g.gap_id for g in gap_list))
        child_id = "skill-" + hashlib.sha256(f"{parent.skill_id}|{specialization}".encode()).hexdigest()[:16]
        return ReproductionProposal(
            proposal_id=p_id,
            parent_skill_id=parent.skill_id,
            child_skill_id=child_id,
            objective=f"Specialize {project} for {specialization}",
            reason="capability gap requires a distinct contract and failure boundary",
            specialization=specialization,
            source_capability_ids=tuple(c.capability_id for c in caps),
            gap_ids=tuple(g.gap_id for g in gap_list),
            requested_level=level,
            requested_permissions=tuple(),
            requested_resources=resources or {},
        )

    def check(self, proposal: ReproductionProposal, *, gaps: Iterable[CapabilityGap], available_resources: dict[str, float], governance_passed: bool) -> ReproductionChecks:
        gap_ids = {g.gap_id for g in gaps}
        necessity = bool(proposal.gap_ids) and gap_ids.issuperset(proposal.gap_ids)
        specialization = bool(proposal.specialization.strip()) and proposal.parent_skill_id != proposal.child_skill_id
        risk = proposal.requested_level.rank <= LifecycleLevel.L4_SUPERVISED_PROMOTION.rank
        resources = all(float(available_resources.get(k, 0.0)) >= float(v) for k, v in proposal.requested_resources.items())
        return ReproductionChecks(necessity, specialization, risk, resources, governance_passed)

    def birth(self, proposal: ReproductionProposal, *, checks: ReproductionChecks, parent: SkillContract) -> SkillCell:
        if not checks.passed:
            raise PermissionError("reproduction proposal failed one or more gates")
        contract = SkillContract(
            skill_id=proposal.child_skill_id,
            name=f"{parent.name}:{proposal.specialization}",
            objective=proposal.objective,
            capabilities=(proposal.specialization,),
            inputs=parent.inputs,
            outputs=parent.outputs,
            forbidden_capabilities=("root-source-mutation", "unapproved-subprocess", "network-any"),
            resource_budget=dict(proposal.requested_resources),
            permission_boundary=proposal.requested_permissions,
            lifecycle_max=LifecycleLevel.L4_SUPERVISED_PROMOTION,
            parent_skill_id=parent.skill_id,
        )
        cell = SkillCell(contract=contract, parent_skill_id=parent.skill_id, status=ProposalStatus.SANDBOXED, lifecycle_level=LifecycleLevel.L2_SANDBOX)
        cell.record("SANDBOXED_BIRTH", proposal_id=proposal.proposal_id)
        self.cells[cell.contract.skill_id] = cell
        return cell

    def validate_capability(self, cell: SkillCell, handler_capability: str, payload: dict[str, Any]) -> dict[str, Any]:
        result = self.sandbox.run(handler_capability, payload, level=LifecycleLevel.L2_SANDBOX)
        cell.record("CAPABILITY_TEST", capability=handler_capability, result=result.to_dict())
        if result.status == "PASS":
            cell.status = ProposalStatus.VALIDATED
        return result.to_dict()

    def promote(self, cell: SkillCell, *, reviewed: bool, target_level: LifecycleLevel = LifecycleLevel.L4_SUPERVISED_PROMOTION) -> bool:
        if not reviewed or cell.status != ProposalStatus.VALIDATED:
            cell.status = ProposalStatus.BLOCKED if not reviewed else cell.status
            cell.record("PROMOTION_BLOCKED", reason="review-required-or-validation-missing")
            return False
        if target_level.rank > cell.contract.lifecycle_max.rank:
            cell.status = ProposalStatus.BLOCKED
            cell.record("PROMOTION_BLOCKED", reason="contract-lifecycle-boundary")
            return False
        cell.status = ProposalStatus.ACTIVE
        cell.lifecycle_level = target_level
        cell.record("PROMOTED", level=target_level.value)
        return True

    def retire(self, cell: SkillCell, reason: str) -> None:
        cell.status = ProposalStatus.RETIRED
        cell.record("RETIRED", reason=reason)
