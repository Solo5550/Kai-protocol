from __future__ import annotations

import json
from typing import Any

from kai.protocol.interop import SemanticMessage, SEMANTIC_VERSION, SemanticValidationError, validate_semantic_message

HEADER = f"KAI-LANG/{SEMANTIC_VERSION}"
MAX_BYTES = 16 * 1024 * 1024


class SemanticCodecError(ValueError):
    pass


def encode_semantic(message: SemanticMessage | dict[str, Any]) -> str:
    data = message.to_dict() if isinstance(message, SemanticMessage) else dict(message)
    errors = validate_semantic_message(data)
    if errors:
        raise SemanticCodecError("; ".join(errors))
    return HEADER + "\n" + json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\nEND\n"


def decode_semantic(text: str, *, verify_integrity: bool = True, max_bytes: int = MAX_BYTES) -> dict[str, Any]:
    if len(text.encode("utf-8")) > max_bytes:
        raise SemanticCodecError("KAI-LANG/0.8 frame exceeds size limit")
    lines = text.splitlines()
    if len(lines) != 3 or lines[0] != HEADER or lines[2] != "END":
        raise SemanticCodecError(f"expected canonical {HEADER} frame")
    try:
        data = json.loads(lines[1])
    except json.JSONDecodeError as exc:
        raise SemanticCodecError("invalid canonical JSON payload") from exc
    if not isinstance(data, dict):
        raise SemanticCodecError("semantic payload must be object")
    if verify_integrity:
        errors = validate_semantic_message(data)
        if errors:
            raise SemanticCodecError("; ".join(errors))
    return data
