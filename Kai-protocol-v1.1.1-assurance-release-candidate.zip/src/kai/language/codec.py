from __future__ import annotations

import base64
import json
from typing import Any

from kai.protocol.models import Direction, Message, MessageType
from kai.protocol.messages import sha256_hex

LANGUAGE_VERSION = "0.1"
HEADER = f"KAI-LANG/{LANGUAGE_VERSION}"
FIELDS = (
    "TYPE",
    "MSG",
    "UNIT",
    "ROUND",
    "LAYER",
    "DIRECTION",
    "PARENTS",
    "PAYLOAD",
    "PROVENANCE",
    "INTEGRITY",
)


class LanguageCodecError(ValueError):
    pass


def _b64_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _from_b64_json(value: str) -> Any:
    pad = "=" * (-len(value) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode((value + pad).encode("ascii")).decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LanguageCodecError("invalid base64url JSON field") from exc


def encode_message(message: Message | dict[str, Any]) -> str:
    data = message.to_dict() if isinstance(message, Message) else dict(message)
    required = {"protocol", "version", "type", "message_id", "unit_id", "round", "layer", "direction", "parents", "payload", "provenance", "integrity"}
    missing = sorted(required - set(data))
    if missing:
        raise LanguageCodecError(f"missing fields: {', '.join(missing)}")
    if data["protocol"] != "kai" or data["version"] != "0.2":
        raise LanguageCodecError("codec currently carries kai/0.2 wire messages")
    parents = data["parents"]
    if not isinstance(parents, list):
        raise LanguageCodecError("PARENTS must be an array")
    lines = [HEADER]
    lines.append(f"TYPE {data['type']}")
    lines.append(f"MSG {data['message_id']}")
    lines.append(f"UNIT {data['unit_id']}")
    lines.append(f"ROUND {data['round']}")
    lines.append(f"LAYER {data['layer']}")
    lines.append(f"DIRECTION {data['direction']}")
    lines.append(f"PARENTS {','.join(parents) if parents else '-'}")
    lines.append(f"PAYLOAD {_b64_json(data['payload'])}")
    lines.append(f"PROVENANCE {_b64_json(data['provenance'])}")
    integ = data["integrity"]
    lines.append(f"INTEGRITY {integ['algorithm']}:{integ['digest']}")
    lines.append("END")
    return "\n".join(lines) + "\n"


def decode_message(text: str, *, verify_integrity: bool = True, max_bytes: int = 4 * 1024 * 1024) -> dict[str, Any]:
    if len(text.encode("utf-8")) > max_bytes:
        raise LanguageCodecError("KAI-LANG frame exceeds size limit")
    lines = text.strip("\n").splitlines()
    if not lines or lines[0].strip() != HEADER:
        raise LanguageCodecError(f"expected {HEADER}")
    if lines[-1].strip() != "END":
        raise LanguageCodecError("missing END")
    values: dict[str, str] = {}
    for idx, line in enumerate(lines[1:-1], start=2):
        if " " not in line:
            raise LanguageCodecError(f"invalid field line {idx}")
        key, value = line.split(" ", 1)
        if key not in FIELDS:
            raise LanguageCodecError(f"unknown field: {key}")
        if key in values:
            raise LanguageCodecError(f"duplicate field: {key}")
        values[key] = value
    required = set(FIELDS)
    missing = sorted(required - values.keys())
    if missing:
        raise LanguageCodecError(f"missing fields: {', '.join(missing)}")
    try:
        message_type = MessageType(values["TYPE"])
        direction = Direction(values["DIRECTION"])
        round_number = int(values["ROUND"])
        layer = int(values["LAYER"])
    except (ValueError, TypeError) as exc:
        raise LanguageCodecError("invalid typed scalar field") from exc
    parents = [] if values["PARENTS"] == "-" else values["PARENTS"].split(",")
    integ = values["INTEGRITY"].split(":", 1)
    if len(integ) != 2:
        raise LanguageCodecError("invalid INTEGRITY field")
    data = {
        "protocol": "kai",
        "version": "0.2",
        "message_id": values["MSG"],
        "unit_id": values["UNIT"],
        "round": round_number,
        "layer": layer,
        "direction": direction.value,
        "type": message_type.value,
        "payload": _from_b64_json(values["PAYLOAD"]),
        "parents": parents,
        "provenance": _from_b64_json(values["PROVENANCE"]),
        "integrity": {"algorithm": integ[0], "digest": integ[1]},
        "language": HEADER,
    }
    if verify_integrity:
        canonical = {k: data[k] for k in ("protocol", "version", "message_id", "unit_id", "round", "layer", "direction", "type", "payload", "parents", "provenance")}
        expected = sha256_hex(canonical)
        if data["integrity"]["algorithm"] != "sha256" or data["integrity"]["digest"] != expected:
            raise LanguageCodecError("integrity verification failed")
    return data
