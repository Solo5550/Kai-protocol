from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from kai.protocol.models import Message, MessageType
from .dialogue import DialogueEngine, DialogueError


@dataclass
class KaiChannel:
    """Multi-unit code-to-code channel with one global CONTRACT and local dialogues."""

    contract_seen: bool = False
    units: dict[str, DialogueEngine] = field(default_factory=dict)

    def ingest(self, message: Message) -> None:
        if message.type == MessageType.CONTRACT:
            if self.contract_seen:
                raise DialogueError("channel accepts exactly one CONTRACT")
            self.contract_seen = True
            return
        if not self.contract_seen:
            raise DialogueError("CONTRACT must be established before other messages")
        engine = self.units.setdefault(
            message.unit_id, DialogueEngine(require_local_pass_for_accept=False, track_history=False)
        )
        engine.accept(message)

    def ingest_many(self, messages: Iterable[Message]) -> None:
        for message in messages:
            self.ingest(message)

    @property
    def closed_units(self) -> list[str]:
        return sorted(uid for uid, d in self.units.items() if d.state.closed)
