from __future__ import annotations

from typing import Any, Iterable, Iterator
import struct

try:
    import msgpack
except ImportError as exc:  # pragma: no cover
    msgpack = None

from kai.protocol.messages import sha256_hex
from kai.protocol.models import Message, MessageType, Direction

MAGIC = b"KAI-BIN/1\0"
MAX_BYTES = 16 * 1024 * 1024


class CompactCodecError(ValueError):
    pass


def _require_msgpack() -> None:
    if msgpack is None:
        raise CompactCodecError("compact codec requires optional dependency 'msgpack'")


def _sorted_tree(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _sorted_tree(value[k]) for k in sorted(value)}
    if isinstance(value, list):
        return [_sorted_tree(v) for v in value]
    if isinstance(value, tuple):
        return [_sorted_tree(v) for v in value]
    return value


def _canonical_map(data: dict[str, Any]) -> dict[str, Any]:
    return _sorted_tree(data)


def _message_dict(message: Message | dict[str, Any]) -> dict[str, Any]:
    data = message.to_dict() if isinstance(message, Message) else dict(message)
    if data.get("protocol") != "kai" or data.get("version") != "0.2":
        raise CompactCodecError("compact codec currently carries kai/0.2 messages")
    required = {"protocol", "version", "type", "message_id", "unit_id", "round", "layer", "direction", "parents", "payload", "provenance", "integrity"}
    missing = sorted(required - set(data))
    if missing:
        raise CompactCodecError(f"missing fields: {', '.join(missing)}")
    return data


def _pack_frame(data: dict[str, Any], packer: Any) -> bytes:
    frame = _canonical_map(data)
    packed = packer.pack(frame)
    if len(packed) > MAX_BYTES:
        raise CompactCodecError("compact frame exceeds size limit")
    return MAGIC + struct.pack(">I", len(packed)) + packed


def encode_compact(message: Message | dict[str, Any]) -> bytes:
    _require_msgpack()
    data = _message_dict(message)
    packer = msgpack.Packer(use_bin_type=True, strict_types=True)
    return _pack_frame(data, packer)


def encode_compact_many(messages: Iterable[Message | dict[str, Any]]) -> bytes:
    _require_msgpack()
    packer = msgpack.Packer(use_bin_type=True, strict_types=True)
    return b"".join(_pack_frame(_message_dict(message), packer) for message in messages)


def decode_compact(frame: bytes, *, verify_integrity: bool = True, max_bytes: int = MAX_BYTES) -> dict[str, Any]:
    _require_msgpack()
    raw = bytes(frame)
    if len(raw) > max_bytes:
        raise CompactCodecError("compact frame exceeds size limit")
    if len(raw) < len(MAGIC) + 4 or not raw.startswith(MAGIC):
        raise CompactCodecError("invalid KAI-BIN header")
    declared = struct.unpack(">I", raw[len(MAGIC):len(MAGIC)+4])[0]
    payload = raw[len(MAGIC)+4:]
    if declared != len(payload):
        raise CompactCodecError("frame length mismatch")
    return _decode_payload(payload, verify_integrity=verify_integrity)


def _decode_payload(payload: bytes, *, verify_integrity: bool) -> dict[str, Any]:
    try:
        data = msgpack.unpackb(payload, raw=False, strict_map_key=False)
    except Exception as exc:
        raise CompactCodecError("invalid MessagePack payload") from exc
    if not isinstance(data, dict):
        raise CompactCodecError("compact message must decode to object")
    required = {"protocol", "version", "type", "message_id", "unit_id", "round", "layer", "direction", "parents", "payload", "provenance", "integrity"}
    missing = sorted(required - set(data))
    if missing:
        raise CompactCodecError(f"missing fields: {', '.join(missing)}")
    try:
        MessageType(data["type"])
        Direction(data["direction"])
        data["round"] = int(data["round"])
        data["layer"] = int(data["layer"])
    except (ValueError, TypeError) as exc:
        raise CompactCodecError("invalid typed scalar field") from exc
    if not isinstance(data["parents"], list) or not isinstance(data["payload"], dict) or not isinstance(data["provenance"], dict) or not isinstance(data["integrity"], dict):
        raise CompactCodecError("invalid compact field types")
    if verify_integrity:
        canonical = {k: data[k] for k in ("protocol", "version", "message_id", "unit_id", "round", "layer", "direction", "type", "payload", "parents", "provenance")}
        expected = sha256_hex(canonical)
        integ = data["integrity"]
        if integ.get("algorithm") != "sha256" or integ.get("digest") != expected:
            raise CompactCodecError("integrity verification failed")
    data["language"] = "KAI-BIN/1"
    return data


def decode_compact_stream(stream: bytes, *, verify_integrity: bool = True, max_bytes: int = 256 * 1024 * 1024) -> Iterator[dict[str, Any]]:
    _require_msgpack()
    raw = memoryview(stream)
    if len(raw) > max_bytes:
        raise CompactCodecError("compact stream exceeds size limit")
    pos = 0
    header_len = len(MAGIC)
    while pos < len(raw):
        if len(raw) - pos < header_len + 4 or raw[pos:pos + header_len].tobytes() != MAGIC:
            raise CompactCodecError("invalid KAI-BIN stream header")
        pos += header_len
        declared = struct.unpack_from(">I", raw, pos)[0]
        pos += 4
        end = pos + declared
        if end > len(raw):
            raise CompactCodecError("truncated compact stream frame")
        yield _decode_payload(raw[pos:end].tobytes(), verify_integrity=verify_integrity)
        pos = end
