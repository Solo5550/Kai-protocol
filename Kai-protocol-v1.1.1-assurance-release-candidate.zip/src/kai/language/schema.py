from __future__ import annotations

from kai.protocol.models import MessageType


def required_fields(message_type: MessageType) -> tuple[str, ...]:
    common = ("unit_id", "round", "layer", "type", "payload")
    if message_type is MessageType.CLAIM:
        return common + ("claim",)
    if message_type is MessageType.EVIDENCE:
        return common + ("statement",)
    if message_type is MessageType.TEST:
        return common + ("test_id", "kind", "expected")
    if message_type is MessageType.RESULT:
        return common + ("test_id", "status", "actual")
    if message_type is MessageType.OBJECTION:
        return common + ("target_id", "statement")
    if message_type is MessageType.REVISION:
        return common + ("parent_claim_id", "changed_fields", "rationale")
    if message_type is MessageType.VERDICT:
        return common + ("verdict",)
    if message_type is MessageType.SECRET:
        return common + ("envelope",)
    return common
