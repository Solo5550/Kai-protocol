from __future__ import annotations

from typing import Any

from kai.protocol.models import Message, MessageType
from .schema import required_fields


class SemanticValidationError(ValueError):
    pass


def validate_semantics(message: Message | dict[str, Any]) -> list[str]:
    data = message.to_dict() if isinstance(message, Message) else message
    kind = data.get("type")
    payload = data.get("payload")
    if not isinstance(payload, dict):
        return ["payload must be object before semantic validation"]
    # The generic transport schema stays flexible. This layer defines the minimum
    # machine-dialogue contract for typed messages.
    try:
        message_type = MessageType(kind)
    except ValueError:
        return [f"unknown message type: {kind}"]
    required = required_fields(message_type)
    errors = []
    for field in required:
        if field in {"unit_id", "round", "layer", "type", "payload"}:
            continue
        if field not in payload:
            errors.append(f"{kind}: missing payload field {field}")
    if kind == "RESULT" and payload.get("status") not in {"PASS", "FAIL", "BLOCKED", "UNRESOLVED"}:
        errors.append("RESULT: status must be PASS/FAIL/BLOCKED/UNRESOLVED")
    if kind == "VERDICT" and payload.get("verdict") not in {"ACCEPTED", "REJECTED", "BLOCKED", "UNRESOLVED"}:
        errors.append("VERDICT: invalid verdict")
    return errors
