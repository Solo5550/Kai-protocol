from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from kai.protocol.models import Message, MessageType


class DialogueError(ValueError):
    pass


FIRST_TYPES = {MessageType.CONTRACT, MessageType.CLAIM, MessageType.OBSERVATION, MessageType.HYPOTHESIS, MessageType.ASSUMPTION, MessageType.RECONSTRUCTION}

ALLOWED_AFTER: dict[MessageType, set[MessageType]] = {
    MessageType.CONTRACT: {MessageType.OBSERVATION, MessageType.CLAIM, MessageType.ASSUMPTION, MessageType.BLOCK},
    MessageType.OBSERVATION: {MessageType.CLAIM, MessageType.EVIDENCE, MessageType.OBJECTION, MessageType.TEST},
    MessageType.CLAIM: {MessageType.CLAIM, MessageType.OBSERVATION, MessageType.EVIDENCE, MessageType.ASSUMPTION, MessageType.DEPENDENCY, MessageType.ARGUMENT, MessageType.OBJECTION, MessageType.COUNTEREXAMPLE, MessageType.TEST, MessageType.REVISION, MessageType.VERDICT},
    MessageType.EVIDENCE: {MessageType.EVIDENCE, MessageType.OBJECTION, MessageType.OBJECTION, MessageType.COUNTEREXAMPLE, MessageType.TEST, MessageType.REBUTTAL},
    MessageType.ASSUMPTION: {MessageType.OBJECTION, MessageType.COUNTEREXAMPLE, MessageType.TEST, MessageType.REVISION},
    MessageType.DEPENDENCY: {MessageType.OBJECTION, MessageType.TEST, MessageType.ARGUMENT},
    MessageType.ARGUMENT: {MessageType.OBJECTION, MessageType.COUNTEREXAMPLE, MessageType.TEST, MessageType.REBUTTAL, MessageType.VERDICT},
    MessageType.OBJECTION: {MessageType.TEST, MessageType.REBUTTAL, MessageType.REVISION, MessageType.COUNTEREXAMPLE, MessageType.ARGUMENT},
    MessageType.COUNTEREXAMPLE: {MessageType.REVISION, MessageType.REBUTTAL, MessageType.TEST, MessageType.ROOT_CAUSE, MessageType.VERDICT},
    MessageType.HYPOTHESIS: {MessageType.TEST, MessageType.EVIDENCE, MessageType.OBJECTION},
    MessageType.TEST: {MessageType.RESULT, MessageType.FAILURE, MessageType.BLOCK},
    MessageType.RESULT: {MessageType.RESULT, MessageType.REBUTTAL, MessageType.REVISION, MessageType.RECONSTRUCTION, MessageType.VERDICT, MessageType.ROOT_CAUSE},
    MessageType.FAILURE: {MessageType.ROOT_CAUSE, MessageType.REVISION, MessageType.TEST, MessageType.BLOCK},
    MessageType.ROOT_CAUSE: {MessageType.REVISION, MessageType.TEST, MessageType.REBUTTAL},
    MessageType.REVISION: {MessageType.RETEST if hasattr(MessageType, 'RETEST') else MessageType.TEST, MessageType.EVIDENCE, MessageType.REBUTTAL, MessageType.TEST},
    MessageType.REBUTTAL: {MessageType.TEST, MessageType.VERDICT, MessageType.REVISION, MessageType.COUNTEREXAMPLE},
    MessageType.RECONSTRUCTION: {MessageType.VERDICT, MessageType.REOPEN, MessageType.REOPEN, MessageType.BLOCK},
    MessageType.VERDICT: {MessageType.PROMOTE, MessageType.REOPEN, MessageType.REVISION},
    MessageType.PROMOTE: {MessageType.REOPEN},
    MessageType.REOPEN: {MessageType.OBJECTION, MessageType.TEST, MessageType.REVISION, MessageType.CONTRACT},
    MessageType.BLOCK: {MessageType.REOPEN, MessageType.CONTRACT},
    MessageType.SECRET: {MessageType.EVIDENCE, MessageType.OBJECTION, MessageType.TEST, MessageType.VERDICT},
}


@dataclass
class DialogueState:
    message_ids: list[str] = field(default_factory=list)
    last_type: MessageType | None = None
    open_objections: set[str] = field(default_factory=set)
    passed_tests: set[str] = field(default_factory=set)
    has_passed_test: bool = False
    rejected: bool = False
    closed: bool = False


class DialogueEngine:
    """Deterministic semantic conversation gate for code-to-code exchange."""

    def __init__(self, *, require_local_pass_for_accept: bool = True, track_history: bool = True, history_limit: int = 0) -> None:
        self.state = DialogueState()
        self.require_local_pass_for_accept = require_local_pass_for_accept
        self.track_history = track_history
        self.history_limit = max(0, history_limit)
        self.message_count = 0

    def accept(self, message: Message) -> None:
        self._validate_message(message)
        mt = message.type
        self.message_count += 1
        if self.track_history:
            if self.history_limit:
                self.state.message_ids.append(message.message_id)
                if len(self.state.message_ids) > self.history_limit:
                    del self.state.message_ids[:-self.history_limit]
            else:
                self.state.message_ids.append(message.message_id)
        self.state.last_type = mt
        payload = message.payload
        if mt == MessageType.OBJECTION:
            oid = payload.get("objection_id", message.message_id)
            self.state.open_objections.add(oid)
        elif mt == MessageType.RESULT:
            test_id = payload.get("test_id")
            status = payload.get("status")
            if test_id and status == "PASS":
                self.state.has_passed_test = True
                if self.track_history:
                    self.state.passed_tests.add(test_id)
            if status == "FAIL":
                self.state.rejected = True
        elif mt == MessageType.REBUTTAL:
            target = payload.get("target_objection_id")
            if target:
                self.state.open_objections.discard(target)
        elif mt == MessageType.VERDICT:
            verdict = payload.get("verdict")
            if verdict in {"REJECTED", "BLOCKED"}:
                self.state.rejected = True
            if verdict in {"ACCEPTED", "REJECTED", "BLOCKED"}:
                self.state.closed = True
        elif mt == MessageType.REOPEN:
            self.state.closed = False
            self.state.rejected = False

    def accept_many(self, messages: Iterable[Message]) -> None:
        for message in messages:
            self.accept(message)

    def can_accept(self, message: Message) -> bool:
        try:
            self._validate_message(message)
            return True
        except DialogueError:
            return False

    def _validate_message(self, message: Message) -> None:
        if self.state.closed and message.type != MessageType.REOPEN:
            raise DialogueError("dialogue is closed; REOPEN is required")
        if self.state.last_type is None and message.type not in FIRST_TYPES:
            raise DialogueError(f"{message.type.value} cannot start a dialogue")
        if self.state.last_type is not None:
            allowed = ALLOWED_AFTER.get(self.state.last_type, set())
            if message.type not in allowed:
                raise DialogueError(f"{message.type.value} cannot follow {self.state.last_type.value}")
        if message.type == MessageType.CONTRACT and self.state.message_ids:
            raise DialogueError("only one root CONTRACT is allowed per dialogue")
        if message.type == MessageType.VERDICT:
            if self.state.open_objections:
                raise DialogueError("open objections must be resolved before VERDICT")
            if self.require_local_pass_for_accept and not (self.state.passed_tests or self.state.has_passed_test) and message.payload.get("verdict") == "ACCEPTED":
                raise DialogueError("ACCEPTED requires at least one passing TEST result")
        if message.type == MessageType.PROMOTE and message.payload.get("verdict") != "ACCEPTED":
            raise DialogueError("PROMOTE requires ACCEPTED verdict")
