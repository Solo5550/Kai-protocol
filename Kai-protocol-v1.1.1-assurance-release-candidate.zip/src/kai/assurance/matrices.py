from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class Finding:
    id: str
    category: str
    severity: str
    statement: str
    evidence: tuple[str, ...] = ()
    affected_surface: str | None = None


@dataclass(frozen=True)
class RootCause:
    id: str
    finding_ids: tuple[str, ...]
    mechanism: str
    confidence: float
    counter_evidence: tuple[str, ...] = ()
    falsifier: str | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("root-cause confidence must be in [0,1]")


@dataclass(frozen=True)
class Solution:
    id: str
    root_cause_ids: tuple[str, ...]
    description: str
    risk_reduction: float
    implementation_cost: float
    reversibility: float
    observability_gain: float = 0.0
    dependencies: tuple[str, ...] = ()
    status: str = "PROPOSED"

    def __post_init__(self) -> None:
        for value in (self.risk_reduction, self.implementation_cost, self.reversibility, self.observability_gain):
            if not 0.0 <= value <= 1.0:
                raise ValueError("solution scores must be in [0,1]")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def solution_portfolio(options: list[Solution]) -> list[Solution]:
    """Deterministic Pareto-ish ordering without a political-style overall score."""
    return sorted(
        options,
        key=lambda s: (-s.risk_reduction, -s.observability_gain, -s.reversibility, s.implementation_cost, s.id),
    )
