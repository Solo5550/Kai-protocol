from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class AssuranceStage(str, Enum):
    STAGE_CONTRACT = "STAGE_CONTRACT"
    DEEP_FORENSIC_INSPECTION = "DEEP_FORENSIC_INSPECTION"
    REVERSE_ENGINEERING = "REVERSE_ENGINEERING"
    FULL_FAILURE_CENSUS = "FULL_FAILURE_CENSUS"
    BOTTLENECK_CENSUS = "BOTTLENECK_CENSUS"
    GAP_CENSUS = "GAP_CENSUS"
    VIBRATION_DRIFT_CENSUS = "VIBRATION_DRIFT_CENSUS"
    ROOT_CAUSE_ANALYSIS = "ROOT_CAUSE_ANALYSIS"
    SOLUTION_MATRIX = "SOLUTION_MATRIX"
    SOLUTION_PORTFOLIO = "SOLUTION_PORTFOLIO"
    ARCHITECTURAL_DECISION = "ARCHITECTURAL_DECISION"
    FULL_CLEAN_REWRITE = "FULL_CLEAN_REWRITE"
    BUILD_FROM_CLEAN_STATE = "BUILD_FROM_CLEAN_STATE"
    UNIT_TEST = "UNIT_TEST"
    CONTRACT_TEST = "CONTRACT_TEST"
    INTEGRATION_TEST = "INTEGRATION_TEST"
    SYSTEM_TEST = "SYSTEM_TEST"
    REVERSE_ENGINEERING_TEST = "REVERSE_ENGINEERING_TEST"
    ADVERSARIAL_TEST = "ADVERSARIAL_TEST"
    MUTATION_TEST = "MUTATION_TEST"
    CHAOS_FAILURE_INJECTION = "CHAOS_FAILURE_INJECTION"
    SECURITY = "SECURITY"
    PERFORMANCE = "PERFORMANCE"
    REPRODUCIBILITY = "REPRODUCIBILITY"
    REGRESSION = "REGRESSION"
    MEASURED_BENCHMARK = "MEASURED_BENCHMARK"
    STAGE_EXIT = "STAGE_EXIT"


@dataclass(frozen=True)
class AssuranceGate:
    stage: AssuranceStage
    critical: bool = True
    allow_skip: bool = False


@dataclass(frozen=True)
class GateOutcome:
    stage: AssuranceStage
    status: str
    evidence: tuple[str, ...] = ()
    notes: str = ""
    metrics: dict[str, Any] = field(default_factory=dict)


DEFAULT_GATES: tuple[AssuranceGate, ...] = tuple(
    AssuranceGate(stage=s, critical=True, allow_skip=s in {
        AssuranceStage.MUTATION_TEST,
        AssuranceStage.SECURITY,
    })
    for s in AssuranceStage
    if s != AssuranceStage.STAGE_EXIT
) + (AssuranceGate(AssuranceStage.STAGE_EXIT, critical=True),)


class AssuranceController:
    """Fail-closed stage controller with deterministic reroute semantics.

    A failed critical gate invalidates the current promotion attempt and sends the
    workflow back to ROOT_CAUSE_ANALYSIS. A non-critical skipped stage is recorded,
    never silently omitted.
    """

    def __init__(self, gates: tuple[AssuranceGate, ...] | None = None) -> None:
        self.gates = gates or DEFAULT_GATES
        self.outcomes: dict[AssuranceStage, GateOutcome] = {}
        self.active_stage = self.gates[0].stage
        self.reroutes: list[dict[str, str]] = []

    def record(self, outcome: GateOutcome) -> None:
        expected = self.active_stage
        if outcome.stage != expected:
            raise ValueError(f"out_of_order_stage expected={expected.value} actual={outcome.stage.value}")
        normalized = outcome.status.upper()
        if normalized not in {"PASS", "FAIL", "BLOCKED", "UNRESOLVED", "SKIPPED"}:
            raise ValueError(f"invalid_gate_status:{outcome.status}")
        gate = next(g for g in self.gates if g.stage == outcome.stage)
        if normalized == "SKIPPED" and not gate.allow_skip:
            raise ValueError(f"stage_not_skippable:{outcome.stage.value}")
        self.outcomes[outcome.stage] = GateOutcome(
            stage=outcome.stage, status=normalized, evidence=tuple(outcome.evidence),
            notes=outcome.notes, metrics=dict(outcome.metrics),
        )
        if normalized in {"FAIL", "BLOCKED", "UNRESOLVED"} and gate.critical:
            self.reroutes.append({"from": outcome.stage.value, "to": AssuranceStage.ROOT_CAUSE_ANALYSIS.value})
            self.active_stage = AssuranceStage.ROOT_CAUSE_ANALYSIS
            return
        index = [g.stage for g in self.gates].index(expected)
        self.active_stage = self.gates[index + 1].stage if index + 1 < len(self.gates) else AssuranceStage.STAGE_EXIT

    @property
    def promotable(self) -> bool:
        if AssuranceStage.STAGE_EXIT not in self.outcomes:
            return False
        if self.outcomes[AssuranceStage.STAGE_EXIT].status != "PASS":
            return False
        return all(
            o.status == "PASS" or (o.status == "SKIPPED" and not next(g for g in self.gates if g.stage == stage).critical)
            for stage, o in self.outcomes.items()
        ) and not self.reroutes

    def required_failures(self) -> list[str]:
        return [
            stage.value for stage, o in self.outcomes.items()
            if o.status in {"FAIL", "BLOCKED", "UNRESOLVED"}
            and next(g for g in self.gates if g.stage == stage).critical
        ]

    def snapshot(self) -> dict[str, Any]:
        return {
            "active_stage": self.active_stage.value,
            "promotable": self.promotable,
            "required_failures": self.required_failures(),
            "reroutes": list(self.reroutes),
            "outcomes": {
                stage.value: {
                    "status": out.status,
                    "evidence": list(out.evidence),
                    "notes": out.notes,
                    "metrics": out.metrics,
                }
                for stage, out in self.outcomes.items()
            },
        }
