"""Deterministic release-assurance control plane.

The assurance layer turns inspection, failure analysis, remediation, and release
validation into explicit, auditable gates. It is deliberately separate from the
runtime execution kernel so assurance policy cannot become an accidental runtime
side channel.
"""

from .control import AssuranceController, AssuranceGate, AssuranceStage, GateOutcome
from .matrices import Finding, RootCause, Solution, solution_portfolio

__all__ = [
    "AssuranceController", "AssuranceGate", "AssuranceStage", "GateOutcome",
    "Finding", "RootCause", "Solution", "solution_portfolio",
]
