from __future__ import annotations

from dataclasses import dataclass

from kai.protocol.models import Unit, Direction, Provenance
from .graph import KnowledgeGraph


@dataclass
class ReconstructionReport:
    reconstructed_claim: str
    source_claim: str
    preserved: bool
    missing_units: list[str]
    extra_units: list[str]
    mismatched_claims: list[str]
    fidelity: float


class ReconstructionEngine:
    def __init__(self, graph: KnowledgeGraph) -> None:
        self.graph = graph

    def reconstruct(self, synthesis_id: str, source_root_id: str) -> ReconstructionReport:
        synthesis = self.graph.get(synthesis_id)
        source = self.graph.get(source_root_id)
        expected_leaves = set(synthesis.parent_ids)
        actual_support = set(synthesis.metadata.get("supporting_units", []))
        missing = sorted(expected_leaves - actual_support)
        extra = sorted(actual_support - expected_leaves)
        mismatched = []
        if synthesis.claim and source.claim:
            # The source claim must appear verbatim in the reconstruction, or the
            # caller must supply a domain-specific equivalence relation in metadata.
            if source.claim not in synthesis.claim and synthesis.claim != source.claim:
                mismatched.append(f"source claim not preserved: {source.claim}")
        total = max(len(expected_leaves | actual_support), 1)
        intersection = len(expected_leaves & actual_support)
        structure_fidelity = intersection / total
        claim_fidelity = 1.0 if not mismatched else 0.0
        fidelity = (structure_fidelity + claim_fidelity) / 2.0
        preserved = not missing and not extra and not mismatched
        return ReconstructionReport(
            reconstructed_claim=synthesis.claim or "",
            source_claim=source.claim or "",
            preserved=preserved,
            missing_units=missing,
            extra_units=extra,
            mismatched_claims=mismatched,
            fidelity=fidelity,
        )

    def emit_reconstruction_unit(self, report: ReconstructionReport, unit_id: str = "reconstruction.final") -> Unit:
        state = "VERIFIED" if report.preserved else "CONTESTED"
        return Unit(
            unit_id=unit_id,
            parent_ids=[u.unit_id for u in self.graph.leaves()],
            layer=max((u.layer for u in self.graph.units.values()), default=0) + 1,
            direction=Direction.UP,
            state=state,
            claim=report.reconstructed_claim,
            provenance=[Provenance(source_id=unit_id, source_type="reconstruction", extracted_by="reconstructor", transformation="reverse-assembly")],
            metadata={
                "fidelity": report.fidelity,
                "preserved": report.preserved,
                "missing_units": report.missing_units,
                "extra_units": report.extra_units,
                "mismatched_claims": report.mismatched_claims,
            },
        )
