from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Iterable

from kai.protocol.models import Unit


@dataclass
class KnowledgeGraph:
    units: dict[str, Unit] = field(default_factory=dict)

    def add(self, unit: Unit) -> None:
        if unit.unit_id in self.units:
            raise ValueError(f"duplicate unit id: {unit.unit_id}")
        self.units[unit.unit_id] = unit

    def get(self, unit_id: str) -> Unit:
        return self.units[unit_id]

    def children(self, parent_id: str) -> list[Unit]:
        return sorted((u for u in self.units.values() if parent_id in u.parent_ids), key=lambda u: u.unit_id)

    def roots(self) -> list[Unit]:
        return sorted((u for u in self.units.values() if not u.parent_ids), key=lambda u: u.unit_id)

    def leaves(self) -> list[Unit]:
        parent_ids = {p for u in self.units.values() for p in u.parent_ids}
        return sorted((u for uid, u in self.units.items() if uid not in parent_ids), key=lambda u: u.unit_id)

    def layers(self) -> dict[int, list[Unit]]:
        result: dict[int, list[Unit]] = defaultdict(list)
        for unit in self.units.values():
            result[unit.layer].append(unit)
        return {k: sorted(v, key=lambda u: u.unit_id) for k, v in sorted(result.items())}

    def topological(self) -> list[Unit]:
        indegree = {uid: len(u.parent_ids) for uid, u in self.units.items()}
        children: dict[str, list[str]] = defaultdict(list)
        for uid, u in self.units.items():
            for p in u.parent_ids:
                if p not in self.units:
                    raise ValueError(f"missing parent: {p}")
                children[p].append(uid)
        queue = deque(sorted(uid for uid, d in indegree.items() if d == 0))
        order: list[Unit] = []
        while queue:
            uid = queue.popleft()
            order.append(self.units[uid])
            for child in sorted(children[uid]):
                indegree[child] -= 1
                if indegree[child] == 0:
                    queue.append(child)
        if len(order) != len(self.units):
            raise ValueError("graph contains a cycle")
        return order
