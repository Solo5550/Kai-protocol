from __future__ import annotations

from dataclasses import dataclass

from kai.protocol.models import Direction, Provenance, Unit
from .graph import KnowledgeGraph


@dataclass
class SynthesisResult:
    claim: str
    supporting_units: list[str]
    contradictions: list[str]


class Synthesizer:
    def __init__(self, graph: KnowledgeGraph) -> None:
        self.graph = graph

    def synthesize(self, unit_ids: list[str] | None = None) -> SynthesisResult:
        ids = unit_ids or [u.unit_id for u in self.graph.leaves()]
        claims = []
        contradictions = []
        for uid in sorted(ids):
            unit = self.graph.get(uid)
            if unit.claim:
                claims.append(unit.claim.strip())
            for obj in unit.objections:
                if obj.severity in {"critical", "blocking"}:
                    contradictions.append(obj.statement)
        claim = " AND ".join(f"({c})" for c in claims) if claims else "UNRESOLVED"
        return SynthesisResult(claim=claim, supporting_units=sorted(ids), contradictions=contradictions)

    def add_synthesis_unit(self, result: SynthesisResult, unit_id: str = "synthesis.base") -> Unit:
        root_ids = self.graph.roots()
        parent_ids = [u.unit_id for u in self.graph.leaves()]
        unit = Unit(
            unit_id=unit_id,
            parent_ids=parent_ids,
            layer=max((u.layer for u in self.graph.units.values()), default=0) + 1,
            direction=Direction.UP,
            state="SUPPORTED" if not result.contradictions and result.claim != "UNRESOLVED" else "UNRESOLVED",
            claim=result.claim,
            provenance=[Provenance(source_id=unit_id, source_type="synthesis", extracted_by="synthesizer", transformation="conjunction", parent_ids=parent_ids)],
            metadata={"supporting_units": result.supporting_units},
        )
        self.graph.add(unit)
        return unit
