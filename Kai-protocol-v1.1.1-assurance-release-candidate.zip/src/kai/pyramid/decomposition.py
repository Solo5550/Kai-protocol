from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from kai.protocol.models import Direction, Unit, Provenance
from .graph import KnowledgeGraph


@dataclass
class ForwardPyramid:
    graph: KnowledgeGraph

    @classmethod
    def from_parts(cls, source_id: str, claim: str, parts: list[dict[str, Any]]) -> "ForwardPyramid":
        graph = KnowledgeGraph()
        root = Unit(
            unit_id=source_id,
            layer=0,
            direction=Direction.DOWN,
            state="CLAIMED",
            claim=claim,
            provenance=[Provenance(source_id=source_id, source_type="input", extracted_by="forward-pyramid", transformation="root")],
        )
        graph.add(root)
        for idx, part in enumerate(parts, start=1):
            unit_id = part.get("unit_id", f"{source_id}.u{idx}")
            unit = Unit(
                unit_id=unit_id,
                parent_ids=[source_id],
                layer=1,
                direction=Direction.DOWN,
                state="CLAIMED",
                claim=part["claim"],
                assumptions=list(part.get("assumptions", [])),
                provenance=[Provenance(source_id=part.get("source_id", unit_id), source_type=part.get("source_type", "input"), extracted_by="forward-pyramid", transformation="decomposition", parent_ids=[source_id])],
                metadata={"role": part.get("role", "child")},
            )
            graph.add(unit)
        return cls(graph)

    def validate_decomposition(self) -> list[str]:
        errors: list[str] = []
        for unit in self.graph.units.values():
            for parent in unit.parent_ids:
                if parent not in self.graph.units:
                    errors.append(f"{unit.unit_id}: missing parent {parent}")
        if len(self.graph.roots()) != 1:
            errors.append("expected exactly one root")
        return errors
