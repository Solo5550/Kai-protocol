from __future__ import annotations

from dataclasses import dataclass


class UnitState:
    RAW = "RAW"
    PARSED = "PARSED"
    CLAIMED = "CLAIMED"
    EVIDENCED = "EVIDENCED"
    TESTING = "TESTING"
    SUPPORTED = "SUPPORTED"
    CONTESTED = "CONTESTED"
    REVISED = "REVISED"
    RETESTING = "RETESTING"
    VERIFIED = "VERIFIED"
    REJECTED = "REJECTED"
    UNRESOLVED = "UNRESOLVED"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class Transition:
    source: str
    event: str
    target: str


TRANSITIONS = {
    (UnitState.RAW, "parse"): UnitState.PARSED,
    (UnitState.PARSED, "claim"): UnitState.CLAIMED,
    (UnitState.CLAIMED, "evidence"): UnitState.EVIDENCED,
    (UnitState.EVIDENCED, "test"): UnitState.TESTING,
    (UnitState.TESTING, "result-pass"): UnitState.SUPPORTED,
    (UnitState.TESTING, "result-fail"): UnitState.CONTESTED,
    (UnitState.CONTESTED, "revise"): UnitState.REVISED,
    (UnitState.REVISED, "retest"): UnitState.RETESTING,
    (UnitState.RETESTING, "result-pass"): UnitState.VERIFIED,
    (UnitState.RETESTING, "result-fail"): UnitState.REJECTED,
}


class InvalidTransition(ValueError):
    pass


class StateMachine:
    def transition(self, state: str, event: str) -> str:
        try:
            return TRANSITIONS[(state, event)]
        except KeyError as exc:
            raise InvalidTransition(f"No transition from {state} via {event}") from exc

    def mark_unresolved(self) -> str:
        return UnitState.UNRESOLVED

    def mark_blocked(self) -> str:
        return UnitState.BLOCKED

    def can_transition(self, state: str, event: str) -> bool:
        return (state, event) in TRANSITIONS
