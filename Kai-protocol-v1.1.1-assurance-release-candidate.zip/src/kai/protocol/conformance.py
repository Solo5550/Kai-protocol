from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .interop import SemanticMessage, validate_semantic_message
from .validator import ProtocolValidator


@dataclass(frozen=True, slots=True)
class ConformanceResult:
    name: str
    passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]


def _vector_root() -> Path:
    packaged = Path(__file__).resolve().parent / "spec" / "0.8" / "vectors"
    if packaged.exists():
        return packaged
    return Path(__file__).resolve().parents[3] / "spec" / "kai" / "0.8" / "vectors"


def load_vectors(root: Path | None = None) -> list[dict[str, Any]]:
    root = root or _vector_root()
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(root.glob("*.json"))]


def check_vector(vector: dict[str, Any]) -> ConformanceResult:
    name = str(vector.get("name", "unnamed"))
    message_data = vector.get("message")
    checks: list[str] = []
    failures: list[str] = []
    if not isinstance(message_data, dict):
        return ConformanceResult(name, False, (), ("message must be object",))

    semantic_errors = validate_semantic_message(message_data)
    if semantic_errors:
        failures.extend(f"semantic: {e}" for e in semantic_errors)
    else:
        checks.append("semantic-validation")

    try:
        message = SemanticMessage.from_dict(message_data)
        if message.to_dict() != message_data:
            failures.append("round-trip projection mismatch")
        else:
            checks.append("object-round-trip")
        if message.verify_integrity():
            checks.append("integrity")
        else:
            failures.append("integrity verification failed")
    except Exception as exc:
        failures.append(f"object decode: {type(exc).__name__}: {exc}")

    legacy_errors = ProtocolValidator().validate_message(message_data) if {"version", "unit_id", "round"}.issubset(message_data) else []
    if legacy_errors:
        failures.extend(f"legacy-validator: {e}" for e in legacy_errors)
    elif "version" in message_data:
        checks.append("legacy-validation")

    return ConformanceResult(name, not failures, tuple(checks), tuple(failures))


def run_conformance(root: Path | None = None) -> tuple[ConformanceResult, ...]:
    return tuple(check_vector(v) for v in load_vectors(root))


def main() -> int:
    results = run_conformance()
    payload = {
        "passed": all(r.passed for r in results),
        "vectors": len(results),
        "results": [
            {"name": r.name, "passed": r.passed, "checks": list(r.checks), "failures": list(r.failures)}
            for r in results
        ],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
