from __future__ import annotations

from copy import deepcopy
from typing import Any


class MergeError(ValueError):
    pass


class MergeStrategy:
    """Explicit merge contract. Unknown fields are not silently merged."""

    def __init__(self, fields: dict[str, str]) -> None:
        self.fields = fields

    def merge(self, left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
        result = deepcopy(left)
        for key, strategy in self.fields.items():
            lv, rv = left.get(key), right.get(key)
            if strategy == "set-union":
                result[key] = sorted(set(lv or []) | set(rv or []))
            elif strategy == "max":
                result[key] = max(lv, rv)
            elif strategy == "last-write":
                result[key] = rv
            elif strategy == "reject-on-conflict":
                if lv is not None and rv is not None and lv != rv:
                    raise MergeError(f"conflict on field: {key}")
                result[key] = rv if rv is not None else lv
            else:
                raise MergeError(f"unknown merge strategy: {strategy}")
        return result
