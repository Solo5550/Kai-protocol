from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .messages import canonical_json

SEMANTIC_VERSION = "0.8"
SCHEMA_ID = "kai/semantic/0.8"
MAX_STRING_LENGTH = 4096
MAX_PARENT_IDS = 128
MAX_EFFECTS = 1024
MAX_EXTENSIONS = 64
CORE_FIELDS = {"protocol", "semantic_version", "schema_id", "message_id", "conversation_id", "sender", "recipient", "act", "intent", "causality", "authority", "capability", "contract", "input", "expected", "execution", "outcome", "effects", "proof", "provenance", "extensions", "integrity"}


class SemanticError(ValueError):
    """Base error for Kai semantic protocol violations."""


class ReplayError(SemanticError):
    pass


class SemanticValidationError(SemanticError):
    pass


class SpeechAct(str, Enum):
    REQUEST = "REQUEST"
    ACCEPT = "ACCEPT"
    REJECT = "REJECT"
    PROGRESS = "PROGRESS"
    RESULT = "RESULT"
    FAILURE = "FAILURE"
    RECOVER = "RECOVER"
    PROOF = "PROOF"
    EVENT = "EVENT"


_EFFECTFUL = {"external_write", "irreversible"}


def _validate_json_value(value: Any, *, path: str = "value") -> None:
    if value is None or isinstance(value, (str, bool, int)):
        if isinstance(value, str) and len(value) > MAX_STRING_LENGTH:
            raise SemanticError(f"{path} exceeds max string length")
        return
    if isinstance(value, float):
        import math
        if not math.isfinite(value):
            raise SemanticError(f"{path} contains non-finite number")
        return
    if isinstance(value, list) or isinstance(value, tuple):
        for i, item in enumerate(value):
            _validate_json_value(item, path=f"{path}[{i}]")
        return
    if isinstance(value, dict):
        if len(value) > MAX_EXTENSIONS and path.endswith("extensions"):
            raise SemanticError("extensions exceeds max properties")
        for key, item in value.items():
            if not isinstance(key, str):
                raise SemanticError(f"{path} contains non-string object key")
            if len(key) > MAX_STRING_LENGTH:
                raise SemanticError(f"{path} contains overlong object key")
            _validate_json_value(item, path=f"{path}.{key}")
        return
    raise SemanticError(f"{path} contains unsupported value type: {type(value).__name__}")


def _digest(value: Any) -> str:
    _validate_json_value(value)
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _without_integrity(data: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in data.items() if k != "integrity"}


def _identity_body(data: dict[str, Any]) -> dict[str, Any]:
    body = _without_integrity(data)
    authority = body.get("authority")
    if isinstance(authority, dict) and "signature" in authority:
        authority = dict(authority)
        authority.pop("signature", None)
        body["authority"] = authority
    return body


def _identity_digest(data: dict[str, Any], *, empty_message_id: bool = False) -> str:
    body = _identity_body(data)
    if empty_message_id:
        body["message_id"] = ""
    return _digest(body)


@dataclass(frozen=True, slots=True)
class Authority:
    issuer: str
    subject: str
    scopes: tuple[str, ...] = ()
    tenant: str | None = None
    policy_ref: str | None = None
    issued_at: str | None = None
    expires_at: str | None = None
    signature: dict[str, str] | None = None

    def to_dict(self) -> dict[str, Any]:
        out = {
            "issuer": self.issuer,
            "subject": self.subject,
            "scopes": list(self.scopes),
            "tenant": self.tenant,
            "policy_ref": self.policy_ref,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
        }
        if self.signature is not None:
            out["signature"] = dict(self.signature)
        return {k: v for k, v in out.items() if v is not None}


@dataclass(frozen=True, slots=True)
class CapabilityRef:
    capability_id: str
    version: str
    implementation_id: str | None = None
    contract_id: str | None = None
    contract_version: str | None = None
    side_effect_class: str = "pure"

    def to_dict(self) -> dict[str, Any]:
        return {
            "capability_id": self.capability_id,
            "version": self.version,
            "implementation_id": self.implementation_id,
            "contract_id": self.contract_id,
            "contract_version": self.contract_version,
            "side_effect_class": self.side_effect_class,
        }


@dataclass(frozen=True, slots=True)
class Causality:
    conversation_id: str
    correlation_id: str
    sequence: int
    parent_ids: tuple[str, ...] = ()
    causation_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "conversation_id": self.conversation_id,
            "correlation_id": self.correlation_id,
            "sequence": self.sequence,
            "parent_ids": list(self.parent_ids),
            "causation_id": self.causation_id,
        }


@dataclass(frozen=True, slots=True)
class SemanticMessage:
    """Kai v0.8 semantic discourse envelope, independent of transport encoding.

    The outer protocol identity remains ``kai`` while the semantic version advances
    independently from the legacy ``kai/0.2`` wire protocol. Every message carries
    intent/authority/capability/execution/evidence context in a deterministic envelope.
    """

    message_id: str
    schema_id: str
    conversation_id: str
    sender: str
    recipient: str
    act: SpeechAct
    intent: str
    causality: Causality
    authority: Authority | None = None
    capability: CapabilityRef | None = None
    contract: dict[str, Any] | None = None
    input: dict[str, Any] = field(default_factory=dict)
    expected: Any = None
    execution: dict[str, Any] | None = None
    outcome: dict[str, Any] | None = None
    effects: tuple[dict[str, Any], ...] = ()
    proof: dict[str, Any] | None = None
    provenance: dict[str, Any] = field(default_factory=dict)
    extensions: dict[str, Any] = field(default_factory=dict)
    integrity: dict[str, str] = field(default_factory=lambda: {"algorithm": "sha256", "digest": ""})

    @classmethod
    def build(
        cls,
        *,
        conversation_id: str,
        sender: str,
        recipient: str,
        act: SpeechAct,
        intent: str,
        causality: Causality,
        authority: Authority | None = None,
        capability: CapabilityRef | None = None,
        contract: dict[str, Any] | None = None,
        input: dict[str, Any] | None = None,
        expected: Any = None,
        execution: dict[str, Any] | None = None,
        outcome: dict[str, Any] | None = None,
        effects: list[dict[str, Any]] | tuple[dict[str, Any], ...] | None = None,
        proof: dict[str, Any] | None = None,
        provenance: dict[str, Any] | None = None,
        extensions: dict[str, Any] | None = None,
    ) -> "SemanticMessage":
        base = {
            "protocol": "kai",
            "semantic_version": SEMANTIC_VERSION,
            "schema_id": SCHEMA_ID,
            "message_id": "",
            "conversation_id": conversation_id,
            "sender": sender,
            "recipient": recipient,
            "act": act.value,
            "intent": intent,
            "causality": causality.to_dict(),
            "authority": authority.to_dict() if authority else None,
            "capability": capability.to_dict() if capability else None,
            "contract": contract,
            "input": input or {},
            "expected": expected,
            "execution": execution,
            "outcome": outcome,
            "effects": list(effects or ()),
            "proof": proof,
            "provenance": provenance or {},
            "extensions": extensions or {},
        }
        message_id = _identity_digest(base, empty_message_id=True)
        base["message_id"] = message_id
        digest = _identity_digest(base)
        return cls(
            message_id=message_id,
            schema_id=SCHEMA_ID,
            conversation_id=conversation_id,
            sender=sender,
            recipient=recipient,
            act=act,
            intent=intent,
            causality=causality,
            authority=authority,
            capability=capability,
            contract=contract,
            input=input or {},
            expected=expected,
            execution=execution,
            outcome=outcome,
            effects=tuple(effects or ()),
            proof=proof,
            provenance=provenance or {},
            extensions=extensions or {},
            integrity={"algorithm": "sha256", "digest": digest},
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SemanticMessage":
        errors = validate_semantic_message(data)
        if errors:
            raise SemanticValidationError("; ".join(errors))
        authority_data = data.get("authority")
        capability_data = data.get("capability")
        causal_data = data["causality"]
        authority = Authority(
            issuer=authority_data["issuer"], subject=authority_data["subject"],
            scopes=tuple(authority_data.get("scopes", [])), tenant=authority_data.get("tenant"),
            policy_ref=authority_data.get("policy_ref"), issued_at=authority_data.get("issued_at"),
            expires_at=authority_data.get("expires_at"), signature=authority_data.get("signature"),
        ) if authority_data is not None else None
        capability = CapabilityRef(
            capability_id=capability_data["capability_id"], version=capability_data["version"],
            implementation_id=capability_data.get("implementation_id"), contract_id=capability_data.get("contract_id"),
            contract_version=capability_data.get("contract_version"), side_effect_class=capability_data.get("side_effect_class", "pure"),
        ) if capability_data is not None else None
        causality = Causality(
            conversation_id=causal_data["conversation_id"], correlation_id=causal_data["correlation_id"],
            sequence=causal_data["sequence"], parent_ids=tuple(causal_data.get("parent_ids", [])),
            causation_id=causal_data.get("causation_id"),
        )
        return cls(
            message_id=data["message_id"], schema_id=data["schema_id"], conversation_id=data["conversation_id"],
            sender=data["sender"], recipient=data["recipient"], act=SpeechAct(data["act"]), intent=data["intent"],
            causality=causality, authority=authority, capability=capability, contract=data.get("contract"),
            input=data.get("input", {}), expected=data.get("expected"), execution=data.get("execution"),
            outcome=data.get("outcome"), effects=tuple(data.get("effects", [])), proof=data.get("proof"),
            provenance=data.get("provenance", {}), extensions=data.get("extensions", {}),
            integrity=dict(data["integrity"]),
        )

    def unsigned_dict(self) -> dict[str, Any]:
        return {
            "protocol": "kai",
            "semantic_version": SEMANTIC_VERSION,
            "schema_id": self.schema_id,
            "message_id": self.message_id,
            "conversation_id": self.conversation_id,
            "sender": self.sender,
            "recipient": self.recipient,
            "act": self.act.value,
            "intent": self.intent,
            "causality": self.causality.to_dict(),
            "authority": self.authority.to_dict() if self.authority else None,
            "capability": self.capability.to_dict() if self.capability else None,
            "contract": self.contract,
            "input": self.input,
            "expected": self.expected,
            "execution": self.execution,
            "outcome": self.outcome,
            "effects": list(self.effects),
            "proof": self.proof,
            "provenance": self.provenance,
            "extensions": self.extensions,
        }

    def to_dict(self) -> dict[str, Any]:
        return self.unsigned_dict() | {"integrity": dict(self.integrity)}

    def verify_integrity(self) -> bool:
        data = self.unsigned_dict()
        expected = _identity_digest(data)
        return self.integrity.get("algorithm") == "sha256" and self.integrity.get("digest") == expected


def sign_semantic_message(message: SemanticMessage, private_key_path: str, *, key_id: str = "default") -> SemanticMessage:
    from kai.security.authority import sign
    if not message.verify_integrity():
        raise SemanticError("cannot sign message with invalid integrity")
    authority = message.authority
    if authority is None:
        raise SemanticError("authority is required for signing")
    payload = {"kai_semantic_message_digest": message.integrity["digest"], "key_id": key_id, "issuer": authority.issuer, "subject": authority.subject}
    signature = sign(payload, private_key_path)
    signed_authority = Authority(issuer=authority.issuer, subject=authority.subject, scopes=authority.scopes, tenant=authority.tenant, policy_ref=authority.policy_ref, issued_at=authority.issued_at, expires_at=authority.expires_at, signature={"algorithm": "ed25519", "key_id": key_id, "value": signature})
    return SemanticMessage(
        message_id=message.message_id, schema_id=message.schema_id, conversation_id=message.conversation_id, sender=message.sender, recipient=message.recipient,
        act=message.act, intent=message.intent, causality=message.causality, authority=signed_authority, capability=message.capability,
        contract=message.contract, input=message.input, expected=message.expected, execution=message.execution, outcome=message.outcome,
        effects=message.effects, proof=message.proof, provenance=message.provenance, extensions=message.extensions, integrity=message.integrity,
    )


def verify_semantic_signature(message: SemanticMessage, public_key_path: str) -> bool:
    from kai.security.authority import verify
    authority = message.authority
    if authority is None or not authority.signature:
        return False
    sig = authority.signature
    if sig.get("algorithm") != "ed25519" or not sig.get("value"):
        return False
    payload = {"kai_semantic_message_digest": message.integrity.get("digest"), "key_id": sig.get("key_id", "default"), "issuer": authority.issuer, "subject": authority.subject}
    return verify(payload, sig["value"], public_key_path)


def validate_semantic_message(message: SemanticMessage | dict[str, Any], *, require_signatures: bool = False) -> list[str]:
    data = message.to_dict() if isinstance(message, SemanticMessage) else dict(message)
    errors: list[str] = []
    unknown = sorted(set(data) - CORE_FIELDS)
    errors.extend(f"unknown top-level field: {name}" for name in unknown)
    required = tuple(sorted(CORE_FIELDS))
    for name in required:
        if name not in data:
            errors.append(f"missing field: {name}")
    if data.get("protocol") != "kai":
        errors.append("protocol must be kai")
    if data.get("semantic_version") != SEMANTIC_VERSION:
        errors.append("unsupported semantic version")
    if data.get("schema_id") != SCHEMA_ID:
        errors.append("unsupported semantic schema")
    for field_name in ("conversation_id", "sender", "recipient", "intent"):
        value = data.get(field_name)
        if not isinstance(value, str) or not value:
            errors.append(f"{field_name} must be non-empty string")
        elif len(value) > MAX_STRING_LENGTH:
            errors.append(f"{field_name} exceeds max string length")
    try:
        act = SpeechAct(data.get("act"))
    except (TypeError, ValueError):
        act = None
        errors.append("invalid speech act")
    try:
        _validate_json_value(data)
    except SemanticError as exc:
        errors.append(str(exc))
    causality = data.get("causality")
    if not isinstance(causality, dict):
        errors.append("causality must be object")
    else:
        for key in ("conversation_id", "correlation_id", "sequence", "parent_ids", "causation_id"):
            if key not in causality:
                errors.append(f"causality missing: {key}")
        if causality.get("conversation_id") != data.get("conversation_id"):
            errors.append("causality conversation mismatch")
        if not isinstance(causality.get("sequence"), int) or causality.get("sequence", -1) < 0:
            errors.append("causality.sequence must be non-negative integer")
        if not isinstance(causality.get("parent_ids"), list):
            errors.append("causality.parent_ids must be array")
        elif len(causality["parent_ids"]) > MAX_PARENT_IDS:
            errors.append("causality.parent_ids exceeds limit")
    if not isinstance(data.get("input"), dict):
        errors.append("input must be object")
    if not isinstance(data.get("effects"), list):
        errors.append("effects must be array")
    if not isinstance(data.get("provenance"), dict):
        errors.append("provenance must be object")
    if not isinstance(data.get("extensions"), dict):
        errors.append("extensions must be object")
    if data.get("authority") is not None:
        if not isinstance(data["authority"], dict):
            errors.append("authority must be object or null")
        else:
            auth = data["authority"]
            for key in ("issuer", "subject", "scopes"):
                if key not in auth:
                    errors.append(f"authority missing: {key}")
            if not isinstance(auth.get("scopes", []), list) or not all(isinstance(x, str) and x for x in auth.get("scopes", [])):
                errors.append("authority.scopes must be non-empty strings")
            if auth.get("signature") is not None:
                sig = auth["signature"]
                if not isinstance(sig, dict) or sig.get("algorithm") != "ed25519" or not sig.get("key_id") or not sig.get("value"):
                    errors.append("invalid authority signature envelope")
    capability = data.get("capability")
    authority = data.get("authority")
    if capability is not None and isinstance(capability, dict):
        for key in ("capability_id", "version", "implementation_id", "contract_id", "contract_version", "side_effect_class"):
            if key not in capability:
                errors.append(f"capability missing: {key}")
        if capability.get("side_effect_class", "pure") not in {"pure", "read_only", "external_write", "irreversible"}:
            errors.append("invalid capability side_effect_class")
    elif capability is not None:
        errors.append("capability must be object or null")
    if data.get("contract") is not None:
        if not isinstance(data["contract"], dict) or not data["contract"].get("id") or not data["contract"].get("version"):
            errors.append("contract requires id and version")
    if capability is not None:
        if not isinstance(capability, dict) or not capability.get("capability_id") or not capability.get("version"):
            errors.append("capability requires capability_id and version")
        effect_class = capability.get("side_effect_class", "pure") if isinstance(capability, dict) else "pure"
        if effect_class in _EFFECTFUL:
            if not authority:
                errors.append("effectful capability requires authority")
            idem = (data.get("extensions") or {}).get("idempotency_key")
            if not idem:
                errors.append("effectful capability requires idempotency_key")
    effects = data.get("effects")
    if isinstance(effects, list) and len(effects) > MAX_EFFECTS:
        errors.append("effects exceeds limit")
    extensions = data.get("extensions")
    if isinstance(extensions, dict) and len(extensions) > MAX_EXTENSIONS:
        errors.append("extensions exceeds limit")
    if act is not None:
        if act is SpeechAct.REQUEST:
            if not data.get("intent"):
                errors.append("REQUEST requires intent")
            if capability is None:
                errors.append("REQUEST requires capability")
            if not data.get("contract"):
                errors.append("REQUEST requires contract")
        elif act is SpeechAct.ACCEPT:
            if not isinstance(data.get("execution"), dict) or not data["execution"].get("execution_id"):
                errors.append("ACCEPT requires execution.execution_id")
        elif act is SpeechAct.RESULT:
            if not isinstance(data.get("outcome"), dict) or "status" not in data["outcome"]:
                errors.append("RESULT requires outcome.status")
        elif act in {SpeechAct.REJECT, SpeechAct.FAILURE}:
            if not isinstance(data.get("outcome"), dict) or not data["outcome"].get("error"):
                errors.append(f"{act.value} requires outcome.error")
        elif act is SpeechAct.PROOF:
            if not isinstance(data.get("proof"), dict) or not data["proof"].get("proof_id"):
                errors.append("PROOF requires proof.proof_id")
        if act is SpeechAct.RECOVER and not isinstance(data.get("execution"), dict):
            errors.append("RECOVER requires execution context")
    integ = data.get("integrity")
    if not isinstance(integ, dict) or integ.get("algorithm") != "sha256":
        errors.append("integrity algorithm must be sha256")
    elif not isinstance(integ.get("digest"), str) or len(integ.get("digest", "")) != 64 or any(c not in "0123456789abcdef" for c in integ.get("digest", "")):
        errors.append("integrity.digest must be lowercase sha256 hex")
    elif not isinstance(data.get("message_id"), str) or not data.get("message_id"):
        errors.append("message_id missing")
    elif len(data["message_id"]) != 64 or any(c not in "0123456789abcdef" for c in data["message_id"]):
        errors.append("message_id must be lowercase sha256 hex")
    else:
        base = _without_integrity(data)
        message_id_seed = dict(base)
        message_id_seed["message_id"] = ""
        try:
            expected_id = _identity_digest(message_id_seed, empty_message_id=True)
            expected_digest = _identity_digest(base)
        except SemanticError as exc:
            errors.append(str(exc))
        else:
            if data.get("message_id") != expected_id:
                errors.append("message_id is not content-addressed")
            if integ.get("digest") != expected_digest:
                errors.append("integrity digest mismatch")
    if require_signatures and not authority:
        errors.append("authority signature required")
    if authority and not authority.get("issuer"):
        errors.append("authority issuer missing")
    return errors


class DialogueLedger:
    """Minimal deterministic conversation state machine for Kai code-to-code dialogue."""

    _NEXT: dict[SpeechAct, set[SpeechAct]] = {
        SpeechAct.REQUEST: {SpeechAct.ACCEPT, SpeechAct.REJECT, SpeechAct.PROGRESS, SpeechAct.RESULT, SpeechAct.FAILURE},
        SpeechAct.ACCEPT: {SpeechAct.PROGRESS, SpeechAct.RESULT, SpeechAct.FAILURE, SpeechAct.RECOVER},
        SpeechAct.PROGRESS: {SpeechAct.PROGRESS, SpeechAct.RESULT, SpeechAct.FAILURE, SpeechAct.RECOVER},
        SpeechAct.FAILURE: {SpeechAct.RECOVER, SpeechAct.PROOF, SpeechAct.RESULT},
        SpeechAct.RECOVER: {SpeechAct.ACCEPT, SpeechAct.RESULT, SpeechAct.FAILURE},
        SpeechAct.REJECT: {SpeechAct.REQUEST, SpeechAct.PROOF},
        SpeechAct.RESULT: {SpeechAct.PROOF, SpeechAct.REQUEST},
        SpeechAct.PROOF: {SpeechAct.REQUEST, SpeechAct.EVENT},
        SpeechAct.EVENT: {SpeechAct.EVENT, SpeechAct.REQUEST},
    }

    def __init__(self, conversation_id: str, *, max_messages: int = 100_000) -> None:
        if not conversation_id:
            raise ValueError("conversation_id is required")
        self.conversation_id = conversation_id
        self.max_messages = max_messages
        self._messages: list[SemanticMessage] = []
        self._seen: set[str] = set()
        self._last_sequence = -1
        self._last_act: SpeechAct | None = None

    @property
    def messages(self) -> tuple[SemanticMessage, ...]:
        return tuple(self._messages)

    @property
    def message_count(self) -> int:
        return len(self._messages)

    def ingest(self, message: SemanticMessage) -> str:
        errors = validate_semantic_message(message)
        if errors:
            raise SemanticValidationError("; ".join(errors))
        if message.conversation_id != self.conversation_id:
            raise SemanticError("conversation mismatch")
        if message.message_id in self._seen:
            raise ReplayError(f"replayed message: {message.message_id}")
        seq = message.causality.sequence
        if seq <= self._last_sequence:
            raise ReplayError(f"non-monotonic sequence: {seq} <= {self._last_sequence}")
        if self._last_act is not None and message.act not in self._NEXT[self._last_act]:
            raise SemanticError(f"illegal dialogue transition {self._last_act.value} -> {message.act.value}")
        parents = set(message.causality.parent_ids)
        if self._messages and self._messages[-1].message_id not in parents and message.causality.causation_id != self._messages[-1].message_id:
            raise SemanticError("causality must reference the immediately preceding message")
        if len(self._messages) >= self.max_messages:
            raise SemanticError("conversation exceeds max_messages")
        self._messages.append(message)
        self._seen.add(message.message_id)
        self._last_sequence = seq
        self._last_act = message.act
        return "ACCEPTED"
