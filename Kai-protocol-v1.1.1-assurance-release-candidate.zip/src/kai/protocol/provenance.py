from __future__ import annotations

import hashlib
import json
from typing import Any

from .models import Provenance


def provenance_fingerprint(items: list[Provenance]) -> str:
    payload = [p.to_dict() for p in items]
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def is_complete(provenance: Provenance | None) -> bool:
    if provenance is None:
        return False
    return bool(provenance.source_id and provenance.extracted_by and provenance.transformation)


def validate_chain(items: list[Provenance]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    ids = {p.source_id for p in items}
    for p in items:
        for parent in p.parent_ids:
            if parent not in ids:
                errors.append(f"missing provenance parent: {parent}")
    return (not errors, errors)
