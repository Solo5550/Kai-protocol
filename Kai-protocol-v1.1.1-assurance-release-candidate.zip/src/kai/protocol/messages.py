from __future__ import annotations

import hashlib
import json
from typing import Any

from .models import Direction, Message, MessageType

WIRE_VERSION = "0.2"


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()



class MessageFactory:
    """Build deterministic-schema, content-addressed messages with integrity digests."""

    def __init__(self, actor: str = "kai-engine") -> None:
        self.actor = actor


    def create_secret(
        self,
        *,
        unit_id: str,
        round: int,
        layer: int,
        direction: Direction,
        plaintext: str | bytes,
        key: bytes,
        key_id: str = "master",
        parents: list[str] | None = None,
    ) -> Message:
        """Create a SECRET message whose payload contains an authenticated secret envelope."""
        from kai.security.envelope import seal

        envelope = seal(plaintext, key, key_id=key_id)
        return self.create(
            unit_id=unit_id,
            round=round,
            layer=layer,
            direction=direction,
            type=MessageType.SECRET,
            payload={"envelope": envelope},
            parents=parents,
            provenance={"actor": self.actor, "confidential": True},
        )

    def create(
        self,
        *,
        unit_id: str,
        round: int,
        layer: int,
        direction: Direction,
        type: MessageType,
        payload: dict[str, Any],
        parents: list[str] | None = None,
        provenance: dict[str, Any] | None = None,
        message_id: str | None = None,
    ) -> Message:
        resolved_provenance = provenance or {"actor": self.actor}
        if message_id is None:
            seed = {
                "protocol": "kai",
                "version": WIRE_VERSION,
                "message_id": "",
                "unit_id": unit_id,
                "round": round,
                "layer": layer,
                "direction": direction.value,
                "type": type.value,
                "payload": payload,
                "parents": parents or [],
                "provenance": resolved_provenance,
            }
            message_id = sha256_hex(seed)
        msg = Message(
            protocol="kai",
            version=WIRE_VERSION,
            message_id=message_id,
            unit_id=unit_id,
            round=round,
            layer=layer,
            direction=direction,
            type=type,
            payload=payload,
            parents=parents or [],
            provenance=resolved_provenance,
            integrity={"algorithm": "sha256", "digest": ""},
        )
        msg.integrity["digest"] = sha256_hex(msg.canonical_without_integrity())
        return msg
