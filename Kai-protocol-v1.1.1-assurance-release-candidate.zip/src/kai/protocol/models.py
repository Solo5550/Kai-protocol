from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class MessageType(str, Enum):
    CONTRACT = "CONTRACT"
    OBSERVATION = "OBSERVATION"
    CLAIM = "CLAIM"
    EVIDENCE = "EVIDENCE"
    ASSUMPTION = "ASSUMPTION"
    DEPENDENCY = "DEPENDENCY"
    ARGUMENT = "ARGUMENT"
    OBJECTION = "OBJECTION"
    COUNTEREXAMPLE = "COUNTEREXAMPLE"
    HYPOTHESIS = "HYPOTHESIS"
    TEST = "TEST"
    RESULT = "RESULT"
    FAILURE = "FAILURE"
    ROOT_CAUSE = "ROOT_CAUSE"
    REVISION = "REVISION"
    REBUTTAL = "REBUTTAL"
    RECONSTRUCTION = "RECONSTRUCTION"
    VERDICT = "VERDICT"
    PROMOTE = "PROMOTE"
    REOPEN = "REOPEN"
    BLOCK = "BLOCK"
    SECRET = "SECRET"


class Direction(str, Enum):
    DOWN = "down"
    HORIZONTAL = "horizontal"
    UP = "up"


class GateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    BLOCKED = "BLOCKED"
    UNRESOLVED = "UNRESOLVED"


class Verdict(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    UNRESOLVED = "UNRESOLVED"
    BLOCKED = "BLOCKED"


@dataclass(slots=True)
class Provenance:
    source_id: str
    source_type: str = "unknown"
    locator: str | None = None
    extracted_by: str = "unknown"
    transformation: str = "none"
    timestamp: str | None = None
    parent_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Evidence:
    evidence_id: str
    statement: str
    strength: float = 0.0
    independent: bool = False
    provenance: Provenance | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["provenance"] = self.provenance.to_dict() if self.provenance else None
        return d


@dataclass(slots=True)
class TestSpec:
    test_id: str
    kind: str
    preconditions: list[str]
    inputs: dict[str, Any]
    expected: Any
    executor: str = "unknown"
    executor_version: str = "unknown"
    reproducible: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class TestResult:
    test_id: str
    status: GateStatus
    actual: Any
    notes: str = ""
    reproducibility_key: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"status": self.status.value}


@dataclass(slots=True)
class Objection:
    objection_id: str
    target_type: str
    target_id: str
    statement: str
    severity: str = "material"
    counterexample: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Revision:
    revision_id: str
    parent_claim_id: str
    changed_fields: list[str]
    rationale: str
    new_claim: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class GateResult:
    gate: str
    status: GateStatus
    evidence_ids: list[str] = field(default_factory=list)
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"status": self.status.value}


@dataclass
class Unit:
    unit_id: str
    parent_ids: list[str] = field(default_factory=list)
    layer: int = 0
    direction: Direction = Direction.DOWN
    state: str = "RAW"
    claim: str | None = None
    assumptions: list[str] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)
    provenance: list[Provenance] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    objections: list[Objection] = field(default_factory=list)
    tests: list[TestSpec] = field(default_factory=list)
    results: list[TestResult] = field(default_factory=list)
    revisions: list[Revision] = field(default_factory=list)
    gates: list[GateResult] = field(default_factory=list)
    verdict: Verdict | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "unit_id": self.unit_id,
            "parent_ids": list(self.parent_ids),
            "layer": self.layer,
            "direction": self.direction.value,
            "state": self.state,
            "claim": self.claim,
            "assumptions": list(self.assumptions),
            "evidence": [e.to_dict() for e in self.evidence],
            "provenance": [p.to_dict() for p in self.provenance],
            "dependencies": list(self.dependencies),
            "objections": [o.to_dict() for o in self.objections],
            "tests": [t.to_dict() for t in self.tests],
            "results": [r.to_dict() for r in self.results],
            "revisions": [r.to_dict() for r in self.revisions],
            "gates": [g.to_dict() for g in self.gates],
            "verdict": self.verdict.value if self.verdict else None,
            "metadata": self.metadata,
        }


@dataclass(slots=True)
class Message:
    protocol: str
    version: str
    message_id: str
    unit_id: str
    round: int
    layer: int
    direction: Direction
    type: MessageType
    payload: dict[str, Any]
    parents: list[str]
    provenance: dict[str, Any]
    integrity: dict[str, str]

    def canonical_without_integrity(self) -> dict[str, Any]:
        return {
            "protocol": self.protocol,
            "version": self.version,
            "message_id": self.message_id,
            "unit_id": self.unit_id,
            "round": self.round,
            "layer": self.layer,
            "direction": self.direction.value,
            "type": self.type.value,
            "payload": self.payload,
            "parents": self.parents,
            "provenance": self.provenance,
        }

    def to_dict(self) -> dict[str, Any]:
        return self.canonical_without_integrity() | {"integrity": self.integrity}
