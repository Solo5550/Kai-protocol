from __future__ import annotations

from .models import GateResult, GateStatus, Unit, Verdict


REQUIRED_GATES = (
    "decomposition_integrity",
    "horizontal_consistency",
    "vertical_consistency",
    "test_validity",
    "reconstruction_preservation",
    "provenance_completeness",
    "criterion_satisfaction",
)
MASTER_GATE = "master_governance"


class VerdictEngine:
    def evaluate(self, unit: Unit) -> Verdict:
        required = list(REQUIRED_GATES)
        if unit.metadata.get("master_governance_required"):
            required.append(MASTER_GATE)
        by_gate = {g.gate: g.status for g in unit.gates}
        statuses = [by_gate.get(name, GateStatus.UNRESOLVED) for name in required]
        if any(s == GateStatus.FAIL for s in statuses):
            return Verdict.REJECTED
        if any(s == GateStatus.BLOCKED for s in statuses):
            return Verdict.BLOCKED
        if any(s == GateStatus.UNRESOLVED for s in statuses):
            return Verdict.UNRESOLVED
        if all(s == GateStatus.PASS for s in statuses) and unit.state == "VERIFIED":
            return Verdict.ACCEPTED
        return Verdict.UNRESOLVED

    def promotable(self, unit: Unit) -> bool:
        return self.evaluate(unit) == Verdict.ACCEPTED
