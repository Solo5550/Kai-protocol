from __future__ import annotations

from typing import Any

from .messages import sha256_hex
from .models import Message, MessageType
from .provenance import is_complete


MESSAGE_TYPES = {m.value for m in MessageType}
SUPPORTED_VERSIONS = {"0.2"}
DIRECTIONS = {"down", "horizontal", "up"}


class ProtocolValidator:
    def validate_message(self, message: Message | dict[str, Any]) -> list[str]:
        if isinstance(message, Message):
            data = message.to_dict()
            canonical = message.canonical_without_integrity()
        else:
            data = message
            canonical = {k: data[k] for k in (
                "protocol", "version", "message_id", "unit_id", "round", "layer",
                "direction", "type", "payload", "parents", "provenance"
            ) if k in data}
        errors: list[str] = []
        required = ["protocol", "version", "message_id", "unit_id", "round", "layer", "direction", "type", "payload", "parents", "provenance", "integrity"]
        for field in required:
            if field not in data:
                errors.append(f"missing field: {field}")
        if data.get("protocol") != "kai":
            errors.append("protocol must be kai")
        if data.get("version") not in SUPPORTED_VERSIONS:
            errors.append("unsupported protocol version")
        if data.get("direction") not in DIRECTIONS:
            errors.append("invalid direction")
        if data.get("type") not in MESSAGE_TYPES:
            errors.append("invalid message type")
        if not isinstance(data.get("round"), int) or data.get("round", -1) < 0:
            errors.append("round must be non-negative integer")
        if not isinstance(data.get("layer"), int) or data.get("layer", -1) < 0:
            errors.append("layer must be non-negative integer")
        if not isinstance(data.get("payload"), dict):
            errors.append("payload must be object")
        if not isinstance(data.get("parents"), list):
            errors.append("parents must be array")
        integ = data.get("integrity", {})
        if integ.get("algorithm") != "sha256":
            errors.append("integrity algorithm must be sha256")
        if canonical and "digest" in integ:
            actual = sha256_hex(canonical)
            if integ.get("digest") != actual:
                errors.append("integrity digest mismatch")
        return errors

    def validate_unit(self, unit: Any) -> list[str]:
        errors: list[str] = []
        if not getattr(unit, "unit_id", ""):
            errors.append("unit_id missing")
        if unit.claim is None:
            errors.append("claim missing")
        if not unit.provenance and unit.claim:
            errors.append("claim provenance missing")
        for e in unit.evidence:
            if not e.statement:
                errors.append(f"empty evidence: {e.evidence_id}")
            if not is_complete(e.provenance):
                errors.append(f"incomplete evidence provenance: {e.evidence_id}")
        for test in unit.tests:
            if not test.test_id or not test.kind:
                errors.append("invalid test specification")
            if test.expected is None:
                errors.append(f"test expected property missing: {test.test_id}")
        return errors
