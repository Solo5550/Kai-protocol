from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from threading import RLock
from collections import defaultdict
from typing import Any, Callable

from .interop import Authority, CapabilityRef, Causality, DialogueLedger, SemanticMessage, SpeechAct, validate_semantic_message
from kai.language.semantic_codec import decode_semantic, encode_semantic


class EndpointError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class RegisteredCapability:
    capability: CapabilityRef
    contract: dict[str, Any]
    handler: Callable[[dict[str, Any]], Any]


class KaiEndpoint:
    """Reference transport-neutral endpoint for Kai code-to-code discourse.

    It is intentionally small: the endpoint implements the semantic boundary
    while heavier Kai Runtime components may be used behind the registered handler.
    """

    def __init__(self, name: str, *, tenant: str | None = None, authorizer: Callable[[SemanticMessage, CapabilityRef], None] | None = None) -> None:
        self.name = name
        self.tenant = tenant
        self._authorizer = authorizer
        self._caps: dict[str, RegisteredCapability] = {}
        self._dialogs: dict[str, DialogueLedger] = {}
        self._idempotency: dict[tuple[str, str], tuple[str, tuple[SemanticMessage, ...]]] = {}
        self._idempotency_locks: defaultdict[tuple[str, str], RLock] = defaultdict(RLock)
        self._dialogue_locks: defaultdict[str, RLock] = defaultdict(RLock)

    def register(self, capability: CapabilityRef, *, contract: dict[str, Any], handler: Callable[[dict[str, Any]], Any]) -> None:
        if not capability.capability_id or not capability.version:
            raise EndpointError("capability identity is required")
        if not contract.get("id") or not contract.get("version"):
            raise EndpointError("contract id/version are required")
        if capability.contract_id and capability.contract_id != contract["id"]:
            raise EndpointError("capability_contract_mismatch")
        if capability.contract_version and capability.contract_version != contract["version"]:
            raise EndpointError("capability_contract_version_mismatch")
        self._caps[capability.capability_id] = RegisteredCapability(capability, dict(contract), handler)


    def handle_frame(self, frame: str) -> tuple[str, ...]:
        """Handle one canonical KAI-LANG/0.8 frame and return encoded response frames."""
        try:
            data = decode_semantic(frame)
            request = SemanticMessage.from_dict(data) if hasattr(SemanticMessage, "from_dict") else _semantic_from_dict(data)
        except Exception as exc:
            raise EndpointError(f"invalid_kai_frame: {exc}") from exc
        return tuple(encode_semantic(message) for message in self.handle(request))

    def handle(self, request: SemanticMessage) -> tuple[SemanticMessage, ...]:
        errors = validate_semantic_message(request)
        if errors:
            raise EndpointError("; ".join(errors))
        if request.act is not SpeechAct.REQUEST:
            raise EndpointError("endpoint accepts REQUEST messages only")
        if request.recipient != self.name and request.recipient != "*":
            raise EndpointError("recipient_mismatch")
        cap_ref = request.capability
        if cap_ref is None or cap_ref.capability_id not in self._caps:
            return (self._reject(request, "capability_not_registered"),)
        reg = self._caps[cap_ref.capability_id]
        if reg.capability.version != cap_ref.version:
            return (self._reject(request, "capability_version_mismatch"),)
        if reg.contract["id"] != (request.contract or {}).get("id") or reg.contract["version"] != (request.contract or {}).get("version"):
            return (self._reject(request, "contract_mismatch"),)
        self._authorize(request, reg.capability)
        if self._authorizer is not None:
            try:
                self._authorizer(request, reg.capability)
            except EndpointError:
                raise
            except Exception as exc:
                raise EndpointError("authorization_policy_error") from exc
        idem = (request.extensions or {}).get("idempotency_key")
        idem_key = (request.sender, idem) if idem else None
        lock = self._idempotency_locks[idem_key] if idem_key else self._dialogue_locks[request.conversation_id]
        with lock:
            if idem_key and idem_key in self._idempotency:
                cached_request_id, cached_replies = self._idempotency[idem_key]
                if cached_request_id != request.message_id:
                    raise EndpointError("idempotency_key_reused_with_different_message")
                return cached_replies
            dialog = self._dialogs.setdefault(request.conversation_id, DialogueLedger(request.conversation_id))
            dialog.ingest(request)
            execution_id = f"exec-{hashlib.sha256((request.message_id + self.name).encode()).hexdigest()[:24]}"
            accept = SemanticMessage.build(
                conversation_id=request.conversation_id, sender=self.name, recipient=request.sender,
                act=SpeechAct.ACCEPT, intent=request.intent,
                causality=Causality(request.conversation_id, request.causality.correlation_id, request.causality.sequence + 1,
                                     parent_ids=(request.message_id,), causation_id=request.message_id),
                execution={"execution_id": execution_id, "attempt": 1},
                capability=reg.capability, contract=reg.contract, authority=request.authority, extensions=dict(request.extensions),
                provenance={"endpoint": self.name},
            )
            dialog.ingest(accept)
            try:
                result = reg.handler(dict(request.input))
            except Exception as exc:
                failure = SemanticMessage.build(
                    conversation_id=request.conversation_id, sender=self.name, recipient=request.sender,
                    act=SpeechAct.FAILURE, intent=request.intent,
                    causality=Causality(request.conversation_id, request.causality.correlation_id, request.causality.sequence + 2,
                                         parent_ids=(accept.message_id,), causation_id=accept.message_id),
                    execution={"execution_id": execution_id, "attempt": 1}, outcome={"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"},
                    capability=reg.capability, contract=reg.contract, authority=request.authority, extensions=dict(request.extensions),
                    provenance={"endpoint": self.name},
                )
                dialog.ingest(failure)
                responses = (accept, failure)
            else:
                completed = SemanticMessage.build(
                    conversation_id=request.conversation_id, sender=self.name, recipient=request.sender,
                    act=SpeechAct.RESULT, intent=request.intent,
                    causality=Causality(request.conversation_id, request.causality.correlation_id, request.causality.sequence + 2,
                                         parent_ids=(accept.message_id,), causation_id=accept.message_id),
                    execution={"execution_id": execution_id, "attempt": 1}, outcome={"status": "COMPLETED", "value": result},
                    effects=({"idempotency_key": idem, "status": "COMPLETED"},) if idem else (),
                    capability=reg.capability, contract=reg.contract, authority=request.authority, extensions=dict(request.extensions),
                    provenance={"endpoint": self.name},
                )
                dialog.ingest(completed)
                responses = (accept, completed)
            if idem_key:
                self._idempotency[idem_key] = (request.message_id, responses)
            return responses

    def _authorize(self, request: SemanticMessage, capability: CapabilityRef) -> None:
        if capability.side_effect_class not in {"external_write", "irreversible"}:
            return
        if request.authority is None:
            raise EndpointError("authority_required")
        scopes = set(request.authority.scopes)
        if capability.capability_id not in scopes and "*" not in scopes:
            raise EndpointError("authority_scope_denied")
        if self.tenant is not None and request.authority.tenant != self.tenant:
            raise EndpointError("tenant_scope_denied")

    def _reject(self, request: SemanticMessage, reason: str) -> SemanticMessage:
        return SemanticMessage.build(
            conversation_id=request.conversation_id, sender=self.name, recipient=request.sender,
            act=SpeechAct.REJECT, intent=request.intent,
            causality=Causality(request.conversation_id, request.causality.correlation_id, request.causality.sequence + 1,
                                 parent_ids=(request.message_id,), causation_id=request.message_id),
            outcome={"status": "REJECTED", "error": reason},
            provenance={"endpoint": self.name},
        )
