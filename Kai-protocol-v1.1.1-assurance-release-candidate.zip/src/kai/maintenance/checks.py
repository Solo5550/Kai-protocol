from __future__ import annotations

import hashlib
import json
import os
import platform
import statistics
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from .models import GateResult, GateStatus, TestOracle, TestResult
from .oracles import validate_oracle_integrity


def _maint_echo(payload: dict[str, Any]) -> dict[str, Any]:
    return {"ok": payload.get("value")}


def _maint_reverse(payload: dict[str, Any]) -> dict[str, Any]:
    return {"value": payload["value"]}


def _maint_target_good(_payload: dict[str, Any]) -> dict[str, Any]:
    return {"ok": True}


def _maint_target_attacker(_payload: dict[str, Any]) -> dict[str, Any]:
    return {"ok": "attacker"}


def _maint_diff(payload: dict[str, Any]) -> dict[str, Any]:
    return {"x": payload["x"]}


def _maint_stable(payload: dict[str, Any]) -> dict[str, Any]:
    return {"v": payload["v"] + 1}


def _maint_concurrent(payload: dict[str, Any]) -> dict[str, Any]:
    return {"n": payload["n"] * 2}


def _gate(gate_id: str, status: GateStatus, reason: str, *, metrics=None, evidence=(), limitations=(), applicable=True):
    return GateResult(gate_id, status, reason, tuple(evidence), metrics or {}, tuple(limitations), applicable)


def run_static_gate(root: Path) -> GateResult:
    started = time.perf_counter()
    compile_cmd = [sys.executable, "-m", "compileall", "-q", "src"]
    proc = subprocess.run(compile_cmd, cwd=root, text=True, capture_output=True)
    elapsed = (time.perf_counter() - started) * 1000
    return _gate("STATIC", GateStatus.PASS if proc.returncode == 0 else GateStatus.FAIL,
                 "compileall_pass" if proc.returncode == 0 else proc.stderr.strip() or "compileall_failed",
                 metrics={"compile_ms": round(elapsed, 3)}, evidence=("static:compileall",))


def run_test_suite(root: Path) -> GateResult:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root / "src")
    proc = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=root, text=True, capture_output=True, env=env)
    output = (proc.stdout + "\n" + proc.stderr).strip()
    passed = proc.returncode == 0 and " passed" in output
    return _gate("REGRESSION", GateStatus.PASS if passed else GateStatus.FAIL,
                 "existing_suite_passed" if passed else "existing_suite_failed", metrics={"pytest": output[-1000:]}, evidence=("regression:pytest",))


def run_forward_probe() -> tuple[GateResult, dict[str, Any]]:
    from kai.runtime import Capability, Contract, EvidenceBundle, KaiRuntime, Plan, PlanNode, Policy
    with TemporaryDirectory(prefix="kai-maint-forward-") as td:
        runtime = KaiRuntime(data_dir=td)
        cap = Capability(capability_id="maintenance.echo", implementation_id="impl.echo", owner="maintenance", purpose="red-team echo")
        runtime.install_capability(cap, _maint_echo)
        contract = Contract(id="maintenance.contract", version="1.0", input_schema={"required": ["value"]})
        evidence = EvidenceBundle(evidence_id="maintenance.evidence", sources=[{"source_id": "fixture", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})
        plan = Plan(plan_id="maintenance.plan", objective="echo", nodes=[PlanNode(node_id="echo", capability_requirement={"capability_id": cap.capability_id})], acceptance_criteria=["output is deterministic"])
        policy = Policy(policy_id="maintenance.policy", allowed_capabilities=[cap.capability_id], allowed_regions=["local"])
        result = runtime.execute(objective="maintenance-forward", input_data={"value": "x"}, contract=contract, policy=policy,
                                 capability_id=cap.capability_id, evidence=evidence, plan=plan, handler=_maint_echo)
        good = result.execution.state.value == "CLOSED" and result.kernel.status == "SUCCESS" and result.kernel.output == {"ok": "x"}
        return _gate("FORWARD", GateStatus.PASS if good else GateStatus.FAIL, "golden_execution_forward_verified" if good else "forward_invariant_failure", evidence=(f"execution:{result.execution.execution_id}",)), {"execution_id": result.execution.execution_id}


def run_reverse_probe(root: Path) -> GateResult:
    from kai.runtime import Capability, Contract, EvidenceBundle, KaiRuntime, Plan, PlanNode, Policy
    with TemporaryDirectory(prefix="kai-maint-reverse-") as td:
        runtime = KaiRuntime(data_dir=td)
        cap = Capability(capability_id="maintenance.reverse", implementation_id="impl.reverse", owner="maintenance")
        runtime.install_capability(cap, _maint_reverse)
        contract = Contract(id="c", version="1")
        evidence = EvidenceBundle(evidence_id="e", sources=[{"source_id": "s", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})
        plan = Plan(plan_id="p", objective="reverse", nodes=[PlanNode(node_id="n", capability_requirement={"capability_id": cap.capability_id})], acceptance_criteria=["verified"])
        policy = Policy(policy_id="p", allowed_capabilities=[cap.capability_id], allowed_regions=["local"])
        out = runtime.execute(objective="reverse", input_data={"value": 7}, contract=contract, policy=policy, capability_id=cap.capability_id, evidence=evidence, plan=plan, handler=_maint_reverse, expected_outcome={"value": 7})
        recon = runtime.reconstruct(out.execution.execution_id)
        events = recon.get("events", [])
        has_source = recon.get("execution", {}).get("input_data") == {"value": 7}
        has_result = any(e["event_type"] in {"EXECUTION_COMPLETED", "VERIFIED", "PROVEN"} for e in events)
        ok = has_source and has_result and bool(out.execution.execution_id)
        return _gate("REVERSE", GateStatus.PASS if ok else GateStatus.FAIL, "decision_reconstructs_to_execution_input" if ok else "reconstruction_failure", evidence=(f"reconstruction:{out.execution.execution_id}",))


def run_adversarial_probe() -> GateResult:
    from kai.runtime import Capability, Contract, EvidenceBundle, KaiRuntime, Plan, PlanNode, Policy
    with TemporaryDirectory(prefix="kai-maint-adversarial-") as td:
        runtime = KaiRuntime(data_dir=td)
        cap = Capability(capability_id="maintenance.target", implementation_id="impl.target", owner="maintenance")
        runtime.install_capability(cap, _maint_target_good)
        contract = Contract(id="c", version="1")
        evidence = EvidenceBundle(evidence_id="e", sources=[{"source_id": "s", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})
        plan = Plan(plan_id="p", objective="target", nodes=[PlanNode(node_id="n", capability_requirement={"capability_id": cap.capability_id})], acceptance_criteria=["x"])
        policy = Policy(policy_id="p", allowed_capabilities=[cap.capability_id], allowed_regions=["local"])
        try:
            runtime.execute(objective="adversarial", input_data={}, contract=contract, policy=policy, capability_id=cap.capability_id,
                            evidence=evidence, plan=plan, handler=_maint_target_attacker)
            return _gate("ADVERSARIAL", GateStatus.FAIL, "untrusted_handler_accepted", evidence=("adversarial:handler-substitution",))
        except (PermissionError, ValueError) as exc:
            return _gate("ADVERSARIAL", GateStatus.PASS, "handler_substitution_rejected", evidence=("adversarial:handler-substitution",), metrics={"error": str(exc)})


def run_differential_probe() -> GateResult:
    from kai.runtime import Capability, Contract, EvidenceBundle, KaiRuntime, Plan, PlanNode, Policy
    from kai.runtime.envelope import build_envelope, envelope_fingerprint
    from kai.runtime.identity import IdentityContext
    identity = IdentityContext.root(region_id="local", cell_id="cell-local", actor_id="maintenance")
    ref = build_envelope(identity=identity, message_type="ExecutionCommand", contract_ref={"id": "c", "version": "1"},
                         capability_ref={"id": "x", "version": "1.0.0"}, policy_snapshot_ref="p@1", idempotency_key="idem", payload={"x": 1})
    ref_digest = envelope_fingerprint(ref)
    with TemporaryDirectory(prefix="kai-maint-diff-") as td:
        runtime = KaiRuntime(data_dir=td)
        cap = Capability(capability_id="x", implementation_id="impl.x", owner="maintenance")
        runtime.install_capability(cap, _maint_diff)
        contract = Contract(id="c", version="1")
        evidence = EvidenceBundle(evidence_id="e", sources=[{"source_id": "s", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})
        plan = Plan(plan_id="p", objective="diff", nodes=[PlanNode(node_id="n", capability_requirement={"capability_id": "x"})], acceptance_criteria=["x"])
        policy = Policy(policy_id="p", allowed_capabilities=["x"], allowed_regions=["local"])
        out = runtime.execute(objective="diff", input_data={"x": 1}, contract=contract, policy=policy, capability_id="x", evidence=evidence, plan=plan, handler=_maint_diff)
        # Independent oracle: reconstructed execution output must equal the handler oracle.
        actual = out.kernel.output
        ok = actual == {"x": 1} and isinstance(ref_digest, str) and len(ref_digest) == 64
        return _gate("DIFFERENTIAL", GateStatus.PASS if ok else GateStatus.FAIL, "independent_oracle_match" if ok else "differential_mismatch", evidence=("differential:envelope-vector",), metrics={"oracle_digest": ref_digest})


def run_performance_probe(iterations: int = 200) -> tuple[GateResult, dict[str, float]]:
    from kai.runtime.conformance import RuntimeConformance
    samples = []
    for _ in range(iterations):
        t0 = time.perf_counter_ns()
        RuntimeConformance().run()
        samples.append((time.perf_counter_ns() - t0) / 1_000_000)
    xs = sorted(samples)
    def pct(p):
        idx = min(len(xs) - 1, max(0, int(round((len(xs) - 1) * p))))
        return xs[idx]
    stats = {"p50_ms": pct(0.50), "p95_ms": pct(0.95), "p99_ms": pct(0.99), "throughput_ops_s": iterations / (sum(samples) / 1000)}
    stable = all(x > 0 for x in samples)
    return _gate("PERFORMANCE", GateStatus.PASS if stable else GateStatus.FAIL, "measurement_complete" if stable else "invalid_timing_samples", metrics=stats, evidence=("performance:local-baseline",)), stats


def run_recovery_probe() -> GateResult:
    from kai.runtime import FailureCategory, FailureEngine, ReplayEngine, RetryController, RuntimeStore
    store = RuntimeStore()
    failure = FailureEngine(store).capture(execution_id="maint-recovery", state="TIMED_OUT", category=FailureCategory.TIMEOUT,
                                            severity="high", symptom="deadline", trigger="timeout")
    recovery = __import__("kai.runtime", fromlist=["RecoveryEngine"]).RecoveryEngine().recover(failure=failure, allow_retry=True, allow_compensation=False)
    replay = ReplayEngine().replay({"execution": {"execution_id": "maint-recovery"}, "events": []}, mode="RECONSTRUCTION_ONLY")
    retry = RetryController(max_attempts=2).decide(1, retryable=True)
    ok = recovery["action"] == "RETRY" and retry.retry and not replay["reexecute_external_effects"]
    return _gate("RECOVERY", GateStatus.PASS if ok else GateStatus.FAIL, "retry_replay_recovery_invariants_hold" if ok else "recovery_invariant_failure", evidence=("recovery:probe",))


def run_security_probe(root: Path) -> GateResult:
    import ast
    insecure: list[str] = []
    for path in root.glob("src/**/*.py"):
        rel = path.relative_to(root).as_posix()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"), filename=rel)
        except SyntaxError as exc:
            insecure.append(f"{rel}:syntax:{exc.lineno}")
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec"}:
                    insecure.append(f"{rel}:{node.lineno}:{node.func.id}")
                if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "os" and node.func.attr == "system":
                    insecure.append(f"{rel}:{node.lineno}:os.system")
    pip_check = subprocess.run([sys.executable, "-m", "pip", "check"], text=True, capture_output=True)
    env_issue = pip_check.returncode != 0
    ok = not insecure
    limitations = []
    if env_issue:
        limitations.append("pip_check_is_environment_dependent_and_reported_nonzero")
    return _gate("SECURITY", GateStatus.PASS if ok else GateStatus.FAIL, "static_security_probe_clean" if ok else "unsafe_dynamic_execution_pattern_found",
                 evidence=("security:static-source-scan",), metrics={"findings": insecure, "pip_check": pip_check.stdout.strip(), "pip_check_stderr": pip_check.stderr.strip()}, limitations=tuple(limitations))


def run_provenance_probe(root: Path) -> GateResult:
    files = sorted(p for p in root.glob("src/**/*.py") if p.is_file())
    manifest = []
    for path in files:
        data = path.read_bytes()
        manifest.append({"path": path.relative_to(root).as_posix(), "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)})
    payload = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    digest = hashlib.sha256(payload).hexdigest()
    attestation = root / "maintenance-provenance.json"
    attestation.write_text(json.dumps({"kind": "kai.maintenance.source-attestation", "digest": digest, "files": manifest}, indent=2), encoding="utf-8")
    verified = hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()).hexdigest() == digest
    return _gate("PROVENANCE", GateStatus.PASS if verified else GateStatus.FAIL, "source_attestation_self_verifies" if verified else "attestation_mismatch",
                 evidence=(f"artifact:{attestation.name}",), metrics={"files": len(files), "manifest_digest": digest})


def run_integration_compatibility_probe(root: Path) -> GateResult:
    code = "from kai.runtime import KaiRuntime, RuntimeConformance; from kai.maintenance import MaintenanceProtocol; assert RuntimeConformance().run().passed"
    env = dict(os.environ); env["PYTHONPATH"] = str(root / "src")
    proc = subprocess.run([sys.executable, "-c", code], cwd=root, text=True, capture_output=True, env=env)
    status = GateStatus.PASS if proc.returncode == 0 else GateStatus.FAIL
    return _gate("INTEGRATION_COMPATIBILITY", status, "public_api_imports_and_conformance_ok" if status is GateStatus.PASS else proc.stderr.strip(), evidence=("integration:public-api", "compatibility:runtime-0.6"))


def run_reproducibility_probe() -> GateResult:
    from kai.runtime.envelope import build_envelope
    from kai.runtime.identity import IdentityContext
    semantic = {
        "envelope_version", "message_type", "tenant_id", "namespace_id", "run_id", "execution_id",
        "parent_execution_id", "root_execution_id", "trace_id", "span_id", "causal_parent_id",
        "region_id", "cell_id", "actor_id", "contract_ref", "capability_ref", "policy_snapshot_ref",
        "deadline_at", "attempt", "idempotency_key", "security_context_ref", "provenance_ref",
        "payload_ref", "classification", "status",
    }
    results = []
    for _ in range(2):
        identity = IdentityContext(tenant_id="t", namespace_id="n", run_id="r", execution_id="e", parent_execution_id=None,
                                  root_execution_id="e", trace_id="tr", span_id="sp", causal_parent_id=None, region_id="local", cell_id="cell-local", actor_id="a")
        env = build_envelope(identity=identity, message_type="X", contract_ref={"id": "c", "version": "1"},
                             idempotency_key="i", payload={"a": 1})
        from dataclasses import fields
        results.append({f.name: getattr(env, f.name) for f in fields(env) if f.name in semantic})
    ok = results[0] == results[1]
    return _gate("REPRODUCIBILITY", GateStatus.PASS if ok else GateStatus.FAIL, "semantic_vector_reproduced" if ok else "semantic_variance_detected", evidence=("reproducibility:semantic-vector",), limitations=("volatile object/timestamp/message identifiers intentionally excluded from semantic comparison",))


def run_change_and_oracle_gates() -> tuple[GateResult, GateResult]:
    from .models import ChangeRecord
    from .oracles import freeze_oracle
    oracle = freeze_oracle(oracle_id="maintenance.acceptance", expected_result="PASS", invariants=["all_applicable_gates_pass"], thresholds={})
    oracle_ok = validate_oracle_integrity(oracle)
    change = ChangeRecord(change_id="maintenance-current", risk_class="HIGH", blast_radius={"global": True}, affected_contracts=("runtime-contracts",), affected_states=("all",), test_scope=("full-red-team",), rollback_plan="restore previous revision", rollforward_plan="complete qualification", owner="maintenance", review_status="INDEPENDENT_REQUIRED", approval_status="PENDING", post_change_observation="REQUIRED")
    change_ok = all((change.change_id, change.rollback_plan, change.owner, change.test_scope))
    return (_gate("TEST_ORACLE", GateStatus.PASS if oracle_ok else GateStatus.FAIL, "oracle_digest_frozen" if oracle_ok else "oracle_tampered" , evidence=("oracle:maintenance-acceptance",)),
            _gate("CHANGE_GOVERNANCE", GateStatus.PASS if change_ok else GateStatus.FAIL, "change_record_complete" if change_ok else "change_record_incomplete", evidence=("change:maintenance-current",)))


def run_operationally_blocked_gates() -> tuple[GateResult, ...]:
    reason = "no live multi-node production deployment target is connected to this execution environment"
    return tuple(_gate(g, GateStatus.BLOCKED, reason, evidence=(f"blocked:{g.lower()}",), limitations=(reason,), applicable=True) for g in (
        "CANARY_PROGRESSIVE_DEPLOYMENT", "SLO_ERROR_BUDGET", "REGIONAL_FAILOVER", "NODE_LOSS_CHAOS", "SUPPLY_CHAIN_EXTERNAL_ATTESTATION",
    ))


def run_stability_probe(iterations: int = 12) -> GateResult:
    from kai.runtime import Capability, Contract, EvidenceBundle, KaiRuntime, Plan, PlanNode, Policy
    latencies = []
    failures = 0
    errors: list[str] = []
    for i in range(iterations):
        with TemporaryDirectory(prefix="kai-maint-stability-") as td:
            runtime = KaiRuntime(data_dir=td)
            cap = Capability(capability_id="maintenance.stability", implementation_id="impl.stability", owner="maintenance")
            runtime.install_capability(cap, _maint_stable)
            contract = Contract(id="c", version="1", input_schema={"required": ["v"]})
            evidence = EvidenceBundle(evidence_id=f"e{i}", sources=[{"source_id": "fixture", "observed_at": "2099-01-01T00:00:00+00:00"}], integrity={"validated": True})
            plan = Plan(plan_id=f"p{i}", objective="stability", nodes=[PlanNode(node_id="n", capability_requirement={"capability_id": cap.capability_id})], acceptance_criteria=["stable"])
            policy = Policy(policy_id="p", allowed_capabilities=[cap.capability_id], allowed_regions=["local"])
            t0 = time.perf_counter_ns()
            try:
                out = runtime.execute(objective="stability", input_data={"v": i}, contract=contract, policy=policy,
                                      capability_id=cap.capability_id, evidence=evidence, plan=plan, handler=_maint_stable, expected_outcome={"v": i + 1})
                failures += int(out.execution.state.value != "CLOSED" or out.kernel.output != {"v": i + 1})
            except Exception as exc:
                failures += 1
                errors.append(f"{type(exc).__name__}: {exc}")
            latencies.append((time.perf_counter_ns() - t0) / 1_000_000)
    mean = statistics.mean(latencies)
    stdev = statistics.pstdev(latencies)
    cv = stdev / mean if mean else float("inf")
    ok = failures == 0
    return _gate("STABILITY_OBSERVATION", GateStatus.PASS if ok else GateStatus.FAIL,
                 "local_observation_window_clean" if ok else "local_stability_failures",
                 metrics={"iterations": iterations, "failures": failures, "mean_ms": mean, "cv": cv, "errors": errors[:8]}, evidence=("stability:local-window",))


def run_concurrency_probe(workers: int = 4, jobs: int = 8) -> GateResult:
    """Concurrent kernel submissions against shared RuntimeStore.

    Uses ProcessExecutor with the platform-stable start method (fork on POSIX)
    so the probe measures store/kernel concurrency invariants, not spawn-bootstrap
    races (see KAI-RC-0006).
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from kai.runtime import Contract, ExecutionKernel, RuntimeStore
    from kai.runtime.executor import ProcessExecutor
    from kai.runtime.identity import IdentityContext
    store = RuntimeStore()
    executor = ProcessExecutor()  # fork-preferring after RC-0006
    kernel = ExecutionKernel(store=store, executor=executor)
    def one(i):
        identity = IdentityContext(tenant_id="t", namespace_id="n", run_id=f"r-{i}", execution_id=f"e-{i}", parent_execution_id=None, root_execution_id=f"e-{i}", trace_id=f"tr-{i}", span_id=f"sp-{i}", causal_parent_id=None, region_id="local", cell_id="cell-local", actor_id="maintenance")
        out = kernel.submit(identity=identity, objective="concurrency", input_data={"n": i}, contract=Contract(id="c", version="1"), handler=_maint_concurrent, timeout=10)
        if out.status != "SUCCESS" or out.output != {"n": i * 2}:
            return False, f"i={i} status={out.status} output={out.output} error={out.error}"
        return True, None
    t0 = time.perf_counter()
    results = []
    errors: list[str] = []
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = [ex.submit(one, i) for i in range(jobs)]
        for f in as_completed(futures):
            try:
                ok_i, detail = f.result()
                results.append(ok_i)
                if not ok_i and detail:
                    errors.append(detail)
            except Exception as exc:
                import traceback
                errors.append(f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}")
    elapsed = time.perf_counter() - t0
    ok = not errors and all(results) and len(results) == jobs
    executor.close()
    return _gate(
        "CONCURRENCY",
        GateStatus.PASS if ok else GateStatus.FAIL,
        "parallel_kernel_submissions_consistent" if ok else "concurrency_failure",
        metrics={
            "workers": workers, "jobs": jobs, "elapsed_s": elapsed,
            "throughput": jobs / elapsed if elapsed else 0,
            "errors": errors[:8],
            "start_method": getattr(executor, "start_method", "unknown"),
        },
        evidence=("concurrency:kernel-submit", "KAI-RC-0006"),
    )


def run_resource_leak_probe(iterations: int = 30) -> GateResult:
    from kai.runtime import RuntimeStore
    before = len(os.listdir("/proc/self/fd")) if os.path.exists("/proc/self/fd") else None
    stores = []
    for _ in range(iterations):
        s = RuntimeStore()
        s.create_execution(__import__("kai.runtime", fromlist=["Execution"]).Execution(execution_id=f"leak-{time.time_ns()}", run_id="r", objective="leak"))
        stores.append(s)
    for s in stores:
        s.close()
    after = len(os.listdir("/proc/self/fd")) if before is not None and os.path.exists("/proc/self/fd") else None
    if before is None or after is None:
        return _gate("RESOURCE_LEAK", GateStatus.NA, "fd_probe_not_supported_on_this_platform", evidence=("resource:fd-probe",), limitations=("/proc/self/fd unavailable",), applicable=False)
    delta = after - before
    return _gate("RESOURCE_LEAK", GateStatus.PASS if delta <= 2 else GateStatus.FAIL, "fd_usage_stable" if delta <= 2 else "fd_growth_detected", metrics={"before_fd": before, "after_fd": after, "delta": delta}, evidence=("resource:fd-probe",))


def run_maintainability_probe(root: Path) -> GateResult:
    import ast
    max_function_lines = 0
    files = 0
    for path in root.glob("src/kai/maintenance/**/*.py"):
        files += 1
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
        except SyntaxError:
            return _gate("MAINTAINABILITY", GateStatus.FAIL, f"syntax_failure:{path}", evidence=("maintainability:ast",))
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                end = getattr(node, "end_lineno", node.lineno)
                max_function_lines = max(max_function_lines, end - node.lineno + 1)
    ok = max_function_lines <= 320
    return _gate("MAINTAINABILITY", GateStatus.PASS if ok else GateStatus.FAIL, "maintenance_functions_within_budget" if ok else "function_complexity_budget_exceeded", metrics={"files": files, "max_function_lines": max_function_lines, "budget": 320}, evidence=("maintainability:ast",))
