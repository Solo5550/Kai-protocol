from __future__ import annotations

from .models import Alternative, AlternativeAnalysis

# Higher is better. Cost/complexity/blast radius are therefore negated by the caller.
DEFAULT_DIRECTIONS = {
    "correctness": 1,
    "reliability": 1,
    "latency": 1,
    "throughput": 1,
    "recovery": 1,
    "security": 1,
    "complexity": -1,
    "maintainability": 1,
    "compatibility": 1,
    "cost": -1,
    "blast_radius": -1,
}


def _dominates(a: Alternative, b: Alternative, directions: dict[str, int]) -> bool:
    keys = set(a.attributes) | set(b.attributes)
    not_worse = True
    strictly = False
    for k in keys:
        av = a.attributes.get(k, 0.0) * directions.get(k, 1)
        bv = b.attributes.get(k, 0.0) * directions.get(k, 1)
        if av < bv:
            not_worse = False
            break
        strictly = strictly or av > bv
    return not_worse and strictly


def analyze_alternatives(alternatives: list[Alternative], *, directions: dict[str, int] | None = None) -> AlternativeAnalysis:
    directions = directions or DEFAULT_DIRECTIONS
    nondominated = []
    dominated = []
    for i, candidate in enumerate(alternatives):
        if not candidate.constraints_met:
            dominated.append(candidate.alternative_id)
            continue
        is_dominated = any(_dominates(other, candidate, directions) for j, other in enumerate(alternatives) if j != i and other.constraints_met)
        (dominated if is_dominated else nondominated).append(candidate.alternative_id)
    return AlternativeAnalysis(tuple(alternatives), tuple(nondominated), tuple(dominated), {"directions": directions})
