from __future__ import annotations

import hashlib
import json
from typing import Any

from .models import TestOracle


def freeze_oracle(*, oracle_id: str, expected_result: Any, invariants: list[str], thresholds: dict[str, float]) -> TestOracle:
    payload = json.dumps({
        "oracle_id": oracle_id,
        "expected_result": expected_result,
        "invariants": invariants,
        "thresholds": thresholds,
    }, sort_keys=True, separators=(",", ":"), default=str).encode()
    return TestOracle(oracle_id, expected_result, tuple(invariants), thresholds, hashlib.sha256(payload).hexdigest())


def validate_oracle_integrity(oracle: TestOracle) -> bool:
    rebuilt = freeze_oracle(oracle_id=oracle.oracle_id, expected_result=oracle.expected_result,
                            invariants=list(oracle.invariants), thresholds=oracle.thresholds)
    return rebuilt.frozen_digest == oracle.frozen_digest
