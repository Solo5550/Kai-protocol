"""Optional Global Red-Team Maintenance, Root-Cause Repair & Requalification layer.

This layer is independent from runtime execution semantics. It observes and qualifies
an existing runtime; it does not own execution or provide a bypass path.
"""
from .models import *
from .protocol import MaintenanceProtocol, MaintenancePolicyError
from .baseline import build_baseline
from .archaeology import ArchaeologyScanner
from .alternatives import analyze_alternatives
from .oracles import freeze_oracle, validate_oracle_integrity

__all__ = [
    "MaintenanceProtocol", "MaintenancePolicyError", "build_baseline", "ArchaeologyScanner",
    "analyze_alternatives", "freeze_oracle", "validate_oracle_integrity",
]
__all__ += [name for name in globals() if not name.startswith("_") and name not in __all__]
from .coverage import RequirementCoverage, coverage
from .operational import (
    ContainmentRecord, ProgressiveDecision, build_blast_radius, change_record_complete,
    debt_item_valid, evaluate_slo, progressive_step, validate_waiver,
)

__all__ += [
    "RequirementCoverage", "coverage", "ContainmentRecord", "ProgressiveDecision", "build_blast_radius",
    "change_record_complete", "debt_item_valid", "evaluate_slo", "progressive_step", "validate_waiver",
]
