from __future__ import annotations

import ast
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ArchaeologyReport:
    actual_execution_paths: tuple[str, ...]
    orphan_modules: tuple[str, ...]
    duplicate_implementations: tuple[tuple[str, ...], ...]
    legacy_paths: tuple[str, ...]
    circular_dependencies: tuple[tuple[str, ...], ...]
    unbounded_retry_sites: tuple[str, ...]
    broad_exception_sites: tuple[str, ...]
    observability_gaps: tuple[str, ...]
    contract_drift_candidates: tuple[str, ...]
    schema_drift_candidates: tuple[str, ...]
    shadow_paths: tuple[str, ...]

    @property
    def drift_count(self) -> int:
        return sum(len(x) for x in (
            self.orphan_modules, self.duplicate_implementations, self.legacy_paths,
            self.circular_dependencies, self.unbounded_retry_sites, self.broad_exception_sites,
            self.observability_gaps, self.contract_drift_candidates, self.schema_drift_candidates,
            self.shadow_paths,
        ))


class ArchaeologyScanner:
    """Static archaeology of the actual source tree.

    This scanner only inspects source/configuration. It never executes a capability and
    cannot create an alternate runtime path.
    """

    def scan(self, root: str | Path) -> ArchaeologyReport:
        root = Path(root).resolve()
        src = root / "src"
        py_files = sorted(src.rglob("*.py")) if src.exists() else []
        module_names = {self._module_name(p, src) for p in py_files if p.name != "__init__.py"}
        import_graph: dict[str, set[str]] = {m: set() for m in module_names}
        reverse_refs: dict[str, set[str]] = {m: set() for m in module_names}
        duplicate_hashes: dict[str, list[str]] = {}
        orphan_candidates: list[str] = []
        legacy: list[str] = []
        retries: list[str] = []
        broad: list[str] = []
        obs_gaps: list[str] = []
        contract_drift: list[str] = []
        schema_drift: list[str] = []
        shadow: list[str] = []
        execution_paths: list[str] = []

        for path in py_files:
            rel = path.relative_to(root).as_posix()
            text = path.read_text(encoding="utf-8", errors="ignore")
            normalized = self._normalize_source(text)
            duplicate_hashes.setdefault(hashlib.sha256(normalized.encode()).hexdigest(), []).append(rel)
            if re.search(r"(?:legacy|deprecated|old_|backup|shadow|experimental)", rel, re.I):
                legacy.append(rel)
            if re.search(r"(?:shadow|alternate|fallback_path|legacy_path)", text, re.I):
                shadow.append(rel)
            try:
                tree = ast.parse(text, filename=rel)
            except SyntaxError:
                continue
            module = self._module_name(path, src)
            imports = self._imports(tree, module_names)
            import_graph.setdefault(module, set()).update(imports)
            for target in imports:
                reverse_refs.setdefault(target, set()).add(module)
            for node in ast.walk(tree):
                if isinstance(node, (ast.Retry,)) if hasattr(ast, "Retry") else False:
                    retries.append(f"{rel}:{getattr(node, 'lineno', 0)}")
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "retry":
                    retries.append(f"{rel}:{node.lineno}")
                if isinstance(node, ast.ExceptHandler) and node.type is None:
                    broad.append(f"{rel}:{node.lineno}")
            if module.startswith("kai.runtime"):
                execution_paths.append(module)
                if "Observation" not in text and "observ" not in text.lower():
                    obs_gaps.append(rel)
                if "Contract" not in text and "contract" not in text.lower():
                    contract_drift.append(rel)
                if "schema" not in text.lower():
                    schema_drift.append(rel)

        for module, refs in reverse_refs.items():
            if not refs and not module.endswith(".__init__") and not module.startswith("kai.cli"):
                orphan_candidates.append(module)
        dupes = tuple(tuple(paths) for paths in duplicate_hashes.values() if len(paths) > 1)
        circular = tuple(tuple(cycle) for cycle in self._cycles(import_graph))
        return ArchaeologyReport(
            actual_execution_paths=tuple(sorted(set(execution_paths))),
            orphan_modules=tuple(sorted(orphan_candidates)),
            duplicate_implementations=dupes,
            legacy_paths=tuple(sorted(set(legacy))),
            circular_dependencies=circular,
            unbounded_retry_sites=tuple(retries),
            broad_exception_sites=tuple(broad),
            observability_gaps=tuple(sorted(set(obs_gaps))),
            contract_drift_candidates=tuple(sorted(set(contract_drift))),
            schema_drift_candidates=tuple(sorted(set(schema_drift))),
            shadow_paths=tuple(sorted(set(shadow))),
        )

    @staticmethod
    def _module_name(path: Path, src: Path) -> str:
        rel = path.relative_to(src).with_suffix("")
        return ".".join(rel.parts)

    @staticmethod
    def _normalize_source(text: str) -> str:
        text = re.sub(r"#[^\n]*", "", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    @staticmethod
    def _imports(tree: ast.AST, modules: set[str]) -> set[str]:
        found: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    candidate = alias.name
                    if candidate in modules:
                        found.add(candidate)
            elif isinstance(node, ast.ImportFrom) and node.module:
                base = node.module
                if base in modules:
                    found.add(base)
        return found

    @staticmethod
    def _cycles(graph: dict[str, set[str]]) -> list[list[str]]:
        cycles: list[list[str]] = []
        visiting: list[str] = []
        visited: set[str] = set()

        def dfs(node: str):
            if node in visiting:
                i = visiting.index(node)
                cycles.append(visiting[i:] + [node])
                return
            if node in visited:
                return
            visiting.append(node)
            for child in sorted(graph.get(node, ())):
                dfs(child)
            visiting.pop()
            visited.add(node)

        for node in sorted(graph):
            dfs(node)
        normalized = set()
        output = []
        for cycle in cycles:
            body = cycle[:-1]
            rotations = [tuple(body[i:] + body[:i]) for i in range(len(body))]
            key = min(rotations)
            if key not in normalized:
                normalized.add(key)
                output.append(list(key) + [key[0]])
        return output

    def json_report(self, root: str | Path) -> dict[str, Any]:
        report = self.scan(root)
        return {
            "actual_execution_paths": report.actual_execution_paths,
            "orphan_modules": report.orphan_modules,
            "duplicate_implementations": report.duplicate_implementations,
            "legacy_paths": report.legacy_paths,
            "circular_dependencies": report.circular_dependencies,
            "unbounded_retry_sites": report.unbounded_retry_sites,
            "broad_exception_sites": report.broad_exception_sites,
            "observability_gaps": report.observability_gaps,
            "contract_drift_candidates": report.contract_drift_candidates,
            "schema_drift_candidates": report.schema_drift_candidates,
            "shadow_paths": report.shadow_paths,
            "drift_count": report.drift_count,
        }
