from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .models import ChangeRecord, DebtItem, GateResult, GateStatus, SLOSpec, Waiver


@dataclass(frozen=True)
class ContainmentRecord:
    case_id: str
    why: str
    scope: str
    risk: str
    operator: str
    start_time: str
    expiry: str
    rollback: str
    follow_up_case: str


@dataclass(frozen=True)
class ProgressiveDecision:
    stage: str
    action: str  # HOLD / EXPAND / ROLLBACK
    reason: str
    metrics: dict[str, Any]


def evaluate_slo(spec: SLOSpec, *, success_rate: float, observed_burn_rate: float) -> GateResult:
    ok = success_rate >= spec.target and observed_burn_rate <= spec.max_burn_rate
    return GateResult(
        gate_id=f"SLO:{spec.name}",
        status=GateStatus.PASS if ok else GateStatus.FAIL,
        reason="slo_within_policy" if ok else "slo_or_burn_rate_violation",
        metrics={"success_rate": success_rate, "target": spec.target, "burn_rate": observed_burn_rate, "max_burn_rate": spec.max_burn_rate},
        evidence_refs=(f"slo:{spec.name}",),
    )


def progressive_step(stage: str, *, error_rate: float, max_error_rate: float, rollback_signal: bool = False) -> ProgressiveDecision:
    if rollback_signal:
        return ProgressiveDecision(stage, "ROLLBACK", "predeclared_rollback_signal", {"error_rate": error_rate})
    if error_rate > max_error_rate:
        return ProgressiveDecision(stage, "HOLD", "error_rate_above_expansion_threshold", {"error_rate": error_rate})
    return ProgressiveDecision(stage, "EXPAND", "predeclared_threshold_met", {"error_rate": error_rate})


def build_blast_radius(*, direct: list[str], indirect: list[str], dependencies: list[str], contracts: list[str], states: list[str], data: list[str], security: list[str], performance: list[str], regional: list[str], global_: list[str]) -> dict[str, list[str]]:
    return {
        "DIRECT_IMPACT": direct, "INDIRECT_IMPACT": indirect, "DEPENDENCY_IMPACT": dependencies,
        "CONTRACT_IMPACT": contracts, "STATE_IMPACT": states, "DATA_IMPACT": data,
        "SECURITY_IMPACT": security, "PERFORMANCE_IMPACT": performance,
        "REGIONAL_IMPACT": regional, "GLOBAL_IMPACT": global_,
    }


def validate_waiver(waiver: Waiver, *, critical_failure: bool, critical_security_gap: bool, provenance_broken: bool) -> GateResult:
    blocked = critical_failure or critical_security_gap or provenance_broken
    return GateResult(
        gate_id=f"WAIVER:{waiver.waiver_id}",
        status=GateStatus.FAIL if blocked else GateStatus.PASS,
        reason="waiver_cannot_convert_critical_failure_to_pass" if blocked else "waiver_scope_recorded_without_converting_status",
        evidence_refs=(waiver.waiver_id,),
    )


def change_record_complete(change: ChangeRecord) -> bool:
    return all((change.change_id, change.owner, change.rollback_plan, change.rollforward_plan, change.test_scope, change.review_status, change.approval_status, change.post_change_observation))


def debt_item_valid(item: DebtItem) -> bool:
    return all((item.debt_id, item.kind, item.description, item.owner, item.risk, item.expiry, item.remediation_path))
