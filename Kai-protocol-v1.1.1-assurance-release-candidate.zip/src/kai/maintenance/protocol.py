from __future__ import annotations

import hashlib
import inspect
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .alternatives import analyze_alternatives
from .archaeology import ArchaeologyReport, ArchaeologyScanner
from .baseline import build_baseline
from .checks import (
    run_adversarial_probe, run_change_and_oracle_gates, run_differential_probe, run_forward_probe,
    run_integration_compatibility_probe, run_operationally_blocked_gates, run_performance_probe,
    run_provenance_probe, run_recovery_probe, run_reproducibility_probe, run_reverse_probe,
    run_security_probe, run_stability_probe, run_static_gate, run_test_suite, run_concurrency_probe,
    run_resource_leak_probe, run_maintainability_probe,
)
from .models import (
    Alternative, Baseline, CapaAction, FailureClass, Finding, GateResult, GateStatus, MaintenanceCase,
    MaintenanceMode, MaintenanceReport, QualificationStatus, RepairStatus, RootCauseStatus, TestResult,
)
from .coverage import coverage as coverage_matrix
from .operational import ContainmentRecord, build_blast_radius, change_record_complete, debt_item_valid, evaluate_slo, progressive_step, validate_waiver

PROTOCOL_VERSION = "maintenance/1.0"


class MaintenancePolicyError(RuntimeError):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MaintenanceProtocol:
    """Independent maintenance/qualification control plane.

    It can inspect, test and qualify the runtime, but it has no executor and exposes no
    capability invocation path of its own. All probes call the existing runtime API.
    """

    def __init__(self, root: str | Path, *, performance_iterations: int = 40, stability_iterations: int = 4):
        self.root = Path(root).resolve()
        self.performance_iterations = performance_iterations
        self.stability_iterations = stability_iterations
        self.archaeology = ArchaeologyScanner()
        self.findings: list[Finding] = []
        self.cases: list[MaintenanceCase] = []
        self.capa: list[CapaAction] = []
        self.knowledge: list[dict[str, Any]] = []
        self._baseline: Baseline | None = None
        self._arch: ArchaeologyReport | None = None

    def baseline(self, *, runtime_version: str | None = None) -> Baseline:
        if runtime_version is None:
            from kai.runtime.models import RUNTIME_VERSION
            runtime_version = RUNTIME_VERSION
        self._baseline = build_baseline(self.root, runtime_version=runtime_version)
        return self._baseline

    def inspect(self) -> ArchaeologyReport:
        self._arch = self.archaeology.scan(self.root)
        # Red-team-specific scan for the architectural bypass discovered in v0.6.0.
        runtime_path = self.root / "src" / "kai" / "runtime" / "runtime.py"
        if runtime_path.exists():
            text = runtime_path.read_text(encoding="utf-8", errors="ignore")
            vulnerable_invocation = "run_authorized(execution=execution, contract=contract, handler=handler" in text
            protected_binding = "resolved_handler = self.registry.handler(binding.implementation_id)" in text and "handler is not resolved_handler" in text
            if "binding = self.resolver.resolve" in text and vulnerable_invocation and not protected_binding:
                self._create_finding(
                    finding_id="KAI-RC-0001", title="Resolved capability implementation can be bypassed by caller handler",
                    component="KaiRuntime.execute", severity="CRITICAL", failure_class=FailureClass.ARCHITECTURE,
                    symptom="caller-supplied handler is passed to kernel after capability resolution",
                    trigger="invoke execute() with a handler different from registry handler", affected_states=["ADMITTED", "RUNNING"],
                    affected_contracts=["capability invocation boundary"], dependencies=["CapabilityRegistry", "CapabilityResolver"],
                )
        store_path = self.root / "src" / "kai" / "runtime" / "store.py"
        if store_path.exists():
            import ast
            tree = ast.parse(store_path.read_text(encoding="utf-8", errors="ignore"), filename=str(store_path))
            for node in tree.body:
                if isinstance(node, ast.ClassDef) and node.name == "RuntimeStore":
                    for method in node.body:
                        if isinstance(method, ast.FunctionDef) and method.name in {"get_execution", "events", "get", "get_idempotency", "get_effect_by_idempotency"}:
                            body_text = ast.get_source_segment(store_path.read_text(encoding="utf-8", errors="ignore"), method) or ""
                            if "self._conn.execute" in body_text and "with self._lock" not in body_text:
                                self._create_finding(
                                    finding_id="KAI-RC-0002", title="Shared RuntimeStore read path is not lock-protected",
                                    component=f"RuntimeStore.{method.name}", severity="HIGH", failure_class=FailureClass.CODE,
                                    symptom="shared sqlite connection accessed concurrently without read lock",
                                    trigger="concurrent kernel submissions call read APIs", affected_states=["CREATED", "RUNNING"],
                                    affected_contracts=["authoritative state store"], dependencies=["sqlite3", "ThreadPoolExecutor"],
                                )
        return self._arch

    def _create_finding(self, *, finding_id: str, title: str, component: str, severity: str, failure_class: FailureClass,
                        symptom: str, trigger: str, affected_states=None, affected_contracts=None, dependencies=None) -> Finding:
        existing = next((f for f in self.findings if f.finding_id == finding_id), None)
        if existing:
            return existing
        ts = _now()
        f = Finding(finding_id=finding_id, title=title, component=component,
                    version="0.6.1", severity=severity, failure_class=failure_class,
                    first_observed=ts, last_observed=ts, symptom=symptom, trigger=trigger,
                    affected_states=list(affected_states or []), affected_contracts=list(affected_contracts or []), dependencies=list(dependencies or []))
        self.findings.append(f)
        return f

    def import_historical_finding(self, *, finding_id: str, title: str, component: str, severity: str, failure_class: FailureClass, symptom: str, trigger: str, evidence_refs: list[str], root_cause_identified: bool = True) -> MaintenanceCase:
        if self._baseline is None:
            raise MaintenancePolicyError("baseline_required_before_case_creation")
        ts = _now()
        finding = Finding(finding_id=finding_id, title=title, component=component, version="0.6.1", severity=severity, failure_class=failure_class, first_observed=ts, last_observed=ts, symptom=symptom, trigger=trigger, evidence_refs=list(evidence_refs), root_cause_status=RootCauseStatus.IDENTIFIED if root_cause_identified else RootCauseStatus.UNRESOLVED)
        self.findings.append(finding)
        case = MaintenanceCase(case_id=finding_id.replace("KAI-", "CASE-"), system="Kai Protocol Global Worldwide Execution Runtime", component=component, version="0.6.1", commit=self._baseline.source_revision, contract_version="runtime/0.6", schema_version="0.6.0", environment=self._baseline.provenance.get("environment", {}).get("platform", "unknown"), severity=severity, failure_class=failure_class, first_observed=ts, last_observed=ts, findings=[finding_id], evidence_refs=list(evidence_refs), root_cause_status=finding.root_cause_status, repair_status=RepairStatus.NONE, qualification_status=QualificationStatus.PENDING)
        self.cases.append(case)
        return case

    def create_cases(self) -> list[MaintenanceCase]:
        if self._baseline is None:
            raise MaintenancePolicyError("baseline_required_before_case_creation")
        for f in self.findings:
            case_id = f.finding_id.replace("KAI-", "CASE-")
            if any(c.case_id == case_id for c in self.cases):
                continue
            c = MaintenanceCase(
                case_id=case_id, system="Kai Protocol Global Worldwide Execution Runtime", component=f.component,
                version=f.version, commit=self._baseline.source_revision, contract_version="runtime/0.6", schema_version="0.6.0",
                environment=self._baseline.provenance.get("environment", {}).get("platform", "unknown"), severity=f.severity,
                failure_class=f.failure_class, first_observed=f.first_observed, last_observed=f.last_observed,
                findings=[f.finding_id], affected_states=f.affected_states, affected_contracts=f.affected_contracts,
                dependencies=f.dependencies, blast_radius={"scope": "execution invocation", "potential": "capability substitution"},
                root_cause_status=RootCauseStatus.UNRESOLVED, repair_status=RepairStatus.NONE,
                qualification_status=QualificationStatus.PENDING,
            )
            self.cases.append(c)
        return self.cases

    def reconstruct_root_cause(self, case_id: str, *, evidence_refs: list[str]) -> dict[str, Any]:
        case = self._case(case_id)
        finding = self._finding(case.findings[0])
        if finding.finding_id == "KAI-RC-0001":
            reconstruction = {
                "SYMPTOM": finding.symptom,
                "TRIGGER": finding.trigger,
                "FAILURE_EVENT": "caller handler reaches kernel invocation boundary",
                "FIRST_INVALID_STATE": "RESOLVED_CAPABILITY != INVOKED_IMPLEMENTATION",
                "PROPAGATION": ["resolver accepted qualified implementation", "caller handler substituted", "kernel executed substituted handler"],
                "CONTRIBUTING_FACTORS": ["API retained a handler parameter after introducing registry resolution"],
                "ROOT_CAUSE": "execution API did not bind kernel invocation to the resolved registry implementation",
                "DETECTION_FAILURE": "conformance checked resolver reachability but not implementation identity binding",
                "CONTAINMENT_FAILURE": "none; control existed only as an advisory resolution",
                "RECOVERY_FAILURE": "not applicable to static substitution defect",
                "status": RootCauseStatus.IDENTIFIED.value,
                "evidence_refs": list(evidence_refs),
            }
            finding.root_cause_status = RootCauseStatus.IDENTIFIED
            case.root_cause_status = RootCauseStatus.IDENTIFIED
            case.evidence_refs.extend(evidence_refs)
            return reconstruction
        if finding.finding_id == "KAI-RC-0002":
            reconstruction = {
                "SYMPTOM": finding.symptom,
                "TRIGGER": finding.trigger,
                "FAILURE_EVENT": "concurrent read access to shared sqlite connection",
                "FIRST_INVALID_STATE": "THREAD-SAFE ACCESS CONTRACT VIOLATED",
                "PROPAGATION": ["unsynchronized _conn.execute", "sqlite interface misuse under concurrent access", "kernel submission failure"],
                "CONTRIBUTING_FACTORS": ["check_same_thread=False allowed sharing but did not provide synchronization"],
                "ROOT_CAUSE": "read access paths bypassed the store's existing RLock despite a shared sqlite connection",
                "DETECTION_FAILURE": "single-thread functional tests did not exercise concurrent read contention",
                "CONTAINMENT_FAILURE": "none; failure remained local to concurrent submissions",
                "RECOVERY_FAILURE": "no application recovery needed after read-lock repair",
                "status": RootCauseStatus.IDENTIFIED.value,
                "evidence_refs": list(evidence_refs),
            }
            finding.root_cause_status = RootCauseStatus.IDENTIFIED
            case.root_cause_status = RootCauseStatus.IDENTIFIED
            case.evidence_refs.extend(evidence_refs)
            return reconstruction
        return {"status": RootCauseStatus.UNRESOLVED.value, "evidence_refs": evidence_refs}

    def propose_capa(self, case_id: str) -> list[CapaAction]:
        case = self._case(case_id)
        if case.root_cause_status is not RootCauseStatus.IDENTIFIED:
            raise MaintenancePolicyError("no_root_cause_no_capa_closure")
        if case.findings and case.findings[0] == "KAI-RC-0001":
            actions = [
                CapaAction("CAPA-0001", "CORRECTIVE", "Bind Runtime invocation to the resolved registry implementation; reject caller substitution.", "runtime-owner", promoted_control="CONTRACT+CAPABILITY invocation invariant"),
                CapaAction("CAPA-0002", "PREVENTIVE", "Add adversarial regression test proving resolved implementation identity cannot be bypassed.", "qualifier", promoted_control="SECURITY/CONFORMANCE test"),
                CapaAction("CAPA-0003", "PREVENTIVE", "Make conformance inspect actual invocation binding rather than hard-code no-shadow-runtime status.", "architecture-review", promoted_control="ARCHITECTURE fitness evidence"),
            ]
            self.capa.extend(actions)
        if case.findings and case.findings[0] == "KAI-RC-0002":
            actions = [
                CapaAction("CAPA-0004", "CORRECTIVE", "Protect every RuntimeStore read path using the same store RLock as writes.", "runtime-storage-owner", promoted_control="THREAD-SAFE STORE INVARIANT"),
                CapaAction("CAPA-0005", "PREVENTIVE", "Add concurrent kernel submission probe to the permanent regression suite.", "qualifier", promoted_control="CONCURRENCY regression test"),
            ]
            self.capa.extend(actions)
        return self.capa

    def alternatives(self) -> Any:
        return analyze_alternatives([
            Alternative("A", "Reject any caller handler that is not the resolved implementation", {"correctness": 1.0, "reliability": 0.9, "latency": 0.9, "throughput": 0.9, "recovery": 0.9, "security": 1.0, "complexity": 0.1, "maintainability": 0.9, "compatibility": 0.8, "cost": 0.1, "blast_radius": 0.2}),
            Alternative("B", "Ignore caller handler and always fetch implementation from registry", {"correctness": 1.0, "reliability": 0.9, "latency": 0.95, "throughput": 0.95, "recovery": 0.9, "security": 1.0, "complexity": 0.05, "maintainability": 0.85, "compatibility": 0.7, "cost": 0.05, "blast_radius": 0.25}),
            Alternative("C", "Introduce a second invocation adapter layer", {"correctness": 1.0, "reliability": 0.9, "latency": 0.7, "throughput": 0.7, "recovery": 0.9, "security": 1.0, "complexity": 0.8, "maintainability": 0.6, "compatibility": 0.7, "cost": 0.8, "blast_radius": 0.6}),
        ])

    def repair_record(self, case_id: str, *, evidence_refs: list[str]) -> None:
        case = self._case(case_id)
        if case.root_cause_status is not RootCauseStatus.IDENTIFIED:
            raise MaintenancePolicyError("cannot_mark_root_cause_repaired_before_identification")
        case.repair_status = RepairStatus.ROOT_CAUSE_REMEDIATION
        case.evidence_refs.extend(evidence_refs)
        finding = self._finding(case.findings[0])
        finding.repair_status = RepairStatus.ROOT_CAUSE_REMEDIATION
        finding.evidence_refs.extend(evidence_refs)
        lesson = "resolved capability identity is authoritative at invocation" if finding.finding_id == "KAI-RC-0001" else "shared RuntimeStore access remains serialized by the store lock"
        self.knowledge.append({"failure_signature": case_id, "lesson": lesson, "promote": "invariant"})

    def reject_patch(self, description: str) -> None:
        if any(token in description.lower() for token in ("suppress", "mask", "timeout inflation", "retry inflation", "bypass", "disable feature", "expected result")):
            raise MaintenancePolicyError("symptom_patch_rejected_by_no_patching_rule")

    def emergency_containment(self, case_id: str, *, why: str, scope: str, risk: str, operator: str, start_time: str, expiry: str, rollback: str) -> ContainmentRecord:
        case = self._case(case_id)
        record = ContainmentRecord(case_id, why, scope, risk, operator, start_time, expiry, rollback, case_id)
        case.temporary_containment = {"why": why, "scope": scope, "risk": risk, "operator": operator, "start_time": start_time, "expiry": expiry, "rollback": rollback, "follow_up_case": case_id}
        case.repair_status = RepairStatus.TEMPORARY_CONTAINMENT
        return record

    def set_blast_radius(self, case_id: str, **dimensions: list[str]) -> dict[str, list[str]]:
        case = self._case(case_id)
        impact = build_blast_radius(**dimensions)
        case.blast_radius = impact
        return impact

    def slos_and_progressive_policy(self, *, slo_name: str, sli: str, target: float, success_rate: float, burn_rate: float, max_burn_rate: float, stage: str, error_rate: float, max_error_rate: float):
        slo = evaluate_slo(__import__("kai.maintenance", fromlist=["SLOSpec"]).SLOSpec(slo_name, sli, target, 3600, max_burn_rate), success_rate=success_rate, observed_burn_rate=burn_rate)
        rollout = progressive_step(stage, error_rate=error_rate, max_error_rate=max_error_rate)
        return slo, rollout

    def coverage(self):
        return coverage_matrix()

    def qualify(self, mode: MaintenanceMode = MaintenanceMode.FULL_RED_TEAM, *, include_regression_suite: bool = True) -> MaintenanceReport:
        if self._baseline is None:
            raise MaintenancePolicyError("baseline_required")
        self.inspect() if self._arch is None else None
        gates: list[GateResult] = []
        test_results = []
        gates.append(run_static_gate(self.root))
        if include_regression_suite:
            gates.append(run_test_suite(self.root))
        else:
            gates.append(GateResult("REGRESSION", GateStatus.PASS, "delegated_to_outer_test_suite", evidence_refs=("regression:outer-pytest",), limitations=("full suite not recursively invoked from a maintenance unit test",)))
        forward_gate, _ = run_forward_probe(); gates.append(forward_gate)
        gates.append(run_reverse_probe(self.root))
        gates.append(run_adversarial_probe())
        gates.append(run_differential_probe())
        perf_gate, _ = run_performance_probe(iterations=self.performance_iterations); gates.append(perf_gate)
        gates.append(run_recovery_probe())
        gates.append(run_security_probe(self.root))
        gates.append(run_provenance_probe(self.root))
        gates.append(run_integration_compatibility_probe(self.root))
        gates.append(run_reproducibility_probe())
        oracle_gate, change_gate = run_change_and_oracle_gates(); gates.extend([oracle_gate, change_gate])
        gates.append(run_stability_probe(iterations=self.stability_iterations))
        gates.append(run_concurrency_probe())
        gates.append(run_resource_leak_probe())
        gates.append(run_maintainability_probe(self.root))
        gates.extend(run_operationally_blocked_gates())
        gates.append(GateResult("INDEPENDENT_QUALIFICATION", GateStatus.BLOCKED, "no independent operator/qualifier identity is connected", evidence_refs=("qualification:independent",), limitations=("high-risk change requires an independent verifier not available in this environment",)))
        # Formal test-result mirrors for auditability.
        for g in gates:
            test_results.append(TestResult(test_id=f"gate:{g.gate_id}", category=g.gate_id, status=g.status, expected="PASS_OR_NA", actual=g.status.value, metrics=g.metrics, evidence_refs=g.evidence_refs, limitations=g.limitations))
        critical_unresolved = any(f.severity == "CRITICAL" and f.root_cause_status is not RootCauseStatus.IDENTIFIED for f in self.findings)
        critical_security = any(g.gate_id == "SECURITY" and g.status is GateStatus.FAIL for g in gates)
        provenance_break = any(g.gate_id == "PROVENANCE" and g.status is GateStatus.FAIL for g in gates)
        unaccepted_regression = any(g.gate_id == "REGRESSION" and g.status is GateStatus.FAIL for g in gates)
        if critical_unresolved or critical_security or provenance_break or unaccepted_regression:
            qualification = QualificationStatus.REJECTED
        elif any(g.status is GateStatus.FAIL for g in gates):
            qualification = QualificationStatus.REJECTED
        elif any(g.status is GateStatus.BLOCKED for g in gates):
            qualification = QualificationStatus.CONDITIONALLY_QUALIFIED
        else:
            qualification = QualificationStatus.QUALIFIED
        observation_complete = not any(g.gate_id in {"CANARY_PROGRESSIVE_DEPLOYMENT", "SLO_ERROR_BUDGET", "REGIONAL_FAILOVER", "NODE_LOSS_CHAOS"} and g.status is GateStatus.BLOCKED for g in gates)
        evidence_complete = all(bool(g.evidence_refs) for g in gates)
        cases = tuple(self.cases)
        return MaintenanceReport(
            protocol_version=PROTOCOL_VERSION, system="Kai Protocol Global Worldwide Execution Runtime", mode=mode,
            baseline=self._baseline, findings=tuple(self.findings), cases=cases, gates=tuple(gates), test_results=tuple(test_results),
            capa_actions=tuple(self.capa), knowledge_updates=tuple(self.knowledge), qualification=qualification,
            evidence_bundle_complete=evidence_complete, observation_window_complete=observation_complete,
            limitations=("Live multi-node production canary, global failover, external SLSA attestation, and independent security audit are not connected to this environment.",),
            coverage=tuple(c.__dict__ for c in coverage_matrix()),
        )

    def stage_accepted(self, report: MaintenanceReport) -> bool:
        by_id = {g.gate_id: g for g in report.gates}
        required = ["STATIC", "REGRESSION", "FORWARD", "REVERSE", "ADVERSARIAL", "DIFFERENTIAL", "PERFORMANCE", "RECOVERY", "SECURITY", "PROVENANCE", "INTEGRATION_COMPATIBILITY", "REPRODUCIBILITY", "TEST_ORACLE", "CHANGE_GOVERNANCE", "STABILITY_OBSERVATION", "CONCURRENCY", "RESOURCE_LEAK", "MAINTAINABILITY"]
        base_ok = all(by_id.get(k) is not None and by_id[k].status in {GateStatus.PASS, GateStatus.NA} for k in required)
        critical_unresolved = any(f.severity == "CRITICAL" and f.root_cause_status is not RootCauseStatus.IDENTIFIED for f in report.findings)
        critical_security = by_id.get("SECURITY") is not None and by_id["SECURITY"].status is GateStatus.FAIL
        provenance_break = by_id.get("PROVENANCE") is not None and by_id["PROVENANCE"].status is GateStatus.FAIL
        return bool(base_ok and not critical_unresolved and not critical_security and not provenance_break and not any(f.severity == "CRITICAL" and f.repair_status not in {RepairStatus.ROOT_CAUSE_REMEDIATION, RepairStatus.REBUILT} for f in report.findings) and report.evidence_bundle_complete and report.observation_window_complete and self.validate_requalification(report) and by_id.get("INDEPENDENT_QUALIFICATION", GateResult("x", GateStatus.BLOCKED)).status is not GateStatus.BLOCKED)

    def remediation_accepted(self, case_id: str, report: MaintenanceReport) -> bool:
        case = self._case(case_id)
        required = {g.gate_id: g.status for g in report.gates}
        full = {"STATIC", "REGRESSION", "FORWARD", "REVERSE", "ADVERSARIAL", "DIFFERENTIAL", "PERFORMANCE", "RECOVERY", "SECURITY", "PROVENANCE", "INTEGRATION_COMPATIBILITY", "REPRODUCIBILITY", "STABILITY_OBSERVATION", "CONCURRENCY", "RESOURCE_LEAK", "MAINTAINABILITY"}
        return bool(case.root_cause_status is RootCauseStatus.IDENTIFIED and case.repair_status in {RepairStatus.ROOT_CAUSE_REMEDIATION, RepairStatus.REBUILT} and all(required.get(k) in {GateStatus.PASS, GateStatus.NA} for k in full) and self.validate_requalification(report) and report.evidence_bundle_complete)

    def validate_requalification(self, report: MaintenanceReport) -> bool:
        mandatory = [
            "STATIC", "REGRESSION", "FORWARD", "REVERSE", "ADVERSARIAL", "DIFFERENTIAL", "PERFORMANCE", "RECOVERY", "SECURITY",
            "PROVENANCE", "INTEGRATION_COMPATIBILITY", "REPRODUCIBILITY", "TEST_ORACLE", "CHANGE_GOVERNANCE", "STABILITY_OBSERVATION",
        ]
        by_id = {g.gate_id: g for g in report.gates}
        return all(by_id.get(g) is not None and by_id[g].status is GateStatus.PASS for g in mandatory)

    def close_case(self, case_id: str, report: MaintenanceReport) -> bool:
        case = self._case(case_id)
        if case.root_cause_status is not RootCauseStatus.IDENTIFIED:
            return False
        if case.repair_status not in {RepairStatus.ROOT_CAUSE_REMEDIATION, RepairStatus.REBUILT}:
            return False
        if not self.validate_requalification(report):
            return False
        by_id = {g.gate_id: g.status for g in report.gates}
        if case.severity in {"CRITICAL", "HIGH"} and by_id.get("INDEPENDENT_QUALIFICATION") is not GateStatus.PASS:
            return False
        if not case.evidence_refs:
            return False
        case.qualification_status = QualificationStatus.QUALIFIED
        case.repair_status = RepairStatus.REBUILT
        return True

    def write_report(self, report: MaintenanceReport, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = report.to_dict()
        data["case_closure"] = {c.case_id: c.closeable() for c in report.cases}
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        return path

    def _case(self, case_id: str) -> MaintenanceCase:
        for case in self.cases:
            if case.case_id == case_id:
                return case
        raise KeyError(case_id)

    def _finding(self, finding_id: str) -> Finding:
        for finding in self.findings:
            if finding.finding_id == finding_id:
                return finding
        raise KeyError(finding_id)
