from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class Normative(str, Enum):
    MUST = "MUST"
    MUST_NOT = "MUST_NOT"
    SHOULD = "SHOULD"
    MAY = "MAY"
    NA = "N/A"


class Applicability(str, Enum):
    APPLICABLE = "APPLICABLE"
    NA = "N/A"


class GateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    BLOCKED = "BLOCKED"
    UNRESOLVED = "UNRESOLVED"
    NA = "N/A"


class MaintenanceMode(str, Enum):
    TARGETED = "TARGETED"
    SYSTEMATIC = "SYSTEMATIC"
    FULL_RED_TEAM = "FULL_RED_TEAM"
    CERTIFICATION = "CERTIFICATION"
    CONTINUOUS = "CONTINUOUS"


class RootCauseStatus(str, Enum):
    IDENTIFIED = "IDENTIFIED"
    UNRESOLVED = "UNRESOLVED"


class RepairStatus(str, Enum):
    NONE = "NONE"
    TEMPORARY_CONTAINMENT = "TEMPORARY_CONTAINMENT"
    ROOT_CAUSE_REMEDIATION = "ROOT_CAUSE_REMEDIATION"
    REBUILT = "REBUILT"


class QualificationStatus(str, Enum):
    PENDING = "PENDING"
    QUALIFIED = "QUALIFIED"
    CONDITIONALLY_QUALIFIED = "CONDITIONALLY_QUALIFIED"
    REJECTED = "REJECTED"
    INCONCLUSIVE = "INCONCLUSIVE"


class FailureClass(str, Enum):
    REQUIREMENT = "REQUIREMENT"
    ARCHITECTURE = "ARCHITECTURE"
    DESIGN = "DESIGN"
    CONTRACT = "CONTRACT"
    STATE_MODEL = "STATE_MODEL"
    ALGORITHM = "ALGORITHM"
    CODE = "CODE"
    DATA = "DATA"
    INTEGRATION = "INTEGRATION"
    DEPENDENCY = "DEPENDENCY"
    CONFIGURATION = "CONFIGURATION"
    SECURITY = "SECURITY"
    OBSERVABILITY = "OBSERVABILITY"
    PERFORMANCE = "PERFORMANCE"
    RECOVERY = "RECOVERY"
    OPERATIONS = "OPERATIONS"
    TEST = "TEST"
    BUILD_SUPPLY_CHAIN = "BUILD_SUPPLY_CHAIN"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class EvidenceRef:
    ref_id: str
    kind: str
    digest: str | None = None
    source: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GateResult:
    gate_id: str
    status: GateStatus
    reason: str = ""
    evidence_refs: tuple[str, ...] = ()
    metrics: dict[str, Any] = field(default_factory=dict)
    limitations: tuple[str, ...] = ()
    applicable: bool = True

    @property
    def accepted(self) -> bool:
        return self.status in {GateStatus.PASS, GateStatus.NA}


@dataclass(frozen=True)
class Baseline:
    baseline_id: str
    source_revision: str
    build_digest: str
    dependency_lock_digest: str
    configuration_digest: str
    schema_versions: tuple[str, ...]
    contract_versions: tuple[str, ...]
    runtime_version: str
    test_suite_version: str
    fixtures_digest: str
    environment_signature: str
    performance_baseline: dict[str, Any]
    security_baseline: dict[str, Any]
    provenance: dict[str, Any]


@dataclass
class Finding:
    finding_id: str
    title: str
    component: str
    version: str
    severity: str
    failure_class: FailureClass
    first_observed: str
    last_observed: str
    reproduction: dict[str, Any] = field(default_factory=dict)
    evidence_refs: list[str] = field(default_factory=list)
    trace_refs: list[str] = field(default_factory=list)
    artifact_refs: list[str] = field(default_factory=list)
    affected_states: list[str] = field(default_factory=list)
    affected_contracts: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    blast_radius: dict[str, Any] = field(default_factory=dict)
    root_cause_status: RootCauseStatus = RootCauseStatus.UNRESOLVED
    repair_status: RepairStatus = RepairStatus.NONE
    qualification_status: QualificationStatus = QualificationStatus.PENDING
    symptom: str = ""
    trigger: str = ""


@dataclass
class MaintenanceCase:
    case_id: str
    system: str
    component: str
    version: str
    commit: str
    contract_version: str
    schema_version: str
    environment: str
    severity: str
    failure_class: FailureClass
    first_observed: str
    last_observed: str
    findings: list[str] = field(default_factory=list)
    reproduction: dict[str, Any] = field(default_factory=dict)
    evidence_refs: list[str] = field(default_factory=list)
    trace_refs: list[str] = field(default_factory=list)
    artifact_refs: list[str] = field(default_factory=list)
    affected_states: list[str] = field(default_factory=list)
    affected_contracts: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    blast_radius: dict[str, Any] = field(default_factory=dict)
    root_cause_status: RootCauseStatus = RootCauseStatus.UNRESOLVED
    repair_status: RepairStatus = RepairStatus.NONE
    qualification_status: QualificationStatus = QualificationStatus.PENDING
    temporary_containment: dict[str, Any] | None = None

    def closeable(self) -> bool:
        return bool(self.root_cause_status is RootCauseStatus.IDENTIFIED and
                    self.repair_status in {RepairStatus.ROOT_CAUSE_REMEDIATION, RepairStatus.REBUILT} and
                    self.qualification_status is QualificationStatus.QUALIFIED and self.evidence_refs)


@dataclass(frozen=True)
class FailureReconstruction:
    case_id: str
    symptom: str
    trigger: str
    failure_event: str
    first_invalid_state: str
    propagation: tuple[str, ...]
    contributing_factors: tuple[str, ...]
    root_cause: str | None
    detection_failure: str | None
    containment_failure: str | None
    recovery_failure: str | None
    status: RootCauseStatus
    evidence_refs: tuple[str, ...]


@dataclass(frozen=True)
class CapaAction:
    action_id: str
    kind: str  # CORRECTIVE / PREVENTIVE
    description: str
    owner: str
    due: str | None = None
    promoted_control: str | None = None


@dataclass(frozen=True)
class Alternative:
    alternative_id: str
    description: str
    attributes: dict[str, float]
    constraints_met: bool = True


@dataclass(frozen=True)
class AlternativeAnalysis:
    alternatives: tuple[Alternative, ...]
    nondominated: tuple[str, ...]
    dominated: tuple[str, ...]
    rationale: dict[str, Any]


@dataclass(frozen=True)
class ChangeRecord:
    change_id: str
    risk_class: str
    blast_radius: dict[str, Any]
    affected_contracts: tuple[str, ...]
    affected_states: tuple[str, ...]
    test_scope: tuple[str, ...]
    rollback_plan: str
    rollforward_plan: str
    owner: str
    review_status: str
    approval_status: str
    post_change_observation: str


@dataclass(frozen=True)
class SLOSpec:
    name: str
    sli: str
    target: float
    window_seconds: int
    max_burn_rate: float


@dataclass(frozen=True)
class ObservationWindow:
    window_id: str
    start: str
    end: str
    metrics: dict[str, Any]
    status: GateStatus
    evidence_refs: tuple[str, ...] = ()


@dataclass(frozen=True)
class DebtItem:
    debt_id: str
    kind: str
    description: str
    owner: str
    risk: str
    expiry: str
    remediation_path: str
    status: str = "OPEN"


@dataclass(frozen=True)
class Waiver:
    waiver_id: str
    scope: str
    reason: str
    risk: str
    owner: str
    expires_at: str
    accepted_by: str
    does_not_convert_failure_to_pass: bool = True


@dataclass(frozen=True)
class TestOracle:
    oracle_id: str
    expected_result: Any
    invariants: tuple[str, ...]
    thresholds: dict[str, float]
    frozen_digest: str


@dataclass(frozen=True)
class TestResult:
    test_id: str
    category: str
    status: GateStatus
    expected: Any = None
    actual: Any = None
    metrics: dict[str, Any] = field(default_factory=dict)
    evidence_refs: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()


@dataclass(frozen=True)
class MaintenanceReport:
    protocol_version: str
    system: str
    mode: MaintenanceMode
    baseline: Baseline
    findings: tuple[Finding, ...]
    cases: tuple[MaintenanceCase, ...]
    gates: tuple[GateResult, ...]
    test_results: tuple[TestResult, ...]
    capa_actions: tuple[CapaAction, ...]
    knowledge_updates: tuple[dict[str, Any], ...]
    qualification: QualificationStatus
    evidence_bundle_complete: bool
    observation_window_complete: bool
    limitations: tuple[str, ...]
    coverage: tuple[dict[str, Any], ...] = ()

    def to_dict(self) -> dict[str, Any]:
        def conv(v):
            if hasattr(v, "value"):
                return v.value
            if isinstance(v, tuple):
                return [conv(x) for x in v]
            if isinstance(v, list):
                return [conv(x) for x in v]
            if isinstance(v, dict):
                return {k: conv(x) for k, x in v.items()}
            if hasattr(v, "__dataclass_fields__"):
                return {k: conv(x) for k, x in asdict(v).items()}
            return v
        return conv(self)
