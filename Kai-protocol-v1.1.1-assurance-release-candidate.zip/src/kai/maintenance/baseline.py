from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

from .models import Baseline


def _digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _digest_tree(root: Path, patterns: tuple[str, ...]) -> str:
    entries: list[tuple[str, str]] = []
    for pattern in patterns:
        for p in sorted(root.glob(pattern)):
            if p.is_file():
                try:
                    rel = p.relative_to(root).as_posix()
                    entries.append((rel, _digest_bytes(p.read_bytes())))
                except OSError:
                    continue
    payload = json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()
    return _digest_bytes(payload)


def _git_revision(root: Path) -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return "GIT_UNAVAILABLE"


def _git_clean(root: Path) -> bool:
    try:
        return not bool(subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True, stderr=subprocess.DEVNULL).strip())
    except Exception:
        return False


def build_baseline(root: str | Path, *, runtime_version: str, test_suite_version: str = "maintenance-1") -> Baseline:
    root = Path(root).resolve()
    source_digest = _digest_tree(root, ("src/**/*.py", "tests/**/*.py", "scripts/**/*.py"))
    dependency_digest = _digest_tree(root, ("pyproject.toml", "requirements*.txt", "uv.lock", "poetry.lock"))
    config_digest = _digest_tree(root, ("*.toml", "*.ini", "*.cfg", "*.yaml", "*.yml", "*.json"))
    fixtures_digest = _digest_tree(root, ("tests/fixtures/**", "examples/*.json"))
    build_files = sorted((root / "dist").glob("*.whl")) if (root / "dist").exists() else []
    build_digest = _digest_tree(root, ("dist/*.whl", "dist/*.tar.gz")) if build_files else "NO_BUILD_ARTIFACT"
    env = {
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "cwd": str(root),
    }
    environment_signature = _digest_bytes(json.dumps(env, sort_keys=True).encode())
    baseline_id = "baseline-" + _digest_bytes((source_digest + dependency_digest + config_digest + environment_signature).encode())[:20]
    provenance = {
        "git_revision": _git_revision(root),
        "git_clean": _git_clean(root),
        "source_digest": source_digest,
        "environment": env,
    }
    schema_versions = _discover_versions(root, "RUNTIME_SCHEMA_VERSION")
    contract_versions = _discover_versions(root, "version")
    return Baseline(
        baseline_id=baseline_id,
        source_revision=provenance["git_revision"],
        build_digest=build_digest,
        dependency_lock_digest=dependency_digest,
        configuration_digest=config_digest,
        schema_versions=tuple(sorted(set(schema_versions))),
        contract_versions=tuple(sorted(set(contract_versions))),
        runtime_version=runtime_version,
        test_suite_version=test_suite_version,
        fixtures_digest=fixtures_digest,
        environment_signature=environment_signature,
        performance_baseline={"status": "captured", "artifact_digest": build_digest},
        security_baseline={"status": "captured", "static_only": True},
        provenance=provenance,
    )


def _discover_versions(root: Path, token: str) -> list[str]:
    values: list[str] = []
    for path in root.glob("src/**/*.py"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in (f'{token} = "', f"{token} = '"):
            if marker in text:
                tail = text.split(marker, 1)[1]
                values.append(tail.split(marker[-1], 1)[0])
    return values
