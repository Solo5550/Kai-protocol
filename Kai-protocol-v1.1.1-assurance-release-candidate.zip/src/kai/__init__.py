"""Kai Protocol — Proof Layer for Machines.

Invariant: Machines that cannot prove must not act.
"""

__version__ = "1.1.1"
__protocol__ = "kai/0.2"
__language__ = "kai-lang/0.8"

from kai.product import (
    KaiProductRuntime,
    KaiGate,
    GateDecision,
    GateDenial,
    ProofReceipt,
    issue_receipt,
    verify_receipt,
    generate_issuer_keypair,
    INVARIANT,
)
