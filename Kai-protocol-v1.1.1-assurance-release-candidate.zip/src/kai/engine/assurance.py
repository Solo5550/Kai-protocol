from __future__ import annotations

from dataclasses import dataclass
from kai.protocol.models import GateResult, GateStatus, Unit
from kai.protocol.provenance import is_complete
from kai.protocol.verdict import REQUIRED_GATES


@dataclass
class AssuranceSummary:
    gates: list[GateResult]
    critical_failures: list[str]

    @property
    def all_pass(self) -> bool:
        return all(g.status == GateStatus.PASS for g in self.gates)


class AssuranceEngine:
    def evaluate(
        self,
        unit: Unit,
        *,
        decomposition_ok: bool,
        horizontal_ok: bool,
        vertical_ok: bool,
        reconstruction_ok: bool,
        criterion_ok: bool,
        master_governance_ok: GateStatus | bool | None = None,
    ) -> AssuranceSummary:
        gates = [
            GateResult("decomposition_integrity", GateStatus.PASS if decomposition_ok else GateStatus.FAIL),
            GateResult("horizontal_consistency", GateStatus.PASS if horizontal_ok else GateStatus.FAIL),
            GateResult("vertical_consistency", GateStatus.PASS if vertical_ok else GateStatus.FAIL),
            GateResult("test_validity", self._test_validity(unit)),
            GateResult("reconstruction_preservation", GateStatus.PASS if reconstruction_ok else GateStatus.FAIL),
            GateResult("provenance_completeness", self._provenance(unit)),
            GateResult("criterion_satisfaction", GateStatus.PASS if criterion_ok else GateStatus.FAIL),
        ]
        if master_governance_ok is not None:
            status = master_governance_ok if isinstance(master_governance_ok, GateStatus) else (GateStatus.PASS if master_governance_ok else GateStatus.FAIL)
            gates.append(GateResult("master_governance", status))
        failures = [g.gate for g in gates if g.status != GateStatus.PASS]
        unit.gates = gates
        return AssuranceSummary(gates=gates, critical_failures=failures)

    @staticmethod
    def _test_validity(unit: Unit) -> GateStatus:
        if not unit.tests:
            child_statuses = unit.metadata.get("supporting_test_statuses", [])
            if not child_statuses:
                return GateStatus.UNRESOLVED
            if "FAIL" in child_statuses:
                return GateStatus.FAIL
            if any(s in {"UNRESOLVED", "BLOCKED"} for s in child_statuses):
                return GateStatus.UNRESOLVED
            return GateStatus.PASS if all(s == "PASS" for s in child_statuses) else GateStatus.UNRESOLVED
        by_id = {r.test_id: r for r in unit.results}
        if any(t.test_id not in by_id for t in unit.tests):
            return GateStatus.UNRESOLVED
        if any(by_id[t.test_id].status == GateStatus.FAIL for t in unit.tests):
            return GateStatus.FAIL
        if any(by_id[t.test_id].status in {GateStatus.UNRESOLVED, GateStatus.BLOCKED} for t in unit.tests):
            return GateStatus.UNRESOLVED
        return GateStatus.PASS

    @staticmethod
    def _provenance(unit: Unit) -> GateStatus:
        if not unit.provenance:
            return GateStatus.FAIL
        for e in unit.evidence:
            if not is_complete(e.provenance):
                return GateStatus.FAIL
        return GateStatus.PASS
