from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from kai.master import MasterGovernor, MasterReview
from kai.language import KaiChannel
from kai.protocol.messages import MessageFactory
from kai.protocol.models import Direction, GateStatus, MessageType, Provenance, TestResult, TestSpec, Unit, Verdict
from kai.protocol.state_machine import StateMachine, UnitState
from kai.protocol.validator import ProtocolValidator
from kai.protocol.verdict import VerdictEngine
from kai.pyramid.decomposition import ForwardPyramid
from kai.pyramid.graph import KnowledgeGraph
from kai.pyramid.reconstruction import ReconstructionEngine
from kai.pyramid.synthesis import Synthesizer
from .assurance import AssuranceEngine
from .adaptive import DepthDecision
from .census import CensusEngine


@dataclass
class KaiSession:
    source_id: str
    source_claim: str
    graph: KnowledgeGraph = field(default_factory=KnowledgeGraph)
    messages: list[Any] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.factory = MessageFactory(actor="kai-session")
        self.state_machine = StateMachine()
        self.validator = ProtocolValidator()
        self.verdict_engine = VerdictEngine()
        self.assurance = AssuranceEngine()
        self.master = MasterGovernor()
        self.master_preflight: MasterReview | None = None
        self.master_postflight: MasterReview | None = None
        self.channel = KaiChannel()
        self.language_errors: list[str] = []

    @classmethod
    def from_parts(cls, source_id: str, source_claim: str, parts: list[dict[str, Any]]) -> "KaiSession":
        forward = ForwardPyramid.from_parts(source_id, source_claim, parts)
        session = cls(source_id, source_claim, forward.graph)
        session.messages.append(session.factory.create(
            unit_id=source_id, round=0, layer=0, direction=Direction.DOWN,
            type=MessageType.CONTRACT, payload={"scope": "knowledge-analysis", "claim": source_claim}
        ))
        for uid in sorted(session.graph.units):
            unit = session.graph.get(uid)
            session.messages.append(session.factory.create(
                unit_id=uid, round=1, layer=unit.layer, direction=unit.direction,
                type=MessageType.CLAIM, payload={"claim": unit.claim or ""},
                provenance={"source_id": uid, "actor": "forward-pyramid"}
            ))
        session._refresh_language_audit()
        return session

    def _refresh_language_audit(self) -> None:
        """Rebuild the language projection from the authoritative message log."""
        self.channel = KaiChannel()
        self.language_errors = []
        try:
            self.channel.ingest_many(self.messages)
        except Exception as exc:
            self.language_errors.append(str(exc))

    def _append_message(self, message: Any) -> None:
        """Append once and update the language projection incrementally.

        The message log is authoritative; the channel is a derived index.  We
        therefore avoid replaying the complete log on every mutation.  If an
        unexpected incremental-ingest error occurs, rebuild from the log so the
        derived projection cannot silently drift.
        """
        self.messages.append(message)
        try:
            self.channel.ingest(message)
        except Exception as exc:
            self._refresh_language_audit()
            if not self.language_errors:
                self.language_errors.append(str(exc))


    def attach_evidence(self, unit_id: str, statement: str, source_id: str, strength: float = 1.0, independent: bool = True) -> None:
        from kai.protocol.models import Evidence
        unit = self.graph.get(unit_id)
        p = Provenance(source_id=source_id, source_type="evidence", extracted_by="kai-session", transformation="attached")
        unit.evidence.append(Evidence(evidence_id=f"{unit_id}.e{len(unit.evidence)+1}", statement=statement, strength=strength, independent=independent, provenance=p))
        if unit.state == UnitState.CLAIMED:
            unit.state = UnitState.EVIDENCED
        self._append_message(self.factory.create(
            unit_id=unit_id, round=2, layer=unit.layer, direction=Direction.HORIZONTAL,
            type=MessageType.EVIDENCE, payload={"statement": statement, "strength": strength, "independent": independent},
            provenance={"source_id": source_id, "actor": "kai-session"}
        ))

    def attach_test(self, unit_id: str, kind: str, inputs: dict[str, Any], expected: Any, reproducible: bool = True) -> str:
        unit = self.graph.get(unit_id)
        test_id = f"{unit_id}.t{len(unit.tests)+1}"
        spec = TestSpec(test_id, kind, preconditions=[], inputs=inputs, expected=expected, executor="kai-session", executor_version="0.2", reproducible=reproducible)
        unit.tests.append(spec)
        if unit.state == UnitState.EVIDENCED:
            unit.state = UnitState.TESTING
        self._append_message(self.factory.create(
            unit_id=unit_id, round=3, layer=unit.layer, direction=Direction.HORIZONTAL,
            type=MessageType.TEST, payload=spec.to_dict()
        ))
        return test_id

    def record_result(self, unit_id: str, test_id: str, status: GateStatus, actual: Any, notes: str = "") -> None:
        unit = self.graph.get(unit_id)
        unit.results.append(TestResult(test_id, status, actual, notes))
        if unit.state == UnitState.TESTING:
            unit.state = UnitState.SUPPORTED if status == GateStatus.PASS else UnitState.CONTESTED if status == GateStatus.FAIL else UnitState.UNRESOLVED
        elif unit.state == UnitState.RETESTING:
            unit.state = UnitState.VERIFIED if status == GateStatus.PASS else UnitState.REJECTED if status == GateStatus.FAIL else UnitState.UNRESOLVED
        self._append_message(self.factory.create(
            unit_id=unit_id, round=4, layer=unit.layer, direction=Direction.HORIZONTAL,
            type=MessageType.RESULT, payload={"test_id": test_id, "status": status.value, "actual": actual, "notes": notes}
        ))

    def synthesize(self) -> tuple[Unit, Unit]:
        forward_errors = ForwardPyramid(self.graph).validate_decomposition()
        if forward_errors:
            raise ValueError("decomposition invalid: " + "; ".join(forward_errors))
        synthesis_result = Synthesizer(self.graph).synthesize()
        synthesis = Synthesizer(self.graph).add_synthesis_unit(synthesis_result)
        reconstruction_report = ReconstructionEngine(self.graph).reconstruct("synthesis.base", self.source_id)
        synthesis.metadata["supporting_test_statuses"] = []
        for uid in synthesis.parent_ids:
            child = self.graph.get(uid)
            if not child.tests:
                synthesis.metadata["supporting_test_statuses"].append("UNRESOLVED")
                continue
            results = {r.test_id: r.status.value for r in child.results}
            synthesis.metadata["supporting_test_statuses"].extend(results.get(t.test_id, "UNRESOLVED") for t in child.tests)
        reconstruction = ReconstructionEngine(self.graph).emit_reconstruction_unit(reconstruction_report)
        self.graph.add(reconstruction)
        self._append_message(self.factory.create(
            unit_id=synthesis.unit_id, round=5, layer=synthesis.layer, direction=Direction.UP,
            type=MessageType.RECONSTRUCTION, payload=reconstruction.metadata
        ))
        return synthesis, reconstruction

    def finalize(
        self,
        synthesis: Unit,
        reconstruction: Unit,
        *,
        criterion_ok: bool,
        criterion_name: str,
        depth_decision: DepthDecision,
        preflight: MasterReview | None = None,
        decision_options: list[dict[str, Any]] | None = None,
    ) -> Verdict:
        self.master_preflight = preflight or self.master_preflight
        census_engine = CensusEngine()
        units = list(self.graph.units.values())
        census = {
            "failures": [x.to_dict() for x in census_engine.failure_census(units)],
            "bottlenecks": [x.to_dict() for x in census_engine.bottleneck_census(units)],
            "gaps": [x.to_dict() for x in census_engine.gap_census(units)],
            "drift": [x.to_dict() for x in census_engine.drift_census(units)],
        }
        # First evaluate the native Kai assurance gates without MASTER. MASTER is
        # the governing layer that adjudicates this base assurance result.
        base_summary = self.assurance.evaluate(
            synthesis,
            decomposition_ok=not ForwardPyramid(self.graph).validate_decomposition(),
            horizontal_ok=not any(obj.severity in {"critical", "blocking"} for u in self.graph.units.values() if u.unit_id != synthesis.unit_id for obj in u.objections),
            vertical_ok=all(self.graph.get(p).claim is not None for p in synthesis.parent_ids),
            reconstruction_ok=bool(reconstruction.metadata.get("preserved")),
            criterion_ok=criterion_ok,
            master_governance_ok=None,
        )
        self.master_postflight = self.master.postflight(
            graph=self.graph,
            source_id=self.source_id,
            source_claim=self.source_claim,
            criterion_name=criterion_name,
            synthesis=synthesis,
            reconstruction=reconstruction,
            assurance=base_summary,
            depth=depth_decision,
            criterion_ok=criterion_ok,
            export_payload=self.export(include_master=False),
            census=census,
            decision_options=decision_options,
        )
        master_gate = self.master.master_gate(self.master_postflight)
        final_summary = self.assurance.evaluate(
            synthesis,
            decomposition_ok=not ForwardPyramid(self.graph).validate_decomposition(),
            horizontal_ok=not any(obj.severity in {"critical", "blocking"} for u in self.graph.units.values() if u.unit_id != synthesis.unit_id for obj in u.objections),
            vertical_ok=all(self.graph.get(p).claim is not None for p in synthesis.parent_ids),
            reconstruction_ok=bool(reconstruction.metadata.get("preserved")),
            criterion_ok=criterion_ok,
            master_governance_ok=master_gate,
        )
        synthesis.metadata["master_governance_required"] = True
        synthesis.metadata["criterion_name"] = criterion_name
        synthesis.metadata["master_preflight_score"] = self.master_preflight.score if self.master_preflight else None
        synthesis.metadata["master_postflight_score"] = self.master_postflight.score
        synthesis.metadata["master_promotable"] = self.master_postflight.promotable
        synthesis.state = UnitState.VERIFIED if all(g.status == GateStatus.PASS for g in final_summary.gates) else synthesis.state
        synthesis.verdict = self.verdict_engine.evaluate(synthesis)
        self._append_message(self.factory.create(
            unit_id=synthesis.unit_id, round=6, layer=synthesis.layer, direction=Direction.UP,
            type=MessageType.VERDICT,
            payload={
                "verdict": synthesis.verdict.value,
                "criterion": criterion_name,
                "gates": [g.to_dict() for g in final_summary.gates],
                "master": self.master_postflight.to_dict(),
            },
        ))
        return synthesis.verdict

    def export(self, include_master: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "protocol": "kai",
            "version": "0.2",
            "source": {"id": self.source_id, "claim": self.source_claim},
            "units": [self.graph.units[k].to_dict() for k in sorted(self.graph.units)],
            "messages": [m.to_dict() for m in self.messages],
            "language": {"version": "0.1", "valid": not self.language_errors, "errors": list(self.language_errors), "closed_units": self.channel.closed_units},
        }
        if include_master:
            payload["master"] = {
                "preflight": self.master_preflight.to_dict() if self.master_preflight else None,
                "postflight": self.master_postflight.to_dict() if self.master_postflight else None,
            }
        return payload
