from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from kai.protocol.models import Unit


@dataclass(frozen=True)
class CensusItem:
    id: str
    category: str
    severity: str
    statement: str
    unit_id: str | None = None
    evidence_ids: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class CensusEngine:
    def failure_census(self, units: list[Unit]) -> list[CensusItem]:
        out=[]
        for u in units:
            if u.state in {"CONTESTED", "REJECTED"}:
                out.append(CensusItem(f"failure:{u.unit_id}", "failure", "critical", f"unit state={u.state}", u.unit_id))
            for r in u.results:
                if r.status.value == "FAIL":
                    out.append(CensusItem(f"result:{u.unit_id}:{r.test_id}", "failure", "high", r.notes or "test failed", u.unit_id, (r.test_id,)))
        return out

    def bottleneck_census(self, units: list[Unit]) -> list[CensusItem]:
        out=[]
        for u in units:
            if u.state in {"BLOCKED", "UNRESOLVED"}:
                out.append(CensusItem(f"bottleneck:{u.unit_id}", "bottleneck", "high", f"unit state={u.state}", u.unit_id))
        return out

    def gap_census(self, units: list[Unit]) -> list[CensusItem]:
        out=[]
        for u in units:
            if not u.evidence:
                out.append(CensusItem(f"gap:evidence:{u.unit_id}", "gap", "high", "no evidence", u.unit_id))
            if not u.tests:
                out.append(CensusItem(f"gap:test:{u.unit_id}", "gap", "medium", "no tests", u.unit_id))
            if not u.provenance:
                out.append(CensusItem(f"gap:provenance:{u.unit_id}", "gap", "critical", "no provenance", u.unit_id))
        return out

    def drift_census(self, units: list[Unit]) -> list[CensusItem]:
        out=[]
        for u in units:
            if u.metadata.get("drift"):
                out.append(CensusItem(f"drift:{u.unit_id}", "drift", "medium", str(u.metadata["drift"]), u.unit_id))
        return out
