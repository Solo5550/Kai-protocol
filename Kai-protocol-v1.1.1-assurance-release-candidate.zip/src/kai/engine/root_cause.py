from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class CauseStatus(str, Enum):
    SUPPORTED = "SUPPORTED"
    HYPOTHESIZED = "HYPOTHESIZED"
    CONDITIONAL = "CONDITIONAL"
    REJECTED = "REJECTED"
    UNKNOWN = "UNKNOWN"


@dataclass
class CauseNode:
    id: str
    statement: str
    status: CauseStatus = CauseStatus.HYPOTHESIZED
    parents: list[str] = field(default_factory=list)


@dataclass
class RootCauseGraph:
    nodes: dict[str, CauseNode] = field(default_factory=dict)

    def add(self, node: CauseNode) -> None:
        if node.id in self.nodes:
            raise ValueError(f"duplicate cause id: {node.id}")
        self.nodes[node.id] = node

    def roots(self) -> list[CauseNode]:
        return sorted((n for n in self.nodes.values() if not n.parents), key=lambda n: n.id)

    def supported_roots(self) -> list[CauseNode]:
        return [n for n in self.roots() if n.status == CauseStatus.SUPPORTED]
