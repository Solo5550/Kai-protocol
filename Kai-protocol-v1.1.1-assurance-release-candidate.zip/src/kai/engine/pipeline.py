from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from kai.master import MasterGovernor, MasterReview
from kai.protocol.models import GateStatus, Verdict
from .adaptive import AdaptiveDepthController, DepthSignals
from .census import CensusEngine
from .session import KaiSession


@dataclass
class PipelineReport:
    verdict: Verdict
    depth: int
    depth_rationale: list[str]
    failures: list[dict[str, Any]]
    bottlenecks: list[dict[str, Any]]
    gaps: list[dict[str, Any]]
    drift: list[dict[str, Any]]
    reconstruction_fidelity: float
    exported_artifacts: dict[str, Any]
    master_preflight: MasterReview | None = None
    master_postflight: MasterReview | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["verdict"] = self.verdict.value
        d["master_preflight"] = self.master_preflight.to_dict() if self.master_preflight else None
        d["master_postflight"] = self.master_postflight.to_dict() if self.master_postflight else None
        return d


class AssurancePipeline:
    """End-to-end runner with MASTER as the governing pre/post promotion layer."""

    def __init__(self) -> None:
        self.depth_controller = AdaptiveDepthController()
        self.census = CensusEngine()
        self.master = MasterGovernor()

    def run(
        self,
        *,
        source_id: str,
        source_claim: str,
        parts: list[dict[str, Any]],
        signals: DepthSignals | None = None,
        criterion_ok: bool | None = None,
        criterion_name: str | None = None,
        decision_options: list[dict[str, Any]] | None = None,
        expert_methods: list[str] | None = None,
    ) -> PipelineReport:
        active_signals = signals or DepthSignals()
        decision = self.depth_controller.choose(active_signals)
        preflight = self.master.preflight(
            source_id=source_id,
            source_claim=source_claim,
            parts=parts,
            criterion_name=criterion_name,
            criterion_ok=criterion_ok,
            signals=active_signals,
            expert_methods=expert_methods,
            alternatives=decision_options,
        )
        if not preflight.promotable:
            exported = {
                "protocol": "kai",
                "version": "0.2",
                "source": {"id": source_id, "claim": source_claim},
                "units": [],
                "messages": [],
                "master": {"preflight": preflight.to_dict(), "postflight": None},
            }
            return PipelineReport(
                verdict=self.master.master_gate(preflight) == GateStatus.BLOCKED and Verdict.BLOCKED or Verdict.UNRESOLVED,
                depth=decision.depth,
                depth_rationale=decision.rationale,
                failures=[], bottlenecks=preflight.blockers, gaps=[], drift=[],
                reconstruction_fidelity=0.0,
                exported_artifacts=exported,
                master_preflight=preflight,
                master_postflight=None,
            )

        session = KaiSession.from_parts(source_id, source_claim, parts)
        session.master_preflight = preflight
        for part in parts:
            uid = part["unit_id"]
            evidence = part.get("evidence")
            if evidence:
                session.attach_evidence(uid, evidence["statement"], evidence["source_id"], evidence.get("strength", 1.0), evidence.get("independent", True))
            test = part.get("test")
            if test:
                test_id = session.attach_test(uid, test["kind"], test.get("inputs", {}), test.get("expected"), test.get("reproducible", True))
                if "result" in test:
                    result = test["result"]
                    session.record_result(uid, test_id, GateStatus(result["status"]), result.get("actual"), result.get("notes", ""))
        synthesis, reconstruction = session.synthesize()
        verdict = session.finalize(
            synthesis,
            reconstruction,
            criterion_ok=bool(criterion_ok),
            criterion_name=criterion_name or "undeclared",
            depth_decision=decision,
            preflight=preflight,
            decision_options=decision_options,
        )
        units = list(session.graph.units.values())
        return PipelineReport(
            verdict=verdict,
            depth=decision.depth,
            depth_rationale=decision.rationale,
            failures=[x.to_dict() for x in self.census.failure_census(units)],
            bottlenecks=[x.to_dict() for x in self.census.bottleneck_census(units)],
            gaps=[x.to_dict() for x in self.census.gap_census(units)],
            drift=[x.to_dict() for x in self.census.drift_census(units)],
            reconstruction_fidelity=float(reconstruction.metadata.get("fidelity", 0.0)),
            exported_artifacts=session.export(),
            master_preflight=preflight,
            master_postflight=session.master_postflight,
        )
