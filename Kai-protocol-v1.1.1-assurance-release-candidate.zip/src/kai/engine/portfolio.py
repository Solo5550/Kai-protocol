from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SolutionOption:
    id: str
    description: str
    expected_risk_reduction: float
    implementation_cost: float
    reversibility: float
    dependencies: tuple[str, ...] = ()


@dataclass(frozen=True)
class ADR:
    decision: str
    context: str
    options: tuple[SolutionOption, ...]
    selected_id: str
    rejected_reasons: dict[str, str]


class SolutionMatrix:
    def __init__(self, options: list[SolutionOption]) -> None:
        self.options = options

    def ordered_by_risk_reduction(self) -> list[SolutionOption]:
        return sorted(self.options, key=lambda o: (-o.expected_risk_reduction, o.implementation_cost, o.id))

    def to_dict(self) -> dict[str, Any]:
        return {"options": [o.__dict__ for o in self.options]}
