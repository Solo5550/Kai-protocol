from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DepthSignals:
    uncertainty: float = 0.0
    impact: float = 0.0
    novelty: float = 0.0
    coupling: float = 0.0
    irreversibility: float = 0.0
    attack_surface: float = 0.0
    observability_gap: float = 0.0
    evidence_conflict: float = 0.0
    temporal_instability: float = 0.0


@dataclass(frozen=True)
class DepthDecision:
    depth: int
    rationale: list[str]


class AdaptiveDepthController:
    """Deterministic depth selection from risk/uncertainty signals."""

    weights = {
        "uncertainty": 1.3, "impact": 1.4, "novelty": 0.8, "coupling": 1.0,
        "irreversibility": 1.4, "attack_surface": 1.1, "observability_gap": 1.0,
        "evidence_conflict": 1.5, "temporal_instability": 0.7,
    }

    def choose(self, signals: DepthSignals, minimum: int = 1, maximum: int = 12) -> DepthDecision:
        values = signals.__dict__
        score = sum(self.weights[k] * max(0.0, min(1.0, float(v))) for k, v in values.items())
        normalized = score / sum(self.weights.values())
        depth = minimum + round((maximum - minimum) * normalized)
        rationale = [k for k, v in values.items() if float(v) >= 0.7]
        if not rationale:
            rationale = ["baseline-risk"]
        return DepthDecision(depth=max(minimum, min(maximum, depth)), rationale=rationale)
