from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterator

from kai.language.compact import MAGIC, decode_compact, encode_compact, encode_compact_many
from kai.protocol.models import Message

JOURNAL_MAGIC = b"KAI-JOURNAL/1\0"
MAX_FRAME = 16 * 1024 * 1024
CHECKPOINT_MAGIC = "KAI-JOURNAL-CP/1"


class JournalError(ValueError):
    pass


class MessageJournal:
    """Append-only KAI-BIN/1 journal with bounded RAM and crash-aware checkpoints.

    The journal keeps message objects out of RAM. A sidecar checkpoint records a
    durable prefix (count + byte offset) so clean reopen only scans the tail after
    the checkpoint. If the checkpoint is missing, stale, corrupt, or ahead of the
    journal, the implementation safely falls back to a full scan.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        sync: bool = False,
        checkpoint_interval_messages: int = 8192,
    ) -> None:
        if checkpoint_interval_messages < 1:
            raise ValueError("checkpoint_interval_messages must be >= 1")
        self.path = Path(path)
        self.sync = sync
        self.checkpoint_interval_messages = checkpoint_interval_messages
        self._count = 0
        self._bytes = 0
        self._since_checkpoint = 0
        self._fh = None
        self._checkpoint_path = self.path.with_suffix(self.path.suffix + ".cp")
        self._open()

    def _open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        exists = self.path.exists() and self.path.stat().st_size > 0
        self._fh = self.path.open("ab+")
        if not exists:
            self._fh.write(JOURNAL_MAGIC)
            self._fh.flush()
            if self.sync:
                os.fsync(self._fh.fileno())
            self._count = 0
            self._bytes = 0
        else:
            self._validate_header()
            checkpoint = self._load_checkpoint()
            if checkpoint is None:
                self._count, self._bytes = self._scan_counts()
            else:
                cp_offset, cp_count, cp_bytes = checkpoint
                file_size = self.path.stat().st_size
                if cp_offset < len(JOURNAL_MAGIC) or cp_offset > file_size:
                    self._count, self._bytes = self._scan_counts()
                else:
                    tail_count, tail_bytes = self._scan_counts(start_offset=cp_offset)
                    self._count = cp_count + tail_count
                    self._bytes = cp_bytes + tail_bytes
                    self._since_checkpoint = tail_count
        self._fh.seek(0, os.SEEK_END)

    def _validate_header(self) -> None:
        self._fh.seek(0)
        header = self._fh.read(len(JOURNAL_MAGIC))
        if header != JOURNAL_MAGIC:
            raise JournalError("invalid KAI journal header")

    def _scan_counts(
        self,
        *,
        start_offset: int = len(JOURNAL_MAGIC),
    ) -> tuple[int, int]:
        self._fh.seek(start_offset)
        count = 0
        total = 0
        while True:
            header = self._fh.read(len(MAGIC) + 4)
            if not header:
                break
            if len(header) != len(MAGIC) + 4 or not header.startswith(MAGIC):
                raise JournalError("corrupt KAI-BIN frame header")
            size = int.from_bytes(header[len(MAGIC) :], "big")
            if size > MAX_FRAME:
                raise JournalError("journal frame exceeds limit")
            payload = self._fh.read(size)
            if len(payload) != size:
                raise JournalError("truncated KAI-BIN frame")
            count += 1
            total += len(header) + size
        return count, total

    def _load_checkpoint(self) -> tuple[int, int, int] | None:
        if not self._checkpoint_path.exists():
            return None
        try:
            raw = json.loads(self._checkpoint_path.read_text(encoding="utf-8"))
            if raw.get("magic") != CHECKPOINT_MAGIC:
                return None
            if raw.get("journal_name") != self.path.name:
                return None
            offset = int(raw["offset"])
            count = int(raw["count"])
            data_bytes = int(raw["bytes"])
            if offset < len(JOURNAL_MAGIC) or count < 0 or data_bytes < 0:
                return None
            if data_bytes + len(JOURNAL_MAGIC) != offset:
                return None
            return offset, count, data_bytes
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            return None

    def _write_checkpoint(self) -> None:
        self._fh.flush()
        if self.sync:
            os.fsync(self._fh.fileno())
        offset = self._fh.seek(0, os.SEEK_END)
        data = {
            "magic": CHECKPOINT_MAGIC,
            "journal_name": self.path.name,
            "offset": offset,
            "count": self._count,
            "bytes": self._bytes,
        }
        tmp = self._checkpoint_path.with_suffix(self._checkpoint_path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, sort_keys=True, separators=(",", ":")), encoding="utf-8")
        with tmp.open("rb") as fh:
            os.fsync(fh.fileno())
        os.replace(tmp, self._checkpoint_path)
        if self.sync:
            dir_fd = os.open(self._checkpoint_path.parent, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        self._since_checkpoint = 0

    def append(self, message: Message) -> int:
        frame = encode_compact(message)
        self._fh.seek(0, os.SEEK_END)
        offset = self._fh.tell()
        self._fh.write(frame)
        if self.sync:
            self._fh.flush()
            os.fsync(self._fh.fileno())
        self._count += 1
        self._bytes += len(frame)
        self._since_checkpoint += 1
        if self._since_checkpoint >= self.checkpoint_interval_messages:
            self._write_checkpoint()
        return offset

    def extend(self, messages, *, batch_size: int = 4096) -> int:
        if batch_size < 1:
            raise ValueError("batch_size must be >= 1")
        total = 0
        batch = []
        for message in messages:
            batch.append(message)
            if len(batch) >= batch_size:
                total += self._write_batch(batch)
                batch.clear()
        if batch:
            total += self._write_batch(batch)
        return total

    def _write_batch(self, messages: list[Message]) -> int:
        frame = encode_compact_many(messages)
        self._fh.seek(0, os.SEEK_END)
        self._fh.write(frame)
        if self.sync:
            self._fh.flush()
            os.fsync(self._fh.fileno())
        self._count += len(messages)
        self._bytes += len(frame)
        self._since_checkpoint += len(messages)
        if self._since_checkpoint >= self.checkpoint_interval_messages:
            self._write_checkpoint()
        return len(messages)

    def iter_messages(self, *, verify_integrity: bool = True) -> Iterator[dict]:
        self._fh.flush()
        with self.path.open("rb") as fh:
            header = fh.read(len(JOURNAL_MAGIC))
            if header != JOURNAL_MAGIC:
                raise JournalError("invalid KAI journal header")
            while True:
                frame_header = fh.read(len(MAGIC) + 4)
                if not frame_header:
                    return
                if len(frame_header) != len(MAGIC) + 4 or not frame_header.startswith(MAGIC):
                    raise JournalError("corrupt KAI-BIN frame header")
                size = int.from_bytes(frame_header[len(MAGIC) :], "big")
                if size > MAX_FRAME:
                    raise JournalError("journal frame exceeds limit")
                payload = fh.read(size)
                if len(payload) != size:
                    raise JournalError("truncated KAI-BIN frame")
                yield decode_compact(frame_header + payload, verify_integrity=verify_integrity)

    @property
    def count(self) -> int:
        return self._count

    @property
    def bytes_written(self) -> int:
        return self._bytes

    def flush(self) -> None:
        self._fh.flush()

    def checkpoint(self) -> None:
        self._write_checkpoint()

    def close(self) -> None:
        if self._fh is not None:
            self._write_checkpoint()
            self._fh.close()
            self._fh = None

    def __enter__(self) -> "MessageJournal":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
