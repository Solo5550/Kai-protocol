"""SSDF connectors: DSSE Ed25519, runtime guard, artifact verifier."""
