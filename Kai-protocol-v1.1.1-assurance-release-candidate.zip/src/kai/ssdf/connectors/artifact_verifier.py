from __future__ import annotations
import hashlib, json, base64
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def verify_slsa_subject(path: Path, artifact_digest: str) -> dict:
    d = json.loads(path.read_text(encoding='utf-8'))
    reasons=[]
    ok=True
    if d.get('_type') != 'https://in-toto.io/Statement/v1': ok=False; reasons.append('wrong statement type')
    subjects=d.get('subject')
    if not isinstance(subjects,list) or not subjects: ok=False; reasons.append('missing subject')
    matched=False
    for s in subjects or []:
        dg=s.get('digest',{}).get('sha256') if isinstance(s,dict) else None
        if isinstance(dg,str) and dg.lower()==artifact_digest.lower(): matched=True
    if not matched: ok=False; reasons.append('artifact digest not bound to provenance subject')
    pred=d.get('predicate',{})
    bd=pred.get('buildDefinition') if isinstance(pred,dict) else None
    rd=pred.get('runDetails') if isinstance(pred,dict) else None
    if not isinstance(bd,dict): ok=False; reasons.append('missing buildDefinition')
    if not isinstance(rd,dict) or not isinstance(rd.get('builder'),dict) or not rd['builder'].get('id'): ok=False; reasons.append('missing builder identity')
    return {'valid':ok,'reasons':reasons,'artifact_digest':artifact_digest}


def verify_dsse_like_envelope(path: Path, expected_payload_type: str | None = None) -> dict:
    d=json.loads(path.read_text(encoding='utf-8'))
    payload=d.get('payload')
    ptype=d.get('payloadType')
    ok=isinstance(payload,str) and bool(ptype)
    reasons=[]
    if not ok: reasons.append('missing DSSE payload or payloadType')
    if expected_payload_type and ptype!=expected_payload_type: ok=False; reasons.append('payloadType mismatch')
    decoded=None
    if ok:
        try:
            decoded=base64.b64decode(payload).decode('utf-8')
        except Exception:
            ok=False; reasons.append('payload is not valid base64')
    return {'valid':ok,'reasons':reasons,'payloadType':ptype,'decoded_payload':decoded}
