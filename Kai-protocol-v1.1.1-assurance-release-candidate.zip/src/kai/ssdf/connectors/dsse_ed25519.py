from __future__ import annotations
import base64, json
from pathlib import Path


def verify_ed25519_dsse(path: Path, public_key_b64: str, expected_payload_type: str|None=None) -> dict:
    """Verify a DSSE-like envelope with an Ed25519 public key.

    This adapter validates signatures supplied by the caller; it does not establish
    Sigstore identity, Rekor inclusion, or a public trust-root by itself.
    """
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except Exception as e:
        return {'valid':False,'reasons':[f'cryptography unavailable: {e}']}
    d=json.loads(path.read_text(encoding='utf-8'))
    payload=d.get('payload'); ptype=d.get('payloadType'); sigs=d.get('signatures')
    reasons=[]
    if not isinstance(payload,str) or not isinstance(ptype,str) or not isinstance(sigs,list) or not sigs:
        return {'valid':False,'reasons':['invalid DSSE envelope shape']}
    if expected_payload_type and ptype!=expected_payload_type:
        reasons.append('payloadType mismatch')
    try:
        payload_bytes=base64.b64decode(payload)
        pk=Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64))
        pae=b'DSSEv1 '+ptype.encode()+b' '+str(len(payload_bytes)).encode()+b' '+payload_bytes
        # DSSE PAE uses exact byte lengths separated by spaces; use the reference formulation below.
        pae=b'DSSEv1 '+_pae_field(ptype.encode())+_pae_field(payload_bytes)
        verified=False
        for s in sigs:
            if not isinstance(s,dict): continue
            sig=s.get('sig')
            if not sig: continue
            try:
                pk.verify(base64.b64decode(sig),pae); verified=True; break
            except Exception: pass
        if not verified: reasons.append('no valid Ed25519 signature')
        return {'valid':verified and not reasons,'reasons':reasons,'payloadType':ptype}
    except Exception as e:
        return {'valid':False,'reasons':[str(e)],'payloadType':ptype}


def _pae_field(b: bytes) -> bytes:
    return str(len(b)).encode()+b' '+b
