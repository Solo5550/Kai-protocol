from __future__ import annotations
import base64
import hashlib
import json
import urllib.request
from urllib.parse import quote
from datetime import datetime, timezone
from .contracts import EvidenceEnvelope, GitProvider, ConnectorError

API_ROOT = "https://api.github.com"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _get(url: str) -> tuple[str, dict]:
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "ssdf-one-maintenance/1.3"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read()
            ctype = r.headers.get("Content-Type", "")
            text = raw.decode("utf-8", errors="replace")
            meta = {"status": r.status, "content_type": ctype, "sha256": hashlib.sha256(raw).hexdigest()}
            return text, meta
    except Exception as e:
        raise ConnectorError(f"GitHub read failed: {e}") from e


def _api_path(repo: str, path: str) -> str:
    return f"{API_ROOT}/repos/{repo}/contents/{quote(path, safe='/')}"


class GitHubReadonlyConnector:
    """Read-only GitHub connector. It cannot mutate repositories."""

    def get_file(self, repository: str, path: str, ref: str | None = None) -> EvidenceEnvelope:
        url = _api_path(repository, path)
        if ref:
            url += f"?ref={quote(ref, safe='')}"
        body, meta = _get(url)
        data = json.loads(body)
        if data.get("type") != "file":
            raise ConnectorError(f"not a file: {repository}:{path}")
        content = base64.b64decode(data.get("content", "")).decode("utf-8", errors="replace")
        return EvidenceEnvelope(
            source="github",
            captured_at=_utc_now(),
            scope=f"{repository}@{ref or data.get('git_url', 'default')}:{path}",
            payload={"repository": repository, "path": path, "ref": ref, "content": content, "sha": data.get("sha"), "html_url": data.get("html_url")},
            digest=hashlib.sha256(content.encode()).hexdigest(),
            authority="public-github-repository",
        )

    def get_revision(self, repository: str, ref: str | None = None) -> EvidenceEnvelope:
        url = f"{API_ROOT}/repos/{repository}/commits/{quote(ref, safe='')}" if ref else f"{API_ROOT}/repos/{repository}/commits"
        body, meta = _get(url)
        data = json.loads(body)
        if isinstance(data, list):
            data = data[0] if data else {}
        sha = data.get("sha")
        return EvidenceEnvelope("github", _utc_now(), f"{repository}@{ref or 'latest'}", {"sha": sha, "html_url": data.get("html_url")}, digest=meta["sha256"], authority="public-github-repository")

    def get_workflows(self, repository: str, ref: str | None = None) -> EvidenceEnvelope:
        body, meta = _get(f"{API_ROOT}/repos/{repository}/contents/.github/workflows" + (f"?ref={ref}" if ref else ""))
        data = json.loads(body)
        files = [x for x in data if isinstance(x, dict) and x.get("type") == "file"]
        return EvidenceEnvelope("github", _utc_now(), f"{repository}@{ref or 'default'}:.github/workflows", {"files": files}, digest=meta["sha256"], authority="public-github-repository")
