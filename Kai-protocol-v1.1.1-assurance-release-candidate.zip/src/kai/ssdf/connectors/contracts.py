from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol


class ConnectorError(RuntimeError):
    pass


@dataclass(frozen=True)
class AuthorizationContext:
    """Maintenance layer is denied runtime side effects by default."""
    allow_write: bool = False
    allowed_operations: tuple[str, ...] = ()

    def assert_allowed(self, operation: str) -> None:
        if not self.allow_write or operation not in self.allowed_operations:
            raise ConnectorError(f"operation denied by maintenance authorization policy: {operation}")


@dataclass
class EvidenceEnvelope:
    source: str
    captured_at: str
    scope: str
    payload: dict[str, Any]
    digest: str | None = None
    authority: str = "unknown"
    freshness_seconds: int | None = None


class GitProvider(Protocol):
    def get_file(self, repository: str, path: str, ref: str | None = None) -> EvidenceEnvelope: ...
    def get_revision(self, repository: str, ref: str | None = None) -> EvidenceEnvelope: ...
    def get_workflows(self, repository: str, ref: str | None = None) -> EvidenceEnvelope: ...


class CIProvider(Protocol):
    def get_run(self, identifier: str) -> EvidenceEnvelope: ...


class ArtifactProvider(Protocol):
    def get_artifact(self, identifier: str) -> EvidenceEnvelope: ...


class VulnerabilityProvider(Protocol):
    def get_finding(self, identifier: str) -> EvidenceEnvelope: ...


class ObservabilityProvider(Protocol):
    def query(self, expression: str, start: str, end: str) -> EvidenceEnvelope: ...


class DeploymentProvider(Protocol):
    """Contract only; no default runtime path is implemented by maintenance."""
    def plan_canary(self, artifact: str, policy: dict[str, Any]) -> dict[str, Any]: ...
    def execute(self, plan: dict[str, Any], authorization: AuthorizationContext) -> dict[str, Any]: ...
