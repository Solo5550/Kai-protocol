from __future__ import annotations
from .contracts import AuthorizationContext, ConnectorError

class MaintenanceRuntimeGuard:
    """Explicit deny-by-default guard: the maintenance layer cannot bypass the execution runtime."""
    READ_ONLY_OPERATIONS = {"inspect", "observe", "plan", "verify", "requalify"}

    def authorize(self, operation: str, ctx: AuthorizationContext | None = None) -> None:
        ctx = ctx or AuthorizationContext()
        if operation not in self.READ_ONLY_OPERATIONS:
            ctx.assert_allowed(operation)
