"""SSDF-One absorbed into Kai — secure development controls + DSSE + runtime guard.

Source: SSDF-One v1.3.0 (NIST SP 800-218 aligned control evaluation plane).
Integrated as kai.ssdf without alternate execution path — evaluate/verify only.
"""

from pathlib import Path

SSDF_ROOT = Path(__file__).resolve().parent
SSDF_VERSION = "1.3.0"

def catalog_dir() -> Path:
    return SSDF_ROOT / "catalog"

def profiles_dir() -> Path:
    return SSDF_ROOT / "profiles"

def evaluate_repo(repo_path: str, profile: str = "baseline"):
    """Run SSDF-One evaluator against a repository path."""
    from . import ssdfx
    # ssdfx main entry patterns vary — expose thin wrapper
    if hasattr(ssdfx, "evaluate"):
        return ssdfx.evaluate(repo_path, profile=profile)
    if hasattr(ssdfx, "main"):
        return ssdfx.main(["evaluate", repo_path, "--profile", profile])
    return {"status": "engine_loaded", "module": "kai.ssdf.ssdfx", "profile": profile}

__all__ = ["SSDF_VERSION", "SSDF_ROOT", "catalog_dir", "profiles_dir", "evaluate_repo"]
