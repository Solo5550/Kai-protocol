from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .models import (
    Capability, Contract, Execution, ExecutionState, GateStatus, Plan, Policy,
    RUNTIME_SCHEMA_VERSION, RUNTIME_VERSION,
)


@dataclass(frozen=True)
class ContractCheck:
    status: GateStatus
    errors: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return self.status is GateStatus.PASS


class ContractEngine:
    """Contract-first validation for execution and capability boundaries."""

    def validate_execution(self, execution: Execution, contract: Contract | None) -> ContractCheck:
        if contract is None:
            return ContractCheck(GateStatus.BLOCKED, ("contract_missing",))
        errors: list[str] = []
        if not contract.id or not contract.version:
            errors.append("contract_identity_missing")
        if not execution.objective:
            errors.append("objective_missing")
        if not isinstance(execution.input_data, dict):
            errors.append("input_not_object")
        if contract.input_schema.get("required"):
            for key in contract.input_schema["required"]:
                if key not in execution.input_data:
                    errors.append(f"input_missing:{key}")
        if errors:
            return ContractCheck(GateStatus.FAIL, tuple(errors))
        return ContractCheck(GateStatus.PASS)

    def validate_capability(self, capability: Capability) -> ContractCheck:
        errors: list[str] = []
        if not capability.capability_id:
            errors.append("capability_id_missing")
        if not capability.semantic_version:
            errors.append("capability_version_missing")
        if not capability.owner:
            errors.append("capability_owner_missing")
        if capability.side_effect_class not in {"pure", "read_only", "external_write", "irreversible"}:
            errors.append("invalid_side_effect_class")
        if errors:
            return ContractCheck(GateStatus.FAIL, tuple(errors))
        return ContractCheck(GateStatus.PASS)

    def validate_policy(self, policy: Policy) -> ContractCheck:
        errors: list[str] = []
        if not policy.policy_id or not policy.semantic_version:
            errors.append("policy_identity_missing")
        if policy.denied_capabilities and set(policy.denied_capabilities) & set(policy.allowed_capabilities):
            errors.append("policy_allow_deny_conflict")
        if errors:
            return ContractCheck(GateStatus.FAIL, tuple(errors))
        return ContractCheck(GateStatus.PASS)

    def validate_plan(self, plan: Plan) -> ContractCheck:
        errors: list[str] = []
        ids = [n.node_id for n in plan.nodes]
        if len(ids) != len(set(ids)):
            errors.append("duplicate_plan_node")
        node_ids = set(ids)
        for dep in plan.dependencies:
            if dep.get("from") not in node_ids or dep.get("to") not in node_ids:
                errors.append("plan_dependency_unknown_node")
        if not plan.objective:
            errors.append("plan_objective_missing")
        if errors:
            return ContractCheck(GateStatus.FAIL, tuple(errors))
        return ContractCheck(GateStatus.PASS)

    def compatibility(self, *, capability: Capability, contract: Contract, runtime_version=RUNTIME_VERSION, schema_version=RUNTIME_SCHEMA_VERSION) -> str:
        if runtime_version not in capability.runtime_versions:
            return "INCOMPATIBLE"
        if schema_version not in capability.schema_versions:
            return "INCOMPATIBLE"
        if contract.version not in capability.metadata_supported_contract_versions if hasattr(capability, "metadata_supported_contract_versions") else False:
            return "ADAPTER_REQUIRED"
        return "COMPATIBLE"


# Canonical transition relation. Only TransitionEngine can mutate Execution.state.
TRANSITIONS: dict[ExecutionState, dict[str, ExecutionState]] = {
    ExecutionState.CREATED: {"CONTRACT_VALIDATED": ExecutionState.READY},
    ExecutionState.CONTRACT_VALIDATING: {"CONTRACT_VALIDATED": ExecutionState.READY, "CONTRACT_REJECTED": ExecutionState.REJECTED},
    ExecutionState.READY: {"EVIDENCE_REQUESTED": ExecutionState.EVIDENCE_PENDING, "PLAN_STARTED": ExecutionState.PLANNING, "ADMIT": ExecutionState.ADMITTED, "BLOCK": ExecutionState.BLOCKED},
    ExecutionState.EVIDENCE_PENDING: {"EVIDENCE_ACCEPTED": ExecutionState.EVIDENCE_ACCEPTED, "EVIDENCE_REJECTED": ExecutionState.REJECTED, "EVIDENCE_INCONCLUSIVE": ExecutionState.INCONCLUSIVE},
    ExecutionState.EVIDENCE_ACCEPTED: {"PLAN_STARTED": ExecutionState.PLANNING},
    ExecutionState.PLANNING: {"PLAN_ACCEPTED": ExecutionState.PLAN_ACCEPTED, "PLAN_REJECTED": ExecutionState.REJECTED},
    ExecutionState.PLAN_ACCEPTED: {"ADMIT": ExecutionState.ADMITTED, "BLOCK": ExecutionState.BLOCKED},
    ExecutionState.ADMITTED: {"EXECUTION_STARTED": ExecutionState.RUNNING, "CANCEL_REQUESTED": ExecutionState.CANCEL_REQUESTED, "BLOCK": ExecutionState.BLOCKED},
    ExecutionState.RUNNING: {
        "EXECUTION_COMPLETED": ExecutionState.OBSERVING,
        "EXECUTION_FAILED": ExecutionState.FAILED,
        "EXECUTION_TIMED_OUT": ExecutionState.TIMED_OUT,
        "CANCEL_REQUESTED": ExecutionState.CANCEL_REQUESTED,
        "PARTIAL_COMPLETION": ExecutionState.PARTIALLY_COMPLETED,
    },
    ExecutionState.OBSERVING: {"OBSERVATION_READY": ExecutionState.VERIFICATION_PENDING, "OBSERVATION_INCONCLUSIVE": ExecutionState.INCONCLUSIVE},
    ExecutionState.VERIFICATION_PENDING: {
        "VERIFIED": ExecutionState.VERIFIED,
        "NOT_VERIFIED": ExecutionState.UNPROVEN,
        "VERIFICATION_INCONCLUSIVE": ExecutionState.INCONCLUSIVE,
    },
    ExecutionState.VERIFIED: {"PROVE": ExecutionState.PROVEN, "ANALYZE": ExecutionState.ANALYSIS_PENDING, "PERSIST": ExecutionState.PERSISTING},
    ExecutionState.ANALYSIS_PENDING: {"ANALYZED": ExecutionState.ANALYZED, "ANALYSIS_INCONCLUSIVE": ExecutionState.INCONCLUSIVE},
    ExecutionState.ANALYZED: {"PROVE": ExecutionState.PROVEN, "PERSIST": ExecutionState.PERSISTING},
    ExecutionState.PROVEN: {"PERSIST": ExecutionState.PERSISTING},
    ExecutionState.UNPROVEN: {"PERSIST": ExecutionState.PERSISTING},
    ExecutionState.PERSISTING: {"PERSISTED": ExecutionState.PERSISTED, "PERSISTENCE_FAILED": ExecutionState.RECOVERY_PENDING},
    ExecutionState.PERSISTED: {"LEARN": ExecutionState.LEARNING_PENDING, "CALIBRATE": ExecutionState.CALIBRATING, "CLOSE": ExecutionState.CLOSED},
    ExecutionState.LEARNING_PENDING: {"LEARNED": ExecutionState.LEARNED, "LEARNING_SKIPPED": ExecutionState.CALIBRATING},
    ExecutionState.LEARNED: {"CALIBRATE": ExecutionState.CALIBRATING, "CLOSE": ExecutionState.CLOSED},
    ExecutionState.CALIBRATING: {"CALIBRATED": ExecutionState.CLOSED, "CALIBRATION_SKIPPED": ExecutionState.CLOSED},
    ExecutionState.FAILED: {"RECOVER": ExecutionState.RECOVERY_PENDING, "CLOSE": ExecutionState.CLOSED},
    ExecutionState.TIMED_OUT: {"RECOVER": ExecutionState.RECOVERY_PENDING, "RETRY": ExecutionState.ADMITTED, "CLOSE": ExecutionState.CLOSED},
    ExecutionState.PARTIALLY_COMPLETED: {"RECOVER": ExecutionState.RECOVERY_PENDING, "CANCEL_REQUESTED": ExecutionState.CANCEL_REQUESTED, "CLOSE": ExecutionState.CLOSED},
    ExecutionState.RECOVERY_PENDING: {"RECOVERY_STARTED": ExecutionState.RECOVERING, "BLOCK": ExecutionState.BLOCKED},
    ExecutionState.RECOVERING: {"RECOVERED": ExecutionState.RECOVERED, "RECOVERY_FAILED": ExecutionState.FAILED},
    ExecutionState.RECOVERED: {"RETRY": ExecutionState.ADMITTED, "PERSIST": ExecutionState.PERSISTING, "CLOSE": ExecutionState.CLOSED},
    ExecutionState.CANCEL_REQUESTED: {"CANCEL_PROPAGATE": ExecutionState.PROPAGATING, "CANCELLATION_BLOCKED": ExecutionState.RECOVERY_PENDING},
    ExecutionState.PROPAGATING: {"CANCEL_ACK": ExecutionState.ACKNOWLEDGED, "CANCELLATION_BLOCKED": ExecutionState.RECOVERY_PENDING},
    ExecutionState.ACKNOWLEDGED: {"STOP": ExecutionState.STOPPING},
    ExecutionState.STOPPING: {"CANCELLED": ExecutionState.CANCELLED, "CANCELLATION_BLOCKED": ExecutionState.RECOVERY_PENDING},
    ExecutionState.DEGRADED: {"REQUALIFY": ExecutionState.READY, "QUARANTINE": ExecutionState.QUARANTINED},
    ExecutionState.QUARANTINED: {"REQUALIFY": ExecutionState.READY, "RETIRE": ExecutionState.RETIRED if hasattr(ExecutionState, 'RETIRED') else ExecutionState.CLOSED},
}


class TransitionRejected(RuntimeError):
    pass


class TransitionEngine:
    def can_transition(self, current: ExecutionState, event: str, required_state_version: int | None = None, actual_state_version: int | None = None) -> bool:
        if required_state_version is not None and actual_state_version != required_state_version:
            return False
        return event in TRANSITIONS.get(current, {})

    def transition(self, execution: Execution, event: str, *, required_state_version: int | None = None, event_id: str | None = None) -> ExecutionState:
        if required_state_version is not None and execution.state_version != required_state_version:
            raise TransitionRejected(f"stale_transition expected={required_state_version} actual={execution.state_version}")
        next_state = TRANSITIONS.get(execution.state, {}).get(event)
        if next_state is None:
            raise TransitionRejected(f"illegal_transition state={execution.state.value} event={event}")
        execution.state = next_state
        execution.state_version += 1
        execution.last_event_id = event_id
        execution.touch()
        return next_state


TERMINAL_STATES = {
    ExecutionState.CLOSED,
    ExecutionState.CANCELLED,
    ExecutionState.REJECTED,
    ExecutionState.BLOCKED,
}
