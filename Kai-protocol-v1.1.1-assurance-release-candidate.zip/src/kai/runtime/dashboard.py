from __future__ import annotations

from collections import Counter

from .models import ExecutionState


class OperationalDashboard:
    def __init__(self, runtime) -> None:
        self.runtime = runtime

    def execution_health(self) -> dict[str, int]:
        rows = self.runtime.store._conn.execute("SELECT state,COUNT(*) FROM executions GROUP BY state").fetchall()
        return {row[0]: int(row[1]) for row in rows}

    def questions(self) -> dict[str, object]:
        health = self.execution_health()
        return {
            "what_is_running": health.get(ExecutionState.RUNNING.value, 0),
            "what_is_blocked": health.get(ExecutionState.BLOCKED.value, 0),
            "what_failed": health.get(ExecutionState.FAILED.value, 0),
            "what_timed_out": health.get(ExecutionState.TIMED_OUT.value, 0),
            "regions": self.runtime.scheduler.actual,
            "proof_chain_valid": self.runtime.proof_ledger.verify_chain(),
        }
