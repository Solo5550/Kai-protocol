from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from .cluster import GlobalControlPlane


@dataclass(frozen=True)
class ChaosCase:
    case_id: str
    fault: str
    target: str
    expected: str
    result: str = "UNRUN"
    evidence: dict[str, Any] = field(default_factory=dict)


class ChaosController:
    SUPPORTED = {
        "kill_node", "network_partition", "packet_loss", "packet_delay", "duplicate_delivery",
        "delayed_delivery", "storage_corruption", "clock_skew", "dependency_disappearance", "partial_completion",
    }

    def __init__(self, control: GlobalControlPlane) -> None:
        self.control = control
        self.cases: list[ChaosCase] = []

    def run(self, fault: str, *, node_id: str, case_id: str, execution_factory=None) -> ChaosCase:
        if fault not in self.SUPPORTED:
            raise ValueError(f"unsupported_fault:{fault}")
        expected = {
            "kill_node": "RECOVERY_PENDING", "network_partition": "RECOVERY_PENDING", "packet_loss": "RECOVERY_PENDING",
            "packet_delay": "SAFE_DEADLINE_OR_RETRY", "duplicate_delivery": "IDEMPOTENT_NO_DUPLICATE", "delayed_delivery": "SAFE_RETRY",
            "storage_corruption": "QUARANTINED_OR_RESTORED", "clock_skew": "BOUNDED_TIME_SEMANTICS",
            "dependency_disappearance": "RECOVERY_PENDING", "partial_completion": "PARTIALLY_COMPLETED",
        }[fault]
        evidence: dict[str, Any] = {"fault": fault, "node_id": node_id}
        result = "FAIL"
        if fault == "kill_node":
            affected = self.control.kill_node(node_id)
            evidence["affected_executions"] = affected
            result = "PASS" if self.control.registry.nodes[node_id].status.startswith("FAILED") and all(self.control.observed[e]["state"] == "RECOVERY_PENDING" for e in affected) else "FAIL"
        elif fault == "network_partition":
            self.control.transport.set_partition(node_id, True)
            try:
                try:
                    self.control.heartbeat(node_id)
                    result = "FAIL"
                except Exception as exc:
                    evidence["error"] = str(exc)
                    result = "PASS"
            finally:
                self.control.transport.set_partition(node_id, False)
        elif fault == "packet_loss":
            self.control.transport.set_drop_rate(node_id, 1.0)
            try:
                try:
                    self.control.heartbeat(node_id)
                    result = "FAIL"
                except Exception as exc:
                    evidence["error"] = str(exc)
                    result = "PASS"
            finally:
                self.control.transport.set_drop_rate(node_id, 0.0)
        elif fault in {"packet_delay", "delayed_delivery"}:
            self.control.transport.set_delay(node_id, 0.15)
            try:
                start = time.monotonic()
                try:
                    self.control.heartbeat(node_id)
                except Exception as exc:
                    evidence["error"] = str(exc)
                elapsed = time.monotonic() - start
                evidence["elapsed_seconds"] = elapsed
                result = "PASS" if elapsed >= 0.15 else "FAIL"
            finally:
                self.control.transport.set_delay(node_id, 0.0)
        elif fault == "duplicate_delivery":
            if execution_factory is None:
                raise ValueError("execution_factory_required")
            idem = f"chaos-idem-{case_id}"
            cmd = f"chaos-cmd-{case_id}"
            first = execution_factory(idempotency_key=idem, command_id=cmd)
            second = execution_factory(idempotency_key=idem, command_id=f"{cmd}-retry")
            evidence.update({"first": first, "second": second, "idempotency_key": idem})
            result = "PASS" if second.get("duplicate") is True else "FAIL"
        elif fault == "storage_corruption":
            self.control.corrupt_node_storage(node_id)
            try:
                hb = self.control.heartbeat(node_id)
            except Exception as exc:
                hb = {"error": str(exc)}
            evidence["heartbeat_after_corruption"] = hb
            result = "PASS" if self.control.registry.nodes[node_id].storage_status == "CORRUPT" else "FAIL"
        elif fault == "clock_skew":
            reply = self.control.set_clock_offset(node_id, 120.0)
            hb = self.control.heartbeat(node_id)
            evidence.update({"set": reply, "heartbeat": hb})
            result = "PASS" if float(hb.get("clock_offset_seconds", 0)) == 120.0 else "FAIL"
            self.control.set_clock_offset(node_id, 0.0)
        elif fault == "dependency_disappearance":
            self.control.set_node_dependency(node_id, "dep-x", False)
            try:
                if execution_factory is None:
                    raise ValueError("execution_factory_required")
                try:
                    response = execution_factory(dependencies=["dep-x"])
                except RuntimeError as exc:
                    response = {"error": str(exc)}
                evidence["response"] = response
                result = "PASS" if response.get("error") == "DEPENDENCY_UNAVAILABLE" else "FAIL"
            finally:
                self.control.set_node_dependency(node_id, "dep-x", True)
        elif fault == "partial_completion":
            if execution_factory is None:
                raise ValueError("execution_factory_required")
            try:
                response = execution_factory(partial=True)
            except Exception as exc:
                evidence["transport_error"] = str(exc)
                response = None
            # Node intentionally died after durable PARTIALLY_COMPLETED write.
            result = "PASS" if self.control.registry.nodes[node_id].status.startswith("FAILED") else "FAIL"
        case = ChaosCase(case_id, fault, node_id, expected, result, evidence)
        self.cases.append(case)
        return case
