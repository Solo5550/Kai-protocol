from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from typing import Any

from .models import ENVELOPE_VERSION, RuntimeEnvelope, to_primitive


def build_envelope(*, identity, message_type: str, contract_ref=None, capability_ref=None, policy_snapshot_ref=None,
                   idempotency_key: str = "", security_context_ref=None, provenance_ref=None, payload_ref=None,
                   deadline_at=None, attempt: int = 1, classification: str = "internal", status: str = "READY", payload: Any = None) -> RuntimeEnvelope:
    payload_ref = payload_ref or ("artifact://inline/" + hashlib.sha256(_canonical(payload)).hexdigest() if payload is not None else None)
    return RuntimeEnvelope(
        envelope_version=ENVELOPE_VERSION,
        message_type=message_type,
        tenant_id=identity.tenant_id,
        namespace_id=identity.namespace_id,
        run_id=identity.run_id,
        execution_id=identity.execution_id,
        parent_execution_id=identity.parent_execution_id,
        root_execution_id=identity.root_execution_id,
        trace_id=identity.trace_id,
        span_id=identity.span_id,
        causal_parent_id=identity.causal_parent_id,
        region_id=identity.region_id,
        cell_id=identity.cell_id,
        actor_id=identity.actor_id,
        contract_ref=contract_ref,
        capability_ref=capability_ref,
        policy_snapshot_ref=policy_snapshot_ref,
        deadline_at=deadline_at,
        attempt=attempt,
        idempotency_key=idempotency_key,
        security_context_ref=security_context_ref,
        provenance_ref=provenance_ref,
        payload_ref=payload_ref,
        classification=classification,
        status=status,
    )


def propagate_envelope(env: RuntimeEnvelope, **changes) -> RuntimeEnvelope:
    forbidden = {"execution_id", "run_id", "root_execution_id", "trace_id", "policy_snapshot_ref", "contract_ref", "idempotency_key"}
    if forbidden.intersection(changes):
        raise ValueError("semantic envelope identity/policy fields cannot be rewritten during propagation")
    return replace(env, **changes)


def canonical_json(value: Any) -> str:
    return _canonical(value).decode("utf-8")


def envelope_fingerprint(env: RuntimeEnvelope) -> str:
    return hashlib.sha256(_canonical(to_primitive(env))).hexdigest()


def _canonical(value: Any) -> bytes:
    return json.dumps(to_primitive(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
