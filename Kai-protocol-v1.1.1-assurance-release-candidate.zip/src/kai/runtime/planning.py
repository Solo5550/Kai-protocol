from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict, deque

from .models import Alternative, Hypothesis, Plan, PlanNode


class PlanValidationError(ValueError):
    pass


@dataclass(frozen=True)
class HypothesisSet:
    hypotheses: tuple[Hypothesis, ...]

    def best_supported(self) -> Hypothesis | None:
        supported = [h for h in self.hypotheses if h.status == "SUPPORTED"]
        return max(supported, key=lambda h: h.confidence, default=None)


def validate_plan(plan: Plan) -> None:
    if not plan.nodes:
        raise PlanValidationError("plan_has_no_nodes")
    ids = [n.node_id for n in plan.nodes]
    if len(ids) != len(set(ids)):
        raise PlanValidationError("duplicate_node_id")
    graph = defaultdict(list)
    indegree = {node_id: 0 for node_id in ids}
    for edge in plan.dependencies:
        src, dst = edge.get("from"), edge.get("to")
        if src not in indegree or dst not in indegree:
            raise PlanValidationError("dependency_unknown_node")
        graph[src].append(dst)
        indegree[dst] += 1
    q = deque([n for n, d in indegree.items() if d == 0])
    visited = 0
    while q:
        node = q.popleft(); visited += 1
        for nxt in graph[node]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                q.append(nxt)
    if visited != len(ids):
        raise PlanValidationError("plan_cycle_detected")


def hypothesis_from_evidence(statement: str, *, supporting: list[str] | None = None, contradicting: list[str] | None = None,
                             expected_observations: list[str] | None = None, falsification: list[str] | None = None,
                             confidence: float = 0.5) -> Hypothesis:
    return Hypothesis(statement=statement, supporting_evidence=supporting or [], contradicting_evidence=contradicting or [],
                      expected_observations=expected_observations or [], falsification_conditions=falsification or [],
                      confidence=confidence, status="TESTABLE")


def alternatives_for(decision_id: str, approaches: list[dict]) -> list[Alternative]:
    return [Alternative(alternative_id=f"{decision_id}:alt-{i+1}", **item) for i, item in enumerate(approaches)]
