from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


CAUSAL_LAYERS = ("Observation", "Association", "Correlation", "Statistical Evidence", "Causal Hypothesis", "Causal Identification", "Causal Inference", "Prediction", "Decision")

@dataclass
class AnalysisRecord:
    analysis_id: str
    layer: str
    statement: str
    assumptions: list[str] = field(default_factory=list)
    design: str | None = None
    confounders: list[str] = field(default_factory=list)
    estimand: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    uncertainty: dict[str, Any] = field(default_factory=dict)
    limitations: list[str] = field(default_factory=list)


def validate_causal_claim(analysis: AnalysisRecord) -> None:
    if analysis.layer not in CAUSAL_LAYERS:
        raise ValueError("unknown_analysis_layer")
    if analysis.layer in {"Causal Identification", "Causal Inference"} and not analysis.assumptions:
        raise ValueError("causal_identification_requires_assumptions")
    if analysis.layer == "Causal Inference" and not analysis.estimand:
        raise ValueError("causal_inference_requires_estimand")
