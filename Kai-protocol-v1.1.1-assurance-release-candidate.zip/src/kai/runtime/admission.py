from __future__ import annotations

from dataclasses import dataclass
from threading import Lock
from typing import Any


@dataclass(frozen=True)
class AdmissionDecision:
    allowed: bool
    reason: str
    reservation_id: str | None = None


class AdmissionController:
    def __init__(self, *, concurrency_limit: int = 32, quota_units: float = 1_000.0) -> None:
        self.concurrency_limit = concurrency_limit
        self.quota_units = quota_units
        self._active = 0
        self._reserved = 0.0
        self._lock = Lock()

    def admit(self, *, units: float = 1.0, priority: int = 0, risk: float = 0.0) -> AdmissionDecision:
        del priority
        if units < 0 or risk < 0:
            return AdmissionDecision(False, "invalid_admission_parameters")
        with self._lock:
            if self._active >= self.concurrency_limit:
                return AdmissionDecision(False, "concurrency_limit")
            if self._reserved + units > self.quota_units:
                return AdmissionDecision(False, "quota_exhaustion")
            if risk > 1.0:
                return AdmissionDecision(False, "risk_limit")
            import uuid
            self._active += 1
            self._reserved += units
            return AdmissionDecision(True, "admitted", str(uuid.uuid4()))

    def release(self, *, units: float = 1.0) -> None:
        with self._lock:
            self._active = max(0, self._active - 1)
            self._reserved = max(0.0, self._reserved - max(units, 0.0))

    @property
    def active(self) -> int:
        with self._lock:
            return self._active
