from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any

from .models import Claim, ClaimStatus, ProofRecord, VerificationStatus, to_primitive, utcnow
from .store import RuntimeStore


@dataclass(frozen=True)
class ProofAppend:
    sequence: int
    proof_id: str
    entry_hash: str
    previous_hash: str


class ProofLedger:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store
        with self.store._conn:
            self.store._conn.execute("CREATE TABLE IF NOT EXISTS proof_ledger(sequence INTEGER PRIMARY KEY AUTOINCREMENT, proof_id TEXT UNIQUE, payload TEXT NOT NULL, previous_hash TEXT NOT NULL, entry_hash TEXT NOT NULL)")

    def append(self, proof: ProofRecord) -> ProofAppend:
        payload = json.dumps(to_primitive(proof), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        with self.store.transaction() as conn:
            last = conn.execute("SELECT entry_hash FROM proof_ledger ORDER BY sequence DESC LIMIT 1").fetchone()
            previous_hash = last[0] if last else "GENESIS"
            entry_hash = hashlib.sha256((previous_hash + payload).encode()).hexdigest()
            cur = conn.execute("INSERT INTO proof_ledger(proof_id,payload,previous_hash,entry_hash) VALUES(?,?,?,?)", (proof.proof_id, payload, previous_hash, entry_hash))
            seq = int(cur.lastrowid)
            proof_payload = json.dumps(to_primitive(proof), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            now = utcnow()
            conn.execute(
                "INSERT INTO objects(kind,object_id,payload,version,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(kind,object_id) DO UPDATE SET payload=excluded.payload, version=excluded.version, updated_at=excluded.updated_at",
                ("proof", proof.object_id, proof_payload, 1, now),
            )
        return ProofAppend(seq, proof.proof_id, entry_hash, previous_hash)

    def verify_chain(self) -> bool:
        with self.store._lock:
            rows = self.store._conn.execute("SELECT sequence,payload,previous_hash,entry_hash FROM proof_ledger ORDER BY sequence").fetchall()
        previous = "GENESIS"
        for seq, payload, prev, entry in rows:
            if prev != previous or hashlib.sha256((prev + payload).encode()).hexdigest() != entry:
                return False
            previous = entry
        return True

    def entries(self) -> list[dict[str, Any]]:
        with self.store._lock:
            rows = self.store._conn.execute("SELECT sequence,proof_id,previous_hash,entry_hash,payload FROM proof_ledger ORDER BY sequence").fetchall()
        return [{"sequence": r[0], "proof_id": r[1], "previous_hash": r[2], "entry_hash": r[3], "payload": json.loads(r[4])} for r in rows]


class ProofEngine:
    def __init__(self, ledger: ProofLedger, store: RuntimeStore) -> None:
        self.ledger = ledger
        self.store = store

    def prove(self, *, claim: Claim, verification: str | None, evidence_refs: list[str], observation_refs: list[str],
              execution_refs: list[str], source_refs: list[str], verifier: str = "kai-verifier", assumptions: list[str] | None = None,
              uncertainty: dict[str, Any] | None = None) -> ProofRecord:
        if claim.status is ClaimStatus.SUPPORTED and not verification:
            raise ValueError("supported claim requires verification")
        proof = ProofRecord(
            proof_id=f"proof-{claim.claim_id}", claim_id=claim.claim_id, conclusion=claim.statement,
            status=claim.status, evidence_refs=evidence_refs, observation_refs=observation_refs,
            execution_refs=execution_refs, verification_refs=[verification] if verification else [],
            source_refs=source_refs, assumptions=assumptions or [], uncertainty=uncertainty or {}, verifier=verifier,
        )
        self.ledger.append(proof)
        return proof


class DecisionEngine:
    def decide(self, *, run_id: str, objective: str, selected_action: dict[str, Any], evidence_refs: list[str],
               verification_refs: list[str], proof_refs: list[str], rejected_alternatives: list[str] | None = None,
               assumptions: list[str] | None = None, uncertainty: dict[str, Any] | None = None,
               expected_outcome: Any = None, observed_outcome: Any = None, policy_ref: str | None = None,
               contract_ref: str | None = None) -> Any:
        from .models import Decision
        status = "VERIFIED" if verification_refs and proof_refs else "UNVERIFIED"
        return Decision(run_id=run_id, objective=objective, selected_action=selected_action, evidence_refs=evidence_refs,
                        verification_refs=verification_refs, proof_refs=proof_refs, rejected_alternatives=rejected_alternatives or [],
                        assumptions=assumptions or [], uncertainty=uncertainty or {}, policy_ref=policy_ref,
                        contract_ref_local=contract_ref, expected_outcome=expected_outcome, observed_outcome=observed_outcome, status=status)
