from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import Enum
from typing import Any, get_args, get_origin, get_type_hints


def from_primitive(cls, data: dict[str, Any]):
    hints = get_type_hints(cls)
    kwargs = {}
    for f in fields(cls):
        if f.name not in data:
            continue
        kwargs[f.name] = _convert(hints.get(f.name, Any), data[f.name])
    return cls(**kwargs)


def _convert(tp, value):
    if value is None:
        return None
    origin = get_origin(tp)
    args = get_args(tp)
    if origin in (list, tuple, set):
        subtype = args[0] if args else Any
        vals = [_convert(subtype, x) for x in value]
        return origin(vals) if origin in (tuple, set) else vals
    if origin is dict:
        return {k: v for k, v in value.items()}
    if origin is not None and str(origin).endswith("Union"):
        non_none = [a for a in args if a is not type(None)]
        return _convert(non_none[0], value) if non_none else value
    try:
        if isinstance(tp, type) and issubclass(tp, Enum):
            return tp(value)
    except TypeError:
        pass
    return value
