from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import sysconfig
import ctypes.util
import tempfile
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Callable

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .models import Capability, CapabilityLifecycle, Execution, utcnow


class IsolationBlocked(RuntimeError):
    pass


class IsolationViolation(RuntimeError):
    pass


@dataclass(frozen=True)
class ResourceQuota:
    cpu_seconds: int = 2
    address_space_bytes: int = 256 * 1024 * 1024
    file_size_bytes: int = 8 * 1024 * 1024
    open_files: int = 64
    processes: int = 8
    output_bytes: int = 4 * 1024 * 1024


@dataclass(frozen=True)
class PermissionBoundary:
    allowed: tuple[str, ...] = ()
    denied: tuple[str, ...] = (
        "host.fs.write", "host.fs.read", "network.egress", "process.spawn", "sys.admin"
    )

    def allows(self, permission: str) -> bool:
        return permission in self.allowed and permission not in self.denied


@dataclass(frozen=True)
class CapabilityManifest:
    capability_id: str
    implementation_id: str
    capability_version: str
    contract_ref: dict[str, str]
    owner: str
    requested_permissions: tuple[str, ...]
    execution_mode: str = "isolated-linux"
    runtime_versions: tuple[str, ...] = ()
    schema_versions: tuple[str, ...] = ()
    resource_quota: ResourceQuota = field(default_factory=ResourceQuota)
    permission_boundary: PermissionBoundary = field(default_factory=PermissionBoundary)
    code_sha256: str = ""
    manifest_version: str = "1.0"
    created_at: str = field(default_factory=utcnow)
    issuer: str = ""
    signature: str | None = None

    def unsigned_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["signature"] = None
        return data

    def canonical_bytes(self) -> bytes:
        return json.dumps(self.unsigned_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()

    @property
    def digest(self) -> str:
        return hashlib.sha256(self.canonical_bytes()).hexdigest()

    def sign(self, private_key: bytes, issuer: str) -> "CapabilityManifest":
        private = Ed25519PrivateKey.from_private_bytes(private_key)
        unsigned = replace(self, issuer=issuer, signature=None)
        signature = base64.urlsafe_b64encode(private.sign(unsigned.canonical_bytes())).decode().rstrip("=")
        return replace(unsigned, signature=signature)

    def verify(self, public_key: bytes) -> bool:
        if not self.signature:
            return False
        try:
            signature = base64.urlsafe_b64decode(self.signature + "=" * (-len(self.signature) % 4))
            Ed25519PublicKey.from_public_bytes(public_key).verify(signature, self.canonical_bytes())
            return True
        except Exception:
            return False


@dataclass(frozen=True)
class AttestedResult:
    execution_id: str
    capability_id: str
    manifest_digest: str
    worker_pid: int | None
    status: str
    duration_ms: float = 0.0
    output: Any = None
    error: str | None = None
    started_at: str = field(default_factory=utcnow)
    completed_at: str = field(default_factory=utcnow)
    stdout_sha256: str = ""
    attestation_digest: str = ""
    signature: str = ""
    attestor: str = "kai-runtime-attestor"


class AutonomyGate:
    """Governs execution authority levels; L5/L6 are not available in this release."""

    MAX_ALLOWED = 4

    @classmethod
    def authorize(cls, level: str = "L4") -> None:
        if not isinstance(level, str) or not level.startswith("L") or not level[1:].isdigit():
            raise IsolationBlocked(f"invalid_autonomy_level:{level!r}")
        numeric = int(level[1:])
        if numeric < 0 or numeric > 6:
            raise IsolationBlocked(f"invalid_autonomy_level:{level}")
        if numeric > cls.MAX_ALLOWED:
            raise IsolationBlocked(f"autonomy_level_blocked:{level}")


class ManifestAuthority:
    def __init__(self) -> None:
        self._private = Ed25519PrivateKey.generate()
        self.public_key = self._private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.issuer = "kai-runtime-manifest-authority"

    def sign(self, manifest: CapabilityManifest) -> CapabilityManifest:
        raw = self._private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
        return manifest.sign(raw, self.issuer)

    @classmethod
    def public_only(cls, public_key: bytes) -> "ManifestAuthority":
        obj = cls.__new__(cls)
        obj._private = None
        obj.public_key = bytes(public_key)
        obj.issuer = "kai-runtime-manifest-authority"
        return obj


class ResultAttestor:
    def __init__(self, private_key: Ed25519PrivateKey | None = None) -> None:
        self._private = private_key or Ed25519PrivateKey.generate()
        self.public_key = self._private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.issuer = "kai-runtime-attestor"

    @classmethod
    def load_or_create(cls, path: str | Path) -> "ResultAttestor":
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            key = Ed25519PrivateKey.from_private_bytes(path.read_bytes())
            return cls(key)
        obj = cls()
        raw = obj._private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
        path.write_bytes(raw)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return obj

    def attest(self, result: AttestedResult) -> AttestedResult:
        data = asdict(result)
        data["signature"] = ""
        data["attestation_digest"] = ""
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        digest = hashlib.sha256(canonical).hexdigest()
        signature = base64.urlsafe_b64encode(self._private.sign(canonical)).decode().rstrip("=")
        return replace(result, attestation_digest=digest, signature=signature)

    @staticmethod
    def verify_with_public_key(result: AttestedResult, public_key: bytes) -> bool:
        data = asdict(result)
        signature_b64 = data.pop("signature")
        digest = data.pop("attestation_digest")
        data["signature"] = ""
        data["attestation_digest"] = ""
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        if hashlib.sha256(canonical).hexdigest() != digest:
            return False
        try:
            signature = base64.urlsafe_b64decode(signature_b64 + "=" * (-len(signature_b64) % 4))
            Ed25519PublicKey.from_public_bytes(public_key).verify(signature, canonical)
            return True
        except Exception:
            return False

    def verify(self, result: AttestedResult) -> bool:
        return self.verify_with_public_key(result, self.public_key)


def serialize_handler(handler: Callable[[dict[str, Any]], Any]) -> bytes:
    import cloudpickle, inspect, sys
    module = sys.modules.get(getattr(handler, "__module__", ""))
    registered = False
    if module is not None and getattr(module, "__file__", None):
        try:
            cloudpickle.register_pickle_by_value(module)
            registered = True
        except Exception:
            registered = False
    try:
        return cloudpickle.dumps(handler, protocol=5)
    finally:
        if registered and hasattr(cloudpickle, "unregister_pickle_by_value"):
            try: cloudpickle.unregister_pickle_by_value(module)
            except Exception: pass


class HardIsolationExecutor:
    """Hard Linux execution boundary for the reference runtime.

    Uses user/mount/network/PID namespaces, a chroot rootfs, read-only runtime
    trees, writable tmpfs/workspace only, and process resource limits.
    """

    def __init__(self, *, timeout: float = 5.0, authority: ManifestAuthority | None = None, attestor: ResultAttestor | None = None) -> None:
        self.timeout = timeout
        self.authority = authority or ManifestAuthority()
        self.attestor = attestor or ResultAttestor()
        self.available, self.block_reason = self._probe_platform()

    @staticmethod
    def _probe_platform() -> tuple[bool, str | None]:
        if platform.system() != "Linux":
            return False, "linux_required"
        missing = [tool for tool in ("unshare", "chroot", "mount", "setpriv") if not shutil.which(tool)]
        if ctypes.util.find_library("seccomp") is None:
            missing.append("libseccomp")
        if missing:
            return False, f"missing_tools:{','.join(missing)}"
        try:
            proc = subprocess.run(
                ["unshare", "--user", "--map-root-user", "--mount", "--net", "--pid", "--fork", "--kill-child", "true"],
                capture_output=True, text=True, timeout=3,
            )
        except Exception as exc:
            return False, f"unshare_probe_exception:{type(exc).__name__}"
        if proc.returncode != 0:
            return False, f"unshare_probe_failed:{proc.stderr.strip() or proc.returncode}"
        return True, None

    def build_manifest(self, capability: Capability, contract_version: str, *, contract_id: str = "runtime-contract", permissions: set[str], quota: ResourceQuota | None = None, handler: Callable[[dict[str, Any]], Any] | None = None) -> CapabilityManifest:
        requested = set(capability.required_permissions)
        granted = set(permissions)
        if not requested.issubset(granted):
            raise IsolationViolation("requested_permissions_not_authorized")
        effective_permissions = requested
        if "network.egress" in effective_permissions:
            raise IsolationBlocked("network_egress_requires_managed_proxy_boundary")
        code_digest = hashlib.sha256(capability.implementation_id.encode()).hexdigest()
        if handler is not None:
            code_digest = hashlib.sha256(serialize_handler(handler)).hexdigest()
        manifest = CapabilityManifest(
            capability_id=capability.capability_id,
            implementation_id=capability.implementation_id,
            capability_version=capability.semantic_version,
            contract_ref={"id": contract_id, "version": contract_version},
            owner=capability.owner,
            requested_permissions=tuple(sorted(effective_permissions)),
            runtime_versions=tuple(capability.runtime_versions),
            schema_versions=tuple(capability.schema_versions),
            resource_quota=quota or ResourceQuota(),
            permission_boundary=PermissionBoundary(allowed=tuple(sorted(effective_permissions))),
            code_sha256=code_digest,
        )
        return self.authority.sign(manifest)

    def execute(self, *, execution: Execution, capability: Capability, handler: Callable[[dict[str, Any]], Any], payload: dict[str, Any], manifest: CapabilityManifest, timeout: float | None = None) -> AttestedResult:
        if not self.available:
            raise IsolationBlocked(self.block_reason or "isolation_unavailable")
        if not manifest.verify(self.authority.public_key):
            raise IsolationViolation("manifest_signature_invalid")
        if manifest.capability_id != capability.capability_id or manifest.implementation_id != capability.implementation_id:
            raise IsolationViolation("manifest_capability_binding_mismatch")
        if capability.lifecycle is not CapabilityLifecycle.AVAILABLE:
            raise IsolationViolation("capability_not_available")
        if set(capability.required_permissions) != set(manifest.requested_permissions):
            raise IsolationViolation("manifest_permission_mismatch")
        if set(manifest.permission_boundary.allowed) & set(manifest.permission_boundary.denied):
            raise IsolationViolation("permission_boundary_conflict")

        import cloudpickle
        with tempfile.TemporaryDirectory(prefix=f"kai-isolated-{execution.execution_id}-") as tmp:
            host = Path(tmp)
            root = host / "root"
            work = host / "work"
            root.mkdir(); work.mkdir()
            self._prepare_rootfs(root)
            (work / "handler.pkl").write_bytes(serialize_handler(handler))
            (work / "payload.pkl").write_bytes(cloudpickle.dumps(payload, protocol=5))
            (work / "envelope.json").write_text(json.dumps({"execution_id": execution.execution_id, "capability_id": capability.capability_id, "manifest_digest": manifest.digest, "quota": asdict(manifest.resource_quota), "permissions": list(manifest.permission_boundary.allowed)}, sort_keys=True), encoding="utf-8")
            (work / "runner.py").write_text(self._runner_source(), encoding="utf-8")
            marker = work / "marker.json"
            stdout = work / "stdout.log"
            script = host / "bootstrap.sh"
            python_exec = os.path.realpath(sys.executable)
            python_purelib = sysconfig.get_path("purelib")
            if not python_purelib or not Path(python_purelib).exists():
                raise IsolationBlocked("python_purelib_unavailable")
            script.write_text(
                self._bootstrap_script(root, work, python_exec, python_purelib),
                encoding="utf-8",
            )
            os.chmod(script, 0o700)
            guard = host / "parent_guard.py"
            guard.write_text(self._parent_guard_source(), encoding="utf-8")
            os.chmod(guard, 0o700)
            started = utcnow()
            try:
                with stdout.open("wb") as stdout_handle:
                    proc = subprocess.Popen(
                        [sys.executable, str(guard), "unshare", "--user", "--map-root-user", "--mount", "--net", "--ipc", "--uts", "--pid", "--fork", "--kill-child", str(script)],
                        stdout=stdout_handle, stderr=subprocess.STDOUT,
                    )
                    try:
                        proc.wait(timeout=timeout or self.timeout)
                    except subprocess.TimeoutExpired:
                        proc.kill(); proc.wait(timeout=2)
                        marker_data = {"status": "TIMEOUT", "error": "hard_isolation_deadline_exceeded", "pid": proc.pid}
                    else:
                        marker_data = json.loads(marker.read_text(encoding="utf-8")) if marker.exists() else {"status": "FAILURE", "error": f"isolated_worker_exit:{proc.returncode}", "pid": proc.pid}
                captured = stdout.read_bytes()[: manifest.resource_quota.output_bytes]
                output = None
                if marker_data.get("status") == "SUCCESS" and (work / "result.pkl").exists():
                    if (work / "result.pkl").stat().st_size > manifest.resource_quota.output_bytes:
                        marker_data = {"status": "FAILURE", "error": "result_output_quota_exceeded", "pid": marker_data.get("pid", proc.pid)}
                    else:
                        output = cloudpickle.loads((work / "result.pkl").read_bytes())
                result = AttestedResult(
                    execution_id=execution.execution_id,
                    capability_id=capability.capability_id,
                    manifest_digest=manifest.digest,
                    duration_ms=float(marker_data.get("duration_ms", 0.0)),
                    worker_pid=marker_data.get("pid", proc.pid),
                    status=marker_data.get("status", "FAILURE"),
                    output=output,
                    error=marker_data.get("error"),
                    started_at=started,
                    completed_at=utcnow(),
                    stdout_sha256=hashlib.sha256(captured).hexdigest(),
                )
                return self.attestor.attest(result)
            except Exception as exc:
                return self.attestor.attest(AttestedResult(
                    execution_id=execution.execution_id,
                    capability_id=capability.capability_id,
                    manifest_digest=manifest.digest,
                    duration_ms=0.0,
                    worker_pid=None,
                    status="FAILURE",
                    error=f"isolation_controller:{type(exc).__name__}:{exc}",
                    started_at=started,
                    completed_at=utcnow(),
                ))


    @staticmethod
    def _parent_guard_source() -> str:
        return """import ctypes, os, signal, sys
libc = ctypes.CDLL(None, use_errno=True)
PR_SET_PDEATHSIG = 1
if libc.prctl(PR_SET_PDEATHSIG, signal.SIGKILL, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), \"prctl(PR_SET_PDEATHSIG) failed\")
if len(sys.argv) < 2:
    raise SystemExit(\"missing_command\")
os.execvp(sys.argv[1], sys.argv[1:])
"""

    @staticmethod
    def _set_parent_death_signal() -> None:
        if platform.system() != "Linux":
            return
        try:
            import ctypes
            import signal
            libc = ctypes.CDLL(None, use_errno=True)
            PR_SET_PDEATHSIG = 1
            if libc.prctl(PR_SET_PDEATHSIG, signal.SIGKILL, 0, 0, 0) != 0:
                raise OSError(ctypes.get_errno(), "prctl(PR_SET_PDEATHSIG) failed")
        except Exception as exc:
            raise RuntimeError(f"parent_death_signal_unavailable:{exc}") from exc

    @staticmethod
    def _prepare_rootfs(root: Path) -> None:
        for d in ("bin", "usr", "usr/local", "opt", "lib", "lib64", "sbin", "etc", "dev", "tmp", "work"):
            (root / d).mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _bootstrap_script(root: Path, work: Path, python_exec: str, python_purelib: str) -> str:
        root_s = str(root)
        work_s = str(work)
        py = python_exec
        purelib = python_purelib
        return f'''#!/bin/sh
set -eu
ROOT={root_s}
WORK={work_s}
PY={py}
PURELIB={purelib}
mount --make-rprivate /
for p in /bin /usr /usr/local /opt /lib /lib64 /sbin /etc /dev; do
  if [ -e "$p" ]; then
    t="$ROOT$p"; mkdir -p "$t"; mount --rbind "$p" "$t"; mount -o remount,bind,ro "$t" 2>/dev/null || true
  fi
done
mkdir -p "$ROOT/tmp" "$ROOT/work" "$ROOT/kai-python-site"
if [ -d "$PURELIB" ]; then
  mount --rbind "$PURELIB" "$ROOT/kai-python-site"
  mount -o remount,bind,ro "$ROOT/kai-python-site" 2>/dev/null || true
else
  echo "python_purelib_missing" >&2
  exit 126
fi
mount -t tmpfs -o size=32m,nosuid,nodev tmpfs "$ROOT/tmp"
mount --rbind "$WORK" "$ROOT/work"
chroot "$ROOT" /usr/bin/setpriv --nnp --bounding-set=-all --inh-caps=-all --ambient-caps=-all --reset-env -- /usr/bin/env PYTHONPATH=/kai-python-site "$PY" /work/runner.py
'''

    @staticmethod
    def _runner_source() -> str:
        return r'''import json, os, resource, time
from pathlib import Path
import cloudpickle
root = Path('/work')
started = time.time()
meta = json.loads((root / 'envelope.json').read_text())
q = meta['quota']
try:
    if 'process.spawn' not in meta.get('permissions', []):
        import ctypes, errno
        libsec = ctypes.CDLL('libseccomp.so.2', use_errno=True)
        libsec.seccomp_init.restype = ctypes.c_void_p
        libsec.seccomp_syscall_resolve_name.restype = ctypes.c_int
        libsec.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_uint]
        libsec.seccomp_load.argtypes = [ctypes.c_void_p]
        libsec.seccomp_release.argtypes = [ctypes.c_void_p]
        ctx = libsec.seccomp_init(0x7fff0000)  # SCMP_ACT_ALLOW
        if not ctx: raise RuntimeError('seccomp_init_failed')
        try:
            deny = 0x00050000 | errno.EPERM  # SCMP_ACT_ERRNO(EPERM)
            for name in (b'clone', b'clone3', b'fork', b'vfork'):
                sc = libsec.seccomp_syscall_resolve_name(name)
                if sc >= 0 and libsec.seccomp_rule_add(ctx, deny, sc, 0) != 0:
                    raise RuntimeError('seccomp_rule_add_failed')
            if libsec.seccomp_load(ctx) != 0:
                raise RuntimeError('seccomp_load_failed')
        finally:
            libsec.seccomp_release(ctx)
    resource.setrlimit(resource.RLIMIT_CPU, (int(q['cpu_seconds']), int(q['cpu_seconds'])))
    resource.setrlimit(resource.RLIMIT_AS, (int(q['address_space_bytes']), int(q['address_space_bytes'])))
    resource.setrlimit(resource.RLIMIT_FSIZE, (int(q['file_size_bytes']), int(q['file_size_bytes'])))
    resource.setrlimit(resource.RLIMIT_NOFILE, (int(q['open_files']), int(q['open_files'])))
    nproc_limit = int(q['processes']) if 'process.spawn' in meta.get('permissions', []) else 1
    resource.setrlimit(resource.RLIMIT_NPROC, (nproc_limit, nproc_limit))
    with (root / 'handler.pkl').open('rb') as h: handler = cloudpickle.load(h)
    with (root / 'payload.pkl').open('rb') as h: payload = cloudpickle.load(h)
    result = handler(payload)
    with (root / 'result.pkl').open('wb') as h: cloudpickle.dump(result, h, protocol=5)
    marker = {'status':'SUCCESS','error':None,'duration_ms':(time.time()-started)*1000,'pid':os.getpid()}
except BaseException as exc:
    marker = {'status':'FAILURE','error':f'{type(exc).__name__}: {exc}','duration_ms':(time.time()-started)*1000,'pid':os.getpid()}
(root / 'marker.json').write_text(json.dumps(marker, sort_keys=True), encoding='utf-8')
'''
