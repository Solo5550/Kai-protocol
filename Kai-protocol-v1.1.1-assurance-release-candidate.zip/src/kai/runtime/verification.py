from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .models import Verification, VerificationStatus
from .store import RuntimeStore


@dataclass(frozen=True)
class VerificationResult:
    verification: Verification
    passed_checks: int
    failed_checks: int


class VerificationEngine:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store

    def verify(self, *, execution_id: str, target: str, expected: Any, observed: Any,
               criteria: list[Callable[[Any, Any], bool]] | None = None, evidence_refs: list[str] | None = None,
               independent_observation: bool = False, verifier: str = "kai-verifier") -> VerificationResult:
        checks = criteria or [lambda exp, obs: exp == obs]
        results = []
        for i, criterion in enumerate(checks):
            try:
                ok = bool(criterion(expected, observed))
            except Exception as exc:
                ok = False
                results.append({"check": i, "passed": False, "error": f"{type(exc).__name__}: {exc}"})
            else:
                results.append({"check": i, "passed": ok})
        passed = sum(1 for r in results if r["passed"])
        failed = len(results) - passed
        if failed == 0:
            status = VerificationStatus.VERIFIED
            confidence = 1.0
        elif passed == 0:
            status = VerificationStatus.NOT_VERIFIED
            confidence = 0.0
        else:
            status = VerificationStatus.INCONCLUSIVE
            confidence = passed / len(results)
        verification = Verification(verification_id=f"verification-{execution_id}-{len(self.store.events(execution_id))}", execution_id=execution_id, target=target, status=status, checks=results,
                                    acceptance_criteria=[f"check-{i}" for i in range(len(results))],
                                    evidence_refs=evidence_refs or [], independent_observation=independent_observation,
                                    confidence=confidence, provenance={"verifier": verifier})
        self.store.put("verification", verification)
        return VerificationResult(verification, passed, failed)
