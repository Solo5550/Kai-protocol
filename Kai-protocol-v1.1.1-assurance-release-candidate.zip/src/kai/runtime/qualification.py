from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .conformance import RuntimeConformance, architecture_fitness
from .drift import ArchitectureDriftScanner


@dataclass(frozen=True)
class QualificationReport:
    status: str
    checks: dict[str, bool]
    notes: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return self.status == "REFERENCE_QUALIFIED"


def qualify_reference_runtime(runtime) -> QualificationReport:
    checks = {}
    conformance = RuntimeConformance().run()
    checks["conformance"] = conformance.passed
    checks.update({f"fitness.{k}": v for k, v in architecture_fitness(runtime).items()})
    checks["drift_clean"] = ArchitectureDriftScanner().clean(runtime)
    checks["proof_chain"] = runtime.proof_ledger.verify_chain()
    checks["state_store_authoritative"] = runtime.kernel.store is runtime.store
    checks["process_executor_present"] = runtime.kernel.executor is not None
    notes = (
        "Reference runtime qualification is not production certification.",
        "Process isolation is an OS process boundary, not a hostile-code sandbox/VM boundary.",
        "Worldwide federation is implemented as a local reference model; multi-node operational evidence is still required for production.",
    )
    status = "REFERENCE_QUALIFIED" if all(checks.values()) else "NOT_QUALIFIED"
    return QualificationReport(status, checks, notes)
