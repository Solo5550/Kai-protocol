from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .models import Capability, Execution, Policy, to_primitive, utcnow


def _canonical(policy: Policy) -> bytes:
    data = to_primitive(policy)
    data["hash"] = ""
    data["signature"] = None
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def policy_hash(policy: Policy) -> str:
    return hashlib.sha256(_canonical(policy)).hexdigest()


def sign_policy(policy: Policy, private_key: bytes, issuer: str) -> Policy:
    signed = Policy(**{**to_primitive(policy), "issuer": issuer})
    signed.hash = policy_hash(signed)
    signature = Ed25519PrivateKey.from_private_bytes(private_key).sign(_canonical(signed))
    signed.signature = base64.urlsafe_b64encode(signature).decode().rstrip("=")
    return signed


def verify_policy(policy: Policy, public_key: bytes) -> bool:
    if not policy.signature:
        return False
    try:
        sig = base64.urlsafe_b64decode(policy.signature + "=" * (-len(policy.signature) % 4))
        Ed25519PublicKey.from_public_bytes(public_key).verify(sig, _canonical(policy))
        return policy.hash == policy_hash(policy)
    except Exception:
        return False


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str
    required_permissions: tuple[str, ...] = ()
    effect_authorized: bool = False


class PolicyEngine:
    def decide(self, *, execution: Execution, capability: Capability, policy: Policy, permissions: set[str] | None = None,
               operation: str = "execute") -> PolicyDecision:
        permissions = permissions or set()
        if capability.capability_id in set(policy.denied_capabilities):
            return PolicyDecision(False, "capability_denied")
        allowed = not policy.allowed_capabilities or capability.capability_id in set(policy.allowed_capabilities)
        if not allowed:
            return PolicyDecision(False, "capability_not_allowlisted")
        if policy.denied_regions and execution.region_id in set(policy.denied_regions):
            return PolicyDecision(False, "region_denied")
        if policy.allowed_regions and execution.region_id not in set(policy.allowed_regions):
            return PolicyDecision(False, "region_not_allowlisted")
        required = set(policy.required_permissions) | set(capability.required_permissions)
        missing = sorted(required - permissions)
        if missing:
            return PolicyDecision(False, "missing_permissions", tuple(missing))
        effect_class = capability.side_effect_class
        effect_authorized = True
        if effect_class in {"external_write", "irreversible"}:
            effect_authorized = bool(policy.side_effect_policy.get(operation, False))
            if not effect_authorized:
                return PolicyDecision(False, "external_effect_not_authorized", tuple(sorted(required)), False)
        return PolicyDecision(True, "allowed", tuple(sorted(required)), effect_authorized)


class SignedPolicySnapshot:
    def __init__(self, policy: Policy) -> None:
        if not policy.hash:
            policy.hash = policy_hash(policy)
        self.policy = policy

    @property
    def ref(self) -> str:
        return f"{self.policy.policy_id}@{self.policy.semantic_version}#{self.policy.hash[:16]}"

    def as_ref(self) -> dict[str, str]:
        return {"policy_id": self.policy.policy_id, "version": self.policy.semantic_version, "hash": self.policy.hash, "issued_at": self.policy.issued_at, "expires_at": self.policy.expires_at or ""}
