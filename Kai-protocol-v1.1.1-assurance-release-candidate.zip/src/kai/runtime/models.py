from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping
from uuid import uuid4

RUNTIME_SCHEMA_VERSION = "0.6.0"
RUNTIME_VERSION = "0.7.0"
PROTOCOL_VERSION = "kai/0.2"
ENVELOPE_VERSION = "1.0"


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class ExecutionState(str, Enum):
    CREATED = "CREATED"
    CONTRACT_VALIDATING = "CONTRACT_VALIDATING"
    READY = "READY"
    EVIDENCE_PENDING = "EVIDENCE_PENDING"
    EVIDENCE_ACCEPTED = "EVIDENCE_ACCEPTED"
    PLANNING = "PLANNING"
    PLAN_ACCEPTED = "PLAN_ACCEPTED"
    ADMITTED = "ADMITTED"
    RUNNING = "RUNNING"
    OBSERVING = "OBSERVING"
    VERIFICATION_PENDING = "VERIFICATION_PENDING"
    VERIFIED = "VERIFIED"
    ANALYSIS_PENDING = "ANALYSIS_PENDING"
    ANALYZED = "ANALYZED"
    PROVEN = "PROVEN"
    UNPROVEN = "UNPROVEN"
    PERSISTING = "PERSISTING"
    PERSISTED = "PERSISTED"
    LEARNING_PENDING = "LEARNING_PENDING"
    LEARNED = "LEARNED"
    CALIBRATING = "CALIBRATING"
    CLOSED = "CLOSED"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    TIMED_OUT = "TIMED_OUT"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    PROPAGATING = "PROPAGATING"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    STOPPING = "STOPPING"
    CANCELLED = "CANCELLED"
    PARTIALLY_COMPLETED = "PARTIALLY_COMPLETED"
    RECOVERY_PENDING = "RECOVERY_PENDING"
    RECOVERING = "RECOVERING"
    RECOVERED = "RECOVERED"
    QUARANTINED = "QUARANTINED"
    INCONCLUSIVE = "INCONCLUSIVE"
    REJECTED = "REJECTED"
    DEGRADED = "DEGRADED"


class VerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    NOT_VERIFIED = "NOT_VERIFIED"
    INCONCLUSIVE = "INCONCLUSIVE"


class ClaimStatus(str, Enum):
    SUPPORTED = "SUPPORTED"
    UNSUPPORTED = "UNSUPPORTED"
    REFUTED = "REFUTED"
    UNRESOLVED = "UNRESOLVED"


class GateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    BLOCKED = "BLOCKED"
    UNRESOLVED = "UNRESOLVED"


class CapabilityLifecycle(str, Enum):
    DISCOVERED = "DISCOVERED"
    REGISTERED = "REGISTERED"
    QUALIFIED = "QUALIFIED"
    AVAILABLE = "AVAILABLE"
    DEGRADED = "DEGRADED"
    QUARANTINED = "QUARANTINED"
    DEPRECATED = "DEPRECATED"
    RETIRED = "RETIRED"


class FailureCategory(str, Enum):
    CONTRACT_ERROR = "CONTRACT_ERROR"
    POLICY_ERROR = "POLICY_ERROR"
    INPUT_ERROR = "INPUT_ERROR"
    CAPABILITY_ERROR = "CAPABILITY_ERROR"
    DEPENDENCY_ERROR = "DEPENDENCY_ERROR"
    RESOURCE_ERROR = "RESOURCE_ERROR"
    NETWORK_ERROR = "NETWORK_ERROR"
    TIMEOUT = "TIMEOUT"
    STATE_CONFLICT = "STATE_CONFLICT"
    VERSION_CONFLICT = "VERSION_CONFLICT"
    SECURITY_ERROR = "SECURITY_ERROR"
    SOVEREIGNTY_ERROR = "SOVEREIGNTY_ERROR"
    STORAGE_ERROR = "STORAGE_ERROR"
    VERIFICATION_ERROR = "VERIFICATION_ERROR"
    PROVENANCE_ERROR = "PROVENANCE_ERROR"
    UNKNOWN = "UNKNOWN"


class ConsistencyClass(str, Enum):
    A_SAFETY_SECURITY_AUTH = "A"
    B_REGISTRY_PLACEMENT = "B"
    C_TELEMETRY = "C"
    D_KNOWLEDGE = "D"
    E_LOCAL_EXECUTION = "E"


@dataclass
class RuntimeObject:
    object_id: str = field(default_factory=lambda: str(uuid4()))
    schema_version: str = RUNTIME_SCHEMA_VERSION
    created_at: str = field(default_factory=utcnow)
    updated_at: str = field(default_factory=utcnow)
    producer: str = "kai-runtime"
    provenance: dict[str, Any] = field(default_factory=dict)
    policy_context: dict[str, Any] = field(default_factory=dict)
    contract_ref: dict[str, Any] | None = None
    version: str = RUNTIME_VERSION

    def touch(self) -> None:
        self.updated_at = utcnow()


@dataclass
class Execution(RuntimeObject):
    tenant_id: str = "default"
    namespace_id: str = "default"
    run_id: str = field(default_factory=lambda: f"run-{uuid4()}")
    execution_id: str = field(default_factory=lambda: f"exec-{uuid4()}")
    parent_execution_id: str | None = None
    root_execution_id: str | None = None
    trace_id: str = field(default_factory=lambda: f"trace-{uuid4()}")
    span_id: str = field(default_factory=lambda: f"span-{uuid4()}")
    causal_parent_id: str | None = None
    region_id: str = "local"
    cell_id: str = "cell-local"
    actor_id: str = "unknown"
    capability_ref: dict[str, Any] | None = None
    policy_snapshot_ref: str | None = None
    state: ExecutionState = ExecutionState.CREATED
    state_version: int = 0
    last_event_id: str | None = None
    attempt: int = 1
    idempotency_key: str = field(default_factory=lambda: f"idem-{uuid4()}")
    security_context_ref: str | None = None
    payload_ref: str | None = None
    classification: str = "internal"
    objective: str = ""
    input_data: dict[str, Any] = field(default_factory=dict)
    output_data: dict[str, Any] = field(default_factory=dict)
    expected_outcome: Any = None
    observed_outcome: Any = None
    failure_ref: str | None = None
    decision_ref: str | None = None


@dataclass
class Contract(RuntimeObject):
    id: str = ""
    description: str = ""
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] = field(default_factory=dict)
    preconditions: list[str] = field(default_factory=list)
    postconditions: list[str] = field(default_factory=list)
    invariants: list[str] = field(default_factory=list)


@dataclass
class Capability(RuntimeObject):
    capability_id: str = ""
    semantic_version: str = "1.0.0"
    capability_type: str = "generic"
    purpose: str = ""
    lifecycle: CapabilityLifecycle = CapabilityLifecycle.DISCOVERED
    required_permissions: list[str] = field(default_factory=list)
    supported_execution_modes: list[str] = field(default_factory=lambda: ["local"])
    side_effect_class: str = "pure"
    idempotency_supported: bool = True
    owner: str = ""
    implementation_id: str = ""
    runtime_versions: list[str] = field(default_factory=lambda: [RUNTIME_VERSION])
    schema_versions: list[str] = field(default_factory=lambda: [RUNTIME_SCHEMA_VERSION])
    health: dict[str, Any] = field(default_factory=dict)
    resource_profile: dict[str, Any] = field(default_factory=dict)
    observability: dict[str, Any] = field(default_factory=dict)
    verification: dict[str, Any] = field(default_factory=dict)


@dataclass
class Policy(RuntimeObject):
    policy_id: str = ""
    semantic_version: str = "1.0.0"
    subject: str = "*"
    scope: str = "global"
    allowed_capabilities: list[str] = field(default_factory=list)
    denied_capabilities: list[str] = field(default_factory=list)
    required_permissions: list[str] = field(default_factory=list)
    allowed_regions: list[str] = field(default_factory=list)
    denied_regions: list[str] = field(default_factory=list)
    data_policy: dict[str, Any] = field(default_factory=dict)
    side_effect_policy: dict[str, Any] = field(default_factory=dict)
    resource_policy: dict[str, Any] = field(default_factory=dict)
    reliability_policy: dict[str, Any] = field(default_factory=dict)
    governance: dict[str, Any] = field(default_factory=dict)
    failure_policy: dict[str, Any] = field(default_factory=dict)
    hash: str = ""
    issuer: str = ""
    issued_at: str = field(default_factory=utcnow)
    expires_at: str | None = None
    signature: str | None = None


@dataclass
class EvidenceBundle(RuntimeObject):
    evidence_id: str = ""
    evidence_type: str = "generic"
    sources: list[dict[str, Any]] = field(default_factory=list)
    artifacts: list[str] = field(default_factory=list)
    freshness: dict[str, Any] = field(default_factory=dict)
    integrity: dict[str, Any] = field(default_factory=dict)
    conflict_status: str = "NONE"
    sufficiency: dict[str, Any] = field(default_factory=dict)
    uncertainty: dict[str, Any] = field(default_factory=dict)
    status: str = "EVIDENCE_PENDING"


@dataclass
class Hypothesis(RuntimeObject):
    hypothesis_id: str = ""
    statement: str = ""
    scope: str = ""
    prior_basis: list[str] = field(default_factory=list)
    supporting_evidence: list[str] = field(default_factory=list)
    contradicting_evidence: list[str] = field(default_factory=list)
    expected_observations: list[str] = field(default_factory=list)
    falsification_conditions: list[str] = field(default_factory=list)
    confidence: float = 0.0
    uncertainty: dict[str, Any] = field(default_factory=dict)
    status: str = "CANDIDATE"


@dataclass
class Alternative(RuntimeObject):
    alternative_id: str = ""
    approach: str = ""
    assumptions: list[str] = field(default_factory=list)
    expected_outcome: Any = None
    risks: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    rejected_because: str | None = None


@dataclass
class PlanNode(RuntimeObject):
    node_id: str = ""
    capability_requirement: dict[str, Any] = field(default_factory=dict)
    inputs: dict[str, Any] = field(default_factory=dict)
    preconditions: list[str] = field(default_factory=list)
    expected_observations: list[str] = field(default_factory=list)
    verification_strategy: dict[str, Any] = field(default_factory=dict)
    retry_policy: dict[str, Any] = field(default_factory=dict)
    failure_policy: dict[str, Any] = field(default_factory=dict)
    resource_constraints: dict[str, Any] = field(default_factory=dict)


@dataclass
class Plan(RuntimeObject):
    plan_id: str = ""
    semantic_version: str = "1.0.0"
    objective: str = ""
    assumptions: list[str] = field(default_factory=list)
    nodes: list[PlanNode] = field(default_factory=list)
    dependencies: list[dict[str, Any]] = field(default_factory=list)
    alternatives: list[str] = field(default_factory=list)
    rollback_strategy: dict[str, Any] = field(default_factory=dict)
    compensation_strategy: dict[str, Any] = field(default_factory=dict)
    acceptance_criteria: list[str] = field(default_factory=list)
    proof_requirements: list[str] = field(default_factory=list)
    provenance_requirements: list[str] = field(default_factory=list)


@dataclass
class Observation(RuntimeObject):
    observation_id: str = ""
    execution_id: str = ""
    source: str = ""
    subject: str = ""
    metric_or_fact: str = ""
    value: Any = None
    unit: str | None = None
    confidence: float | None = None
    raw_artifact_ref: str | None = None
    provenance_ref: str | None = None


@dataclass
class Verification(RuntimeObject):
    verification_id: str = ""
    execution_id: str = ""
    target: str = ""
    status: VerificationStatus = VerificationStatus.INCONCLUSIVE
    checks: list[dict[str, Any]] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    independent_observation: bool = False
    confidence: float | None = None
    notes: list[str] = field(default_factory=list)


@dataclass
class Artifact(RuntimeObject):
    artifact_id: str = ""
    artifact_type: str = "generic"
    artifact_version: str = "1.0.0"
    content_ref: str = ""
    content_hash: str = ""
    producer_execution_id: str | None = None
    producer_capability_id: str | None = None
    parent_artifacts: list[str] = field(default_factory=list)
    classification: str = "internal"
    retention_policy: dict[str, Any] = field(default_factory=dict)
    signature: str | None = None


@dataclass
class Claim(RuntimeObject):
    claim_id: str = ""
    statement: str = ""
    status: ClaimStatus = ClaimStatus.UNRESOLVED
    evidence_refs: list[str] = field(default_factory=list)
    verification_refs: list[str] = field(default_factory=list)
    source_refs: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    uncertainty: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProofRecord(RuntimeObject):
    proof_id: str = ""
    claim_id: str = ""
    conclusion: str = ""
    status: ClaimStatus = ClaimStatus.UNRESOLVED
    evidence_refs: list[str] = field(default_factory=list)
    observation_refs: list[str] = field(default_factory=list)
    execution_refs: list[str] = field(default_factory=list)
    verification_refs: list[str] = field(default_factory=list)
    analysis_refs: list[str] = field(default_factory=list)
    source_refs: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    uncertainty: dict[str, Any] = field(default_factory=dict)
    provenance_ref: str | None = None
    decision_ref: str | None = None
    verifier: str = ""


@dataclass
class Decision(RuntimeObject):
    decision_id: str = ""
    run_id: str = ""
    objective: str = ""
    selected_action: dict[str, Any] = field(default_factory=dict)
    evidence_refs: list[str] = field(default_factory=list)
    verification_refs: list[str] = field(default_factory=list)
    proof_refs: list[str] = field(default_factory=list)
    rejected_alternatives: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    uncertainty: dict[str, Any] = field(default_factory=dict)
    policy_ref: str | None = None
    contract_ref_local: str | None = None
    expected_outcome: Any = None
    observed_outcome: Any = None
    status: str = "PENDING"


@dataclass
class Failure(RuntimeObject):
    failure_id: str = ""
    execution_id: str = ""
    state: str = ""
    category: FailureCategory = FailureCategory.UNKNOWN
    severity: str = "medium"
    symptom: str = ""
    trigger: str = ""
    root_cause: str = ""
    contributors: list[str] = field(default_factory=list)
    detection_failure: str | None = None
    containment_failure: str | None = None
    recovery_failure: str | None = None
    affected_artifacts: list[str] = field(default_factory=list)
    affected_capabilities: list[str] = field(default_factory=list)
    affected_regions: list[str] = field(default_factory=list)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    observations: list[str] = field(default_factory=list)
    recovery_action: str | None = None
    compensation_action: str | None = None
    signature_ref: str | None = None
    lesson_ref: str | None = None


@dataclass
class Experience(RuntimeObject):
    experience_id: str = ""
    statement: str = ""
    context_signature: str = ""
    supporting_execution_refs: list[str] = field(default_factory=list)
    verification_refs: list[str] = field(default_factory=list)
    success_rate: float = 0.0
    failure_modes: list[str] = field(default_factory=list)
    applicable_conditions: list[str] = field(default_factory=list)
    non_applicable_conditions: list[str] = field(default_factory=list)
    last_validated_at: str | None = None
    confidence: float = 0.0
    reuse_policy: dict[str, Any] = field(default_factory=dict)
    experience_version: str = "1.0.0"
    status: str = "CANDIDATE"


@dataclass
class CalibrationRecord(RuntimeObject):
    calibration_id: str = ""
    subject_type: str = ""
    subject_id: str = ""
    expected_outcome: Any = None
    observed_outcome: Any = None
    prediction_error: float | None = None
    prior_confidence: float | None = None
    updated_reliability: float | None = None
    context_signature: str = ""


@dataclass
class LineageEdge(RuntimeObject):
    from_id: str = ""
    to_id: str = ""
    relation: str = "DERIVED_FROM"
    causality: str | None = None


@dataclass
class RuntimeEnvelope(RuntimeObject):
    envelope_version: str = ENVELOPE_VERSION
    message_id: str = field(default_factory=lambda: str(uuid4()))
    message_type: str = "ExecutionCommand"
    tenant_id: str = "default"
    namespace_id: str = "default"
    run_id: str = ""
    execution_id: str = ""
    parent_execution_id: str | None = None
    root_execution_id: str | None = None
    trace_id: str = ""
    span_id: str = ""
    causal_parent_id: str | None = None
    region_id: str = "local"
    cell_id: str = "cell-local"
    actor_id: str = ""
    contract_ref: dict[str, Any] | None = None
    capability_ref: dict[str, Any] | None = None
    policy_snapshot_ref: str | None = None
    deadline_at: str | None = None
    attempt: int = 1
    idempotency_key: str = ""
    security_context_ref: str | None = None
    provenance_ref: str | None = None
    payload_ref: str | None = None
    classification: str = "internal"
    status: str = "READY"


def to_primitive(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {f.name: to_primitive(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, Mapping):
        return {str(k): to_primitive(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [to_primitive(v) for v in value]
    return value
