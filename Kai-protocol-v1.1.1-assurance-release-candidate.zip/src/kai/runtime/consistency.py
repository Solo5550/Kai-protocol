from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .models import ConsistencyClass


@dataclass(frozen=True)
class ConsistencyPolicy:
    consistency_class: ConsistencyClass
    model: str
    freshness_seconds: float | None
    conflict_policy: str
    failure_behavior: str
    recovery_strategy: str


DEFAULT_CONSISTENCY_POLICIES = {
    ConsistencyClass.A_SAFETY_SECURITY_AUTH: ConsistencyPolicy(ConsistencyClass.A_SAFETY_SECURITY_AUTH, "strong-authoritative", 0.0, "reject-conflict", "block", "reconcile-before-resume"),
    ConsistencyClass.B_REGISTRY_PLACEMENT: ConsistencyPolicy(ConsistencyClass.B_REGISTRY_PLACEMENT, "eventual-versioned", 60.0, "version-wins-with-freshness", "fallback", "refresh-invalidate"),
    ConsistencyClass.C_TELEMETRY: ConsistencyPolicy(ConsistencyClass.C_TELEMETRY, "async-correlated", 300.0, "timestamp-sequence", "degrade", "buffer-reconcile"),
    ConsistencyClass.D_KNOWLEDGE: ConsistencyPolicy(ConsistencyClass.D_KNOWLEDGE, "versioned-eventual", 3600.0, "provenance-aware-merge", "mark-stale", "revalidate"),
    ConsistencyClass.E_LOCAL_EXECUTION: ConsistencyPolicy(ConsistencyClass.E_LOCAL_EXECUTION, "local-authoritative", 0.0, "state-version", "block", "local-recovery"),
}


def get_policy(consistency_class: ConsistencyClass) -> ConsistencyPolicy:
    return DEFAULT_CONSISTENCY_POLICIES[consistency_class]
