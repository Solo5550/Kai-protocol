from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .compatibility import CompatibilityEngine
from .contracts import ContractEngine
from .models import Capability, CapabilityLifecycle, Contract


@dataclass(frozen=True)
class CapabilityBinding:
    requirement_id: str
    capability_id: str
    implementation_id: str
    capability_version: str
    contract_ref: dict[str, str]
    qualification_ref: str
    rationale: str
    region_id: str
    cell_id: str
    expires_at: str | None = None


class CapabilityRegistry:
    def __init__(self) -> None:
        self._caps: dict[str, Capability] = {}
        self._handlers: dict[str, Callable] = {}
        self._qualification: dict[str, dict[str, Any]] = {}

    def discover(self, capability: Capability, handler: Callable) -> None:
        if capability.lifecycle is not CapabilityLifecycle.DISCOVERED:
            raise ValueError("new capability must begin DISCOVERED")
        self._caps[capability.capability_id] = capability
        self._handlers[capability.implementation_id] = handler

    def register(self, capability_id: str) -> Capability:
        cap = self._caps[capability_id]
        if cap.lifecycle is not CapabilityLifecycle.DISCOVERED:
            raise ValueError("capability must be DISCOVERED before registration")
        cap.lifecycle = CapabilityLifecycle.REGISTERED
        return cap

    def qualify(self, capability_id: str, *, contract_tests=True, schema_tests=True, security_tests=True,
                observability_tests=True, failure_tests=True, idempotency_tests=True, provenance_tests=True,
                compatibility_tests=True) -> dict[str, Any]:
        cap = self._caps[capability_id]
        if cap.lifecycle is not CapabilityLifecycle.REGISTERED:
            raise ValueError("only REGISTERED capability may be qualified")
        checks = {
            "contract": contract_tests, "schema": schema_tests, "security": security_tests,
            "observability": observability_tests, "failure": failure_tests, "idempotency": idempotency_tests,
            "provenance": provenance_tests, "compatibility": compatibility_tests,
        }
        passed = all(checks.values()) if cap.side_effect_class != "pure" else all(v for k, v in checks.items() if k != "idempotency" or idempotency_tests)
        self._qualification[capability_id] = {"checks": checks, "passed": passed}
        if passed:
            cap.lifecycle = CapabilityLifecycle.QUALIFIED
            cap.health = {**cap.health, "readiness": "READY", "liveness": "UP", "degradation": None}
            cap.lifecycle = CapabilityLifecycle.AVAILABLE
        return self._qualification[capability_id]

    def get(self, capability_id: str) -> Capability:
        return self._caps[capability_id]

    def handler(self, implementation_id: str) -> Callable:
        return self._handlers[implementation_id]

    def quarantine(self, capability_id: str, *, reason: str) -> Capability:
        cap = self._caps[capability_id]
        cap.lifecycle = CapabilityLifecycle.QUARANTINED
        cap.health = {**cap.health, "quarantine_reason": reason}
        return cap

    def set_health(self, capability_id: str, *, readiness: str, liveness: str, degradation: str | None = None) -> None:
        cap = self._caps[capability_id]
        cap.health = {"readiness": readiness, "liveness": liveness, "degradation": degradation}
        if cap.lifecycle is CapabilityLifecycle.AVAILABLE and degradation:
            cap.lifecycle = CapabilityLifecycle.DEGRADED
        elif cap.lifecycle is CapabilityLifecycle.DEGRADED and not degradation and readiness == "READY":
            cap.lifecycle = CapabilityLifecycle.AVAILABLE

    def all(self) -> list[Capability]:
        return list(self._caps.values())


class CapabilityResolver:
    def __init__(self, registry: CapabilityRegistry, *, compatibility: CompatibilityEngine | None = None, contracts: ContractEngine | None = None) -> None:
        self.registry = registry
        self.compatibility = compatibility or CompatibilityEngine()
        self.contracts = contracts or ContractEngine()

    def resolve(self, *, requirement: dict[str, Any], contract: Contract, region_id: str, cell_id: str, policy_version: str | None = None) -> CapabilityBinding:
        wanted = requirement.get("capability_id")
        candidates = self.registry.all()
        if wanted:
            candidates = [c for c in candidates if c.capability_id == wanted]
        candidates = [c for c in candidates if c.lifecycle is CapabilityLifecycle.AVAILABLE]
        for cap in candidates:
            compat = self.compatibility.check(capability=cap, contract=contract, policy_version=policy_version)
            if compat.status != "COMPATIBLE":
                continue
            return CapabilityBinding(
                requirement_id=str(requirement.get("requirement_id", requirement.get("capability_id", "req"))),
                capability_id=cap.capability_id,
                implementation_id=cap.implementation_id,
                capability_version=cap.semantic_version,
                contract_ref={"id": contract.id, "version": contract.version},
                qualification_ref=f"qualification:{cap.capability_id}",
                rationale="first qualified compatible capability",
                region_id=region_id,
                cell_id=cell_id,
            )
        raise LookupError("no qualified compatible capability")
