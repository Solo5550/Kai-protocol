from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .models import EvidenceBundle, GateStatus


@dataclass(frozen=True)
class EvidenceDecision:
    status: GateStatus
    reason: str
    score: float


class EvidenceGate:
    def evaluate(self, bundle: EvidenceBundle, *, min_sources: int = 1, max_age_seconds: float | None = None,
                 require_integrity: bool = True, require_lineage: bool = True) -> EvidenceDecision:
        if len(bundle.sources) < min_sources:
            bundle.status = "EVIDENCE_INSUFFICIENT"
            return EvidenceDecision(GateStatus.UNRESOLVED, "insufficient_sources", 0.0)
        if bundle.conflict_status not in {"NONE", "RESOLVED"}:
            bundle.status = "EVIDENCE_CONFLICTED"
            return EvidenceDecision(GateStatus.UNRESOLVED, "evidence_conflicted", 0.25)
        if require_integrity and not bundle.integrity.get("validated", False):
            bundle.status = "EVIDENCE_REJECTED"
            return EvidenceDecision(GateStatus.FAIL, "integrity_not_validated", 0.0)
        if require_lineage and any(not s.get("source_id") for s in bundle.sources):
            bundle.status = "EVIDENCE_REJECTED"
            return EvidenceDecision(GateStatus.FAIL, "source_lineage_missing", 0.0)
        if max_age_seconds is not None:
            now = datetime.now(timezone.utc)
            for source in bundle.sources:
                ts = source.get("observed_at")
                if not ts:
                    bundle.status = "EVIDENCE_REJECTED"
                    return EvidenceDecision(GateStatus.FAIL, "freshness_timestamp_missing", 0.0)
                age = (now - datetime.fromisoformat(ts)).total_seconds()
                if age > max_age_seconds:
                    bundle.status = "EVIDENCE_REJECTED"
                    return EvidenceDecision(GateStatus.FAIL, "stale_evidence", 0.1)
        bundle.status = "EVIDENCE_ACCEPTED"
        score = min(1.0, 0.6 + 0.1 * min(len(bundle.sources), 4))
        return EvidenceDecision(GateStatus.PASS, "accepted", score)
