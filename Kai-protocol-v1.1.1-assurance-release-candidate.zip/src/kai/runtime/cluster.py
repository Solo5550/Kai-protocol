from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from multiprocessing import get_context

Process = get_context("spawn").Process
from pathlib import Path
from typing import Any, Callable

from .models import Capability, CapabilityLifecycle, Execution, ExecutionState, utcnow
from .isolation import CapabilityManifest, HardIsolationExecutor, ManifestAuthority, ResultAttestor, serialize_handler


@dataclass
class NodeRecord:
    node_id: str
    region_id: str
    cell_id: str
    endpoint: str
    status: str = "REGISTERED"
    lease_id: str = field(default_factory=lambda: f"lease-{uuid.uuid4()}" )
    lease_expires_at: float = 0.0
    last_heartbeat: float = 0.0
    capabilities: set[str] = field(default_factory=set)
    version: str = "0.7.0"
    attestor_public_key_b64: str | None = None
    storage_status: str = "UNKNOWN"
    clock_offset_seconds: float = 0.0

    @property
    def healthy(self) -> bool:
        return self.status == "HEALTHY" and self.lease_expires_at > time.monotonic() and self.storage_status == "OK"


@dataclass(frozen=True)
class Lease:
    lease_id: str
    node_id: str
    expires_at: float


class LeaseManager:
    def __init__(self, ttl: float = 2.0) -> None:
        self.ttl = ttl
        self._leases: dict[str, Lease] = {}
        self._lock = threading.RLock()

    def grant(self, node_id: str) -> Lease:
        lease = Lease(f"lease-{uuid.uuid4()}", node_id, time.monotonic() + self.ttl)
        with self._lock:
            self._leases[node_id] = lease
        return lease

    def renew(self, node_id: str, lease_id: str) -> Lease:
        with self._lock:
            cur = self._leases.get(node_id)
            if not cur or cur.lease_id != lease_id or cur.expires_at <= time.monotonic():
                raise RuntimeError("lease_invalid_or_expired")
            lease = Lease(lease_id, node_id, time.monotonic() + self.ttl)
            self._leases[node_id] = lease
            return lease

    def valid(self, node_id: str, lease_id: str) -> bool:
        with self._lock:
            cur = self._leases.get(node_id)
            return bool(cur and cur.lease_id == lease_id and cur.expires_at > time.monotonic())

    def expire(self, node_id: str) -> None:
        with self._lock:
            self._leases.pop(node_id, None)


class PersistentNodeJournal:
    """Local authoritative node state with digest-protected persistence."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path = self.path.with_suffix(self.path.suffix + ".state.json")
        self.digest_path = self.path.with_suffix(self.path.suffix + ".sha256")
        self.backup_path = self.path.with_suffix(self.path.suffix + ".bak.json")
        self.backup_digest_path = self.path.with_suffix(self.path.suffix + ".bak.sha256")
        self.seen_path = self.path.with_suffix(self.path.suffix + ".replay.json")
        self._lock = threading.RLock()
        self.corrupt = False
        self.state: dict[str, Any] = self._load_state()
        self.seen: dict[str, dict[str, Any]] = self._load_seen()

    def _load_state(self) -> dict[str, Any]:
        if not self.state_path.exists() or not self.digest_path.exists():
            return {"node_state": "STARTING", "executions": {}, "updated_at": utcnow()}
        raw = self.state_path.read_bytes()
        expected = self.digest_path.read_text().strip()
        if hashlib.sha256(raw).hexdigest() != expected:
            self.corrupt = True
            return {"node_state": "STORAGE_CORRUPTION", "executions": {}, "updated_at": utcnow()}
        try:
            return json.loads(raw.decode())
        except json.JSONDecodeError:
            self.corrupt = True
            return {"node_state": "STORAGE_CORRUPTION", "executions": {}, "updated_at": utcnow()}

    def _load_seen(self) -> dict[str, dict[str, Any]]:
        if not self.seen_path.exists():
            return {}
        try:
            return json.loads(self.seen_path.read_text())
        except Exception:
            self.corrupt = True
            return {}

    def _write(self) -> None:
        raw = json.dumps(self.state, sort_keys=True, separators=(",", ":")).encode()
        tmp = self.state_path.with_suffix(self.state_path.suffix + ".tmp")
        tmp.write_bytes(raw)
        os.replace(tmp, self.state_path)
        self.digest_path.write_text(hashlib.sha256(raw).hexdigest())
        backup_tmp = self.backup_path.with_suffix(self.backup_path.suffix + ".tmp")
        backup_tmp.write_bytes(raw)
        os.replace(backup_tmp, self.backup_path)
        self.backup_digest_path.write_text(hashlib.sha256(raw).hexdigest())
        replay_raw = json.dumps(self.seen, sort_keys=True, separators=(",", ":")).encode()
        replay_tmp = self.seen_path.with_suffix(self.seen_path.suffix + ".tmp")
        replay_tmp.write_bytes(replay_raw)
        os.replace(replay_tmp, self.seen_path)

    def get_execution(self, execution_id: str) -> dict[str, Any] | None:
        with self._lock:
            return self.state.get("executions", {}).get(execution_id)

    def set_execution(self, execution_id: str, *, state: str, attempt: int, idempotency_key: str, node_id: str, region_id: str, cell_id: str, manifest_digest: str) -> None:
        with self._lock:
            self.state.setdefault("executions", {})[execution_id] = {
                "state": state, "attempt": attempt, "idempotency_key": idempotency_key,
                "node_id": node_id, "region_id": region_id, "cell_id": cell_id,
                "manifest_digest": manifest_digest, "updated_at": utcnow(),
            }
            self.state["updated_at"] = utcnow()
            self._write()

    def restore_backup(self) -> bool:
        with self._lock:
            if not self.backup_path.exists() or not self.backup_digest_path.exists():
                return False
            raw = self.backup_path.read_bytes()
            if hashlib.sha256(raw).hexdigest() != self.backup_digest_path.read_text().strip():
                return False
            tmp = self.state_path.with_suffix(self.state_path.suffix + ".restore.tmp")
            tmp.write_bytes(raw)
            os.replace(tmp, self.state_path)
            self.digest_path.write_text(hashlib.sha256(raw).hexdigest())
            self.corrupt = False
            return True

    def verify(self) -> bool:
        with self._lock:
            if not self.state_path.exists() or not self.digest_path.exists():
                return not self.corrupt
            raw = self.state_path.read_bytes()
            ok = hashlib.sha256(raw).hexdigest() == self.digest_path.read_text().strip()
            if not ok:
                self.corrupt = True
            return ok

    def accept_once(self, command_id: str, idempotency_key: str) -> tuple[bool, dict[str, Any] | None]:
        with self._lock:
            for record in self.seen.values():
                if record.get("idempotency_key") == idempotency_key:
                    return False, record
            key = f"{command_id}:{uuid.uuid4()}"
            record = {"command_id": command_id, "idempotency_key": idempotency_key, "accepted_at": utcnow()}
            self.seen[key] = record
            self._write()
            return True, record

    def corrupt_storage(self) -> None:
        raw = self.state_path.read_bytes() if self.state_path.exists() else b"{}"
        self.state_path.write_bytes(raw + b"corrupt")


class NodeProcess(Process):
    """Independent OS-process runtime node with TCP control and local journal."""

    def __init__(self, *, node_id: str, region_id: str, cell_id: str, host: str, port: int,
                 capability_specs: dict[str, dict[str, Any]], store_path: str, manifest_public_key: bytes, attestor_key_path: str | None = None, control_auth: bytes | None = None) -> None:
        super().__init__(daemon=True)
        self.node_id = node_id
        self.region_id = region_id
        self.cell_id = cell_id
        self.host = host
        self.port = port
        self.capability_specs = capability_specs
        self.store_path = store_path
        self.manifest_public_key = manifest_public_key
        self.attestor_key_path = attestor_key_path or f"{store_path}.attestor.key"
        self.control_auth = control_auth or os.urandom(32)

    def run(self) -> None:  # pragma: no cover - executed in child process
        import cloudpickle
        journal = PersistentNodeJournal(self.store_path)
        attestor = ResultAttestor.load_or_create(self.attestor_key_path)
        authority = ManifestAuthority.public_only(self.manifest_public_key)
        isolation = HardIsolationExecutor(authority=authority, attestor=attestor)
        clock_offset = 0.0
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.listen(32)
        server.settimeout(0.25)
        while True:
            try:
                conn, _ = server.accept()
            except socket.timeout:
                continue
            try:
                command = json.loads(self._recv_all(conn).decode())
                auth = command.pop("auth", None)
                expected_auth = base64.urlsafe_b64encode(hmac.new(self.control_auth, json.dumps(command, sort_keys=True, default=str, separators=(",", ":")).encode(), hashlib.sha256).digest()).decode().rstrip("=")
                if not auth or not hmac.compare_digest(str(auth), expected_auth):
                    self._send(conn, {"ok": False, "error": "control_auth_required_or_invalid"})
                    continue
                action = command.get("action")
                if action == "heartbeat":
                    journal_ok = journal.verify() and not journal.corrupt
                    response = {
                        "ok": True, "node_id": self.node_id, "region_id": self.region_id, "cell_id": self.cell_id,
                        "status": "HEALTHY" if journal_ok and isolation.available else "QUARANTINED",
                        "storage_status": "OK" if journal_ok else "CORRUPT",
                        "pid": os.getpid(), "clock_offset_seconds": clock_offset,
                        "attestor_public_key_b64": base64.urlsafe_b64encode(attestor.public_key).decode().rstrip("="),
                        "timestamp": utcnow(),
                    }
                elif action == "set_clock_offset":
                    clock_offset = float(command.get("seconds", 0.0))
                    response = {"ok": True, "clock_offset_seconds": clock_offset}
                elif action == "set_dependency":
                    dependency = str(command["dependency"])
                    available = bool(command["available"])
                    journal.state.setdefault("dependencies", {})[dependency] = available
                    journal._write()
                    response = {"ok": True, "dependency": dependency, "available": available}
                elif action == "corrupt_storage":
                    journal.corrupt_storage()
                    response = {"ok": True, "status": "CORRUPTED"}
                elif action == "stop":
                    response = {"ok": True, "status": "STOPPING"}
                    self._send(conn, response)
                    break
                elif action == "execute":
                    response = self._execute(command, journal, isolation, attestor, authority, cloudpickle)
                elif action == "get_execution":
                    response = {"ok": True, "execution": journal.get_execution(command["execution_id"])}
                elif action == "restore_backup":
                    ok = journal.restore_backup()
                    response = {"ok": ok, "status": "RESTORED" if ok else "RESTORE_UNAVAILABLE"}
                elif action == "partial_commit":
                    execution_id = command["execution_id"]
                    journal.set_execution(execution_id, state=ExecutionState.PARTIALLY_COMPLETED.value, attempt=1,
                                          idempotency_key=command["idempotency_key"], node_id=self.node_id,
                                          region_id=self.region_id, cell_id=self.cell_id, manifest_digest=command["manifest_digest"])
                    # Deliberately terminate node after a durable partial state and before ACK.
                    os._exit(75)
                else:
                    response = {"ok": False, "error": "unknown_action"}
                self._send(conn, response)
            except Exception as exc:
                try: self._send(conn, {"ok": False, "error": f"{type(exc).__name__}:{exc}"})
                except Exception: pass
            finally:
                conn.close()
        server.close()

    def _execute(self, command: dict[str, Any], journal: PersistentNodeJournal, isolation: HardIsolationExecutor, attestor: ResultAttestor, authority: ManifestAuthority, cloudpickle) -> dict[str, Any]:
        execution_id = command["execution_id"]
        idem = command["idempotency_key"]
        cmd_id = command["command_id"]
        if journal.corrupt or not journal.verify():
            return {"ok": False, "error": "STORAGE_CORRUPTION", "state": "QUARANTINED"}
        accepted, prior = journal.accept_once(cmd_id, idem)
        if not accepted:
            cached = (prior or {}).get("response")
            if cached:
                return {**cached, "duplicate": True, "prior": prior}
            return {"ok": True, "duplicate": True, "prior": prior, "state": journal.state.get("executions", {}).get(execution_id, {}).get("state")}
        spec = self.capability_specs.get(command["capability_id"])
        if not spec:
            return {"ok": False, "error": "CAPABILITY_NOT_REGISTERED"}
        for dependency in command.get("dependencies", []):
            if not journal.state.get("dependencies", {}).get(dependency, True):
                return {"ok": False, "error": "DEPENDENCY_UNAVAILABLE", "dependency": dependency, "state": ExecutionState.RECOVERY_PENDING.value}
        manifest = _manifest_from_dict(spec["manifest"])
        if not manifest.verify(authority.public_key):
            return {"ok": False, "error": "MANIFEST_SIGNATURE_INVALID"}
        handler_blob = base64.urlsafe_b64decode(spec["handler_blob"] + "=" * (-len(spec["handler_blob"]) % 4))
        if hashlib.sha256(handler_blob).hexdigest() != manifest.code_sha256:
            return {"ok": False, "error": "CAPABILITY_ARTIFACT_DIGEST_MISMATCH"}
        handler = cloudpickle.loads(handler_blob)
        cap = Capability(capability_id=manifest.capability_id, implementation_id=manifest.implementation_id,
                         semantic_version=manifest.capability_version, owner=manifest.owner,
                         required_permissions=list(manifest.requested_permissions), lifecycle=CapabilityLifecycle.AVAILABLE)
        execution = Execution(execution_id=execution_id, input_data=command.get("payload", {}), region_id=self.region_id,
                              cell_id=self.cell_id, actor_id=command.get("actor_id", "global-control"),
                              idempotency_key=idem, capability_ref={"id": cap.capability_id, "version": cap.semantic_version, "implementation_id": cap.implementation_id})
        journal.set_execution(execution_id, state=ExecutionState.RUNNING.value, attempt=int(command.get("attempt", 1)),
                              idempotency_key=idem, node_id=self.node_id, region_id=self.region_id, cell_id=self.cell_id, manifest_digest=manifest.digest)
        if command.get("partial", False):
            # Deliberately model an uncertain crash after durable partial progress and before ACK.
            journal.set_execution(execution_id, state=ExecutionState.PARTIALLY_COMPLETED.value, attempt=int(command.get("attempt", 1)),
                                  idempotency_key=idem, node_id=self.node_id, region_id=self.region_id, cell_id=self.cell_id, manifest_digest=manifest.digest)
            os._exit(75)
        result = isolation.execute(execution=execution, capability=cap, handler=handler, payload=command.get("payload", {}), manifest=manifest, timeout=command.get("timeout"))
        terminal = ExecutionState.VERIFIED.value if result.status == "SUCCESS" and command.get("verified", False) else (ExecutionState.OBSERVING.value if result.status == "SUCCESS" else ExecutionState.FAILED.value)
        journal.set_execution(execution_id, state=terminal, attempt=int(command.get("attempt", 1)), idempotency_key=idem,
                              node_id=self.node_id, region_id=self.region_id, cell_id=self.cell_id, manifest_digest=manifest.digest)
        response = {"ok": True, "duplicate": False, "state": terminal, "result": asdict(result),
                    "provenance": {"execution_id": execution_id, "node_id": self.node_id, "region_id": self.region_id,
                                    "cell_id": self.cell_id, "manifest_digest": manifest.digest, "command_id": cmd_id,
                                    "timestamp": utcnow()}}
        for record in journal.seen.values():
            if record.get("idempotency_key") == idem:
                record["response"] = response
                break
        journal._write()
        return response

    @staticmethod
    def _recv_all(conn: socket.socket) -> bytes:
        chunks = []
        while True:
            data = conn.recv(1024 * 1024)
            if not data: return b"".join(chunks)
            chunks.append(data)
            if len(data) < 1024 * 1024: return b"".join(chunks)

    @staticmethod
    def _send(conn: socket.socket, obj: dict[str, Any]) -> None:
        conn.sendall(json.dumps(obj, sort_keys=True, default=str).encode())


def _manifest_from_dict(data: dict[str, Any]) -> CapabilityManifest:
    from .isolation import ResourceQuota, PermissionBoundary
    raw = dict(data)
    raw["resource_quota"] = ResourceQuota(**raw["resource_quota"])
    raw["permission_boundary"] = PermissionBoundary(**raw["permission_boundary"])
    return CapabilityManifest(**raw)


class NodeRegistry:
    def __init__(self) -> None:
        self.nodes: dict[str, NodeRecord] = {}
        self._lock = threading.RLock()

    def register(self, node_id: str, region_id: str, cell_id: str, endpoint: str, capabilities: set[str], *, version: str = "0.7.0") -> NodeRecord:
        with self._lock:
            rec = NodeRecord(node_id=node_id, region_id=region_id, cell_id=cell_id, endpoint=endpoint,
                             capabilities=set(capabilities), version=version, last_heartbeat=time.monotonic())
            self.nodes[node_id] = rec
            return rec

    def update_heartbeat(self, node_id: str, payload: dict[str, Any], lease: Lease) -> NodeRecord:
        with self._lock:
            node = self.nodes[node_id]
            node.last_heartbeat = time.monotonic()
            node.lease_id = lease.lease_id
            node.lease_expires_at = lease.expires_at
            node.status = payload.get("status", "HEALTHY")
            node.storage_status = payload.get("storage_status", "UNKNOWN")
            node.attestor_public_key_b64 = payload.get("attestor_public_key_b64", node.attestor_public_key_b64)
            node.clock_offset_seconds = float(payload.get("clock_offset_seconds", 0.0))
            return node

    def mark_failed(self, node_id: str, reason: str) -> None:
        with self._lock:
            self.nodes[node_id].status = f"FAILED:{reason}"


class NetworkTransport:
    def __init__(self) -> None:
        self.partitioned: set[str] = set()
        self.delay: dict[str, float] = {}
        self.drop_rate: dict[str, float] = {}
        self._lock = threading.RLock()

    def set_partition(self, node_id: str, value: bool) -> None:
        with self._lock:
            (self.partitioned.add(node_id) if value else self.partitioned.discard(node_id))

    def set_delay(self, node_id: str, seconds: float) -> None:
        with self._lock: self.delay[node_id] = max(0.0, seconds)

    def set_drop_rate(self, node_id: str, rate: float) -> None:
        with self._lock: self.drop_rate[node_id] = min(1.0, max(0.0, rate))

    def request(self, node: NodeRecord, command: dict[str, Any], *, timeout: float = 1.0, auth_key: bytes | None = None) -> dict[str, Any]:
        with self._lock:
            if node.node_id in self.partitioned:
                raise TimeoutError("network_partition")
            delay = self.delay.get(node.node_id, 0.0)
            drop = self.drop_rate.get(node.node_id, 0.0)
        if delay: time.sleep(delay)
        if drop >= 1.0: raise TimeoutError("packet_loss")
        host, port = node.endpoint.rsplit(":", 1)
        outbound = dict(command)
        if auth_key is not None:
            signing = json.dumps(outbound, sort_keys=True, default=str, separators=(",", ":")).encode()
            outbound["auth"] = base64.urlsafe_b64encode(hmac.new(auth_key, signing, hashlib.sha256).digest()).decode().rstrip("=")
        with socket.create_connection((host, int(port)), timeout=timeout) as sock:
            sock.sendall(json.dumps(outbound, sort_keys=True, default=str).encode())
            sock.shutdown(socket.SHUT_WR)
            data = sock.recv(16 * 1024 * 1024)
            if not data: raise ConnectionError("empty_response")
            return json.loads(data.decode())


class FailureDetector:
    def __init__(self, registry: NodeRegistry, leases: LeaseManager) -> None:
        self.registry = registry; self.leases = leases

    def scan(self) -> list[str]:
        failed = []; now = time.monotonic()
        for node_id, node in list(self.registry.nodes.items()):
            lease_valid = self.leases.valid(node_id, node.lease_id)
            heartbeat_stale = node.last_heartbeat <= now - self.leases.ttl
            if node.lease_expires_at <= now or not lease_valid or heartbeat_stale:
                self.registry.mark_failed(node_id, "heartbeat_timeout")
                self.leases.expire(node_id)
                failed.append(node_id)
        return failed


class StateReconciler:
    def reconcile(self, desired: dict[str, Any], observed: dict[str, Any]) -> dict[str, Any]:
        keys = ("state", "attempt", "idempotency_key")
        if observed.get("state") == ExecutionState.PARTIALLY_COMPLETED.value:
            return {"status": "RECOVERY_REQUIRED", "desired": desired, "observed": observed, "action": "COMPENSATE_OR_REVIEW"}
        if all(desired.get(k) == observed.get(k) for k in keys):
            return {"status": "IN_SYNC", **{k: observed.get(k) for k in keys}}
        return {"status": "DRIFT", "desired": desired, "observed": observed, "action": "RECOVERY_PENDING"}


class GlobalControlPlane:
    def __init__(self, *, manifest_authority: ManifestAuthority | None = None) -> None:
        self.manifest_authority = manifest_authority or ManifestAuthority()
        self.registry = NodeRegistry()
        self.leases = LeaseManager()
        self.transport = NetworkTransport()
        self.detector = FailureDetector(self.registry, self.leases)
        self.reconciler = StateReconciler()
        self._processes: dict[str, Process] = {}
        self.desired: dict[str, dict[str, Any]] = {}
        self.observed: dict[str, dict[str, Any]] = {}
        self.provenance: dict[str, dict[str, Any]] = {}
        self.manifests: dict[str, CapabilityManifest] = {}
        self._node_configs: dict[str, dict[str, Any]] = {}

    def _node_request(self, node_id: str, command: dict[str, Any], *, timeout: float = 1.0) -> dict[str, Any]:
        node = self.registry.nodes[node_id]
        proc = self._processes.get(node_id)
        auth_key = getattr(proc, "control_auth", None)
        if auth_key is None:
            raise PermissionError("node_control_auth_unavailable")
        return self.transport.request(node, command, timeout=timeout, auth_key=auth_key)


    def register_process_node(self, node: NodeProcess, node_id: str, region_id: str, cell_id: str, endpoint: str, capabilities: set[str]) -> NodeRecord:
        node.start()
        deadline = time.monotonic() + 3
        while True:
            try:
                hb = self.transport.request(NodeRecord(node_id, region_id, cell_id, endpoint), {"action": "heartbeat"}, timeout=0.2, auth_key=node.control_auth)
                break
            except OSError:
                if time.monotonic() > deadline: node.terminate(); node.join(timeout=1); raise
                time.sleep(0.05)
        rec = self.registry.register(node_id, region_id, cell_id, endpoint, capabilities)
        rec.attestor_public_key_b64 = hb.get("attestor_public_key_b64")
        rec.storage_status = hb.get("storage_status", "UNKNOWN")
        rec.status = hb.get("status", "REGISTERED")
        lease = self.leases.grant(node_id)
        self.registry.update_heartbeat(node_id, hb, lease)
        self._processes[node_id] = node
        self._node_configs[node_id] = {
            "node_id": node_id, "region_id": region_id, "cell_id": cell_id, "host": node.host, "port": node.port,
            "capability_specs": node.capability_specs, "store_path": node.store_path,
            "manifest_public_key": node.manifest_public_key, "attestor_key_path": node.attestor_key_path, "control_auth": node.control_auth,
        }
        return rec

    def heartbeat(self, node_id: str) -> dict[str, Any]:
        node = self.registry.nodes[node_id]
        reply = self._node_request(node.node_id, {"action": "heartbeat"})
        lease = self.leases.renew(node_id, node.lease_id)
        self.registry.update_heartbeat(node_id, reply, lease)
        return reply

    def execute_capability(self, *, node_id: str, capability: Capability, handler: Callable[[dict[str, Any]], Any], manifest: CapabilityManifest,
                           payload: dict[str, Any], execution_id: str | None = None, idempotency_key: str | None = None,
                           command_id: str | None = None, timeout: float = 5.0, actor_id: str = "global-control",
                           verified: bool = False, dependencies: list[str] | None = None, partial: bool = False) -> dict[str, Any]:
        node = self.registry.nodes[node_id]
        if not self.leases.valid(node_id, node.lease_id):
            raise RuntimeError("node_lease_invalid")
        if not manifest.verify(self.manifest_authority.public_key):
            raise PermissionError("global_manifest_verification_failed")
        if manifest.capability_id != capability.capability_id or manifest.implementation_id != capability.implementation_id:
            raise PermissionError("manifest_binding_mismatch")
        blob = serialize_handler(handler)
        digest = hashlib.sha256(blob).hexdigest()
        if digest != manifest.code_sha256:
            raise PermissionError("manifest_code_digest_mismatch")
        execution_id = execution_id or f"exec-{uuid.uuid4()}"
        idem = idempotency_key or f"idem-{execution_id}"
        command_id = command_id or f"cmd-{uuid.uuid4()}"
        desired = {"state": ExecutionState.PARTIALLY_COMPLETED.value if partial else ExecutionState.RUNNING.value, "attempt": 1, "idempotency_key": idem, "node_id": node_id}
        self.desired[execution_id] = desired
        command = {
            "action": "execute", "execution_id": execution_id, "command_id": command_id, "idempotency_key": idem,
            "capability_id": capability.capability_id, "actor_id": actor_id, "payload": payload, "timeout": timeout,
            "attempt": 1, "verified": verified, "dependencies": dependencies or [],
            "manifest_digest": manifest.digest, "partial": partial,
        }
        self.manifests[execution_id] = manifest
        # Node receives an already-signed manifest and the exact implementation artifact bytes.
        if capability.capability_id not in node.capabilities:
            raise PermissionError("capability_not_registered_on_node")
        # Capability specs are immutable for a process; exact manifest/artifact must match registration.
        node_spec = getattr(self._processes[node_id], "capability_specs", {}).get(capability.capability_id)
        if node_spec and node_spec.get("manifest", {}).get("signature") != manifest.signature:
            raise PermissionError("node_manifest_mismatch")
        try:
            reply = self._node_request(node.node_id, {**command}, timeout=max(2.0, float(timeout) + 1.0))
        except (TimeoutError, OSError, ConnectionError):
            self.observed[execution_id] = {"state": ExecutionState.RECOVERY_PENDING.value, "attempt": 1, "idempotency_key": idem}
            self.desired[execution_id]["state"] = ExecutionState.RECOVERY_PENDING.value
            raise
        if not reply.get("ok"):
            raise RuntimeError(reply.get("error", "node_execution_failed"))
        if reply.get("duplicate"):
            self.observed[execution_id] = {"state": reply.get("state"), "attempt": 1, "idempotency_key": idem}
            return reply
        result = reply.get("result")
        if result is not None:
            from .isolation import AttestedResult
            attested = AttestedResult(**result)
            pub = base64.urlsafe_b64decode((node.attestor_public_key_b64 or "") + "=" * (-len(node.attestor_public_key_b64 or "") % 4))
            if not ResultAttestor.verify_with_public_key(attested, pub):
                raise PermissionError("attestation_verification_failed")
            reply["attestation_verified"] = True
        state = reply.get("state", ExecutionState.FAILED.value)
        self.observed[execution_id] = {"state": state, "attempt": 1, "idempotency_key": idem}
        self.provenance[execution_id] = reply.get("provenance", {})
        return reply

    def restart_node(self, node_id: str) -> NodeRecord:
        old = self._processes.get(node_id)
        if old and old.is_alive():
            old.terminate(); old.join(timeout=1)
        cfg = self._node_configs[node_id]
        node = NodeProcess(**cfg)
        self.registry.nodes[node_id].status = "STARTING"
        self._processes[node_id] = node
        node.start()
        deadline = time.monotonic() + 3
        while True:
            try:
                hb = self._node_request(node_id, {"action": "heartbeat"}, timeout=0.2)
                break
            except OSError:
                if time.monotonic() > deadline:
                    node.terminate(); node.join(timeout=1)
                    raise
                time.sleep(0.05)
        lease = self.leases.grant(node_id)
        self.registry.update_heartbeat(node_id, hb, lease)
        return self.registry.nodes[node_id]

    def recover_execution(self, execution_id: str) -> dict[str, Any]:
        desired = self.desired.get(execution_id)
        if not desired:
            raise KeyError(execution_id)
        node = self.registry.nodes[desired["node_id"]]
        reply = self._node_request(node.node_id, {"action": "get_execution", "execution_id": execution_id})
        observed = reply.get("execution") or {}
        self.observed[execution_id] = {
            "state": observed.get("state", ExecutionState.RECOVERY_PENDING.value),
            "attempt": observed.get("attempt", desired.get("attempt", 1)),
            "idempotency_key": observed.get("idempotency_key", desired.get("idempotency_key")),
            "manifest_digest": observed.get("manifest_digest"),
        }
        return self.reconcile(execution_id)

    def set_node_dependency(self, node_id: str, dependency: str, available: bool) -> dict[str, Any]:
        return self._node_request(node_id, {"action": "set_dependency", "dependency": dependency, "available": available})

    def set_clock_offset(self, node_id: str, seconds: float) -> dict[str, Any]:
        return self._node_request(node_id, {"action": "set_clock_offset", "seconds": seconds})

    def restore_node_storage(self, node_id: str) -> dict[str, Any]:
        reply = self._node_request(node_id, {"action": "restore_backup"})
        if reply.get("ok"):
            self.registry.nodes[node_id].storage_status = "OK"
            self.registry.nodes[node_id].status = "HEALTHY"
        return reply

    def corrupt_node_storage(self, node_id: str) -> dict[str, Any]:
        reply = self._node_request(node_id, {"action": "corrupt_storage"})
        self.registry.nodes[node_id].storage_status = "CORRUPT"
        self.registry.nodes[node_id].status = "QUARANTINED"
        return reply

    def reconcile(self, execution_id: str, observed: dict[str, Any] | None = None) -> dict[str, Any]:
        desired = self.desired[execution_id]
        current = observed or self.observed.get(execution_id, {})
        return self.reconciler.reconcile(desired, current)

    def mark_recovery_pending_for_node(self, node_id: str) -> list[str]:
        affected = []
        for execution_id, state in self.desired.items():
            if state.get("node_id") == node_id and state.get("state") in {ExecutionState.RUNNING.value, ExecutionState.RECOVERY_PENDING.value}:
                state["state"] = ExecutionState.RECOVERY_PENDING.value
                self.observed[execution_id] = {"state": ExecutionState.RECOVERY_PENDING.value, "attempt": state.get("attempt", 1), "idempotency_key": state.get("idempotency_key")}
                affected.append(execution_id)
        return affected

    def kill_node(self, node_id: str) -> list[str]:
        process = self._processes[node_id]
        if process.is_alive():
            process.terminate(); process.join(timeout=1)
        self.registry.mark_failed(node_id, "killed")
        self.leases.expire(node_id)
        return self.mark_recovery_pending_for_node(node_id)

    def stop_all(self) -> None:
        for node_id, process in list(self._processes.items()):
            if process.is_alive():
                process.terminate(); process.join(timeout=1)
            self.registry.mark_failed(node_id, "stopped")


# Backward-compatible name used by the v0.6 reference tests.
JsonLineNode = NodeProcess
