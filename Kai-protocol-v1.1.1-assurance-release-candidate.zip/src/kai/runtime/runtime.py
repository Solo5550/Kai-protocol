from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .analysis import AnalysisRecord
from .artifacts import ArtifactStore
from .capability import CapabilityRegistry, CapabilityResolver
from .contracts import ContractEngine
from .evidence import EvidenceGate
from .experience import CalibrationEngine, ExperienceEngine
from .federation import Cell, PlacementEngine, PlacementRequest, Region, Scheduler
from .identity import IdentityContext
from .kernel import ExecutionKernel, KernelRun
from .executor import HardIsolationKernelExecutor
from .isolation import AutonomyGate, HardIsolationExecutor, ManifestAuthority, ResultAttestor
from .models import (
    Capability, Claim, ClaimStatus, Contract, Decision, EvidenceBundle, Execution, ExecutionState,
    Observation, Plan, PlanNode, Policy, ProofRecord, VerificationStatus,
)
from .observability import ObservationBus, ObservabilityRecord
from .planning import HypothesisSet, hypothesis_from_evidence, validate_plan
from .policy import PolicyEngine, SignedPolicySnapshot
from .proof import DecisionEngine, ProofEngine, ProofLedger
from .provenance import ProvenanceEngine
from .store import RuntimeStore
from .verification import VerificationEngine


@dataclass
class GoldenRun:
    execution: Execution
    decision: Decision
    proof: ProofRecord | None
    kernel: KernelRun


class KaiRuntime:
    """Reference implementation of the canonical governed-execution Golden Path."""

    def __init__(self, *, data_dir: str | Path | None = None, regions: dict[str, Region] | None = None, executor_start_method: str | None = None) -> None:
        root = Path(data_dir) if data_dir else Path.cwd() / ".kai-runtime"
        root.mkdir(parents=True, exist_ok=True)
        self.store = RuntimeStore(root / "runtime.db")
        self.artifacts = ArtifactStore(root / "artifacts", self.store)
        self.observations = ObservationBus(self.store)
        self.provenance = ProvenanceEngine(self.store)
        self.evidence_gate = EvidenceGate()
        self.contracts = ContractEngine()
        self.policy_engine = PolicyEngine()
        self.registry = CapabilityRegistry()
        self.resolver = CapabilityResolver(self.registry)
        self.verifier = VerificationEngine(self.store)
        self.proof_ledger = ProofLedger(self.store)
        self.proof = ProofEngine(self.proof_ledger, self.store)
        self.experience = ExperienceEngine(self.store)
        self.calibration = CalibrationEngine()
        self.decisions = DecisionEngine()
        self.manifest_authority = ManifestAuthority()
        self.isolation_executor = HardIsolationExecutor(authority=self.manifest_authority)
        # The governed Runtime has one execution path: hard-isolated execution.
        # The legacy ProcessExecutor remains available only to low-level kernel unit tests.
        if not self.isolation_executor.available:
            raise RuntimeError(f"hard_isolation_unavailable:{self.isolation_executor.block_reason}")
        self.kernel = ExecutionKernel(store=self.store, executor=HardIsolationKernelExecutor(authority=self.manifest_authority, isolation=self.isolation_executor))
        self.regions = regions or self._default_regions()
        self.placement = PlacementEngine(self.regions)
        self.scheduler = Scheduler(self.regions)

    def _default_regions(self) -> dict[str, Region]:
        region = Region("local")
        region.add_cell(Cell("cell-local", "local", capacity_units=64, capability_ids=set()))
        return {region.region_id: region}

    def install_capability(self, capability: Capability, handler: Callable[[dict[str, Any]], Any], *, qualification: dict[str, bool] | None = None) -> None:
        self.registry.discover(capability, handler)
        self.registry.register(capability.capability_id)
        self.registry.qualify(capability.capability_id, **(qualification or {}))
        for region in self.regions.values():
            for cell in region.cells.values():
                cell.capability_ids.add(capability.capability_id)

    def execute(
        self, *, objective: str, input_data: dict[str, Any], contract: Contract, policy: Policy,
        capability_id: str, evidence: EvidenceBundle, plan: Plan, handler: Callable[[dict[str, Any]], Any],
        expected_outcome: Any = None, verification_criteria=None, claim_statement: str | None = None,
        permissions: set[str] | None = None, region_id: str = "local", actor_id: str = "runtime",
        resource_units: float = 1.0, risk: float = 0.0, timeout: float | None = 5.0,
        side_effect: bool = False, effect_request: dict[str, Any] | None = None, autonomy_level: str = "L4",
    ) -> GoldenRun:
        try:
            AutonomyGate.authorize(autonomy_level)
        except Exception:
            # Store no runnable state for blocked autonomy levels; the Gate is authoritative.
            raise
        identity = IdentityContext.root(region_id=region_id, cell_id=next(iter(self.regions[region_id].cells)), actor_id=actor_id)
        execution = Execution(
            tenant_id=identity.tenant_id, namespace_id=identity.namespace_id, run_id=identity.run_id,
            execution_id=identity.execution_id, parent_execution_id=None, root_execution_id=identity.root_execution_id,
            trace_id=identity.trace_id, span_id=identity.span_id, causal_parent_id=None, region_id=region_id,
            cell_id=identity.cell_id, actor_id=actor_id, objective=objective, input_data=input_data,
            idempotency_key=f"idem-{identity.execution_id}", policy_snapshot_ref=f"{policy.policy_id}@{policy.semantic_version}",
            contract_ref={"id": contract.id, "version": contract.version},
        )
        self.store.create_execution(execution)
        envelope = self.kernel  # canonical kernel is the only execution owner; envelope is attached by kernel on run.
        del envelope

        self._transition(execution, "CONTRACT_VALIDATED", expected_state=ExecutionState.CREATED)
        if not self.contracts.validate_execution(execution, contract).ok or not self.contracts.validate_plan(plan).ok:
            raise RuntimeError("contract or plan validation failed")

        self._transition(execution, "EVIDENCE_REQUESTED", expected_state=ExecutionState.READY)
        evidence_decision = self.evidence_gate.evaluate(evidence)
        if evidence_decision.status.value != "PASS":
            raise RuntimeError(f"evidence_gate:{evidence_decision.reason}")
        self.store.put("evidence", evidence)
        self._transition(execution, "EVIDENCE_ACCEPTED", expected_state=ExecutionState.EVIDENCE_PENDING)

        self._transition(execution, "PLAN_STARTED", expected_state=ExecutionState.EVIDENCE_ACCEPTED)
        validate_plan(plan)
        self.store.put("plan", plan)
        self._transition(execution, "PLAN_ACCEPTED", expected_state=ExecutionState.PLANNING)

        cap = self.registry.get(capability_id)
        binding = self.resolver.resolve(requirement={"capability_id": capability_id, "requirement_id": capability_id}, contract=contract,
                                        region_id=region_id, cell_id=identity.cell_id, policy_version=policy.semantic_version)
        resolved_handler = self.registry.handler(binding.implementation_id)
        self.store.append_event(execution.execution_id, "CAPABILITY_RESOLVED", {
            "capability_id": binding.capability_id,
            "capability_version": binding.capability_version,
            "implementation_id": binding.implementation_id,
            "region_id": binding.region_id,
            "cell_id": binding.cell_id,
        })
        if handler is not resolved_handler:
            self._transition(execution, "BLOCK", expected_state=ExecutionState.PLAN_ACCEPTED)
            raise PermissionError("handler_mismatch_with_resolved_capability")
        self.store.append_event(execution.execution_id, "CAPABILITY_HANDLER_BOUND", {"implementation_id": binding.implementation_id})
        execution.capability_ref = {"id": binding.capability_id, "version": binding.capability_version, "implementation_id": binding.implementation_id}
        granted_permissions = set(permissions or set())
        try:
            manifest = self.kernel.executor.bind(execution_id=execution.execution_id, capability=cap, contract_id=contract.id, contract_version=contract.version,
                                                 handler=resolved_handler, permissions=granted_permissions)
        except Exception as exc:
            self._transition(execution, "BLOCK", expected_state=ExecutionState.PLAN_ACCEPTED)
            raise PermissionError(f"manifest_admission_blocked:{exc}") from exc
        self.store.append_event(execution.execution_id, "CAPABILITY_MANIFEST_SIGNED", {"manifest_digest": manifest.digest, "code_sha256": manifest.code_sha256})
        policy_check = self.policy_engine.decide(execution=execution, capability=cap, policy=policy, permissions=granted_permissions, operation="execute")
        self.store.append_event(execution.execution_id, "POLICY_EVALUATED", {"allowed": policy_check.allowed, "reason": policy_check.reason, "manifest_digest": manifest.digest})
        if not policy_check.allowed:
            self._transition(execution, "BLOCK", expected_state=ExecutionState.PLAN_ACCEPTED)
            raise PermissionError(policy_check.reason)

        decision = self.placement.select(PlacementRequest(execution.execution_id, capability_id, preferred_region=region_id,
                                                          data_region=input_data.get("data_region"), allowed_regions=tuple(policy.allowed_regions),
                                                          denied_regions=tuple(policy.denied_regions), resource_units=resource_units),
                                        policy_ref=f"{policy.policy_id}@{policy.semantic_version}", capability_ref=f"{capability_id}@{cap.semantic_version}")
        self.scheduler.set_desired(decision)
        self.scheduler.observe_actual(execution.execution_id, region_id, identity.cell_id)
        self.scheduler.reconcile(execution.execution_id)
        execution.region_id, execution.cell_id = decision.selected_region, decision.selected_cell
        execution.policy_snapshot_ref = SignedPolicySnapshot(policy).ref
        execution.policy_context["autonomy_level"] = autonomy_level
        execution.policy_context["manifest_digest"] = manifest.digest
        adm = self.kernel.admission.admit(units=resource_units, risk=risk)
        if not adm.allowed:
            self._transition(execution, "BLOCK", expected_state=ExecutionState.PLAN_ACCEPTED)
            raise RuntimeError(f"admission:{adm.reason}")
        try:
            self._transition(execution, "ADMIT", expected_state=ExecutionState.PLAN_ACCEPTED)
            if side_effect:
                from .failure import EffectLedger
                request = effect_request or input_data
                self._effect = EffectLedger(self.store)
                effect, duplicate = self._effect.begin(execution_id=execution.execution_id, idempotency_key=execution.idempotency_key,
                                                        target=request.get("target", "runtime"), operation=request.get("operation", "execute"),
                                                        request=request, authorization_ref="policy-authorized", policy_ref=execution.policy_snapshot_ref)
                if duplicate:
                    kernel_run = KernelRun(execution, self.kernel_run_envelope(execution, contract, cap), "SUCCESS", output={"deduplicated": True}, events=self.store.events(execution.execution_id))
                else:
                    kernel_run = self.kernel.run_authorized(execution=execution, contract=contract, handler=handler, timeout=timeout, envelope=self.kernel_run_envelope(execution, contract, cap))
                    self._effect.complete(effect["effect_id"], status="COMPLETED" if kernel_run.status == "SUCCESS" else "FAILED")
            else:
                kernel_run = self.kernel.run_authorized(execution=execution, contract=contract, handler=handler, timeout=timeout, envelope=self.kernel_run_envelope(execution, contract, cap))
        finally:
            if self.kernel.admission.active > 0:
                self.kernel.admission.release(units=resource_units)

        execution = kernel_run.execution
        attestation = getattr(getattr(self.kernel, "executor", None), "last_attestation", None)
        if attestation:
            self.store.append_event(execution.execution_id, "EXECUTION_ATTESTED", {"attestation_digest": attestation.get("attestation_digest"), "manifest_digest": attestation.get("manifest_digest"), "worker_pid": attestation.get("worker_pid")})
        if kernel_run.status != "SUCCESS":
            execution.failure_ref = f"execution-failure-{execution.execution_id}"
            self.store.append_event(execution.execution_id, "EXECUTION_TERMINAL_FAILURE", {"status": kernel_run.status, "error": kernel_run.error, "attestation_digest": (attestation or {}).get("attestation_digest")})
            failure_decision = self.decisions.decide(run_id=execution.run_id, objective=objective, selected_action={"capability": capability_id},
                                                     evidence_refs=[evidence.evidence_id], verification_refs=[], proof_refs=[],
                                                     expected_outcome=expected_outcome, observed_outcome=kernel_run.output,
                                                     policy_ref=execution.policy_snapshot_ref, contract_ref=contract.id)
            failure_decision.decision_id = f"decision-{execution.execution_id}"
            failure_decision.object_id = failure_decision.decision_id
            self.store.put("decision", failure_decision)
            execution.decision_ref = failure_decision.object_id
            return GoldenRun(execution=execution, decision=failure_decision, proof=None, kernel=kernel_run)
        observation = Observation(observation_id=f"observation-{execution.execution_id}", execution_id=execution.execution_id,
                                  source="runtime", subject=objective, metric_or_fact="output", value=kernel_run.output,
                                  confidence=1.0, provenance_ref=f"prov-{execution.execution_id}-observation")
        self.store.put("observation", observation)
        execution.observed_outcome = kernel_run.output
        self._transition(execution, "OBSERVATION_READY", expected_state=ExecutionState.VERIFICATION_PENDING) if execution.state is ExecutionState.OBSERVING else None
        if execution.state is ExecutionState.OBSERVING:
            self._transition(execution, "OBSERVATION_READY", expected_state=ExecutionState.OBSERVING)
        # Kernel normally reaches VERIFICATION_PENDING; tolerate both direct representations.
        if execution.state is ExecutionState.OBSERVING:
            self._transition(execution, "OBSERVATION_READY", expected_state=ExecutionState.OBSERVING)
        ver = self.verifier.verify(execution_id=execution.execution_id, target=objective, expected=expected_outcome,
                                   observed=kernel_run.output, criteria=verification_criteria, evidence_refs=[evidence.evidence_id], independent_observation=True)
        if ver.verification.status is VerificationStatus.VERIFIED:
            self._transition(execution, "VERIFIED", expected_state=ExecutionState.VERIFICATION_PENDING)
            claim = Claim(claim_id=f"claim-{execution.execution_id}", statement=claim_statement or objective,
                          status=ClaimStatus.SUPPORTED, evidence_refs=[evidence.evidence_id], verification_refs=[ver.verification.verification_id],
                          source_refs=[s.get("source_id", "unknown") for s in evidence.sources])
            self.store.put("claim", claim)
            proof = self.proof.prove(claim=claim, verification=ver.verification.verification_id, evidence_refs=[evidence.evidence_id],
                                     observation_refs=[observation.observation_id], execution_refs=[execution.execution_id],
                                     source_refs=claim.source_refs)
            self._transition(execution, "PROVE", expected_state=ExecutionState.VERIFIED)
        elif ver.verification.status is VerificationStatus.NOT_VERIFIED:
            self._transition(execution, "NOT_VERIFIED", expected_state=ExecutionState.VERIFICATION_PENDING)
            proof = None
        else:
            self._transition(execution, "VERIFICATION_INCONCLUSIVE", expected_state=ExecutionState.VERIFICATION_PENDING)
            proof = None

        artifact = self.artifacts.put(json.dumps(kernel_run.output, sort_keys=True, default=str).encode(), artifact_type="execution-output",
                                      producer_execution_id=execution.execution_id, producer_capability_id=capability_id)
        self.provenance.derive(evidence.evidence_id, artifact.artifact_id, activity_id=execution.execution_id, agent_id=actor_id)
        execution.payload_ref = artifact.content_ref
        self._transition(execution, "PERSIST", expected_state=execution.state)
        self._transition(execution, "PERSISTED", expected_state=ExecutionState.PERSISTING)

        exp = None
        if proof:
            self._transition(execution, "LEARN", expected_state=ExecutionState.PERSISTED)
            exp = self.experience.propose(statement=claim.statement, context=input_data, execution_refs=[execution.execution_id], verification_refs=[ver.verification.verification_id], confidence=ver.verification.confidence or 0.0)
            exp = self.experience.validate(exp, success_rate=1.0 if ver.verification.status is VerificationStatus.VERIFIED else 0.0, verifier_count=1)
            self._transition(execution, "LEARNED", expected_state=ExecutionState.LEARNING_PENDING)
            self._transition(execution, "CALIBRATE", expected_state=ExecutionState.LEARNED)
        else:
            self._transition(execution, "CALIBRATE", expected_state=ExecutionState.PERSISTED)
        if expected_outcome is not None and isinstance(expected_outcome, (int, float)) and isinstance(kernel_run.output, (int, float)):
            self.calibration.calculate(expected=float(expected_outcome), observed=float(kernel_run.output), prior_confidence=ver.verification.confidence or 0.0)
        execution.decision_ref = f"decision-{execution.execution_id}"
        final_decision = self.decisions.decide(run_id=execution.run_id, objective=objective, selected_action={"capability": capability_id},
                                               evidence_refs=[evidence.evidence_id], verification_refs=[ver.verification.verification_id],
                                               proof_refs=[proof.proof_id] if proof else [], expected_outcome=expected_outcome,
                                               observed_outcome=kernel_run.output, policy_ref=execution.policy_snapshot_ref, contract_ref=contract.id)
        final_decision.decision_id = f"decision-{execution.execution_id}"
        final_decision.object_id = final_decision.decision_id
        self.store.put("decision", final_decision)
        execution.decision_ref = final_decision.object_id
        self._transition(execution, "CALIBRATED", expected_state=ExecutionState.CALIBRATING)
        return GoldenRun(execution=execution, decision=final_decision, proof=proof, kernel=kernel_run)

    def kernel_run_envelope(self, execution: Execution, contract: Contract, capability: Capability):
        from .envelope import build_envelope
        identity = IdentityContext(
            tenant_id=execution.tenant_id, namespace_id=execution.namespace_id, run_id=execution.run_id,
            execution_id=execution.execution_id, parent_execution_id=execution.parent_execution_id,
            root_execution_id=execution.root_execution_id or execution.execution_id, trace_id=execution.trace_id,
            span_id=execution.span_id, causal_parent_id=execution.causal_parent_id, region_id=execution.region_id,
            cell_id=execution.cell_id, actor_id=execution.actor_id,
        )
        return build_envelope(identity=identity, message_type="ExecutionCommand", contract_ref=execution.contract_ref,
                              capability_ref={"id": capability.capability_id, "version": capability.semantic_version},
                              policy_snapshot_ref=execution.policy_snapshot_ref, idempotency_key=execution.idempotency_key,
                              payload=execution.input_data)

    def reconstruct(self, execution_id: str) -> dict[str, Any]:
        return self.kernel.reconstruct(execution_id)

    def _transition(self, execution: Execution, event: str, *, expected_state: ExecutionState) -> None:
        if execution.state is not expected_state:
            raise RuntimeError(f"state_mismatch expected={expected_state.value} actual={execution.state.value} event={event}")
        self.kernel._transition(execution, event)
