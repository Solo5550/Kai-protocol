from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator

from .store import RuntimeStore


@dataclass
class ObservabilityRecord:
    execution_id: str
    trace_id: str
    span_id: str
    state: str
    event: str
    attempt: int
    duration_ms: float | None = None
    outcome: str | None = None
    error: str | None = None
    resource_usage: dict[str, Any] = field(default_factory=dict)
    policy_ref: str | None = None
    capability_ref: str | None = None
    artifact_refs: list[str] = field(default_factory=list)
    provenance_refs: list[str] = field(default_factory=list)


class ObservationBus:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store

    def emit(self, execution_id: str, event: str, record: ObservabilityRecord | dict[str, Any]) -> str:
        payload = record.__dict__ if isinstance(record, ObservabilityRecord) else dict(record)
        return self.store.append_event(execution_id, event, payload)

    @contextmanager
    def span(self, *, execution_id: str, trace_id: str, span_id: str, state: str, attempt: int, **metadata) -> Iterator[ObservabilityRecord]:
        started = time.monotonic()
        record = ObservabilityRecord(execution_id=execution_id, trace_id=trace_id, span_id=span_id, state=state, event="SPAN_STARTED", attempt=attempt, **metadata)
        self.emit(execution_id, "SPAN_STARTED", record)
        try:
            yield record
        except Exception as exc:
            record.duration_ms = (time.monotonic() - started) * 1000
            record.outcome = "FAILURE"
            record.error = f"{type(exc).__name__}: {exc}"
            self.emit(execution_id, "SPAN_FAILED", record)
            raise
        else:
            record.duration_ms = (time.monotonic() - started) * 1000
            record.outcome = "SUCCESS"
            self.emit(execution_id, "SPAN_FINISHED", record)

    def golden_path(self, execution_id: str) -> dict[str, Any]:
        events = self.store.events(execution_id)
        return {
            "execution_id": execution_id,
            "events": events,
            "event_count": len(events),
            "trace_ids": sorted({e.get("payload", {}).get("trace_id") for e in events if e.get("payload", {}).get("trace_id")}),
        }
