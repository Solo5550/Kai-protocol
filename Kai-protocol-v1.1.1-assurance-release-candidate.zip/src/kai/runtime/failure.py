from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Callable

from .models import Failure, FailureCategory, ExecutionState, utcnow
from .store import RuntimeStore


@dataclass(frozen=True)
class EffectResult:
    effect_id: str
    status: str
    output: Any = None
    deduplicated: bool = False


class EffectLedger:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store

    def begin(self, *, execution_id: str, idempotency_key: str, target: str, operation: str, request: Any,
              authorization_ref: str, policy_ref: str) -> tuple[dict[str, Any], bool]:
        fingerprint = hashlib.sha256(json.dumps(request, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()
        effect = {
            "effect_id": f"effect-{hashlib.sha256((execution_id + idempotency_key).encode()).hexdigest()[:24]}",
            "execution_id": execution_id, "idempotency_key": idempotency_key, "target": target, "operation": operation,
            "request_fingerprint": fingerprint, "authorization_ref": authorization_ref, "policy_ref": policy_ref,
            "started_at": utcnow(), "status": "STARTED",
        }
        return self.store.begin_effect(effect)

    def complete(self, effect_id: str, *, status: str, compensation_ref: str | None = None, evidence_ref: str | None = None) -> None:
        self.store.update_effect(effect_id, status=status, completed_at=utcnow(), compensation_ref=compensation_ref, evidence_ref=evidence_ref)


@dataclass(frozen=True)
class RetryDecision:
    retry: bool
    attempt: int
    delay_seconds: float
    reason: str


class RetryController:
    def __init__(self, *, max_attempts: int = 3, base_delay: float = 0.01, max_delay: float = 1.0, jitter: float = 0.0) -> None:
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.jitter = jitter

    def decide(self, attempt: int, *, retryable: bool) -> RetryDecision:
        if not retryable or attempt >= self.max_attempts:
            return RetryDecision(False, attempt, 0.0, "retry_not_allowed_or_exhausted")
        delay = min(self.max_delay, self.base_delay * (2 ** (attempt - 1)))
        if self.jitter:
            import random
            delay += random.uniform(0, self.jitter)
        return RetryDecision(True, attempt + 1, delay, "retryable_failure")


class CancellationManager:
    def request(self, current: ExecutionState) -> ExecutionState:
        if current in {ExecutionState.CLOSED, ExecutionState.CANCELLED, ExecutionState.REJECTED, ExecutionState.BLOCKED}:
            return current
        return ExecutionState.CANCEL_REQUESTED

    def acknowledge(self) -> ExecutionState:
        return ExecutionState.ACKNOWLEDGED

    def stopping(self) -> ExecutionState:
        return ExecutionState.STOPPING

    def cancelled(self) -> ExecutionState:
        return ExecutionState.CANCELLED


class FailureEngine:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store

    def capture(self, *, execution_id: str, state: str, category: FailureCategory, severity: str, symptom: str,
                trigger: str, root_cause: str = "", contributors: list[str] | None = None, affected_capabilities=None,
                affected_regions=None, observations=None, recovery_action: str | None = None,
                compensation_action: str | None = None) -> Failure:
        failure = Failure(failure_id=f"failure-{execution_id}-{int(time.time_ns())}", execution_id=execution_id, state=state,
                          category=category, severity=severity, symptom=symptom, trigger=trigger, root_cause=root_cause,
                          contributors=contributors or [], affected_capabilities=affected_capabilities or [],
                          affected_regions=affected_regions or [], observations=observations or [], recovery_action=recovery_action,
                          compensation_action=compensation_action)
        self.store.put("failure", failure)
        return failure

    def reverse_engineer(self, failure: Failure) -> dict[str, Any]:
        causal_chain = {
            "failure_id": failure.failure_id,
            "steps": ["RECONSTRUCTION", "CONTRACT_ANALYSIS", "STATE_ANALYSIS", "TRACE_ANALYSIS", "INPUT_ANALYSIS", "ENVIRONMENT_ANALYSIS", "DEPENDENCY_ANALYSIS", "CAUSAL_ANALYSIS", "ROOT_CAUSE", "CONTRIBUTING_FACTORS", "FAILURE_SIGNATURE", "LESSON", "SYSTEM_CHANGE"],
            "root_cause": failure.root_cause or failure.trigger,
            "signature": hashlib.sha256((failure.category.value + "|" + failure.symptom + "|" + failure.trigger).encode()).hexdigest()[:24],
            "system_changes": ["regression_test", "monitoring_signal"] if failure.category is not FailureCategory.UNKNOWN else ["regression_test"],
        }
        return causal_chain


class RecoveryEngine:
    def recover(self, *, failure: Failure, allow_retry: bool, allow_compensation: bool) -> dict[str, Any]:
        if failure.category is FailureCategory.TIMEOUT and allow_retry:
            return {"state": ExecutionState.RECOVERY_PENDING.value, "action": "RETRY"}
        if failure.compensation_action and allow_compensation:
            return {"state": ExecutionState.RECOVERY_PENDING.value, "action": "COMPENSATE", "compensation": failure.compensation_action}
        return {"state": ExecutionState.FAILED.value, "action": "ESCALATE"}


class ReplayEngine:
    def replay(self, reconstruction: dict[str, Any], *, mode: str = "RECONSTRUCTION_ONLY") -> dict[str, Any]:
        if mode not in {"DETERMINISTIC", "BEST_EFFORT", "RECONSTRUCTION_ONLY", "NON_REPLAYABLE_EXTERNAL_EFFECT"}:
            raise ValueError("unsupported_replay_mode")
        return {"mode": mode, "execution": reconstruction["execution"], "events": reconstruction["events"], "reexecute_external_effects": False}
