from __future__ import annotations

from dataclasses import dataclass, field


EVOLUTION_STAGES = ("PROPOSAL", "CONTRACT_IMPACT", "COMPATIBILITY", "CONFORMANCE", "SHADOW", "CANARY", "LIMITED_ROLLOUT", "OBSERVATION", "VERIFICATION", "PROMOTED", "ROLLED_BACK")


@dataclass
class EvolutionProposal:
    proposal_id: str
    subject: str
    current_version: str
    candidate_version: str
    risk: float
    stages_completed: list[str] = field(default_factory=list)
    status: str = "PROPOSAL"

    def advance(self, stage: str, *, health_ok: bool = True, evidence_ok: bool = True) -> None:
        if stage not in EVOLUTION_STAGES:
            raise ValueError("unknown_evolution_stage")
        expected_index = len(self.stages_completed)
        if expected_index >= len(EVOLUTION_STAGES):
            raise ValueError("evolution_already_terminal")
        if EVOLUTION_STAGES[expected_index] != stage:
            raise ValueError(f"out_of_order_evolution_stage expected={EVOLUTION_STAGES[expected_index]} actual={stage}")
        if stage in {"CANARY", "LIMITED_ROLLOUT", "PROMOTED"} and not (health_ok and evidence_ok):
            self.status = "ROLLED_BACK" if stage == "PROMOTED" else "PROPOSAL"
            raise ValueError("health_or_evidence_gate_failed")
        self.stages_completed.append(stage)
        self.status = stage
