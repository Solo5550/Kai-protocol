from __future__ import annotations

from dataclasses import dataclass

from .models import Capability, Contract, RUNTIME_SCHEMA_VERSION, RUNTIME_VERSION


@dataclass(frozen=True)
class CompatibilityResult:
    status: str
    reasons: tuple[str, ...] = ()


class CompatibilityEngine:
    def check(self, *, capability: Capability, contract: Contract, runtime_version: str = RUNTIME_VERSION,
               schema_version: str = RUNTIME_SCHEMA_VERSION, policy_version: str | None = None) -> CompatibilityResult:
        reasons: list[str] = []
        if runtime_version not in capability.runtime_versions:
            reasons.append("runtime_version_unsupported")
        if schema_version not in capability.schema_versions:
            reasons.append("schema_version_unsupported")
        supported_contracts = capability.observability.get("supported_contract_versions", [contract.version])
        if contract.version not in supported_contracts:
            reasons.append("contract_version_unsupported")
        supported_policies = capability.observability.get("supported_policy_versions")
        if policy_version and supported_policies is not None and policy_version not in supported_policies:
            reasons.append("policy_version_unsupported")
        if reasons:
            return CompatibilityResult("INCOMPATIBLE", tuple(reasons))
        return CompatibilityResult("COMPATIBLE")
