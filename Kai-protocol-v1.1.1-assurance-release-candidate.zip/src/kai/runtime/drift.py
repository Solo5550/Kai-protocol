from __future__ import annotations


class ArchitectureDriftScanner:
    def scan(self, runtime) -> dict[str, list[str]]:
        drift: dict[str, list[str]] = {k: [] for k in ("contract", "policy", "schema", "capability", "topology", "state", "security", "observability", "provenance")}
        for cap in runtime.registry.all():
            if not cap.owner:
                drift["capability"].append(f"unowned:{cap.capability_id}")
            if cap.lifecycle.value == "AVAILABLE" and cap.capability_id not in [c for r in runtime.regions.values() for cell in r.cells.values() for c in cell.capability_ids]:
                drift["topology"].append(f"unplaced:{cap.capability_id}")
        return drift

    def clean(self, runtime) -> bool:
        return not any(self.scan(runtime).values())
