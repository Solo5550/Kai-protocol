from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from .models import Artifact
from .store import RuntimeStore


class ArtifactStore:
    """Content-addressed immutable artifact storage."""

    def __init__(self, root: str | Path, store: RuntimeStore) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.store = store

    def put(self, content: bytes, *, artifact_type: str, producer_execution_id: str | None = None,
            producer_capability_id: str | None = None, parent_artifacts: list[str] | None = None, classification: str = "internal") -> Artifact:
        digest = hashlib.sha256(content).hexdigest()
        version = "1.0.0"
        artifact_id = f"artifact-{digest[:32]}"
        path = self.root / digest
        if path.exists() and path.read_bytes() != content:
            raise IOError("content address collision")
        if not path.exists():
            path.write_bytes(content)
        ref = f"artifact://sha256/{digest}"
        existing = self.store.get("artifact", artifact_id)
        if existing is not None:
            if existing["content_hash"] != digest:
                raise IOError("immutable artifact identity mismatch")
            from .serialization import from_primitive
            return from_primitive(Artifact, existing)
        artifact = Artifact(object_id=artifact_id, artifact_id=artifact_id, artifact_type=artifact_type,
                            artifact_version=version, content_ref=ref, content_hash=digest,
                            producer_execution_id=producer_execution_id, producer_capability_id=producer_capability_id,
                            parent_artifacts=parent_artifacts or [], classification=classification)
        self.store.put("artifact", artifact)
        return artifact

    def read(self, artifact: Artifact) -> bytes:
        digest = artifact.content_hash
        path = self.root / digest
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise IOError("artifact integrity failure")
        return data
