from __future__ import annotations

import json
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable
from urllib.parse import urlparse


class APIAuthorizationError(PermissionError):
    pass


@dataclass(frozen=True, slots=True)
class RequestContext:
    principal: str
    tenant: str
    transport: str = "inproc"
    secure: bool = True


class _DefaultLocalAuthorizer:
    def authorize(self, context: RequestContext, action: str, execution) -> bool:
        return context.transport == "inproc" and context.principal == "local" and context.tenant == getattr(execution, "tenant_id", "default")


class RuntimeAPI:
    def __init__(self, runtime, authorizer: Callable[[RequestContext, str, Any], bool] | Any | None = None):
        self.runtime = runtime
        self.authorizer = authorizer or _DefaultLocalAuthorizer()

    def _is_authorized(self, context: RequestContext, action: str, execution: Any) -> bool:
        if hasattr(self.authorizer, "authorize"):
            decision = self.authorizer.authorize(context, action, execution)
        else:
            decision = self.authorizer(context, action, execution)
        return bool(decision)

    def _require(self, context: RequestContext, action: str, execution: Any) -> None:
        if execution is None:
            raise KeyError("not_found")
        if not self._is_authorized(context, action, execution):
            raise APIAuthorizationError("authorization_denied")

    def get_execution(self, execution_id: str, context: RequestContext | None = None):
        context = context or RequestContext("local", "default")
        execution = self.runtime.store.get_execution(execution_id)
        self._require(context, "read_execution", execution)
        return self.runtime.reconstruct(execution_id)

    def get_state(self, execution_id: str, context: RequestContext | None = None) -> dict[str, Any]:
        context = context or RequestContext("local", "default")
        execution = self.runtime.store.get_execution(execution_id)
        self._require(context, "read_state", execution)
        return {"execution_id": execution_id, "state": execution.state.value}

    def get_timeline(self, execution_id: str, context: RequestContext | None = None) -> dict[str, Any]:
        context = context or RequestContext("local", "default")
        execution = self.runtime.store.get_execution(execution_id)
        self._require(context, "read_timeline", execution)
        return {"execution_id": execution_id, "events": self.runtime.store.events(execution_id)}

    def get_proof(self, execution_id: str, context: RequestContext | None = None) -> dict[str, Any]:
        context = context or RequestContext("local", "default")
        execution = self.runtime.store.get_execution(execution_id)
        self._require(context, "read_proof", execution)
        proofs = []
        for entry in self.runtime.proof_ledger.entries():
            payload = entry.get("payload", {})
            refs = set(payload.get("execution_refs", [])) if isinstance(payload, dict) else set()
            if execution_id in refs:
                proofs.append(entry)
        return {"execution_id": execution_id, "proof_chain_valid": self.runtime.proof_ledger.verify_chain(), "proofs": proofs}

    def get_provenance(self, execution_id: str, context: RequestContext | None = None) -> dict[str, Any]:
        context = context or RequestContext("local", "default")
        execution = self.runtime.store.get_execution(execution_id)
        self._require(context, "read_provenance", execution)
        return {"execution_id": execution_id, "lineage": self.runtime.provenance.lineage(execution_id)}

    def get_artifacts(self, execution_id: str, context: RequestContext | None = None) -> dict[str, Any]:
        context = context or RequestContext("local", "default")
        execution = self.runtime.store.get_execution(execution_id)
        self._require(context, "read_artifacts", execution)
        rows = self.runtime.store._conn.execute("SELECT payload FROM objects WHERE kind='artifact'").fetchall()
        artifacts = []
        for row in rows:
            item = json.loads(row[0])
            if item.get("producer_execution_id") == execution_id:
                artifacts.append(item)
        return {"execution_id": execution_id, "artifacts": artifacts}


class _Handler(BaseHTTPRequestHandler):
    runtime_api: RuntimeAPI

    def _context(self) -> RequestContext:
        principal = self.headers.get("X-Kai-Principal", "anonymous")
        tenant = self.headers.get("X-Kai-Tenant", "")
        secure = self.headers.get("X-Kai-Secure", "false").lower() == "true"
        return RequestContext(principal=principal, tenant=tenant, transport="http", secure=secure)

    def _json(self, status: int, payload):
        raw = json.dumps(payload, ensure_ascii=False, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        path = urlparse(self.path).path
        if path.startswith("/executions/"):
            parts = path.split("/")
            execution_id = parts[2]
            execution = self.runtime_api.runtime.store.get_execution(execution_id)
            if execution is None:
                self._json(404, {"error": "not_found"}); return
            context = self._context()
            try:
                self.runtime_api._require(context, "mutate_execution", execution)
                if path.endswith("/cancel"):
                    execution = self.runtime_api.runtime.kernel.cancel(execution)
                elif path.endswith("/retry"):
                    execution = self.runtime_api.runtime.kernel.retry(execution)
                elif path.endswith("/recover"):
                    execution = self.runtime_api.runtime.kernel.recover(execution)
                else:
                    self._json(400, {"error": "unsupported_command"}); return
                self._json(200, {"execution_id": execution.execution_id, "state": execution.state.value, "state_version": execution.state_version})
            except APIAuthorizationError:
                self._json(403, {"error": "authorization_denied"})
            except Exception as exc:
                self._json(409, {"error": f"{type(exc).__name__}: {exc}"})
            return
        self._json(404, {"error": "not_found"})

    def do_GET(self):
        path = urlparse(self.path).path
        if path.startswith("/executions/"):
            parts = path.split("/")
            execution_id = parts[2]
            context = self._context()
            try:
                if len(parts) == 3:
                    payload = self.runtime_api.get_execution(execution_id, context)
                elif parts[3] == "state":
                    payload = self.runtime_api.get_state(execution_id, context)
                elif parts[3] == "timeline":
                    payload = self.runtime_api.get_timeline(execution_id, context)
                elif parts[3] == "proof":
                    payload = self.runtime_api.get_proof(execution_id, context)
                elif parts[3] == "provenance":
                    payload = self.runtime_api.get_provenance(execution_id, context)
                elif parts[3] == "artifacts":
                    payload = self.runtime_api.get_artifacts(execution_id, context)
                else:
                    raise KeyError(execution_id)
                self._json(200, payload)
            except APIAuthorizationError:
                self._json(403, {"error": "authorization_denied"})
            except KeyError:
                self._json(404, {"error": "not_found"})
            return
        self._json(404, {"error": "not_found"})

    def log_message(self, format, *args):
        return


def serve(runtime, host="127.0.0.1", port=8080, *, authorizer=None, secure_transport: bool = False):
    loopback = host in {"127.0.0.1", "localhost", "::1"}
    if not loopback and not secure_transport:
        raise ValueError("external_bind_requires_secure_transport")
    if not loopback and authorizer is None:
        raise ValueError("external_bind_requires_authorizer")
    _Handler.runtime_api = RuntimeAPI(runtime, authorizer=authorizer)
    server = ThreadingHTTPServer((host, port), _Handler)
    server.serve_forever()
