from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .models import Capability


@dataclass
class Region:
    region_id: str
    allowed_data_classes: set[str] = field(default_factory=set)
    cells: dict[str, "Cell"] = field(default_factory=dict)
    healthy: bool = True
    policy_version: str = "1.0.0"

    def add_cell(self, cell: "Cell") -> None:
        self.cells[cell.cell_id] = cell


@dataclass
class Cell:
    cell_id: str
    region_id: str
    capacity_units: float = 100.0
    used_units: float = 0.0
    healthy: bool = True
    trust_zone: str = "default"
    capability_ids: set[str] = field(default_factory=set)

    @property
    def available(self) -> float:
        return max(0.0, self.capacity_units - self.used_units)


@dataclass(frozen=True)
class PlacementRequest:
    execution_id: str
    capability_id: str
    preferred_region: str | None = None
    data_region: str | None = None
    processing_regions: tuple[str, ...] = ()
    artifact_regions: tuple[str, ...] = ()
    allowed_regions: tuple[str, ...] = ()
    denied_regions: tuple[str, ...] = ()
    trust_zone: str | None = None
    resource_units: float = 1.0
    max_latency_ms: float | None = None


@dataclass(frozen=True)
class PlacementDecision:
    execution_id: str
    selected_region: str
    selected_cell: str
    rationale: str
    constraints_checked: tuple[str, ...]
    policy_ref: str
    capability_ref: str
    expiration: str | None = None


class SovereigntyError(RuntimeError):
    pass


class PlacementEngine:
    def __init__(self, regions: dict[str, Region]) -> None:
        self.regions = regions

    def select(self, request: PlacementRequest, *, policy_ref: str, capability_ref: str) -> PlacementDecision:
        candidates = list(self.regions.values())
        if request.preferred_region:
            candidates.sort(key=lambda r: 0 if r.region_id == request.preferred_region else 1)
        for region in candidates:
            if not region.healthy:
                continue
            if request.allowed_regions and region.region_id not in request.allowed_regions:
                continue
            if region.region_id in request.denied_regions:
                continue
            if request.data_region and request.data_region != region.region_id and request.processing_regions and region.region_id not in request.processing_regions:
                continue
            for cell in region.cells.values():
                if not cell.healthy or cell.available < request.resource_units:
                    continue
                if request.trust_zone and cell.trust_zone != request.trust_zone:
                    continue
                if request.capability_id not in cell.capability_ids:
                    continue
                return PlacementDecision(request.execution_id, region.region_id, cell.cell_id, "first permitted healthy capacity match", ("health", "capacity", "capability", "region_policy", "data_residency"), policy_ref, capability_ref)
        raise SovereigntyError("no placement satisfies sovereignty/capability/capacity constraints")


class Scheduler:
    def __init__(self, regions: dict[str, Region]) -> None:
        self.regions = regions
        self.desired: dict[str, PlacementDecision] = {}
        self.actual: dict[str, tuple[str, str]] = {}

    def set_desired(self, decision: PlacementDecision) -> None:
        self.desired[decision.execution_id] = decision

    def observe_actual(self, execution_id: str, region_id: str, cell_id: str) -> None:
        self.actual[execution_id] = (region_id, cell_id)

    def reconcile(self, execution_id: str) -> tuple[str, str]:
        desired = self.desired[execution_id]
        actual = self.actual.get(execution_id)
        if actual == (desired.selected_region, desired.selected_cell):
            return actual
        self.actual[execution_id] = (desired.selected_region, desired.selected_cell)
        return self.actual[execution_id]


class PolicyDriftGuard:
    def ensure(self, *, local_version: str, required_version: str, affected: bool = True) -> str:
        if affected and local_version != required_version:
            return "BLOCKED_DRIFT"
        return "IN_SYNC"


@dataclass
class SafeModePolicy:
    allowed_operations: set[str]
    forbidden_operations: set[str]
    max_execution_duration: float
    allowed_capabilities: set[str]
    external_effects: bool = False
    data_movement: bool = False


class SafeModeController:
    def __init__(self, policy: SafeModePolicy) -> None:
        self.policy = policy
        self.active = False

    def enter(self) -> None:
        self.active = True

    def authorize(self, *, operation: str, capability_id: str) -> bool:
        if not self.active:
            return True
        if operation in self.policy.forbidden_operations:
            return False
        return operation in self.policy.allowed_operations and capability_id in self.policy.allowed_capabilities and not self.policy.external_effects


class FederationManager:
    def __init__(self, regions: dict[str, Region]) -> None:
        self.regions = regions
        self.global_available = True
        self.snapshots: dict[str, dict[str, Any]] = {}

    def publish_snapshot(self, region_id: str, policy_snapshot: dict[str, Any]) -> None:
        self.snapshots[region_id] = dict(policy_snapshot)
        self.regions[region_id].policy_version = str(policy_snapshot.get("version", "1.0.0"))

    def set_global_available(self, value: bool) -> None:
        self.global_available = value

    def can_continue(self, *, region_id: str, capability_id: str, side_effect: bool = False) -> bool:
        if self.global_available:
            return True
        snap = self.snapshots.get(region_id, {})
        if snap.get("safe_mode", True) and side_effect:
            return False
        return capability_id in set(snap.get("allowed_capabilities", []))

    def federated_summary(self) -> dict[str, Any]:
        return {rid: {"healthy": r.healthy, "policy_version": r.policy_version, "cells": {cid: {"healthy": c.healthy, "available": c.available} for cid, c in r.cells.items()}} for rid, r in self.regions.items()}
