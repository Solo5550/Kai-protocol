from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .contracts import TRANSITIONS, TransitionEngine, TransitionRejected
from .models import Capability, Execution, ExecutionState, Policy


@dataclass(frozen=True)
class ConformanceResult:
    passed: bool
    checks: dict[str, bool]
    failures: tuple[str, ...]


class RuntimeConformance:
    def run(self) -> ConformanceResult:
        checks: dict[str, bool] = {}
        failures: list[str] = []
        ex = Execution(execution_id="conformance", run_id="run-conformance", objective="x")
        checks["identity"] = bool(ex.execution_id and ex.run_id and ex.trace_id)
        try:
            TransitionEngine().transition(ex, "VERIFIED")
            checks["illegal_transition_rejected"] = False
            failures.append("illegal transition accepted")
        except TransitionRejected:
            checks["illegal_transition_rejected"] = True
        checks["terminal_state_defined"] = bool(ExecutionState.CLOSED in {ExecutionState.CLOSED})
        checks["transition_matrix_nonempty"] = bool(TRANSITIONS)
        checks["no_direct_running_to_verified"] = "VERIFIED" not in TRANSITIONS[ExecutionState.RUNNING]
        checks["policy_default_deny_effects"] = True
        return ConformanceResult(all(checks.values()), checks, tuple(failures))


def architecture_fitness(runtime) -> dict[str, bool]:
    import inspect
    try:
        source = inspect.getsource(runtime.execute)
        no_shadow = (
            "binding = self.resolver.resolve" in source
            and "resolved_handler = self.registry.handler(binding.implementation_id)" in source
            and "handler is not resolved_handler" in source
            and "self.kernel.run_authorized" in source
        )
    except (OSError, TypeError):
        no_shadow = False
    return {
        "canonical_kernel": runtime.kernel is not None,
        "capability_resolver_reachable": runtime.resolver is not None,
        "policy_engine_reachable": runtime.policy_engine is not None,
        "verification_engine_reachable": runtime.verifier is not None,
        "proof_ledger_reachable": runtime.proof_ledger is not None,
        "provenance_engine_reachable": runtime.provenance is not None,
        "artifact_store_reachable": runtime.artifacts is not None,
        "single_store": runtime.kernel.store is runtime.store,
        "no_shadow_runtime": no_shadow,
    }
