from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .models import Experience
from .store import RuntimeStore


@dataclass(frozen=True)
class ReuseDecision:
    eligible: bool
    reason: str


class ExperienceEngine:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store

    def propose(self, *, statement: str, context: dict[str, Any], execution_refs: list[str], verification_refs: list[str], confidence: float = 0.5) -> Experience:
        sig = hashlib.sha256(str(sorted(context.items())).encode()).hexdigest()[:24]
        return Experience(experience_id=f"experience-{hashlib.sha256(statement.encode()).hexdigest()[:24]}", statement=statement,
                          context_signature=sig, supporting_execution_refs=execution_refs, verification_refs=verification_refs,
                          confidence=confidence, status="CANDIDATE", provenance={"context": context})

    def validate(self, experience: Experience, *, success_rate: float, verifier_count: int, policy: dict[str, Any] | None = None) -> Experience:
        if not experience.supporting_execution_refs or verifier_count <= 0:
            experience.status = "CANDIDATE"
            return experience
        experience.success_rate = max(0.0, min(1.0, success_rate))
        experience.last_validated_at = datetime.now(timezone.utc).isoformat()
        experience.reuse_policy = policy or {"min_success_rate": 0.8, "require_fresh": True}
        experience.status = "QUALIFIED" if experience.success_rate >= float(experience.reuse_policy.get("min_success_rate", 0.8)) else "VALIDATED"
        self.store.put("experience", experience)
        return experience

    def eligible_for_reuse(self, experience: Experience, *, context_signature: str, policy: dict[str, Any], compatible: bool = True, fresh: bool = True) -> ReuseDecision:
        if experience.status != "QUALIFIED":
            return ReuseDecision(False, "not_qualified")
        if experience.context_signature != context_signature:
            return ReuseDecision(False, "context_mismatch")
        if not compatible:
            return ReuseDecision(False, "incompatible")
        if policy.get("require_fresh", True) and not fresh:
            return ReuseDecision(False, "stale")
        if experience.success_rate < float(policy.get("min_success_rate", 0.8)):
            return ReuseDecision(False, "historical_reliability_below_threshold")
        return ReuseDecision(True, "eligible")


@dataclass(frozen=True)
class CalibrationOutcome:
    prediction_error: float
    updated_reliability: float


class CalibrationEngine:
    def calculate(self, *, expected: float, observed: float, prior_confidence: float) -> CalibrationOutcome:
        denom = max(abs(expected), 1e-12)
        error = abs(observed - expected) / denom
        reliability = max(0.0, min(1.0, prior_confidence * (1.0 - min(error, 1.0))))
        return CalibrationOutcome(error, reliability)
