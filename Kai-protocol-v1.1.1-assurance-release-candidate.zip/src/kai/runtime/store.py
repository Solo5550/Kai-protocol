from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from .models import Execution, RuntimeObject, to_primitive, utcnow


class RuntimeStore:
    """SQLite reference store: authoritative local state plus append-oriented events."""

    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        with self._conn:
            self._conn.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS executions (
                    execution_id TEXT PRIMARY KEY,
                    state TEXT NOT NULL,
                    state_version INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    execution_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(execution_id, sequence)
                );
                CREATE TABLE IF NOT EXISTS objects (
                    kind TEXT NOT NULL,
                    object_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    version INTEGER NOT NULL DEFAULT 1,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(kind, object_id)
                );
                CREATE TABLE IF NOT EXISTS effects (
                    effect_id TEXT PRIMARY KEY,
                    execution_id TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    target TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    request_fingerprint TEXT NOT NULL,
                    authorization_ref TEXT NOT NULL,
                    policy_ref TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completed_at TEXT,
                    status TEXT NOT NULL,
                    compensation_ref TEXT,
                    evidence_ref TEXT
                );
                CREATE TABLE IF NOT EXISTS idempotency (
                    idempotency_key TEXT PRIMARY KEY,
                    execution_id TEXT NOT NULL,
                    effect_fingerprint TEXT,
                    result TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_events_execution ON events(execution_id, sequence);
                """
            )

    @contextmanager
    def transaction(self):
        with self._lock:
            try:
                self._conn.execute("BEGIN IMMEDIATE")
                yield self._conn
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise

    def create_execution(self, execution: Execution) -> None:
        payload = json.dumps(to_primitive(execution), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO executions(execution_id,state,state_version,payload,updated_at) VALUES(?,?,?,?,?)",
                (execution.execution_id, execution.state.value, execution.state_version, payload, execution.updated_at),
            )
            self._append_event_conn(conn, execution.execution_id, "EXECUTION_CREATED", {"state": execution.state.value})

    def get_execution(self, execution_id: str) -> Execution | None:
        with self._lock:
            row = self._conn.execute("SELECT payload FROM executions WHERE execution_id=?", (execution_id,)).fetchone()
            if row is None:
                return None
            from .serialization import from_primitive
            return from_primitive(Execution, json.loads(row["payload"]))

    def transition_persist(self, execution: Execution, *, expected_state_version: int, event_type: str, event_payload: dict[str, Any] | None = None) -> None:
        payload = json.dumps(to_primitive(execution), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        with self.transaction() as conn:
            cur = conn.execute(
                "UPDATE executions SET state=?, state_version=?, payload=?, updated_at=? WHERE execution_id=? AND state_version=?",
                (execution.state.value, execution.state_version, payload, execution.updated_at, execution.execution_id, expected_state_version),
            )
            if cur.rowcount != 1:
                raise RuntimeError("authoritative state compare-and-swap failed")
            self._append_event_conn(conn, execution.execution_id, event_type, event_payload or {"state": execution.state.value})

    def append_event(self, execution_id: str, event_type: str, payload: dict[str, Any] | None = None, event_id: str | None = None) -> str:
        with self.transaction() as conn:
            return self._append_event_conn(conn, execution_id, event_type, payload or {}, event_id=event_id)

    def _append_event_conn(self, conn, execution_id: str, event_type: str, payload: dict[str, Any], event_id: str | None = None) -> str:
        import uuid
        event_id = event_id or str(uuid.uuid4())
        row = conn.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM events WHERE execution_id=?", (execution_id,)).fetchone()
        seq = int(row[0])
        conn.execute(
            "INSERT INTO events(event_id,execution_id,sequence,event_type,payload,created_at) VALUES(?,?,?,?,?,?)",
            (event_id, execution_id, seq, event_type, json.dumps(payload, sort_keys=True), utcnow()),
        )
        return event_id

    def events(self, execution_id: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT event_id,sequence,event_type,payload,created_at FROM events WHERE execution_id=? ORDER BY sequence", (execution_id,)).fetchall()
            return [{"event_id": r[0], "sequence": r[1], "event_type": r[2], "payload": json.loads(r[3]), "created_at": r[4]} for r in rows]

    def put(self, kind: str, obj: RuntimeObject) -> None:
        payload = json.dumps(to_primitive(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        with self.transaction() as conn:
            old = conn.execute("SELECT version FROM objects WHERE kind=? AND object_id=?", (kind, obj.object_id)).fetchone()
            version = int(old[0]) + 1 if old else 1
            conn.execute(
                "INSERT INTO objects(kind,object_id,payload,version,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(kind,object_id) DO UPDATE SET payload=excluded.payload, version=excluded.version, updated_at=excluded.updated_at",
                (kind, obj.object_id, payload, version, obj.updated_at),
            )

    def get(self, kind: str, object_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute("SELECT payload FROM objects WHERE kind=? AND object_id=?", (kind, object_id)).fetchone()
            return json.loads(row[0]) if row else None

    def remember_idempotency(self, key: str, execution_id: str, result: Any, effect_fingerprint: str | None = None) -> bool:
        with self.transaction() as conn:
            try:
                conn.execute(
                    "INSERT INTO idempotency(idempotency_key,execution_id,effect_fingerprint,result,created_at) VALUES(?,?,?,?,?)",
                    (key, execution_id, effect_fingerprint, json.dumps(result, sort_keys=True, default=str), utcnow()),
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def get_idempotency(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute("SELECT execution_id,effect_fingerprint,result,created_at FROM idempotency WHERE idempotency_key=?", (key,)).fetchone()
            if not row:
                return None
            return {"execution_id": row[0], "effect_fingerprint": row[1], "result": json.loads(row[2]), "created_at": row[3]}

    def begin_effect(self, record: dict[str, Any]) -> tuple[dict[str, Any], bool]:
        """Atomically reserve an effect idempotency key and return (record, duplicate)."""
        import hashlib
        request_fingerprint = str(record["request_fingerprint"])
        with self.transaction() as conn:
            row = conn.execute(
                "SELECT effect_id,execution_id,idempotency_key,target,operation,request_fingerprint,authorization_ref,policy_ref,started_at,completed_at,status,compensation_ref,evidence_ref FROM effects WHERE idempotency_key=?",
                (record["idempotency_key"],),
            ).fetchone()
            if row is not None:
                names = ["effect_id","execution_id","idempotency_key","target","operation","request_fingerprint","authorization_ref","policy_ref","started_at","completed_at","status","compensation_ref","evidence_ref"]
                existing = dict(zip(names, row))
                if existing["request_fingerprint"] != request_fingerprint:
                    raise ValueError("idempotency_key_reused_with_different_effect")
                return existing, True
            conn.execute(
                "INSERT INTO effects(effect_id,execution_id,idempotency_key,target,operation,request_fingerprint,authorization_ref,policy_ref,started_at,completed_at,status,compensation_ref,evidence_ref) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (record["effect_id"], record["execution_id"], record["idempotency_key"], record["target"], record["operation"], request_fingerprint, record["authorization_ref"], record["policy_ref"], record["started_at"], record.get("completed_at"), record["status"], record.get("compensation_ref"), record.get("evidence_ref")),
            )
            return dict(record), False

    def put_effect(self, record: dict[str, Any]) -> None:
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO effects(effect_id,execution_id,idempotency_key,target,operation,request_fingerprint,authorization_ref,policy_ref,started_at,completed_at,status,compensation_ref,evidence_ref) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (record["effect_id"], record["execution_id"], record["idempotency_key"], record["target"], record["operation"], record["request_fingerprint"], record["authorization_ref"], record["policy_ref"], record["started_at"], record.get("completed_at"), record["status"], record.get("compensation_ref"), record.get("evidence_ref")),
            )

    def get_effect_by_idempotency(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute("SELECT effect_id,execution_id,idempotency_key,target,operation,request_fingerprint,authorization_ref,policy_ref,started_at,completed_at,status,compensation_ref,evidence_ref FROM effects WHERE idempotency_key=?", (key,)).fetchone()
            if not row:
                return None
            names = ["effect_id","execution_id","idempotency_key","target","operation","request_fingerprint","authorization_ref","policy_ref","started_at","completed_at","status","compensation_ref","evidence_ref"]
            return dict(zip(names, row))

    def update_effect(self, effect_id: str, *, status: str, completed_at: str | None = None, compensation_ref: str | None = None, evidence_ref: str | None = None) -> None:
        with self.transaction() as conn:
            conn.execute("UPDATE effects SET status=?, completed_at=COALESCE(?,completed_at), compensation_ref=COALESCE(?,compensation_ref), evidence_ref=COALESCE(?,evidence_ref) WHERE effect_id=?", (status, completed_at, compensation_ref, evidence_ref, effect_id))

    def close(self) -> None:
        self._conn.close()
