from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class CompressedRepresentation:
    summary: str
    source_refs: list[str] = field(default_factory=list)
    coverage: float = 0.0
    omissions: list[str] = field(default_factory=list)
    confidence: float = 0.0
    compression_method: str = "extractive-reference"
    original_artifact_refs: list[str] = field(default_factory=list)


def compress_with_provenance(text: str, *, source_refs: list[str], original_artifact_refs: list[str], max_chars: int = 240) -> CompressedRepresentation:
    summary = text if len(text) <= max_chars else text[:max_chars].rstrip() + "…"
    coverage = min(1.0, len(summary) / max(len(text), 1))
    omissions = [] if coverage == 1.0 else ["truncated_tail"]
    return CompressedRepresentation(summary, source_refs, coverage, omissions, max(0.0, coverage), "bounded-truncation", original_artifact_refs)
