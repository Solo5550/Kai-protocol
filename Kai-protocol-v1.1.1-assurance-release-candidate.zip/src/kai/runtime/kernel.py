from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Callable

from .admission import AdmissionController
from .contracts import ContractEngine, TransitionEngine, TransitionRejected
from .envelope import build_envelope
from .executor import ProcessExecutor
from .identity import IdentityContext
from .models import Contract, Execution, ExecutionState, RuntimeEnvelope, to_primitive
from .store import RuntimeStore


@dataclass
class KernelRun:
    execution: Execution
    envelope: RuntimeEnvelope
    status: str
    output: Any = None
    error: str | None = None
    events: list[dict[str, Any]] | None = None


class ExecutionKernel:
    """Minimal canonical execution kernel. Higher-level intelligence stays outside."""

    def __init__(self, *, store: RuntimeStore | None = None, admission: AdmissionController | None = None,
                 executor: ProcessExecutor | None = None, contract_engine: ContractEngine | None = None,
                 transition_engine: TransitionEngine | None = None) -> None:
        self.store = store or RuntimeStore()
        self.admission = admission or AdmissionController()
        self.executor = executor or ProcessExecutor()
        self.contract_engine = contract_engine or ContractEngine()
        self.transitions = transition_engine or TransitionEngine()

    def submit(self, *, identity: IdentityContext, objective: str, input_data: dict[str, Any], contract: Contract,
               handler: Callable[[dict[str, Any]], Any], timeout: float | None = None, idempotency_key: str | None = None,
               resource_units: float = 1.0, risk: float = 0.0, policy_snapshot_ref: str | None = None) -> KernelRun:
        execution = Execution(
            tenant_id=identity.tenant_id, namespace_id=identity.namespace_id, run_id=identity.run_id,
            execution_id=identity.execution_id, parent_execution_id=identity.parent_execution_id,
            root_execution_id=identity.root_execution_id, trace_id=identity.trace_id, span_id=identity.span_id,
            causal_parent_id=identity.causal_parent_id, region_id=identity.region_id, cell_id=identity.cell_id,
            actor_id=identity.actor_id, objective=objective, input_data=input_data,
            idempotency_key=idempotency_key or f"idem-{identity.execution_id}", policy_snapshot_ref=policy_snapshot_ref,
            contract_ref={"id": contract.id, "version": contract.version},
        )
        if self.store.get_execution(execution.execution_id):
            raise ValueError("duplicate execution_id")
        self.store.create_execution(execution)
        envelope = build_envelope(identity=identity, message_type="ExecutionCommand",
                                  contract_ref=execution.contract_ref, idempotency_key=execution.idempotency_key,
                                  policy_snapshot_ref=policy_snapshot_ref, payload=input_data)
        check = self.contract_engine.validate_execution(execution, contract)
        if not check.ok:
            self._transition(execution, "CONTRACT_REJECTED") if execution.state == ExecutionState.CONTRACT_VALIDATING else self._transition(execution, "BLOCK") if execution.state == ExecutionState.READY else None
            return KernelRun(execution, envelope, "REJECTED", error=";".join(check.errors), events=self.store.events(execution.execution_id))
        self._transition(execution, "CONTRACT_VALIDATED")
        adm = self.admission.admit(units=resource_units, risk=risk)
        if not adm.allowed:
            self._transition(execution, "BLOCK")
            return KernelRun(execution, envelope, "BLOCKED", error=adm.reason, events=self.store.events(execution.execution_id))
        self._transition(execution, "ADMIT")
        self._transition(execution, "EXECUTION_STARTED")
        result = self.executor.execute(execution.execution_id, handler, input_data, timeout=timeout)
        execution.output_data = result.output if isinstance(result.output, dict) else {"value": result.output} if result.output is not None else {}
        execution.observed_outcome = {"status": result.status, "duration_ms": result.duration_ms, "pid": result.pid}
        if result.attestation:
            execution.observed_outcome["attestation_digest"] = result.attestation.get("attestation_digest")
            execution.provenance["attestation_digest"] = result.attestation.get("attestation_digest")
            execution.provenance["manifest_digest"] = result.attestation.get("manifest_digest")
        execution.touch()
        try:
            if result.status == "SUCCESS":
                self._transition(execution, "EXECUTION_COMPLETED")
                self._transition(execution, "OBSERVATION_READY")
                execution.state = ExecutionState.VERIFICATION_PENDING
                execution.state_version += 1
                execution.touch()
                self.store.transition_persist(execution, expected_state_version=execution.state_version - 1, event_type="VERIFICATION_PENDING")
                status = "SUCCESS"
            elif result.status == "TIMEOUT":
                self._transition(execution, "EXECUTION_TIMED_OUT")
                status = "TIMEOUT"
            else:
                self._transition(execution, "EXECUTION_FAILED")
                status = "FAILURE"
        finally:
            self.admission.release(units=resource_units)
        events = self.store.events(execution.execution_id)
        return KernelRun(execution, envelope, status, output=result.output, error=result.error, events=events)

    def run_authorized(self, *, execution: Execution, contract: Contract, handler: Callable[[dict[str, Any]], Any], timeout: float | None, envelope: RuntimeEnvelope) -> KernelRun:
        if execution.state is not ExecutionState.ADMITTED:
            raise TransitionRejected(f"execution must be ADMITTED before canonical execution; got {execution.state.value}")
        self._transition(execution, "EXECUTION_STARTED")
        result = self.executor.execute(execution.execution_id, handler, execution.input_data, timeout=timeout)
        execution.output_data = result.output if isinstance(result.output, dict) else {"value": result.output} if result.output is not None else {}
        execution.observed_outcome = {"status": result.status, "duration_ms": result.duration_ms, "pid": result.pid}
        if result.attestation:
            execution.observed_outcome["attestation_digest"] = result.attestation.get("attestation_digest")
            execution.provenance["attestation_digest"] = result.attestation.get("attestation_digest")
            execution.provenance["manifest_digest"] = result.attestation.get("manifest_digest")
        if result.status == "SUCCESS":
            self._transition(execution, "EXECUTION_COMPLETED")
            self._transition(execution, "OBSERVATION_READY")
            return KernelRun(execution, envelope, "SUCCESS", output=result.output, events=self.store.events(execution.execution_id))
        if result.status == "TIMEOUT":
            self._transition(execution, "EXECUTION_TIMED_OUT")
            return KernelRun(execution, envelope, "TIMEOUT", error=result.error, events=self.store.events(execution.execution_id))
        self._transition(execution, "EXECUTION_FAILED")
        return KernelRun(execution, envelope, "FAILURE", error=result.error, events=self.store.events(execution.execution_id))

    def _transition(self, execution: Execution, event: str) -> None:
        expected = execution.state_version
        self.transitions.transition(execution, event, required_state_version=expected)
        self.store.transition_persist(execution, expected_state_version=expected, event_type=event, event_payload={"state": execution.state.value, "state_version": execution.state_version})

    def cancel(self, execution: Execution) -> Execution:
        if execution.state in {ExecutionState.RUNNING, ExecutionState.ADMITTED}:
            if execution.state is ExecutionState.RUNNING:
                execution.state_version_before_cancel = execution.state_version if hasattr(execution, "state_version_before_cancel") else execution.state_version
            if execution.state is ExecutionState.RUNNING:
                self.executor.cancel(execution.execution_id)
            else:
                self._transition(execution, "CANCEL_REQUESTED")
            if execution.state is ExecutionState.RUNNING:
                self._transition(execution, "CANCEL_REQUESTED")
            self._transition(execution, "CANCEL_PROPAGATE",)
            self._transition(execution, "CANCEL_ACK")
            self._transition(execution, "STOP")
            self._transition(execution, "CANCELLED")
            return execution
        if execution.state in {ExecutionState.CLOSED, ExecutionState.CANCELLED, ExecutionState.REJECTED, ExecutionState.BLOCKED}:
            return execution
        raise TransitionRejected(f"cannot_cancel_state:{execution.state.value}")

    def retry(self, execution: Execution) -> Execution:
        if execution.state not in {ExecutionState.TIMED_OUT, ExecutionState.RECOVERED}:
            raise TransitionRejected(f"cannot_retry_state:{execution.state.value}")
        self._transition(execution, "RETRY")
        execution.attempt += 1
        execution.idempotency_key = f"{execution.idempotency_key}:attempt-{execution.attempt}"
        self.store.transition_persist(execution, expected_state_version=execution.state_version, event_type="RETRY_ATTEMPT", event_payload={"attempt": execution.attempt, "state": execution.state.value})
        return execution

    def recover(self, execution: Execution) -> Execution:
        if execution.state not in {ExecutionState.FAILED, ExecutionState.TIMED_OUT, ExecutionState.PARTIALLY_COMPLETED, ExecutionState.RECOVERY_PENDING}:
            raise TransitionRejected(f"cannot_recover_state:{execution.state.value}")
        if execution.state is not ExecutionState.RECOVERY_PENDING:
            self._transition(execution, "RECOVER")
        self._transition(execution, "RECOVERY_STARTED")
        self._transition(execution, "RECOVERED")
        return execution

    def reconstruct(self, execution_id: str) -> dict[str, Any]:
        execution = self.store.get_execution(execution_id)
        if execution is None:
            raise KeyError(execution_id)
        return {"execution": to_primitive(execution), "events": self.store.events(execution_id)}
