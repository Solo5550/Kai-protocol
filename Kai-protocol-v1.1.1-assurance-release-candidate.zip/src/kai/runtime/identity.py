from __future__ import annotations

from dataclasses import dataclass
from uuid import uuid4

from .models import Execution


@dataclass(frozen=True)
class IdentityContext:
    tenant_id: str
    namespace_id: str
    run_id: str
    execution_id: str
    parent_execution_id: str | None
    root_execution_id: str
    trace_id: str
    span_id: str
    causal_parent_id: str | None
    region_id: str
    cell_id: str
    actor_id: str

    @classmethod
    def root(cls, *, tenant_id="default", namespace_id="default", region_id="local", cell_id="cell-local", actor_id="system"):
        execution_id = f"exec-{uuid4()}"
        return cls(
            tenant_id=tenant_id, namespace_id=namespace_id, run_id=f"run-{uuid4()}", execution_id=execution_id,
            parent_execution_id=None, root_execution_id=execution_id, trace_id=f"trace-{uuid4()}",
            span_id=f"span-{uuid4()}", causal_parent_id=None, region_id=region_id, cell_id=cell_id, actor_id=actor_id,
        )

    def child(self, *, execution_id: str | None = None, region_id: str | None = None, cell_id: str | None = None, actor_id: str | None = None) -> "IdentityContext":
        child_id = execution_id or f"exec-{uuid4()}"
        return IdentityContext(
            tenant_id=self.tenant_id,
            namespace_id=self.namespace_id,
            run_id=self.run_id,
            execution_id=child_id,
            parent_execution_id=self.execution_id,
            root_execution_id=self.root_execution_id,
            trace_id=self.trace_id,
            span_id=f"span-{uuid4()}",
            causal_parent_id=self.execution_id,
            region_id=region_id or self.region_id,
            cell_id=cell_id or self.cell_id,
            actor_id=actor_id or self.actor_id,
        )


def execution_from_identity(identity: IdentityContext, *, objective: str, input_data: dict | None = None, **kwargs) -> Execution:
    return Execution(
        tenant_id=identity.tenant_id,
        namespace_id=identity.namespace_id,
        run_id=identity.run_id,
        execution_id=identity.execution_id,
        parent_execution_id=identity.parent_execution_id,
        root_execution_id=identity.root_execution_id,
        trace_id=identity.trace_id,
        span_id=identity.span_id,
        causal_parent_id=identity.causal_parent_id,
        region_id=identity.region_id,
        cell_id=identity.cell_id,
        actor_id=identity.actor_id,
        objective=objective,
        input_data=input_data or {},
        **kwargs,
    )
