from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .models import LineageEdge, RuntimeObject, utcnow
from .store import RuntimeStore


@dataclass(frozen=True)
class ProvenanceRecord:
    provenance_id: str
    entity_id: str
    activity_id: str
    agent_id: str
    relation: str
    source_id: str | None = None
    used_entity_id: str | None = None
    generated_entity_id: str | None = None
    created_at: str = field(default_factory=utcnow)


class ProvenanceEngine:
    def __init__(self, store: RuntimeStore) -> None:
        self.store = store

    def record(self, *, entity_id: str, activity_id: str, agent_id: str, relation: str,
               source_id: str | None = None, used_entity_id: str | None = None, generated_entity_id: str | None = None) -> ProvenanceRecord:
        rec = ProvenanceRecord(provenance_id=f"prov-{entity_id}-{activity_id}", entity_id=entity_id, activity_id=activity_id, agent_id=agent_id, relation=relation, source_id=source_id, used_entity_id=used_entity_id, generated_entity_id=generated_entity_id)
        obj = RuntimeObject(object_id=rec.provenance_id, provenance={"entity_id": entity_id, "activity_id": activity_id, "agent_id": agent_id, "relation": relation, "source_id": source_id, "used_entity_id": used_entity_id, "generated_entity_id": generated_entity_id})
        self.store.put("provenance", obj)
        return rec

    def derive(self, source_id: str, artifact_id: str, *, activity_id: str, agent_id: str) -> LineageEdge:
        edge = LineageEdge(object_id=f"lineage-{source_id}-{artifact_id}", from_id=source_id, to_id=artifact_id, relation="DERIVED_FROM", causality=activity_id)
        self.store.put("lineage", edge)
        self.record(entity_id=artifact_id, activity_id=activity_id, agent_id=agent_id, relation="DERIVATION", source_id=source_id, generated_entity_id=artifact_id)
        return edge

    def lineage(self, object_id: str) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for kind in ("lineage", "provenance"):
            # SQLite reference store intentionally exposes a bounded query through internal helper when needed.
            row = self.store._conn.execute("SELECT payload FROM objects WHERE kind=?", (kind,)).fetchall()
            for item in row:
                import json
                data = json.loads(item[0])
                if object_id in str(data):
                    result.append({"kind": kind, **data})
        return result
