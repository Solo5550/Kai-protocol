# Kai Performance Lab — Root Cause & Treatment Report

Overall lab status: **PASS**

## Findings

- **F1 [HIGH]** canonical text codec is slower than compact binary transport — evidence: `{"compact_roundtrips_per_s": 29607.323401996884, "improvement_pct": 25.052463222227605, "text_roundtrips_per_s": 23675.921800422635}`
- **F2 [MEDIUM]** compact representation reduces wire size — evidence: `{"compact_avg_bytes": 432.46063, "reduction_pct": 3.1336051648084826, "text_avg_bytes": 446.45063}`
- **F3 [MEDIUM]** latency tail is materially above median — evidence: `{"max_ms": 0.81078, "p50_ms": 0.013069, "p99_ms": 0.05366040999999993}`
- **F4 [HIGH]** retained Message objects have measurable per-message RSS cost — evidence: `{"python_heap_peak_bytes": 264090872, "rss_per_message_bytes": 2167.406592}`
- **F5 [HIGH]** disk-backed compact journal provides bounded-memory retention path — evidence: `{"journal_bytes_per_message": 433.460857, "messages_per_s": 44814.72193558986}`
- **F5b [MEDIUM]** checkpointed journal recovery avoids full-file scan on clean reopen — evidence: `{"messages": 250000, "reopen_speedup": 428.7190772322079}`
- **F6 [MEDIUM]** parallel speedup must be judged on fixed total work; process startup can mask gains for small batches — evidence: `{"speedup": 1.7736082204686052, "workers": 4}`
- **F7 [LOW]** repeated throughput stability is measurable across fixed workloads — evidence: `{"ci95_half_width_messages_per_s": 294.09592205977066, "cv": 0.0047106519923106145, "mean_messages_per_s": 71225.73052548108}`

## Root Causes

- **RC1** text framing performs line parsing, base64 decoding/encoding, JSON payload parsing, and canonical SHA-256 verification per message
- **RC2** runtime scheduling/allocator/cache noise in an unfixed benchmark environment is visible in p99/max
- **RC3** retaining fully materialized Message objects creates avoidable Python object/dict overhead at high history cardinality
- **RC4** parallel orchestration includes process startup and Python-level scheduling overhead
- **RC5** single-run timing is insufficient to distinguish true regression from host noise

## Treatment Plan

- **T1** (implemented) — use KAI-BIN/1 for high-volume transport; retain KAI-LANG/0.1 as canonical human/audit representation
- **T2** (implemented in lab; host pinning remains environment-dependent) — warm up, repeat fixed workloads, report CV/95% CI, and pin CPU/host conditions where the environment permits
- **T3** (implemented) — use slots, suppress redundant derived history, and move high-volume retention to MessageJournal
- **T3b** (implemented) — use atomic checkpoint sidecar and tail-only recovery with safe full-scan fallback
- **T5** (partially implemented; deployment integration remains) — fix total work, batch work, and reserve long-lived worker-pool reuse for service deployment

## Gate

No optimization is accepted without regression tests, deterministic replay, security/failure-injection checks, and a measured comparison against the prior artifact.
