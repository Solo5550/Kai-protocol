# Kai Assurance Operating Model v1

## Executive architecture

The assurance process is a control plane around Kai, not a second execution kernel:

`Contract → Forensics → Reverse model → Failure/Bottleneck/Gap/Drift census → Root cause → Solution matrix → Portfolio → ADR → Clean-state remediation → Build → Layered verification → Adversarial/Mutation/Chaos/Security → Performance → Reproducibility → Regression → Release gate`

A critical gate that fails does not get locally waived. The promotion attempt returns to root-cause analysis, the repair is recorded, and the downstream gates are rerun.

## Depth router

The existing `AdaptiveDepthController` remains the deterministic depth selector. High uncertainty, high impact, high attack surface, irreversibility, evidence conflict, and observability gaps increase depth. The release controller adds an explicit stop-the-line rule: critical-gate failure overrides any numerical score.

## Reasoning / evidence matrix

| Dimension | Required question | Hard evidence | Exit rule |
|---|---|---|---|
| Contract | Is the expected behavior explicit? | Stage contract + target file | No implicit acceptance |
| Forward | Does implementation satisfy declared behavior? | Unit/integration/system tests | Critical failures = stop |
| Reverse | Can behavior be reconstructed from artifacts? | Schema, state machine, archaeology, reconstruction | Missing causal path = stop |
| Adversarial | Does malformed/hostile input fail safely? | Adversarial + fuzz + security tests | Any unsafe acceptance = stop |
| Recovery | Does failure preserve safety and evidence? | Kill, corruption, partial completion, node-loss tests | Ambiguous side effect = review |
| Performance | Does the candidate meet a declared non-regression target? | Repeated measurement + baseline | Below threshold = root cause |
| Reproducibility | Can a clean environment recreate the artifact? | Clean build/install + digest | Mismatch = stop |
| Provenance | Can source → build → artifact be traced? | SBOM + provenance + hash | Production requires external attestation |

## Failure / bottleneck / gap / drift matrix

`Failure` means observed incorrect behavior. `Bottleneck` means a stage that cannot make progress. `Gap` means a missing contract/evidence/test/control. `Drift` means a previously valid assumption no longer matches the environment, dependency graph, protocol, or measured behavior.

Severity is not a score. Critical findings block promotion.

## Root-cause matrix

A root cause is admissible only when it has: affected findings, a mechanism, evidence, counter-evidence review, and a falsifier. A hypothesis without a falsifier is not a closure condition.

## Solution matrix

Solutions are evaluated on risk reduction, observability gain, cost, reversibility, and dependency load. The portfolio is deterministic; no single scalar score is treated as truth.

This deliberately absorbs ideas from fault-based testing, reproducibility engineering, secure software development, and release engineering rather than treating each as an isolated checklist. NIST SSDF emphasizes integrating security practices into the SDLC and addressing root causes; reproducible-build guidance defines bit-for-bit rebuildability; mutation testing literature uses seeded faults to measure test effectiveness; Google SRE's canary guidance uses limited exposure and measured evaluation before wider rollout; SLSA requires provenance tied to an artifact and emphasizes completeness, authenticity, and accuracy.

## Promotion policy

### Release Candidate

Internal gates must pass. Local chaos/node-loss and rollback drills must pass. Unsigned local provenance is recorded but not treated as production certification.

### Production Claim

In addition to internal gates: signed/external provenance, independent security review, canary evidence, rollback drill evidence, and external qualification are mandatory. This is an evidence policy, not a score.

GitHub branch protection should require the internal assurance jobs before merge; GitHub's protected-branch model supports required status checks and can prevent merging when checks have not passed.

## Why the methodology avoids a blind full rewrite

The forensic evidence does not justify discarding the protocol/runtime core that already passes its contracts. The clean-state rewrite is applied to the assurance/release control plane and to defect-bearing modules only. This keeps the semantic surface stable while replacing weak control paths with explicit gates. A wholesale rewrite would destroy the strongest regression evidence and expand the unknown state space.
