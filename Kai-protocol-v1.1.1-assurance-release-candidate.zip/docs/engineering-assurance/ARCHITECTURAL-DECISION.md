# Architectural Decision — Assurance Control Plane

**Decision:** Keep Kai's protocol/runtime semantics stable and introduce a clean-state, fail-closed assurance control plane around them. Apply targeted rewrites only to defect-bearing execution/lifecycle modules.

## Rejected approach

A repository-wide rewrite of the protocol and runtime core was rejected because the existing implementation has a broad passing regression corpus, protocol conformance vectors, reconstruction tests, recovery tests, and isolation qualification evidence. Replacing all of it would invalidate the most valuable evidence and increase the unobserved state space.

## Selected architecture

1. `kai.protocol` remains the contract surface.
2. `kai.runtime` remains the execution surface.
3. `kai.engine` remains the reasoning/census surface.
4. `kai.assurance` becomes the explicit release-control plane.
5. `tools/` contains reproducible campaign runners; they are not trusted runtime dependencies.
6. CI becomes the merge enforcement surface.
7. External attestations remain outside the repository's local trust boundary.

## Required invariants

- No critical gate can be silently skipped.
- Critical failure reroutes to root-cause analysis.
- Runtime execution cannot fall back from hard isolation to the legacy process executor.
- Orphan child processes are not acceptable release evidence.
- Artifact provenance is bound to artifact digest.
- Performance claims use a declared target and measured baseline.
- Local assurance never masquerades as independent certification.
