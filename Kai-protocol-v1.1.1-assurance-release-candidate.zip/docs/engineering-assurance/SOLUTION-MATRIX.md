# Solution Matrix — v1.1.1 Hardening

| Root cause / gap | Treatment | Risk reduction | Observability gain | Cost | Reversibility | State |
|---|---|---:|---:|---:|---:|---|
| Release metadata drift | Single version source + release verification refresh | 0.85 | 0.90 | 0.20 | 0.95 | Implemented |
| Shell command injection path | argv + `shell=False` + fail closed | 1.00 | 0.95 | 0.20 | 0.90 | Implemented |
| Process lifecycle ambiguity | Executor close/reap API + explicit maintenance cleanup | 0.85 | 0.95 | 0.30 | 0.90 | Implemented |
| CI was advisory | Separate assurance jobs + required-check policy | 0.90 | 0.95 | 0.20 | 0.90 | Workflow implemented; branch protection external |
| Differential coverage gap | JSON Schema oracle differential campaign | 0.80 | 0.90 | 0.25 | 0.95 | Implemented |
| Boundary fuzzing gap | deterministic targeted fuzz harness | 0.80 | 0.90 | 0.20 | 0.95 | Implemented |
| Performance gate was descriptive | measured target + p50/p95/p99 reporting | 0.70 | 0.90 | 0.25 | 0.95 | Implemented |
| SBOM/provenance gap | CycloneDX + SLSA-shaped local provenance | 0.75 | 1.00 | 0.25 | 0.95 | Implemented locally; signed external attestation pending |
| Independent security assurance gap | external review package + evidence index | 1.00 | 0.85 | 0.60 | 0.70 | Pending external |
| Canary/rollback evidence gap | release evolution gates + node-loss/rollback drills | 0.90 | 0.95 | 0.35 | 0.80 | Local drill implemented |
