# Kai Performance Lab

The Performance Lab is an independent harness outside `src/kai`. It measures the production implementation without becoming part of production semantics.

## Scope

- million-message creation throughput
- canonical text codec audit throughput
- million-message compact binary codec throughput
- p50/p95/p99/max latency and jitter
- channel ingest throughput
- retained-memory and heap slope
- injected-failure rejection
- multi-process scaling
- root-cause, gap, bottleneck, and vibration census
- repeated stability runs with CV and 95% confidence intervals
- checkpoint-assisted journal recovery versus forced full scan

## Gates

1. Golden semantic/integrity smoke must pass.
2. All injected faults must be rejected.
3. Repeated deterministic workloads must preserve guards.
4. No performance optimization is accepted when regression tests fail or protocol bytes change unexpectedly.
5. Tail-latency vibrations are investigated separately from correctness failures.
6. Heavy stages are isolated when necessary so the benchmark harness cannot become a shared resource bottleneck.

## Architecture decision

Kai keeps two intentionally different representations: `KAI-LANG/0.1` for canonical human/audit interchange and `KAI-BIN/1` for high-throughput code-to-code transport. This avoids weakening the auditable text contract merely to obtain transport speed.
