# Kai Language v0.1

Kai now has a language layer above the stable `kai/0.2` message wire format.

## Purpose

Kai Language is a deterministic machine-to-machine discourse format. It is not natural-language chat and does not require an AI agent. Programs exchange typed speech acts and adjudication artifacts.

The canonical dialogue vocabulary is:

`CONTRACT → OBSERVATION → CLAIM → EVIDENCE → ASSUMPTION → DEPENDENCY → ARGUMENT → OBJECTION → COUNTEREXAMPLE → HYPOTHESIS → TEST → RESULT → FAILURE → ROOT_CAUSE → REVISION → REBUTTAL → RECONSTRUCTION → VERDICT → PROMOTE/REOPEN/BLOCK`

## Text encoding

A transport frame is UTF-8 text with the header `KAI-LANG/0.1` and fixed fields:

```text
KAI-LANG/0.1
TYPE CLAIM
MSG <content-address>
UNIT unit-1
ROUND 1
LAYER 2
DIRECTION horizontal
PARENTS <id>,<id>
PAYLOAD <base64url(canonical-json)>
PROVENANCE <base64url(canonical-json)>
INTEGRITY sha256:<digest>
END
```

The text representation is a human/developer inspection format. The payload remains structured JSON after base64url decoding.

## Dialogue semantics

`KaiChannel` establishes one global `CONTRACT`, then maintains an independent deterministic dialogue state for each `unit_id`. This permits interleaving conversations between multiple code participants without collapsing them into one linear thread.

An `ACCEPTED` verdict is fail-closed at the dialogue layer: open objections must be resolved. A local dialogue may inherit passing tests from its parent/synthesis context when the channel is configured for pipeline mode.

## Determinism

Message IDs are content-addressed from the message body with an empty ID placeholder. Replaying the same input with the same actor/provenance produces the same message ID and integrity digest.

## What Kai Language is not

The language layer is not encryption. Confidential material uses the separate Kai Secret Envelope. Integrity uses SHA-256 and optional authority signatures use Ed25519.


## KAI-BIN/1 compact transport

Kai defines a compact binary transport path in addition to the canonical `KAI-LANG/0.1` textual form. KAI-BIN/1 preserves the kai/0.2 message envelope, verifies the existing SHA-256 message integrity, and adds length-framed MessagePack encoding for high-volume code-to-code transport. Batch helpers support streaming without retaining an entire conversation in memory.

The text form remains the human/audit representation; the binary form is a performance representation. Neither changes the underlying dialogue semantics.
