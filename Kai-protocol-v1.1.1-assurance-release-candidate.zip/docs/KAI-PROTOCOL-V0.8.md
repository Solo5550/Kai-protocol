# Kai Protocol v0.8 — Semantic Interoperability Core

## Decision

Kai v0.8 establishes a transport-independent semantic protocol for trustworthy software-to-software interaction. The legacy `kai/0.2` wire contract remains supported; v0.8 is a semantic layer above it.

## Core model

Every interaction is expressed as:

`Intent → Authority → Capability → Contract → Execution → Effect → Outcome → Proof → Provenance`

Not every message contains every node, but effectful requests must carry authority and an idempotency key, and all messages carry deterministic causality and integrity metadata.

## Speech acts

`REQUEST`, `ACCEPT`, `REJECT`, `PROGRESS`, `RESULT`, `FAILURE`, `RECOVER`, `PROOF`, `EVENT`.

These are semantic acts, not transport verbs. They are valid across in-process calls, HTTP, TCP, WebSocket, queues, or another transport.

## Deterministic identity

`message_id = SHA-256(canonical(message with message_id="" and no integrity))`

`integrity.digest = SHA-256(canonical(message with actual message_id and no integrity))`

This gives independent implementations a common identity and tamper-detection rule without trusting a Python object representation.

## Causality

Every message has `conversation_id`, `correlation_id`, monotonically increasing `sequence`, and parent/causation references. A compliant dialogue ledger rejects replay and non-causal transitions.

## Authority

Authority is explicit and scoped. Effect classes `external_write` and `irreversible` require an authority object plus an idempotency key.

Cryptographic signatures are deliberately an overlay: the semantic model identifies the authority and the signed claim without coupling Kai to one key-management or transport implementation.

## Interoperability boundary

Implementations MUST preserve the semantic model while MAY choose different transport encodings. `KAI-LANG/0.8` is the canonical human/developer JSON frame for the semantic layer.

## Compatibility

`kai/0.2` remains the existing stable wire identity. v0.8 does not redefine it. A future adapter may tunnel v0.8 semantic frames through legacy messages where a legacy transport is required.

## Qualification consequences

Conformance now has four independent dimensions:

1. semantic schema validity;
2. deterministic identity/integrity;
3. dialogue causality/replay safety;
4. effect authorization/idempotency boundary.

A passing unit test alone does not create release certification. Independent qualification, external attestation, deployment evidence, and governance remain separate gates.

## v0.8 Conformance Stack

The semantic profile is identified by `schema_id = kai/semantic/0.8`. Its closed schema, language-neutral vectors, canonical frame adapter, and independent Go verifier are documented in `docs/KAI-PROTOCOL-V0.8-CONFORMANCE.md`.
