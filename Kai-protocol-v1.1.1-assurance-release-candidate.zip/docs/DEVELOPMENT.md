# Development workflow

Kai is intended to accumulate capability without losing traceability.

## Governing iteration contract

`MASTER PREFLIGHT → CONTRACT → FORENSIC SNAPSHOT → DECOMPOSE → EVIDENCE → CHALLENGE → TEST → RESULT → REVISION → ROOT CAUSE → SOLUTION PORTFOLIO → IMPLEMENT → ASSURANCE CASCADE → RECONSTRUCT → MASTER POSTFLIGHT → BENCHMARK → PROMOTE`

A failed critical gate must remain visible and must point back to the affected unit and root-cause branch.

## Adding a new domain adapter

Keep the protocol layer domain-neutral. Add domain-specific equivalence, scoring, extraction, or test executors behind an adapter. The adapter must return ordinary Kai artifacts: evidence, tests, results, provenance, objections, and revisions.

If a domain requires expert methods beyond the built-in deterministic protocol analysis, declare them in the run contract through `expert_methods` rather than hiding them inside the implementation.

## Reproducibility

A reproducible test should carry executor identity/version, normalized inputs, expected property, and a stable result/reproducibility key when applicable.

## MASTER semantics

MASTER scores are diagnostic process-assurance indicators. They never override gates. `PROMOTE` is gate-based and fail-closed.

The `SKEPTIC` stage records adverse findings without turning their existence into an automatic failure. Critical unresolved findings, however, prevent promotion.

`ALTERNATIVES` and `COMPARE` are conditional and should only be activated when the contract actually contains a decision-options problem.

## Semantics of proof

Use formal proof only when the domain and artifact type justify it. For empirical, historical, or mixed evidence, preserve the distinction between evidence, corroboration, inference, and formal proof.
