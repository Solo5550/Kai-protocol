# Root-Cause and Repair Log — v0.6.0 → v0.6.1 maintenance-qualified reference

## Finding KAI-RC-0001

Symptom: a caller-supplied handler could reach the Kernel after capability resolution.

First invalid state: `RESOLVED_CAPABILITY != INVOKED_IMPLEMENTATION`.

Root cause: the execution API resolved a qualified Registry implementation but did not bind the Kernel invocation to that resolved implementation.

Repair: Runtime now fetches the resolved implementation from `CapabilityRegistry`, records `CAPABILITY_RESOLVED`, rejects handler substitution, records a `BLOCK` transition, and records `CAPABILITY_HANDLER_BOUND` for the accepted path.

Permanent shield: adversarial handler-substitution regression + architecture-fitness assertion.

## Finding KAI-RC-0002

Symptom: the shared SQLite store could exhibit API misuse under concurrent read/write access.

Root cause: `RuntimeStore` permitted shared-connection access from multiple threads while several read paths did not acquire the store's existing RLock.

Repair: authoritative read paths now use the same RLock protecting writes.

Permanent shield: concurrent RuntimeStore read test + kernel concurrency probe.

## Test-system repair

The maintenance harness itself briefly contained three defects that were found and removed before qualification:

1. recursive pytest invocation from a maintenance unit test;
2. non-picklable local multiprocessing handlers;
3. an oracle that compared volatile envelope metadata instead of semantic fields.

These were test-oracle/harness defects, not silently treated as Runtime defects.

## Release boundary

The package version is `0.6.1`; the wire/runtime contract remains `runtime/0.6` and schema compatibility remains `0.6.0` where required. The maintenance layer remains control-plane-only and does not introduce a parallel executor.
### KAI-RC-0003 — Hard-Isolation Python Environment Portability

- Finding class: CODE / INTEGRATION / CONFIGURATION
- Trigger: clean-wheel hard-isolation smoke from an ordinary virtualenv
- First invalid state: worker bootstrap invoked a virtualenv interpreter path that was not mounted inside the chroot
- Propagation: worker exited before handler execution; attestation reported `isolated_worker_exit`
- Root cause: bootstrap assumed the interpreter/dependency tree lived under the base runtime prefix
- Remediation: resolve the real interpreter path; mount the active `purelib` read-only at `/kai-python-site`; inject `PYTHONPATH` only after `setpriv --reset-env`
- Regression shield: `test_bootstrap_mounts_installed_purelib_inside_chroot`
- Status: REMEDIATED / REQUALIFIED

