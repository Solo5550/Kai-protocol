# Kai Protocol v0.8 / package 0.8.1 — Final Conformance Requalification

Status: `CONDITIONALLY_QUALIFIED`

Semantic protocol: `kai/semantic/0.8`

Package release: `0.8.1`

Regression evidence: **192/192 PASS** in the isolated regression qualification. After the package-only version bump, **44 protocol/integration/version-sensitive tests** were re-run and passed. The bump changed package metadata only; the runtime semantic implementation was unchanged.

Semantic conformance: **2/2 Python vectors**, **2/2 Go vectors**, matching `message_id` and `integrity.digest`.

Mutation red-team: **10/10 mutations rejected**.

Clean wheel smoke: PASS; fresh environment import reports package `0.8.1`, schema id `kai/semantic/0.8`, semantic conformance PASS, runtime conformance PASS.

Wheel SHA-256: `73416a3efdf3dd7e543fa085ad3481edf83b6bd996a4f595f7fa4d7285bacf12`

Production certification remains false because governance approval, independent qualification, live canary/SLO/error-budget evidence, regional failover/node-loss chaos, and external supply-chain attestation are not locally available.
