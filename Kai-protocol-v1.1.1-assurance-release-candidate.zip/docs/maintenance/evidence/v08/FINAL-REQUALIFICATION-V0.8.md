# Kai Protocol v0.8.0 — Final Local Requalification

**Status:** CONDITIONALLY_QUALIFIED

**Stage accepted:** FALSE

**Production certification:** FALSE

## Local evidence

- 45 test files / 186 tests collected. Final executed evidence: 186 passed, 0 failed.
- Process-heavy suites were qualified in isolated processes to prevent child-process lifecycle contamination.
- Strict DeprecationWarning runs for cluster, chaos, API, EffectLedger, and v0.8 protocol tests passed after fixing pytest async fixture scope.
- Clean wheel install smoke passed with package `0.8.0`, language `kai-lang/0.8`, legacy wire `kai/0.2`, and runtime conformance.
- v0.8 forensic probe passed semantic contract, deterministic identity, tamper detection, causal dialogue, replay rejection, endpoint authorization/idempotency, authority signature, fail-closed remote exposure, and performance smoke.

## Performance observation

Local semantic-message benchmark: p50 build latency ≈ 43.8 ms per 2,000-message batch; p50 build throughput ≈ 45.7k message constructions/s; p50 encode/decode round-trip ≈ 110.3 ms per 2,000-message batch. These are engineering observations, not production SLOs.

## Remaining blockers

Change governance, independent qualification, canary/progressive deployment, SLO/error-budget evidence, regional failover, node-loss chaos at deployment scale, and external supply-chain attestation remain BLOCKED. No false production certification is asserted.

The process follows the same root-cause/prevention orientation as NIST SSDF: address the underlying cause and prevent recurrence rather than treating the symptom alone. citeturn220312search0turn220312search2
