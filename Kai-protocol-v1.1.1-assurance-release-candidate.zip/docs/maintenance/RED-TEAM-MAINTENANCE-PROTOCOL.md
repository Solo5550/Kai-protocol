# Kai Optional Global Red-Team Maintenance, Root-Cause Repair, Rebuild & Requalification Protocol

Version: `maintenance/1.0`

This is an independent maintenance/control layer. It MUST NOT add runtime capabilities, create an alternate execution path, or bypass Runtime Contracts, Policies, Security Controls, Authorization, or State Semantics.

## Closed Loop

`INSPECT → TEST → BREAK → MEASURE → RECONSTRUCT → DIAGNOSE → ROOT CAUSE → REDESIGN → REPAIR → REBUILD → RETEST → REQUALIFY → OBSERVE → CERTIFY`

## Governing semantics

`MUST` = mandatory. `MUST NOT` = prohibited. `SHOULD` = strong default with documented exception. `MAY` = optional. `N/A` requires justification and evidence.

`PASSED` is reserved for a gate whose applicable success conditions are fully verified.

Final closure rules:

- No symptom patch as a final repair.
- No root cause → no closure.
- No regression shield → no closure.
- No requalification → no release certification.
- No evidence → no claim.
- No independent verification for high-risk change → no final acceptance.
- No SLO safety → no progressive expansion.
- No provenance → no trusted artifact.
- If design is the cause, no clean rebuild → no acceptance.

## Implementation map

The protocol is implemented by:

- `kai.maintenance.models` — normative enums, findings, cases, evidence, CAPA, alternatives, gates, SLO, debt, waivers, oracles and reports.
- `kai.maintenance.baseline` — reproducible protected baseline and environment signature.
- `kai.maintenance.archaeology` — AST/static archaeology of actual source paths.
- `kai.maintenance.checks` — forward, reverse, adversarial, differential, performance, recovery, security, provenance, reproducibility, concurrency, resource-leak and maintainability probes.
- `kai.maintenance.operational` — containment, blast-radius, SLO, progressive rollout, waiver and debt controls.
- `kai.maintenance.coverage` — explicit 47-section coverage matrix.
- `kai.maintenance.protocol` — orchestration, root-cause reconstruction, CAPA, requalification, closure and conservative certification semantics.

## Boundary

The maintenance layer has no executor and no capability registry of its own. Its probes invoke the existing Kai Runtime only through its public runtime execution semantics.

## External-environment gates

Live canary/progressive deployment, production SLO/error-budget telemetry, multi-node failover/chaos, external supply-chain attestation, and independent operator qualification are runtime-environment concerns. When unavailable they are `BLOCKED`, never silently converted to `PASS`.
