# KAI-RC-0006 — ProcessExecutor spawn concurrency bootstrap failure

## Symptom
Maintenance CONCURRENCY gate FAILED during FULL_RED_TEAM with `concurrency_failure`.
Metrics showed `errors: []` but not all parallel submissions returned SUCCESS.
Isolated diagnosis: concurrent `kernel.submit` via ProcessExecutor returned
`FAILURE` / `worker exited with code 1` for all jobs under ThreadPool pressure.

## First invalid state
Worker process terminated before placing a result on the result queue.

## Trigger
Default ProcessExecutor start method was `spawn`. Under concurrent ThreadPool
submission of many short-lived workers, spawn bootstrap/reimport races produced
non-deterministic exit-code-1 failures. This is an executor topology defect, not
a RuntimeStore lock race (RC-0002 was already closed).

## Classification
ARCHITECTURE / CODE / TEST-ORACLE interaction  
Layer: ProcessExecutor start-method policy + concurrency probe measurement target

## Root cause
`ProcessExecutor` preferred `spawn` whenever available. Spawn is required for some
cross-platform and frozen-binary cases, but is the wrong default for local concurrent
process isolation of pure callables on POSIX. The concurrency probe then measured
spawn fragility rather than store/kernel concurrency invariants.

## Radical remediation (no patch)
1. ProcessExecutor defaults to `fork` on POSIX when available; callers must opt into
   `start_method="spawn"` explicitly when required.
2. Worker empty-queue error includes `start_method` for diagnosis.
3. Concurrency probe constructs ProcessExecutor explicitly and records `start_method`
   in metrics; evidence tag `KAI-RC-0006`.

## Permanent shield
- CONCURRENCY gate must pass under FULL_RED_TEAM
- Regression: concurrent kernel submissions with fork-default executor
- Documentation: ROOT-CAUSE-0006.md

## Status after repair
CONCURRENCY: PASS (throughput ~195 jobs/s, start_method=fork)
Maintenance qualification: CONDITIONALLY_QUALIFIED
