# Kai Protocol v0.8 — Normative Semantic Interoperability Profile

## Status

`0.8` is an experimental semantic protocol profile. The legacy `kai/0.2` wire protocol remains supported and is not redefined by this document.

## Design rule

The semantic model is transport-independent. HTTP, TCP, WebSocket, queues, and in-process calls are transports; they do not define Kai semantics.

## Canonical message

Every v0.8 message has a deterministic envelope with these fields:

`protocol, semantic_version, schema_id, message_id, conversation_id, sender, recipient, act, intent, causality, authority, capability, contract, input, expected, execution, outcome, effects, proof, provenance, extensions, integrity`

The field set is fixed. Implementation-specific extensions belong under `extensions` and MUST NOT redefine core fields.

## Identity and integrity

`message_id` is SHA-256 of canonical JSON with `integrity` removed and `message_id` replaced by the empty string. `integrity.digest` is SHA-256 of canonical JSON with `integrity` removed.

The authority signature, when present, is excluded from identity so signing does not change message identity. The signature itself MUST be verified separately.

## Canonical JSON profile

Kai uses compact UTF-8 JSON with lexicographically ordered object keys, no insignificant whitespace, duplicate object keys forbidden, and non-finite numbers forbidden. Implementations MUST preserve the same logical JSON value while emitting the canonical byte sequence before hashing.

The v0.8 reference conformance vectors use ASCII structural values and JSON integer values to make cross-language verification straightforward. Implementations MAY support wider JSON values when their canonicalizer is proven equivalent.

## Authority and effects

`external_write` and `irreversible` capabilities require authority and an idempotency key. A tenant-scoped endpoint requires an authority bearing the exact tenant identifier. A missing or ambiguous tenant authority is denied.

## Dialogue

Messages form a causal sequence within a conversation. Replays and non-monotonic sequences are rejected. A response MUST causally reference the request or immediately preceding message.

## Conformance

A conforming implementation MUST pass:

1. schema validation;
2. deterministic identity vectors;
3. integrity/tamper vectors;
4. causality/replay vectors;
5. effect authorization vectors;
6. idempotency concurrency vectors;
7. legacy compatibility tests.

No single local test suite constitutes independent qualification or production certification.

## Schema governance

`spec/kai/0.8/semantic.yaml` is the source registry for the protocol profile. `semantic.schema.json` is the generated/checked machine-readable schema artifact. Future minor versions MUST introduce a new `schema_id` and a documented compatibility rule rather than silently changing the meaning of `kai/semantic/0.8`.
