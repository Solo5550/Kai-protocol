# Kai Protocol v0.4.1 — Performance & Efficiency Assurance

## Change
The dominant session mutation hotspot was repeated full replay of the complete `KaiChannel` after every appended message. The authoritative message log remains unchanged, but the derived language projection is now updated incrementally.

## Safety behavior
If incremental ingestion unexpectedly fails, Kai rebuilds the projection from the authoritative log and records the failure. This preserves fail-closed behavior and prevents silent state drift.

## Measurements
Representative workload: 40 units, 120 evidence/test mutations, one result mutation.

| Version | Time |
|---|---:|
| v0.4 pre-optimization | 0.035711 s |
| v0.4.1 optimized | 0.029132 s |

Measured improvement: approximately **18.4%** for this workload. This is not a universal throughput guarantee.

## Correctness gates
- Regression tests: **38/38 PASS**
- `compileall`: **PASS**
- Wheel build: **PASS**
- Local wheel installation: **PASS**
- Installed-package import smoke test: **PASS**
- Protocol wire identity: remains `kai/0.2`
- Language identity: remains `KAI-LANG/0.1`

## Optimization ceiling roadmap
1. Add pinned CI performance benchmarks.
2. Profile codec and canonical serialization under realistic payload distributions.
3. Introduce batch transport APIs only after measurement proves transport overhead is material.
4. Preserve golden vectors before any serializer or wire-format optimization.
5. Add memory profiling and bounded-resource tests.
6. Add multi-process/multi-node throughput tests before distributed transport.

## Engineering decision
The incremental projection optimization is accepted because it improves the measured hot path without changing protocol semantics, cryptographic primitives, or verdict logic.
