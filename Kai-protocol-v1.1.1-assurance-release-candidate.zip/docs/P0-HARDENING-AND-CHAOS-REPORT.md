# Kai Protocol v0.7.0 — P0 Hardening, Multi-Node and Chaos Qualification

Date: 2026-10-01

## Decision

`P0_REFERENCE_QUALIFIED_WITH_ENVIRONMENTAL_LIMITATIONS`

The standard `KaiRuntime.execute()` path now uses HardIsolationKernelExecutor. L5 and L6 autonomous execution remain blocked. The reference multi-node runtime uses independent OS processes communicating over real TCP sockets.

This is **not** a production certification. Global/multi-host deployment, OS-level network chaos, SLO/error-budget deployment gates, independent security qualification, and external supply-chain attestation remain outside the current environment.

## Phase A — Hard Execution Isolation

Implemented:

- Signed Ed25519 CapabilityManifest bound to capability, implementation, and real contract id/version.
- Manifest code SHA-256 bound to serialized implementation artifact.
- Least-privilege permission boundary.
- Linux user/mount/network/PID/IPC/UTS namespaces.
- chroot root filesystem with read-only runtime mounts and isolated writable tmpfs/work paths.
- CPU, address-space, file-size, file-descriptor, and process quotas.
- Parent-death termination for isolated workers.
- seccomp denial of `clone`, `clone3`, `fork`, and `vfork` when `process.spawn` is not granted.
- Signed `AttestedResult` verified by the Runtime before acceptance.
- Host filesystem write/read and network egress containment tests.

P0 isolation/runtime-path targeted tests: PASS.

## Phase B — Real Multi-Node Runtime

Implemented:

`Global Control → Region → Node → Cell → Capability`

with:

- node registration
- lease grant/renew/expiry
- heartbeat
- failure detection
- actual TCP control requests
- independent Node OS processes
- signed capability manifest admission
- artifact digest verification
- durable idempotency and replay protection
- persistent node execution journal
- persistent attestor identity across restart
- state reconciliation
- node restart
- execution recovery inspection
- storage backup/restore
- distributed execution provenance in the control-plane result

The present implementation demonstrates multi-node behavior on one Linux host. It does not constitute multi-host or WAN/global certification.

## Phase C — Chaos and Recovery

Validated scenarios:

1. Kill running node → execution becomes `RECOVERY_PENDING`.
2. Network partition → control traffic is denied and failure is observable.
3. Packet loss → control traffic fails closed.
4. Packet delay / delayed delivery → measurable delay and bounded transport timeout behavior.
5. Duplicate delivery → different command ids with the same idempotency key return the original result without re-execution.
6. Storage corruption → node reports `CORRUPT/QUARANTINED`, then backup restore returns it to `HEALTHY/OK`.
7. Clock skew → bounded logical node clock offset is observable.
8. Dependency disappearance → execution is rejected as `DEPENDENCY_UNAVAILABLE`.
9. Partial completion → durable `PARTIALLY_COMPLETED` state survives node restart and requires explicit compensation/review; no implicit retry is performed.

## Test Evidence

- Full project regression: **172/172 PASS**.
- P0 targeted suites: **23/23 PASS** after final packaging/security hardening.
- Additional recovery/chaos runs: PASS.
- `py_compile`: PASS.
- Hard isolation platform probe: PASS in current Linux environment.

The Python 3.13 test environment still reports the standard multiprocessing `fork()` deprecation warning for NodeProcess startup. This does not invalidate the functional results; it remains a maintainability item for a future node-process start-method refactor.

## Environmental Limitation

The current container lacks `CAP_NET_ADMIN`, so Linux kernel `tc/netem` cannot be applied safely/legally in this environment. The P0 network fault cases therefore operate at the Runtime TCP transport control boundary. They are real control-plane fault behaviors, but are not evidence of kernel-level packet shaping or multi-host network partitioning.

## Current Gate

`P0 = REFERENCE_QUALIFIED_WITH_ENVIRONMENTAL_LIMITATIONS`

Do not claim `PRODUCTION_CERTIFIED` until the blocked environmental gates are executed in a dedicated deployment environment.
