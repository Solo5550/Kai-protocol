# Kai Protocol v0.8 — Conformance Stack

Kai v0.8 is now a semantic protocol profile rather than only an in-process Python API.

## Contract

`KAI-LANG/0.8` carries a transport-independent semantic envelope:

`Intent → Authority → Capability → Contract → Execution → Effect → Outcome → Proof → Provenance`

The canonical schema identifier is `kai/semantic/0.8`.

## Interoperability

The protocol's meaning is independent of HTTP, TCP, WebSocket, queues, or in-process transport. The reference endpoint accepts canonical `KAI-LANG/0.8` frames through `KaiEndpoint.handle_frame()`.

The repository ships two language-neutral golden vectors. Python reconstructs and validates the semantic message; a separate Go implementation independently recomputes `message_id` and `integrity.digest`.

## Boundary rules

Top-level fields are closed. Unknown fields are rejected; implementation-specific data belongs in `extensions`.

Effectful capabilities (`external_write`, `irreversible`) require explicit authority and an idempotency key. A tenant-scoped endpoint requires an exact tenant match. Custom authorization policy errors fail closed.

Non-finite numeric values are rejected before identity hashing. Parent lists, effects, extensions, and strings have explicit upper bounds.

## Qualification

The local regression evidence is 192/192 PASS. Process-heavy runtime tests are qualified using isolated test processes; a single monolithic pytest invocation is not used as the certification oracle because child-process lifecycle state can survive file boundaries.

The local result remains `CONDITIONALLY_QUALIFIED`. No local test run creates independent qualification, governance approval, live canary evidence, production SLO/error-budget evidence, regional failover evidence, node-loss chaos evidence, or external supply-chain attestation.

## Evolution rule

`schema_id` is immutable once a profile is released. A future incompatible semantic change MUST use a new schema identifier and document the compatibility transformation. The protocol version and transport implementation MUST NOT silently change the meaning of an existing schema id.
