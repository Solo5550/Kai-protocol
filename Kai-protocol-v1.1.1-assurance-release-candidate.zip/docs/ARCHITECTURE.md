# Architecture

## Governing control plane

`MASTER preflight → Kai execution → native assurance → MASTER postflight → promotion gate`

MASTER is the top-level process-governance layer. It enforces contract completeness, explicit method selection, skeptical review, conditional alternatives/comparison, verification, decision readiness, optimization, execution, debugging, reality checks, output integrity, and continuous improvement.

## Protocol plane

`models → messages → validator → state machine → verdict`

This plane defines what a participant may say, what artifact state is legal, how integrity is checked, and how promotion is adjudicated.

## Reasoning plane

`knowledge graph → forward pyramid → local tests/objections → synthesis → reconstruction`

This plane decomposes a source into independently challengeable units and then reconstructs the whole from the analyzed base.

## Assurance plane

`adaptive depth → failure/bottleneck/gap/drift census → root cause → solution portfolio → gate evaluation`

The assurance plane controls how deeply the system reasons and ensures that uncertainty, contradiction, and operational risk remain visible.

## Fractal recursion

Any nontrivial unit may itself become a local source graph. MASTER can govern that local assurance cone as well; no second reasoning formalism is required.

## No bypass rule

All supported top-level execution paths must enter through `AssurancePipeline`. Lower-level `KaiSession` remains available as an implementation primitive, but it does not constitute a governed promotion path by itself.


## Performance Plane

The independent Performance Lab measures and stress-tests the same kernel through text and compact transport paths. It is deliberately outside the reasoning kernel so measurements cannot alter verdict semantics. See `docs/KAI-PERFORMANCE-LAB.md`.
