# Kai Security Model v0.4

## Separation of concerns

Kai separates four properties:

1. **Canonicalization** — stable serialization for reproducibility.
2. **Integrity** — SHA-256 digest detects accidental or malicious mutation of a message body.
3. **Authority authenticity** — Ed25519 signatures allow developers to verify artifacts signed by an authority without holding the private key.
4. **Confidentiality** — AES-256-GCM secret envelopes protect data that must be readable only by holders of the corresponding 256-bit master key.

## Key ownership

The project source code does not contain a master decryption key. The intended operator flow is to generate a key locally with `kai keygen` and store it with file permissions restricted to the operator. The key identifier is metadata; it is not itself a secret.

Authority signing keys are separate from the decryption key. This prevents a compromise of one capability from automatically granting the other.

## Secret envelope

The envelope includes an authenticated header, random 96-bit nonce, AES-256-GCM ciphertext, and a short key fingerprint for operator diagnostics. The header is included as AEAD associated data, so metadata tampering is authenticated as well.

Nonce uniqueness is generated with the operating system CSPRNG for every seal operation. The implementation does not reuse nonces intentionally.

## Threat model and limits

This is a reference implementation, not a completed security product. It has not received an independent cryptographic audit, penetration test, formal verification, or multi-platform key-management certification. The cryptographic primitives are standard library-backed through `cryptography`, but secure deployment still depends on OS key protection, backups, access controls, memory hygiene, and operational procedures.

The phrase “semi-encrypted knowledge” should therefore be interpreted as **structured knowledge with explicitly encrypted confidentiality zones**, not as a claim that obfuscation itself provides security.


## High-volume retention

For large histories, `MessageJournal` stores authenticated KAI-BIN/1 frames append-only on disk and decodes lazily. The journal defaults to buffered throughput mode; `sync=True` enables per-append durability at the cost of throughput.
