# MASTER × SKILL Execution Matrix

| MASTER | SKILL execution |
|---|---|
| UNDERSTAND | identity, objective, inputs, outputs, constraints |
| FIRST_PRINCIPLES | functional decomposition + capability contracts |
| EXPERT | reasoning matrix dimensions + domain methods |
| SKEPTIC | forensic findings, adversarial checks, counterexamples |
| ALTERNATIVES | solution matrix and portfolio |
| COMPARE | utility, risk, cost, reversibility |
| VERIFY | capability tests + proof evidence |
| DECIDE | governance outcome, not popularity vote |
| OPTIMIZE | bounded lifecycle and resource budgets |
| EXECUTE | build/test/repair/rebuild in sandbox |
| DEBUG | failure census + root-cause loop |
| REALITY_CHECK | environment/resource/security limits |
| OUTPUT | contract, report, lineage, verdict |
| CONTINUOUS_IMPROVEMENT | evolution mutations + retest + promote/reject |

The `/MASTER` layer remains the control plane. A child capability cannot promote itself merely because its own test passed.
