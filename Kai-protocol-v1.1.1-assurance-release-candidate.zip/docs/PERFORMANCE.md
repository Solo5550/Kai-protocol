# Kai Protocol Performance Hardening

## Optimization target

The hot path in `KaiSession` previously rebuilt the complete `KaiChannel` from the full message log after every evidence/test/result/reconstruction/verdict append. This made repeated mutations increasingly expensive as the session grew.

## Optimization

The authoritative message log remains append-only. `KaiChannel` is a derived projection and is now updated incrementally through `_append_message()`. If an unexpected incremental-ingestion error occurs, Kai rebuilds the projection from the authoritative log and records the failure rather than silently accepting drift.

## Measured result

Representative workload: 40 units, 120 evidence/test mutations, and one result mutation.

- Pre-optimization v0.4: ~0.035711 s
- Optimized v0.4.1: ~0.029132 s
- Improvement: ~18.4%

The benchmark is workload-specific and is not a universal throughput claim.

## Correctness gate

The optimization was accepted only after: `38/38` tests passed, `compileall` passed, and the same session semantics remained intact.

## Next performance priorities

1. Add reproducible benchmark suite to CI on pinned runners.
2. Profile `codec.decode_message` and canonical JSON serialization before changing wire semantics.
3. Add batch encode/decode APIs only if transport throughput becomes a measured bottleneck.
4. Do not replace canonical serialization with a faster serializer without golden-vector compatibility tests and an explicit protocol-version decision.
