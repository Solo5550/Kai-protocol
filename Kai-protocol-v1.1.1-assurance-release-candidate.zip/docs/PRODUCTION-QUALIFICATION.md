# Production Qualification Boundary

v0.6.0 implements the semantics needed to qualify a runtime path, but production readiness remains deployment evidence rather than a repository declaration.

Required before production use:

- independent threat-model and security review;
- hardened execution isolation for untrusted capabilities;
- multi-node/multi-region deployment and network-partition evidence;
- durable storage backup/restore and corruption-recovery evidence;
- operational ownership, on-call, SLO/error-budget definitions;
- load/soak/chaos campaigns at deployment scale;
- data-residency/legal policy validation for actual jurisdictions;
- artifact signing/supply-chain controls for actual plugin sources;
- rollback/canary evidence against real service dependencies.
