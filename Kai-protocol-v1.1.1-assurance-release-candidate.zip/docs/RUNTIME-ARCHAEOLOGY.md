# Kai Runtime Archaeology — Phase 0

Baseline: Kai Protocol v0.5.0 reference implementation.

## Inventory

- `kai.protocol`: protocol messages, validation, provenance, state machine, verdicts.
- `kai.language`: KAI-LANG text/compact codecs, dialogue, channel semantics.
- `kai.security`: master-key envelope and Ed25519 authority primitives.
- `kai.skill`: governed capability lifecycle, proof, evolution, reproduction controls.
- `kai.engine`: assurance pipeline, session, census, adaptive depth, root-cause, portfolio.
- `kai.master`: `/MASTER` governance control plane.
- `kai.pyramid`: forward/inverted decomposition and reconstruction.
- `kai.storage`: append-oriented message journal.

## Runtime path before v0.6

The baseline exposes reasoning/skill execution but no single authoritative execution runtime owning identity, contracts, policy, state, admission, scheduling, execution, observation, verification, provenance, proof, recovery, or federation.

## Phase-0 finding

The existing system is a valid v0.5 reasoning/protocol substrate. The v0.6 runtime must be additive and must route new executions through one canonical path without breaking v0.5 APIs or introducing a parallel semantic model.

## Migration rule

Legacy v0.5 components are treated as capabilities/adapters behind runtime contracts. No module is considered integrated solely because it is imported or registered.
