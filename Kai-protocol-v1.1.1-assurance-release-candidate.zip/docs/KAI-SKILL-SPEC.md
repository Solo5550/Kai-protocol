# Kai Protocol SKILL — v0.5.0

## Purpose

`Kai Protocol SKILL` is the governed capability layer above the Kai wire protocol. It turns project-level work into explicit capability decomposition, forensic inspection, reasoning, solution selection, controlled execution, proof/evidence, evolution, and bounded reproduction.

```text
PROJECT
  ↓
CAPABILITY ABSORPTION
  ↓
FUNCTIONAL DECOMPOSITION
  ↓
CAPABILITY GAP ANALYSIS
  ↓
SPECIALIZATION PLAN
  ↓
CHILD-SKILL CONTRACT
  ↓
SPAWN PROPOSAL
  ↓
GOVERNANCE CHECK (/MASTER)
  ↓
SANDBOX
  ↓
BUILD → TEST → REPAIR → REBUILD
  ↓
EVIDENCE / PROVENANCE
  ↓
PROMOTION
  ↓
CHILD BECOMES ACTIVE CELL
```

## SKILL hierarchy

1. IDENTITY / CONTRACT
2. FORENSIC CORTEX
3. REASONING MATRIX
4. SOLUTION ENGINE
5. EXECUTION ENGINE
6. PROOF ENGINE
7. EVIDENCE / PROVENANCE
8. EVOLUTION CORTEX
9. REPRODUCTION ENGINE

## Reproduction model

The implementation deliberately defines reproduction as **capability specialization**, not arbitrary source-code self-copying.

A reproduction proposal must pass:

- Necessity
- Specialization
- Risk boundary
- Resource budget
- Governance

The child is born only inside a sandbox, receives a new explicit contract, and is promoted only after validation and MASTER review.

## Lifecycle levels

| Level | Meaning | Default policy |
|---|---|---|
| L0 | Observe | allowed |
| L1 | Simulate | allowed |
| L2 | Sandbox | allowed |
| L3 | Limited execution | contract-dependent |
| L4 | Supervised promotion | contract-dependent |
| L5 | Autonomous execution | **blocked by default** |
| L6 | Structural/root change | **blocked by default** |

L5/L6 require a deployment authorization boundary outside the protocol core. A protocol message must not self-authorize root changes.

## Why this matters

The architecture closes an important gap between Kai's existing reasoning/proof machinery and operational evolution:

- before: Kai could reason and verify capabilities, but capability birth was mostly architectural intent;
- after: capability birth has an explicit proposal, contract, sandbox, resource envelope, governance decision, evidence trail, and lifecycle boundary.

This improves auditability and operational containment, but increases implementation complexity. The complexity is intentional and is kept behind the `kai.skill` package.

## MASTER integration

`SkillGovernance` invokes the existing `MasterGovernor` as the governing preflight. MASTER is a control plane; it does not replace domain reasoning or provide an automatic truth oracle.

The promotion invariant remains:

```text
PROMOTE = all required skill gates PASS
          AND MASTER authorization PASS
          AND capability validation PASS
```

## Security boundary

The protocol core never executes arbitrary child source code. `SkillSandbox` executes only explicitly registered handlers. A production deployment that accepts untrusted third-party skills must place the handler behind a real OS/container/VM isolation boundary and resource controller.

## Explicit non-goals

- No uncontrolled self-modifying source code.
- No autonomous root mutation from a protocol message.
- No majority voting as proof.
- No claim that a successful test establishes universal truth.
