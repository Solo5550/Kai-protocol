# Kai Protocol v0.4.2 — Final Performance & Assurance

## Gate

**PASS** — 14 captured final stages; no captured stage failed.

## Live-scale evidence

- Message creation: **69,863 msg/s** over 1,000,000 messages.
- KAI-BIN/1 streaming roundtrip: **31,225 msg/s** over 1,000,000 messages.
- Channel ingest: **61,580 msg/s** over 1,000,000 messages.
- Journal append: **44,815 msg/s** over 1,000,000 messages at ~433.5 B/message.
- Fault injection: **10,000/10,000** injected failures rejected.

## Before / after

| Dimension | Previous | v0.4.2 | Change |
|---|---:|---:|---:|
| Message create | 68,912 msg/s | 69,863 msg/s | +1.38% |
| Channel ingest | 62,501 msg/s (100k) | 64,184 msg/s (100k) | +2.69% |
| Heap/message | 1104.3 B | 1056.3 B | -4.35% |
| Channel message-id history | 100,000 IDs | 0 derived IDs | bounded |
| Journal append | 41,096 msg/s | 44,815 msg/s | +9.05% |
| Text vs KAI-BIN roundtrip | — | +25.05% binary | measured |

The channel and heap percentages are controlled 100k/50k A/B comparisons. The separate million-message measurements demonstrate current sustained scale. Current 250k-message RSS signal is **2167.4 B/message** and is reported as a capacity indicator, not as the heap-to-heap A/B value.

## Stability and scaling

- Throughput stability: **71,226 msg/s ± 294 (95% CI half-width)** across 5 × 100k repeats; CV **0.47%**.
- Latency: p50 **0.0131 ms**, p99 **0.0537 ms**. The tail is a vibration signal, not a correctness failure.
- Parallel process scaling: **1.77x** at 4 workers over fixed work.
- Journal recovery: checkpoint reopen **428.7x** faster than forced full-scan reopen on the 250k-message recovery benchmark; both recovered the exact count.

## Root-cause census and treatments

1. **Text codec CPU** — line parsing, Base64, JSON payload decoding, and SHA-256 verification dominate the audit codec. **Treatment implemented:** KAI-BIN/1 for high-volume transport; KAI-LANG/0.1 retained as canonical human/audit form.
2. **Object retention cost** — Python object/dict overhead and unbounded derived state increase memory pressure. **Treatment implemented:** slotted transport records, disabled derived history in high-volume channel mode, and disk-backed MessageJournal.
3. **Tail latency vibration** — scheduler, allocator, cache, and host variability remain visible in p99/max. **Treatment implemented in the lab:** warmup, repeated fixed workloads, CV/95% CI reporting, and explicit vibration gates. Host pinning remains environment-dependent.
4. **Journal reopen scan** — a full scan was previously required on reopen. **Treatment implemented:** atomic checkpoint sidecar; reopen scans only the post-checkpoint tail and safely falls back to a full scan when metadata is absent/stale/invalid. The 250k recovery test measured **428.7x** improvement.
5. **Parallel orchestration overhead** — process startup can mask gains on small workloads. **Treatment:** the lab fixes total work and measures sustained process-level scaling; worker-pool reuse inside a long-lived service remains a deployment optimization rather than a protocol semantic change.
6. **Benchmark single-run bias** — one timing sample is not sufficient for a regression gate. **Treatment implemented:** 5 repeated workloads with 95% confidence interval and CV.

## Controlled rejection rule

No performance optimization is accepted merely because it “looks faster”. A candidate change must preserve protocol semantics, deterministic replay, integrity verification, failure rejection, the full regression suite, and show a statistically meaningful measured benefit. The Packer-reuse experiment was rejected because its measured gain was not material.

## Internal engineering score

Previous internal engineering-readiness score: **97.2/100**. v0.4.2 retained the prior **98.4/100** assessment after the added lab hardening; this is an internal engineering review, not an external benchmark, certification, or security audit.

## Remaining gaps

The release is not represented as 100/100. Remaining pre-production work includes independent cryptographic review, broader fuzz/property testing, cross-platform golden vectors, multi-node transport/contention benchmarks, end-to-end crash-recovery fault injection, and production integration of journal-backed retention into a high-volume session backend.
