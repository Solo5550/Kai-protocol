#!/usr/bin/env python3
"""Python peer oracle for kai/semantic/0.8 — same contract as Go and Rust."""
from __future__ import annotations

import json
import sys
from pathlib import Path

# Prefer installed / PYTHONPATH kai package
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from kai.protocol.conformance import check_vector, load_vectors
from kai.protocol.interop import SCHEMA_ID, SemanticMessage


def main() -> int:
    root = Path(__file__).resolve().parents[1] / "contract" / "vectors"
    if len(sys.argv) > 1 and sys.argv[1] == "--vectors":
        root = Path(sys.argv[2])
    results = []
    all_pass = True
    for vector in load_vectors(root):
        r = check_vector(vector)
        mid = ""
        dig = ""
        try:
            msg = SemanticMessage.from_dict(vector["message"])
            mid = msg.message_id
            dig = msg.integrity["digest"]
        except Exception:
            pass
        results.append({
            "name": r.name,
            "passed": r.passed,
            "message_id": mid,
            "integrity_digest": dig,
            "checks": list(r.checks),
            "failures": list(r.failures),
        })
        if not r.passed:
            all_pass = False
    payload = {
        "implementation": "python",
        "schema_id": SCHEMA_ID,
        "passed": all_pass,
        "results": results,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if all_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
