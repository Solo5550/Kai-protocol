package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"kai.protocol/sdk/kai"
)

func main() {
	dir := flag.String("vectors", "", "directory of golden vectors (*.json)")
	flag.Parse()
	if *dir == "" {
		fmt.Fprintln(os.Stderr, "--vectors is required")
		os.Exit(2)
	}
	entries, err := os.ReadDir(*dir)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	var names []string
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".json") {
			names = append(names, e.Name())
		}
	}
	sort.Strings(names)
	allPass := true
	results := make([]kai.CheckResult, 0, len(names))
	for _, name := range names {
		path := filepath.Join(*dir, name)
		data, err := os.ReadFile(path)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		dec := json.NewDecoder(strings.NewReader(string(data)))
		dec.UseNumber()
		var v kai.Vector
		if err := dec.Decode(&v); err != nil {
			fmt.Fprintf(os.Stderr, "%s: %v\n", name, err)
			os.Exit(1)
		}
		if v.Name == "" {
			v.Name = strings.TrimSuffix(name, ".json")
		}
		r := kai.CheckVector(v)
		results = append(results, r)
		if !r.Passed {
			allPass = false
		}
	}
	out, _ := json.MarshalIndent(map[string]interface{}{
		"implementation": "go",
		"schema_id":      kai.SchemaID,
		"passed":         allPass,
		"results":        results,
	}, "", "  ")
	fmt.Println(string(out))
	if !allPass {
		os.Exit(1)
	}
}
