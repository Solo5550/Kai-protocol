// Package kai implements the Kai semantic contract (kai/semantic/0.8)
// as a peer SDK implementation of the multi-language oracle.
package kai

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
)

const (
	SchemaID         = "kai/semantic/0.8"
	SemanticVersion  = "0.8"
	MaxStringLength  = 4096
	MaxParentIDs     = 128
	MaxEffects       = 1024
	MaxExtensions    = 64
)

// CORE_FIELDS matches the Python reference closed schema.
var CoreFields = map[string]struct{}{
	"protocol": {}, "semantic_version": {}, "schema_id": {}, "message_id": {},
	"conversation_id": {}, "sender": {}, "recipient": {}, "act": {}, "intent": {},
	"causality": {}, "authority": {}, "capability": {}, "contract": {}, "input": {},
	"expected": {}, "execution": {}, "outcome": {}, "effects": {}, "proof": {},
	"provenance": {}, "extensions": {}, "integrity": {},
}

// CanonicalJSON produces the normative compact sorted JSON used for identity.
func CanonicalJSON(v interface{}) ([]byte, error) {
	switch x := v.(type) {
	case nil:
		return []byte("null"), nil
	case bool:
		if x {
			return []byte("true"), nil
		}
		return []byte("false"), nil
	case string:
		return json.Marshal(x) // produces quoted UTF-8
	case json.Number:
		return []byte(string(x)), nil
	case float64:
		return nil, fmt.Errorf("float64 encountered; decoder must use UseNumber")
	case []interface{}:
		parts := make([]string, 0, len(x))
		for _, item := range x {
			b, err := CanonicalJSON(item)
			if err != nil {
				return nil, err
			}
			parts = append(parts, string(b))
		}
		return []byte("[" + strings.Join(parts, ",") + "]"), nil
	case map[string]interface{}:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		var b strings.Builder
		b.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				b.WriteByte(',')
			}
			kb, err := json.Marshal(k)
			if err != nil {
				return nil, err
			}
			vb, err := CanonicalJSON(x[k])
			if err != nil {
				return nil, err
			}
			b.Write(kb)
			b.WriteByte(':')
			b.Write(vb)
		}
		b.WriteByte('}')
		return []byte(b.String()), nil
	default:
		// integers from json may appear as float64 if not UseNumber;
		// also support int/int64 for constructed values
		switch n := v.(type) {
		case int:
			return []byte(fmt.Sprintf("%d", n)), nil
		case int64:
			return []byte(fmt.Sprintf("%d", n)), nil
		case uint64:
			return []byte(fmt.Sprintf("%d", n)), nil
		}
		return nil, fmt.Errorf("unsupported JSON type %T", v)
	}
}

func cloneMap(m map[string]interface{}) map[string]interface{} {
	out := make(map[string]interface{}, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}

func identityBody(m map[string]interface{}) map[string]interface{} {
	body := cloneMap(m)
	delete(body, "integrity")
	if auth, ok := body["authority"].(map[string]interface{}); ok {
		a := cloneMap(auth)
		delete(a, "signature")
		body["authority"] = a
	}
	return body
}

// MessageID computes the normative message_id (empty-id identity digest).
func MessageID(m map[string]interface{}) (string, error) {
	body := identityBody(m)
	body["message_id"] = ""
	b, err := CanonicalJSON(body)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// IntegrityDigest computes the normative integrity.digest.
func IntegrityDigest(m map[string]interface{}) (string, error) {
	body := identityBody(m)
	b, err := CanonicalJSON(body)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// ValidateClosedSchema rejects unknown top-level fields.
func ValidateClosedSchema(m map[string]interface{}) []string {
	var errs []string
	for k := range m {
		if _, ok := CoreFields[k]; !ok {
			errs = append(errs, fmt.Sprintf("unknown top-level field: %s", k))
		}
	}
	if schema, _ := m["schema_id"].(string); schema != "" && schema != SchemaID {
		errs = append(errs, fmt.Sprintf("schema_id mismatch: %s", schema))
	}
	return errs
}

// VerifyIntegrity checks message_id and integrity.digest against recomputed values.
func VerifyIntegrity(m map[string]interface{}) (bool, string, string, error) {
	expectedID, err := MessageID(m)
	if err != nil {
		return false, "", "", err
	}
	expectedDig, err := IntegrityDigest(m)
	if err != nil {
		return false, "", "", err
	}
	gotID, _ := m["message_id"].(string)
	integ, _ := m["integrity"].(map[string]interface{})
	gotDig, _ := integ["digest"].(string)
	ok := gotID == expectedID && gotDig == expectedDig
	return ok, expectedID, expectedDig, nil
}

// Vector is a golden conformance vector.
type Vector struct {
	Name    string                 `json:"name"`
	Message map[string]interface{} `json:"message"`
}

// CheckResult is the oracle result for one vector.
type CheckResult struct {
	Name           string   `json:"name"`
	Passed         bool     `json:"passed"`
	MessageID      string   `json:"message_id"`
	IntegrityDigest string  `json:"integrity_digest"`
	Checks         []string `json:"checks"`
	Failures       []string `json:"failures"`
}

// CheckVector runs the full semantic oracle checks (peer to Python).
func CheckVector(v Vector) CheckResult {
	r := CheckResult{Name: v.Name, Checks: []string{}, Failures: []string{}}
	if v.Message == nil {
		r.Failures = append(r.Failures, "message must be object")
		return r
	}
	if errs := ValidateClosedSchema(v.Message); len(errs) > 0 {
		r.Failures = append(r.Failures, errs...)
	} else {
		r.Checks = append(r.Checks, "closed-schema")
	}
	ok, expID, expDig, err := VerifyIntegrity(v.Message)
	if err != nil {
		r.Failures = append(r.Failures, "identity: "+err.Error())
		return r
	}
	r.MessageID = expID
	r.IntegrityDigest = expDig
	if ok {
		r.Checks = append(r.Checks, "integrity", "message_id")
	} else {
		gotID, _ := v.Message["message_id"].(string)
		integ, _ := v.Message["integrity"].(map[string]interface{})
		gotDig, _ := integ["digest"].(string)
		if gotID != expID {
			r.Failures = append(r.Failures, fmt.Sprintf("message_id mismatch: got %s want %s", gotID, expID))
		}
		if gotDig != expDig {
			r.Failures = append(r.Failures, fmt.Sprintf("integrity.digest mismatch: got %s want %s", gotDig, expDig))
		}
	}
	// Round-trip structural check: re-encode keys via canonical and re-parse
	canon, err := CanonicalJSON(v.Message)
	if err != nil {
		r.Failures = append(r.Failures, "canonical: "+err.Error())
	} else {
		var rt map[string]interface{}
		dec := json.NewDecoder(strings.NewReader(string(canon)))
		dec.UseNumber()
		if err := dec.Decode(&rt); err != nil {
			r.Failures = append(r.Failures, "round-trip decode: "+err.Error())
		} else {
			r.Checks = append(r.Checks, "object-round-trip")
		}
	}
	r.Passed = len(r.Failures) == 0
	return r
}
