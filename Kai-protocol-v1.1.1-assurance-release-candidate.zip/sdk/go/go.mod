module kai.protocol/sdk

go 1.21
