# Kai Semantic Contract — Multi-Language Oracle (Normative)

Schema ID: `kai/semantic/0.8`  
Contract status: **SDK multi-language** (Python, Go, Rust are peer implementations)

## Purpose

All language implementations MUST produce identical results for:

1. Canonical JSON serialization
2. `message_id` (identity digest with empty message_id)
3. `integrity.digest` (body without integrity field; authority.signature excluded)
4. Closed-schema validation (unknown top-level fields rejected)
5. Round-trip projection (from_dict → to_dict preserves semantic fields)
6. Integrity verification

The oracle is language-neutral. A vector passes the multi-language gate only when **every** implementation reports the same digests and the same pass/fail outcome.

## Canonical JSON profile (normative)

- UTF-8
- Object keys sorted lexicographically
- Separators: `","` and `":"` (no spaces)
- `ensure_ascii=false` (Unicode preserved)
- Numbers: JSON number values only; non-finite rejected
- Duplicate object keys: forbidden
- `null`, `true`, `false` as literals

## Identity rules

```
identity_body = message without "integrity"
if authority present and contains "signature": remove signature from authority copy
message_id = sha256_hex( canonical_json( identity_body with message_id = "" ) )
integrity.digest = sha256_hex( canonical_json( identity_body ) )
```

## Closed schema

Top-level keys outside the CORE_FIELDS set are rejected. Implementation-specific data belongs only under `extensions`.

## Oracle verdict

For each golden vector:

| Check | Required |
|-------|----------|
| semantic-validation | pass |
| object-round-trip | pass (or language-equivalent structural equality) |
| integrity | pass |
| message_id match | identical across languages |
| integrity.digest match | identical across languages |

Any divergence → **FAIL** the multi-language conformance gate.

## Evolution

`schema_id` is immutable for 0.8. Incompatible changes require a new schema id.
