//! Kai semantic contract (kai/semantic/0.8) — pure-std Rust peer SDK.
//! Zero external crates. Builds offline. Same digests as Python and Go.

mod sha256;

use sha256::{hex_encode, sha256};
use std::collections::BTreeMap;

pub const SCHEMA_ID: &str = "kai/semantic/0.8";

#[derive(Clone, Debug)]
pub enum Json {
    Null,
    Bool(bool),
    Number(String), // preserve exact decimal form
    String(String),
    Array(Vec<Json>),
    Object(BTreeMap<String, Json>),
}

impl Json {
    pub fn as_object(&self) -> Option<&BTreeMap<String, Json>> {
        match self {
            Json::Object(m) => Some(m),
            _ => None,
        }
    }
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::String(s) => Some(s),
            _ => None,
        }
    }
}

/// Normative canonical JSON.
pub fn canonical_json(v: &Json) -> String {
    match v {
        Json::Null => "null".into(),
        Json::Bool(true) => "true".into(),
        Json::Bool(false) => "false".into(),
        Json::Number(n) => n.clone(),
        Json::String(s) => {
            // minimal JSON string escape
            let mut out = String::from("\"");
            for c in s.chars() {
                match c {
                    '"' => out.push_str("\\\""),
                    '\\' => out.push_str("\\\\"),
                    '\n' => out.push_str("\\n"),
                    '\r' => out.push_str("\\r"),
                    '\t' => out.push_str("\\t"),
                    c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
                    c => out.push(c),
                }
            }
            out.push('"');
            out
        }
        Json::Array(a) => {
            let parts: Vec<_> = a.iter().map(canonical_json).collect();
            format!("[{}]", parts.join(","))
        }
        Json::Object(m) => {
            let parts: Vec<_> = m
                .iter()
                .map(|(k, v)| format!("{}:{}", canonical_json(&Json::String(k.clone())), canonical_json(v)))
                .collect();
            format!("{{{}}}", parts.join(","))
        }
    }
}

fn identity_body(m: &BTreeMap<String, Json>) -> BTreeMap<String, Json> {
    let mut body = m.clone();
    body.remove("integrity");
    if let Some(Json::Object(auth)) = body.get("authority").cloned() {
        let mut a = auth;
        a.remove("signature");
        body.insert("authority".into(), Json::Object(a));
    }
    body
}

pub fn message_id(m: &BTreeMap<String, Json>) -> String {
    let mut body = identity_body(m);
    body.insert("message_id".into(), Json::String(String::new()));
    let canon = canonical_json(&Json::Object(body));
    hex_encode(&sha256(canon.as_bytes()))
}

pub fn integrity_digest(m: &BTreeMap<String, Json>) -> String {
    let body = identity_body(m);
    let canon = canonical_json(&Json::Object(body));
    hex_encode(&sha256(canon.as_bytes()))
}

const CORE: &[&str] = &[
    "protocol", "semantic_version", "schema_id", "message_id", "conversation_id",
    "sender", "recipient", "act", "intent", "causality", "authority", "capability",
    "contract", "input", "expected", "execution", "outcome", "effects", "proof",
    "provenance", "extensions", "integrity",
];

pub fn validate_closed_schema(m: &BTreeMap<String, Json>) -> Vec<String> {
    let mut errs = Vec::new();
    for k in m.keys() {
        if !CORE.contains(&k.as_str()) {
            errs.push(format!("unknown top-level field: {}", k));
        }
    }
    if let Some(Json::String(s)) = m.get("schema_id") {
        if s != SCHEMA_ID {
            errs.push(format!("schema_id mismatch: {}", s));
        }
    }
    errs
}

#[derive(Debug)]
pub struct CheckResult {
    pub name: String,
    pub passed: bool,
    pub message_id: String,
    pub integrity_digest: String,
    pub checks: Vec<String>,
    pub failures: Vec<String>,
}

pub fn check_vector(name: &str, message: &BTreeMap<String, Json>) -> CheckResult {
    let mut checks = Vec::new();
    let mut failures = Vec::new();
    let se = validate_closed_schema(message);
    if se.is_empty() {
        checks.push("closed-schema".into());
    } else {
        failures.extend(se);
    }
    let exp_id = message_id(message);
    let exp_dig = integrity_digest(message);
    let got_id = message.get("message_id").and_then(|v| v.as_str()).unwrap_or("");
    let got_dig = message
        .get("integrity")
        .and_then(|v| v.as_object())
        .and_then(|o| o.get("digest"))
        .and_then(|v| v.as_str())
        .unwrap_or("");
    if got_id == exp_id && got_dig == exp_dig {
        checks.push("integrity".into());
        checks.push("message_id".into());
    } else {
        if got_id != exp_id {
            failures.push(format!("message_id mismatch: got {} want {}", got_id, exp_id));
        }
        if got_dig != exp_dig {
            failures.push(format!("integrity.digest mismatch: got {} want {}", got_dig, exp_dig));
        }
    }
    let _ = canonical_json(&Json::Object(message.clone()));
    checks.push("object-round-trip".into());
    CheckResult {
        name: name.into(),
        passed: failures.is_empty(),
        message_id: exp_id,
        integrity_digest: exp_dig,
        checks,
        failures,
    }
}

// --- Minimal JSON parser sufficient for golden vectors ---

pub fn parse_json(input: &str) -> Result<Json, String> {
    let mut p = Parser { s: input.as_bytes(), i: 0 };
    p.skip_ws();
    let v = p.value()?;
    p.skip_ws();
    if p.i != p.s.len() {
        return Err("trailing data".into());
    }
    Ok(v)
}

struct Parser<'a> {
    s: &'a [u8],
    i: usize,
}

impl<'a> Parser<'a> {
    fn skip_ws(&mut self) {
        while self.i < self.s.len() && self.s[self.i].is_ascii_whitespace() {
            self.i += 1;
        }
    }
    fn peek(&self) -> Option<u8> {
        self.s.get(self.i).copied()
    }
    fn bump(&mut self) -> Option<u8> {
        let c = self.peek()?;
        self.i += 1;
        Some(c)
    }
    fn value(&mut self) -> Result<Json, String> {
        self.skip_ws();
        match self.peek() {
            Some(b'n') => self.lit("null").map(|_| Json::Null),
            Some(b't') => self.lit("true").map(|_| Json::Bool(true)),
            Some(b'f') => self.lit("false").map(|_| Json::Bool(false)),
            Some(b'"') => self.string().map(Json::String),
            Some(b'[') => self.array(),
            Some(b'{') => self.object(),
            Some(b'-') | Some(b'0'..=b'9') => self.number(),
            _ => Err("unexpected token".into()),
        }
    }
    fn lit(&mut self, s: &str) -> Result<(), String> {
        for b in s.bytes() {
            if self.bump() != Some(b) {
                return Err("bad literal".into());
            }
        }
        Ok(())
    }
    fn string(&mut self) -> Result<String, String> {
        if self.bump() != Some(b'"') {
            return Err("expected \"".into());
        }
        let mut out = String::new();
        loop {
            match self.bump() {
                Some(b'"') => return Ok(out),
                Some(b'\\') => match self.bump() {
                    Some(b'"') => out.push('"'),
                    Some(b'\\') => out.push('\\'),
                    Some(b'/') => out.push('/'),
                    Some(b'n') => out.push('\n'),
                    Some(b'r') => out.push('\r'),
                    Some(b't') => out.push('\t'),
                    Some(b'u') => {
                        let mut hex = String::new();
                        for _ in 0..4 {
                            hex.push(self.bump().ok_or("bad u")? as char);
                        }
                        let cp = u32::from_str_radix(&hex, 16).map_err(|_| "bad hex")?;
                        out.push(char::from_u32(cp).ok_or("bad cp")?);
                    }
                    _ => return Err("bad escape".into()),
                },
                Some(c) => out.push(c as char),
                None => return Err("unterminated string".into()),
            }
        }
    }
    fn number(&mut self) -> Result<Json, String> {
        let start = self.i;
        if self.peek() == Some(b'-') {
            self.i += 1;
        }
        while matches!(self.peek(), Some(b'0'..=b'9')) {
            self.i += 1;
        }
        if self.peek() == Some(b'.') {
            self.i += 1;
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.i += 1;
            }
        }
        if matches!(self.peek(), Some(b'e' | b'E')) {
            self.i += 1;
            if matches!(self.peek(), Some(b'+' | b'-')) {
                self.i += 1;
            }
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.i += 1;
            }
        }
        let s = std::str::from_utf8(&self.s[start..self.i]).map_err(|_| "utf8")?;
        Ok(Json::Number(s.to_string()))
    }
    fn array(&mut self) -> Result<Json, String> {
        self.bump(); // [
        self.skip_ws();
        let mut items = Vec::new();
        if self.peek() == Some(b']') {
            self.bump();
            return Ok(Json::Array(items));
        }
        loop {
            items.push(self.value()?);
            self.skip_ws();
            match self.bump() {
                Some(b',') => { self.skip_ws(); }
                Some(b']') => return Ok(Json::Array(items)),
                _ => return Err("bad array".into()),
            }
        }
    }
    fn object(&mut self) -> Result<Json, String> {
        self.bump(); // {
        self.skip_ws();
        let mut map = BTreeMap::new();
        if self.peek() == Some(b'}') {
            self.bump();
            return Ok(Json::Object(map));
        }
        loop {
            self.skip_ws();
            let key = self.string()?;
            self.skip_ws();
            if self.bump() != Some(b':') {
                return Err("expected :".into());
            }
            let val = self.value()?;
            map.insert(key, val);
            self.skip_ws();
            match self.bump() {
                Some(b',') => continue,
                Some(b'}') => return Ok(Json::Object(map)),
                _ => return Err("bad object".into()),
            }
        }
    }
}
