use kai_semantic::{check_vector, parse_json, Json, SCHEMA_ID};
use std::env;
use std::fs;
use std::path::PathBuf;

fn main() {
    let args: Vec<String> = env::args().collect();
    let mut vectors_dir = None;
    let mut i = 1;
    while i < args.len() {
        if args[i] == "--vectors" && i + 1 < args.len() {
            vectors_dir = Some(args[i + 1].clone());
            i += 2;
        } else {
            i += 1;
        }
    }
    let dir = vectors_dir.expect("--vectors <dir> is required");
    let mut paths: Vec<PathBuf> = fs::read_dir(&dir)
        .expect("read dir")
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|x| x == "json").unwrap_or(false))
        .collect();
    paths.sort();

    let mut results_json = Vec::new();
    let mut all_pass = true;
    for path in paths {
        let data = fs::read_to_string(&path).expect("read");
        let v = parse_json(&data).expect("parse");
        let obj = v.as_object().expect("root object");
        let name = obj
            .get("name")
            .and_then(|x| x.as_str())
            .map(|s| s.to_string())
            .unwrap_or_else(|| {
                path.file_stem()
                    .unwrap()
                    .to_string_lossy()
                    .to_string()
            });
        let message = obj
            .get("message")
            .and_then(|x| x.as_object())
            .expect("message");
        let r = check_vector(&name, message);
        if !r.passed {
            all_pass = false;
        }
        let checks = r.checks.iter().map(|s| format!("\"{}\"", s)).collect::<Vec<_>>().join(",");
        let failures = r.failures.iter().map(|s| format!("\"{}\"", s.replace('"', "\\\""))).collect::<Vec<_>>().join(",");
        results_json.push(format!(
            "{{\"name\":\"{}\",\"passed\":{},\"message_id\":\"{}\",\"integrity_digest\":\"{}\",\"checks\":[{}],\"failures\":[{}]}}",
            r.name, r.passed, r.message_id, r.integrity_digest, checks, failures
        ));
    }
    let impls = results_json.join(",");
    println!(
        "{{\"implementation\":\"rust\",\"schema_id\":\"{}\",\"passed\":{},\"results\":[{}]}}",
        SCHEMA_ID, all_pass, impls
    );
    if !all_pass {
        std::process::exit(1);
    }
}
