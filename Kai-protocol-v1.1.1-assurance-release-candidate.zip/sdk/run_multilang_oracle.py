#!/usr/bin/env python3
"""
Blind multi-language oracle gate for kai/semantic/0.8.

Runs Python, Go, and Rust peer implementations against the same golden vectors.
Passes only when every implementation reports identical message_id and integrity.digest
and all individual checks pass. Digests are cross-checked (no expected-answer cheating).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VECTORS = ROOT / "contract" / "vectors"
REPO = ROOT.parent


def run_python() -> dict:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(REPO / "src")
    p = subprocess.run(
        [sys.executable, str(ROOT / "python" / "oracle.py"), "--vectors", str(VECTORS)],
        capture_output=True, text=True, env=env, cwd=str(ROOT),
    )
    if p.returncode not in (0, 1):
        raise RuntimeError(f"python oracle failed: {p.stderr}")
    return json.loads(p.stdout)


def run_go() -> dict:
    go_dir = ROOT / "go"
    bin_path = Path("/tmp/kai-go-oracle")
    subprocess.run(
        ["go", "build", "-o", str(bin_path), "./cmd/oracle"],
        cwd=str(go_dir), check=True,
    )
    p = subprocess.run(
        [str(bin_path), "--vectors", str(VECTORS)],
        capture_output=True, text=True, cwd=str(go_dir),
    )
    if p.returncode not in (0, 1):
        raise RuntimeError(f"go oracle failed: {p.stderr}\n{p.stdout}")
    return json.loads(p.stdout)


def run_rust() -> dict | None:
    if not shutil.which("cargo"):
        return None
    rust_dir = ROOT / "rust"
    subprocess.run(
        ["cargo", "build", "--release"],
        cwd=str(rust_dir), check=True, capture_output=True,
    )
    src = rust_dir / "target" / "release" / "kai-semantic"
    if not src.exists():
        raise RuntimeError("rust binary not found after build")
    bin_path = Path("/tmp/kai-rust-oracle")
    shutil.copy2(src, bin_path)
    bin_path.chmod(0o755)
    p = subprocess.run(
        [str(bin_path), "--vectors", str(VECTORS)],
        capture_output=True, text=True, cwd=str(rust_dir),
    )
    if p.returncode not in (0, 1):
        raise RuntimeError(f"rust oracle failed: {p.stderr}\n{p.stdout}")
    return json.loads(p.stdout)


def cross_check(reports: list[dict]) -> tuple[bool, list[str]]:
    failures: list[str] = []
    by_name: dict[str, list[dict]] = {}
    for rep in reports:
        for r in rep["results"]:
            by_name.setdefault(r["name"], []).append({
                "impl": rep["implementation"],
                "message_id": r.get("message_id", ""),
                "integrity_digest": r.get("integrity_digest", ""),
                "passed": r.get("passed", False),
                "failures": r.get("failures", []),
            })
    for name, entries in sorted(by_name.items()):
        ids = {e["message_id"] for e in entries}
        digs = {e["integrity_digest"] for e in entries}
        if len(ids) != 1 or "" in ids:
            failures.append(f"{name}: message_id divergence across languages: {ids}")
        if len(digs) != 1 or "" in digs:
            failures.append(f"{name}: integrity.digest divergence across languages: {digs}")
        for e in entries:
            if not e["passed"]:
                failures.append(f"{name}/{e['impl']}: {e['failures']}")
    return (len(failures) == 0, failures)


def main() -> int:
    reports = []
    print("=== Python oracle ===")
    py = run_python()
    reports.append(py)
    print(f"  passed={py['passed']} results={len(py['results'])}")

    print("=== Go oracle ===")
    go = run_go()
    reports.append(go)
    print(f"  passed={go['passed']} results={len(go['results'])}")

    print("=== Rust oracle ===")
    try:
        rust = run_rust()
    except Exception as exc:
        print(f"  ERROR: {exc}")
        rust = None
    if rust is None:
        print("  SKIP")
    else:
        reports.append(rust)
        print(f"  passed={rust['passed']} results={len(rust['results'])}")

    ok, failures = cross_check(reports)
    payload = {
        "gate": "multi-language-semantic-oracle",
        "schema_id": "kai/semantic/0.8",
        "implementations": [r["implementation"] for r in reports],
        "passed": ok,
        "failures": failures,
        "reports": reports,
    }
    out_path = ROOT / "contract" / "MULTILANG-ORACLE-RESULT.json"
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"passed": ok, "failures": failures}, indent=2))
    print(f"Wrote {out_path}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
