#!/usr/bin/env python3
"""SSDF One v1.1 — evidence-driven software assurance + root-cause healing.

Design goals:
- Evidence over labels: filenames alone never prove an assurance claim.
- Structured artifacts must contain meaningful fields and cross-artifact linkage.
- Findings are separated from systemic root causes.
- Remediation is transactional: snapshot -> mutate -> test -> reassess -> commit/rollback.
- A post-fix recurrence probe can reintroduce the defect in an isolated copy to test the guardrail.
- The engine is a verification aid, not a certification authority.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from dataclasses import dataclass, asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CATALOG = ROOT / "catalog" / "controls.json"
PROFILES = ROOT / "profiles"
VERSION = "1.2.0"
IGNORE_DIRS = {".git", ".ssdfx", "node_modules", "vendor", "dist", "build", "target", ".venv", "venv", "__pycache__", ".pytest_cache"}
TEXT_EXT = {".md", ".txt", ".yml", ".yaml", ".json", ".toml", ".ini", ".cfg", ".conf", ".py", ".js", ".ts", ".tsx", ".go", ".java", ".rb", ".php", ".cs", ".rs", ".sh", ".xml", ".properties", ".lock"}
CODE_EXT = {".py", ".js", ".ts", ".tsx", ".go", ".java", ".rb", ".php", ".cs", ".rs", ".sh", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".conf", ".json"}
STATUS_VALUE = {"pass": 1.0, "partial": 0.5, "not_proven": 0.25, "fail": 0.0, "not_applicable": 1.0}
SEV_WEIGHT = {"critical": 5, "high": 4, "medium": 2, "low": 1}
FAIL_THRESHOLD = {"critical": 5, "high": 4, "medium": 2, "low": 1, "never": 0}

@dataclass
class Result:
    control_id: str
    title: str
    status: str
    severity: str
    evidence: list[str]
    rationale: str
    next_step: str
    ssdf: list[str]
    source_refs: list[str]
    evidence_strength: float = 0.0
    evidence_basis: list[str] | None = None
    confidence: str = "low"


def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def repo_files(repo: Path) -> list[Path]:
    out=[]
    for p in repo.rglob("*"):
        if p.is_file() and not any(part in IGNORE_DIRS for part in p.parts):
            out.append(p)
    return sorted(out, key=lambda p: p.as_posix().lower())


def rel(p: Path, repo: Path) -> str:
    return p.relative_to(repo).as_posix()


def read_text(p: Path, limit=1_000_000):
    if p.suffix.lower() not in TEXT_EXT and p.name.lower() not in {"codeowners", "security.txt"}:
        return ""
    try:
        return p.read_text(encoding="utf-8", errors="ignore")[:limit]
    except Exception:
        return ""


def _rx(patterns):
    return re.compile("|".join(patterns), re.I)


def semantic_files(files, patterns, repo, content_patterns=None, name_required=False, max_files=12):
    """Return files with substantive content evidence; a filename hit alone is not enough."""
    name_rx = _rx(patterns)
    content_rx = _rx(content_patterns or patterns)
    hits=[]
    for p in files:
        s=read_text(p)
        if not s:
            continue
        name_hit=bool(name_rx.search(p.name) or name_rx.search(rel(p,repo)))
        content_hit=bool(content_rx.search(s))
        if content_hit and (not name_required or name_hit):
            hits.append(rel(p,repo))
            if len(hits)>=max_files:
                break
    return hits


def path_files(files, patterns, repo, max_files=12):
    rx=_rx(patterns)
    out=[]
    for p in files:
        if rx.search(p.name) or rx.search(rel(p,repo)):
            out.append(rel(p,repo))
            if len(out)>=max_files:
                break
    return out


def json_documents(files, repo):
    for p in files:
        if p.suffix.lower() != ".json":
            continue
        s=read_text(p)
        if not s:
            continue
        try:
            yield p, json.loads(s)
        except Exception:
            continue


def _is_hex64(x):
    return isinstance(x, str) and bool(re.fullmatch(r"[0-9a-fA-F]{64}", x))


def file_sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _yamlish_files(files, repo):
    return [(p, read_text(p)) for p in files if p.suffix.lower() in {".yml",".yaml"} and read_text(p)]


def workflow_hardening(files, repo):
    """Conservative local workflow probe inspired by OpenSSF Scorecard.
    It intentionally does not claim platform-level enforcement without connector evidence.
    """
    workflows=[]
    for p,s in _yamlish_files(files,repo):
        path=rel(p,repo)
        looks_workflow=(".github/workflows/" in path or any(x in p.name.lower() for x in ["gitlab-ci","jenkinsfile","azure-pipelines","buildkite"]))
        if not looks_workflow: continue
        issues=[]
        if re.search(r"(?mi)^\s*permissions\s*:\s*$",s) is None:
            issues.append("missing explicit permissions block")
        else:
            if re.search(r"(?mi)^\s*contents\s*:\s*write\s*$",s): issues.append("excessive contents: write permission")
            if re.search(r"(?mi)^\s*permissions\s*:\s*write-all\s*$",s): issues.append("write-all permissions")
        if re.search(r"(?i)pull_request_target|workflow_run",s) and re.search(r"(?i)actions/checkout@(?:v\d+|main|master|[A-Za-z0-9._/-]+)",s):
            # A privileged trigger + non-immutable checkout is a strong warning; full semantic parser would be connector/tool work.
            issues.append("privileged workflow trigger needs untrusted-code isolation review")
        refs=re.findall(r"uses:\s*([^\s#]+)",s)
        unpinned=[r for r in refs if "@" in r and not re.search(r"@[0-9a-fA-F]{40}$",r)]
        if unpinned: issues.append("third-party workflow references are not full-length commit-pinned")
        workflows.append((path,issues))
    if not workflows: return [],"fail","no workflow file with substantive build/test content was found."
    bad=sum(bool(i) for _,i in workflows)
    evidence=[f"{path}" + (f" ({'; '.join(issues)})" if issues else " (hardened signals present)") for path,issues in workflows]
    if bad==0: return evidence,"pass","workflow hardening signals are present; platform enforcement still requires authoritative connector evidence."
    return evidence,"fail","one or more workflow hardening checks found potentially unsafe permissions, triggers, or mutable references."


def supplier_due_diligence(files, repo):
    # Evaluate dedicated supplier evidence documents; require breadth, not keyword presence alone.
    candidates=[]
    for p in files:
        n=p.name.lower()
        if p.suffix.lower() in {".md",".txt",".yml",".yaml",".json"} and any(k in n for k in ["supplier","vendor","third-party","third_party","due-diligence"]):
            candidates.append((p,read_text(p).lower()))
    required=[("foci",["foci","foreign ownership","foreign control","foreign influence"]),("provenance",["provenance"]),("resilience",["resilience"]),("foundational",["foundational","baseline","cyber practices"]),("tiers",["tier","sub-tier","subtier","fourth-party"]),("evidence",["evidence","assessment","scope"])]
    for p,text in candidates:
        hits=[k for k,toks in required if any(t in text for t in toks)]
        if len(hits)>=4:
            return [rel(p,repo)+f" (dimensions:{','.join(hits)})"],"pass","supplier evidence covers a broad set of NIST SP 1326 due-diligence dimensions."
        if len(hits)>=2:
            return [rel(p,repo)+f" (dimensions:{','.join(hits)})"],"partial","supplier evidence exists but does not cover enough due-diligence dimensions."
    return [],"partial","supplier due-diligence evidence is absent or too shallow."


def evidence_quality(files, repo):
    candidates=[]
    for p in files:
        n=p.name.lower()
        if p.suffix.lower() in {".md",".txt",".yml",".yaml",".json"} and any(k in n for k in ["evidence-quality","evidence","attestation","audit-trail"]):
            candidates.append((p,read_text(p).lower()))
    required=[("producer",["producer","assessor","owner"]),("timestamp",["timestamp","collection","observed"]),("freshness",["freshness","expiry","stale"]),("integrity",["digest","hash","integrity"]),("scope",["scope","boundary"]),("verification",["verify","verification"])]
    for p,text in candidates:
        hits=[k for k,toks in required if any(t in text for t in toks)]
        if len(hits)>=5:
            return [rel(p,repo)+f" (dimensions:{','.join(hits)})"],"pass","evidence quality metadata is substantively described."
        if len(hits)>=2:
            return [rel(p,repo)+f" (dimensions:{','.join(hits)})"],"partial","evidence quality metadata exists but is incomplete."
    return [],"partial","evidence provenance/freshness/integrity semantics are not sufficiently evidenced."


def risk_model_semantics(files, repo):
    candidates=[]
    for p in files:
        n=p.name.lower()
        if p.suffix.lower() in {".md",".txt",".yml",".yaml",".json"} and any(k in n for k in ["risk-model","risk","vulnerability-priorit"]):
            candidates.append((p,read_text(p).lower()))
    required=[("cvss",["cvss"]),("epss",["epss"]),("kev",["kev","known exploited"]),("environment",["environment","exposure"]),("criticality",["criticality"]),("sensitivity",["sensitivity"])]
    for p,text in candidates:
        hits=[k for k,toks in required if any(t in text for t in toks)]
        if len(hits)>=5:
            return [rel(p,repo)+f" (signals:{','.join(hits)})"],"pass","risk signals remain distinguishable rather than being treated as one opaque score."
        if len(hits)>=2:
            return [rel(p,repo)+f" (signals:{','.join(hits)})"],"partial","risk model evidence exists but does not preserve enough source semantics."
    return [],"partial","risk scoring semantics are not sufficiently documented."


def healing_validation(files, repo):
    candidates=[]
    for p in files:
        n=p.name.lower()
        if p.suffix.lower() in {".md",".txt",".yml",".yaml",".json"} and any(k in n for k in ["healing-validation","root-cause-capa","root-cause","capa"]):
            candidates.append((p,read_text(p).lower()))
    required=[("hypothesis",["hypothesis","hypoth"]),("corroboration",["corroborat","independent"]),("counterfactual",["counterfactual","reintrod","recurrence"]),("regression",["regression","guardrail"]),("isolation",["isolated","sandbox","rollback"]),("verification",["verify","reassess","tested"])]
    best=None
    for p,text in candidates:
        hits=[k for k,toks in required if any(t in text for t in toks)]
        if best is None or len(hits)>len(best[1]): best=(p,hits)
    if best:
        p,hits=best
        if len(hits)>=5: return [rel(p,repo)+f" (dimensions:{','.join(hits)})"],"pass","healing evidence describes hypothesis validation and recurrence/regression verification."
        if len(hits)>=2: return [rel(p,repo)+f" (dimensions:{','.join(hits)})"],"partial","healing evidence exists but validation/recurrence semantics are incomplete."
    return [],"not_proven","no explicit evidence of hypothesis corroboration and counterfactual/regression validation."


def sbom_valid(files, repo):
    out=[]
    for p,d in json_documents(files,repo):
        ok=False
        if isinstance(d,dict) and d.get("bomFormat")=="CycloneDX":
            sv=str(d.get("specVersion",""))
            comps=d.get("components")
            ok=sv in {"1.7","1.6"} and isinstance(comps,list) and len(comps)>=1
        elif isinstance(d,dict) and str(d.get("spdxVersion","" )).startswith("SPDX-3"):
            # SPDX 3.0+ minimum semantic shape used by this offline probe.
            ok=bool(d.get("name") or d.get("creationInfo") or d.get("dataLicense") or d.get("elements"))
        if ok:
            out.append(rel(p,repo))
    return out


def provenance_records(files, repo):
    out=[]
    for p,d in json_documents(files,repo):
        if not isinstance(d,dict):
            continue
        subject=d.get("subject")
        predicate=d.get("predicate")
        ptype=str(d.get("predicateType",""))
        valid_statement=(d.get("_type")=="https://in-toto.io/Statement/v1" and isinstance(subject,list) and len(subject)>=1)
        valid_slsa=("slsa.dev" in ptype)
        if valid_statement and valid_slsa and isinstance(predicate,dict):
            bd=predicate.get("buildDefinition")
            rd=predicate.get("runDetails")
            if isinstance(bd,dict) and isinstance(rd,dict) and isinstance(rd.get("builder"),dict) and rd["builder"].get("id"):
                digests=[]
                for item in subject:
                    if isinstance(item,dict):
                        dg=item.get("digest",{}).get("sha256") if isinstance(item.get("digest"),dict) else None
                        if _is_hex64(dg): digests.append(dg.lower())
                if digests:
                    out.append((rel(p,repo),digests))
    return out


def provenance_valid(files,repo):
    return [p for p,_ in provenance_records(files,repo)]


def verified_signature_records(files,repo):
    out=[]
    for p,d in json_documents(files,repo):
        if not isinstance(d,dict):
            continue
        if d.get("verification_status")=="verified" and isinstance(d.get("artifact_digest"),str):
            digest=d.get("artifact_digest","").split(":",1)[-1]
            if _is_hex64(digest) and d.get("identity") and d.get("verifier") and d.get("verified_at"):
                out.append((rel(p,repo),digest.lower()))
    return out


def verified_signature_evidence(files,repo):
    return [p for p,_ in verified_signature_records(files,repo)]


def release_linkage(files,repo):
    prov=provenance_records(files,repo)
    sig=verified_signature_records(files,repo)
    prov_d={d for _,ds in prov for d in ds}
    sig_d={d for _,d in sig}
    return sorted(prov_d & sig_d)


def secret_findings(files, repo):
    patterns=[
        (re.compile(r"-----BEGIN (?:RSA|OPENSSH|EC|DSA|PGP) PRIVATE KEY-----"), "private-key material"),
        (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AWS access-key-shaped token"),
        (re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"), "GitHub token-shaped secret"),
        (re.compile(r"(?i)\b(password|passwd|secret|api[_-]?key|token)\s*=\s*['\"][^'\"]{8,}['\"]"), "hard-coded credential-like assignment"),
    ]
    findings=[]
    for p in files:
        if p.suffix.lower() not in CODE_EXT:
            continue
        s=read_text(p)
        if not s:
            continue
        for rx,label in patterns:
            for m in rx.finditer(s):
                findings.append({"file":rel(p,repo),"label":label,"line":s[:m.start()].count("\n")+1})
    return findings[:50]


def control_probe(c, files, repo):
    kind=c["probe"]
    if kind=="requirements":
        ev=semantic_files(files,[r"security.?requirements",r"risk.?register",r"security.?risk"],repo,[r"security",r"risk",r"acceptance",r"requirement"],name_required=True)
        return ev,"pass" if ev else "partial","content-backed security/risk requirements are present."
    if kind=="security_policy":
        ev=semantic_files(files,[r"^SECURITY\.(md|txt)$",r"security\.txt",r"vulnerability.?disclosure"],repo,[r"report",r"vulnerab",r"disclos",r"triage",r"response"],name_required=True)
        return ev,"pass" if ev else "fail","a substantive disclosure/response policy is required."
    if kind=="training":
        ev=semantic_files(files,[r"training",r"secure.?coding"],repo,[r"role",r"secure.?coding",r"review",r"training",r"refresh"],name_required=False)
        return ev,"pass" if ev else "partial","training evidence must describe role-based secure-development activity."
    if kind=="supplier":
        ev=semantic_files(files,[r"supplier",r"third.?party",r"vendor",r"due.?diligence"],repo,[r"provenance",r"vulnerab",r"security",r"supplier",r"third.?party",r"evidence"],False)
        return ev,"pass" if ev else "partial","supplier controls need substantive provenance/security requirements."
    if kind=="ci":
        ev=semantic_files(files,[r"\.github/workflows/",r"gitlab-ci",r"azure-pipelines",r"jenkinsfile",r"buildkite",r"\.circleci/"],repo,[r"jobs?:",r"steps?:",r"uses:",r"run:",r"permissions:",r"on:"],False)
        return ev,"pass" if ev else "fail","a real CI/build definition must be present; labels alone do not prove automation."
    if kind=="ownership":
        ev=path_files(files,[r"CODEOWNERS$"],repo)
        substantive=[]
        for r in ev:
            s=(repo/r).read_text(encoding="utf-8",errors="ignore") if (repo/r).exists() else ""
            if any(line.strip() and not line.lstrip().startswith("#") for line in s.splitlines()): substantive.append(r)
        return substantive,"pass" if substantive else "partial","ownership file must contain at least one active rule."
    if kind=="branch_protection":
        ev=semantic_files(files,[r"branch.?protection",r"ruleset",r"protected.?branch"],repo,[r"protected",r"required",r"review",r"status checks",r"direct pushes"],True)
        return ev,"pass" if ev else "not_proven","repository text documents protection, but authoritative platform enforcement still requires connector evidence."
    if kind=="sast":
        ev=semantic_files(files,[r"codeql",r"semgrep",r"bandit",r"gosec",r"sonar",r"sast"],repo,[r"codeql",r"semgrep",r"bandit",r"gosec",r"sonar",r"sast",r"scan",r"analy"],False)
        return ev,"pass" if ev else "fail","SAST evidence must show an actual scanner/configuration and not only a filename."
    if kind=="sca":
        ev=semantic_files(files,[r"trivy",r"osv.?scanner",r"dependabot",r"renovate",r"snyk",r"dependency",r"software.?composition"],repo,[r"depend",r"component",r"transitive",r"trivy",r"osv",r"renovate",r"dependabot",r"snyk"],False)
        return ev,"pass" if ev else "partial","dependency analysis evidence must address dependencies/components, preferably including transitive coverage."
    if kind=="secrets":
        f=secret_findings(files,repo); ev=[f"{x['file']}:{x['line']} ({x['label']})" for x in f]
        return ev,"fail" if f else "pass","no known credential pattern was detected in code/configuration."
    if kind=="threat_model":
        ev=semantic_files(files,[r"threat.?model",r"stride",r"security.?architecture"],repo,[r"asset",r"trust boundary",r"attacker",r"mitigation",r"residual risk",r"stride"],False)
        return ev,"pass" if ev else "partial","threat-model evidence must connect threats to mitigations and residual risk."
    if kind=="security_testing":
        ev=semantic_files(files,[r"security.?test",r"regression",r"negative.?test",r"test.?security"],repo,[r"authz",r"authorization",r"injection",r"validation",r"security",r"regression"],False)
        return ev,"pass" if ev else "partial","security testing should name security properties or regression cases."
    if kind=="fuzzing":
        ev=semantic_files(files,[r"oss.?fuzz",r"libfuzzer",r"afl",r"jazzer",r"fuzz"],repo,[r"fuzz",r"libfuzzer",r"oss.?fuzz",r"afl",r"jazzer"],False)
        return ev,"pass" if ev else "not_proven","fuzzing must be risk-appropriate; absence is not itself proof of failure."
    if kind=="memory_safety":
        ev=semantic_files(files,[r"memory.?safe",r"memory.?safety",r"rust",r"go",r"sanitizer",r"unsafe.?code"],repo,[r"memory",r"safe",r"rust",r"go",r"sanit",r"unsafe"],False)
        return ev,"pass" if ev else "partial","memory-safety strategy must be explicit for relevant components."
    if kind=="secure_defaults":
        ev=semantic_files(files,[r"secure.?default",r"hardening",r"security.?baseline",r"default.?config",r"configuration.?as.?code"],repo,[r"default",r"baseline",r"hardening",r"secure",r"configuration"],False)
        return ev,"pass" if ev else "partial","secure defaults need testable configuration guidance."
    if kind=="sbom":
        ev=sbom_valid(files,repo)
        return ev,"pass" if ev else "fail","a valid machine-readable SBOM with meaningful component content is required."
    if kind=="provenance":
        ev=provenance_valid(files,repo)
        return ev,"pass" if ev else "fail","provenance must be a valid in-toto/SLSA-style statement with subject digest, build definition, and builder identity."
    if kind=="signing":
        ev=verified_signature_evidence(files,repo)
        return ev,"pass" if ev else "partial","verified signature evidence requires digest, identity, verifier, and verification time."
    if kind=="verification":
        ev=semantic_files(files,[r"release.?verify",r"verify.?release",r"signature.?verification",r"artifact.?verification"],repo,[r"verify",r"digest",r"signature",r"identity",r"provenance"],False)
        return ev,"pass" if ev else "not_proven","release verification policy should explicitly verify artifact identity/integrity."
    if kind=="update_rollback":
        ev=semantic_files(files,[r"rollback",r"canary",r"staged.?rollout",r"progressive.?delivery",r"anti.?downgrade",r"update.?strategy"],repo,[r"rollback",r"canary",r"staged",r"downgrade",r"update"],False)
        return ev,"pass" if ev else "not_proven","update safety should include rollback and downgrade protection where applicable."
    if kind=="vuln_response":
        ev=semantic_files(files,[r"vulnerability",r"incident.?response",r"psirt",r"vdp",r"security\.txt"],repo,[r"report",r"triage",r"remedi",r"disclos",r"response",r"owner"],False)
        return ev,"pass" if ev else "fail","vulnerability intake, assessment, ownership, and remediation path must be evidenced."
    if kind=="vuln_prioritization":
        ev=semantic_files(files,[r"CVSS",r"EPSS",r"KEV",r"SSVC",r"exploitability",r"priority"],repo,[r"CVSS",r"EPSS",r"KEV",r"SSVC",r"environment",r"exploit"],False)
        return ev,"pass" if ev else "partial","prioritization must combine technical severity with threat and environment context."
    if kind=="vex":
        ev=semantic_files(files,[r"VEX",r"CSAF",r"vulnerability.?exploitability"],repo,[r"status",r"vulnerab",r"not affected",r"affected",r"justification"],False)
        return ev,"pass" if ev else "not_proven","VEX/CSAF-style records can distinguish reachability/exploitability from raw presence."
    if kind=="patch_sla":
        ev=semantic_files(files,[r"patch.?SLA",r"remediation.?SLA",r"severity.?SLA",r"time.?to.?remediate"],repo,[r"critical",r"high",r"days?",r"SLA",r"remedi"],False)
        return ev,"pass" if ev else "partial","remediation targets need severity-specific timelines and verification."
    if kind=="eol":
        ev=semantic_files(files,[r"end.?of.?life",r"EOL",r"support.?lifecycle",r"lifecycle"],repo,[r"support",r"end.?of.?life",r"EOL",r"date"],False)
        return ev,"pass" if ev else "partial","support lifecycle and end-of-support behavior should be explicit."
    if kind=="ai_governance":
        ev=semantic_files(files,[r"SP800.?218A",r"AI.?provenance",r"AI.?security",r"LLM",r"model.?card",r"AI.?coding"],repo,[r"lineage",r"provenance",r"model",r"AI",r"approval",r"data"],False)
        return ev,"pass" if ev else "not_proven","AI-specific governance applies where AI development/use is in scope."
    if kind=="ai_eval":
        ev=semantic_files(files,[r"red.?team",r"model.?evaluation",r"evals",r"prompt.?injection",r"jailbreak",r"AI.?testing"],repo,[r"prompt",r"jailbreak",r"red.?team",r"evaluation",r"exfiltration",r"test"],False)
        return ev,"pass" if ev else "not_proven","AI systems/models require dedicated abuse and security evaluation where in scope."
    if kind=="evidence":
        ev=semantic_files(files,[r"evidence",r"attestation",r"assessment",r"audit.?trail"],repo,[r"evidence",r"attestation",r"audit",r"digest",r"timestamp",r"assessor"],False)
        return ev,"pass" if ev else "partial","evidence must be traceable and attributable."
    if kind=="exceptions":
        ev=semantic_files(files,[r"exception",r"risk.?acceptance",r"compensating.?control"],repo,[r"owner",r"risk",r"expires?",r"compensating",r"accept"],False)
        return ev,"pass" if ev else "partial","exceptions should be explicit, owned, risk-accepted, and time-bounded."
    if kind=="metrics":
        ev=semantic_files(files,[r"security.?metric",r"KPI",r"KRI",r"MTTR",r"vulnerability.?trend",r"root.?cause"],repo,[r"metric",r"KPI",r"KRI",r"MTTR",r"recurrence",r"root.?cause"],False)
        return ev,"pass" if ev else "partial","metrics should measure outcomes, exposure, remediation, and recurrence."
    if kind=="rla":
        ev=semantic_files(files,[r"root.?cause",r"RCA",r"CAPA",r"corrective.?action",r"preventive.?action",r"lesson.?learned"],repo,[r"root.?cause",r"corrective",r"preventive",r"CAPA",r"lesson"],False)
        return ev,"pass" if ev else "not_proven","root-cause/learning evidence should connect material findings to corrective and preventive actions."
    if kind=="regression_learning":
        ev=semantic_files(files,[r"regression.?test",r"security.?regression",r"post.?incident",r"lessons.?learned"],repo,[r"regression",r"guardrail",r"lesson",r"post.?incident",r"recurrence"],False)
        return ev,"pass" if ev else "not_proven","material fixes should generate reusable regression/learning controls."
    if kind=="observability":
        ev=semantic_files(files,[r"audit.?log",r"security.?logging",r"telemetry",r"event.?logging"],repo,[r"audit",r"log",r"telemetry",r"event",r"security"],False)
        return ev,"pass" if ev else "partial","security-relevant events should be observable enough for detection and response."
    if kind=="least_privilege":
        ev=semantic_files(files,[r"least.?privilege",r"MFA",r"phishing.?resistant",r"RBAC",r"IAM"],repo,[r"least.?privilege",r"MFA",r"phishing",r"RBAC",r"IAM",r"segmented"],False)
        return ev,"pass" if ev else "partial","development access should be hardened, separated, and least-privilege."
    if kind=="repro_build":
        ev=semantic_files(files,[r"reproducible.?build",r"build.?reproducibility",r"SOURCE_DATE_EPOCH",r"hermetic"],repo,[r"reproduc",r"hermetic",r"pinned",r"timestamp",r"build"],False)
        return ev,"pass" if ev else "not_proven","reproducibility/hermeticity should be explicit where required by risk."
    if kind=="dependency_pinning":
        ev=semantic_files(files,[r"pin.?dependenc",r"lockfile",r"hash.?pin",r"immutable.?digest"],repo,[r"lockfile",r"hash",r"immutable",r"pinned",r"digest"],False)
        return ev,"pass" if ev else "partial","dependency inputs should be integrity-constrained."
    if kind=="ci_hardening":
        return workflow_hardening(files,repo)
    if kind=="supplier_due_diligence":
        return supplier_due_diligence(files,repo)
    if kind=="release_linkage":
        ev=release_linkage(files,repo)
        return ["release digest:"+x for x in ev],"pass" if ev else "fail","provenance subject digest and verified signature digest must intersect on the release artifact identity."
    if kind=="evidence_quality":
        return evidence_quality(files,repo)
    if kind=="healing_validation":
        return healing_validation(files,repo)
    if kind=="risk_model_semantics":
        return risk_model_semantics(files,repo)
    return [],"not_proven","No probe configured."


def evidence_strength_for(probe,status,evidence):
    if status=="pass" and evidence:
        strong={"sbom","provenance","signing","release_linkage"}
        medium={"ci","ci_hardening","sast","sca","requirements","security_policy","threat_model","security_testing","vuln_response","supplier_due_diligence","evidence_quality","healing_validation","risk_model_semantics"}
        return 0.96 if probe in strong else (0.86 if probe in medium else 0.74)
    if status=="fail" and evidence:
        # Negative evidence can be high-confidence detection without constituting positive assurance.
        return 0.92 if probe in {"secrets","ci_hardening","sbom","provenance","release_linkage"} else 0.80
    if status=="partial" and evidence: return 0.62
    if status=="not_proven" and evidence: return 0.45
    return 0.0


def evidence_basis_for(probe,status,evidence):
    if not evidence: return []
    basis=[]
    if probe in {"sbom","provenance","signing","release_linkage"}: basis.append("structured-artifact")
    elif probe=="secrets": basis.append("negative-signal")
    elif probe in {"ci_hardening","ci","branch_protection","ownership"}: basis.append("configuration-content")
    else: basis.append("content-backed")
    if status in {"pass","fail"}: basis.append("material-signal")
    else: basis.append("incomplete-signal")
    return basis


def confidence_label(strength):
    if strength>=0.9: return "high"
    if strength>=0.7: return "medium"
    if strength>0: return "low"
    return "none"


def eval_control(c,files,repo):
    ev,status,why=control_probe(c,files,repo)
    strength=evidence_strength_for(c["probe"],status,ev)
    rationale=why
    if status=="pass":
        rationale += " Local evidence supports the configured outcome; authoritative external/platform claims still require authoritative evidence."
    elif status=="partial":
        rationale += " Some evidence exists, but the full outcome is not established."
    elif status=="not_proven":
        rationale += " Absence of evidence is not treated as evidence of failure."
    elif status=="fail":
        rationale += " A negative signal was detected; remediation should address the control objective rather than silence the finding."
    return Result(c["id"],c["title"],status,c["severity"],ev,rationale,c["next_step"],c.get("ssdf",[]),c.get("sources",[]),strength,evidence_basis_for(c["probe"],status,ev),confidence_label(strength))


def score_results(results):
    denom=sum(SEV_WEIGHT[r.severity] for r in results)
    raw=sum(SEV_WEIGHT[r.severity]*STATUS_VALUE[r.status] for r in results)
    return round(100*raw/denom,1) if denom else 0.0


def assess(repo:Path,profile:str):
    catalog=load_json(CATALOG)["controls"]
    prof=load_json(PROFILES/f"{profile}.json")
    sel=set(prof["controls"])
    files=repo_files(repo)
    results=[eval_control(c,files,repo) for c in catalog if c["id"] in sel]
    counts={s:sum(r.status==s for r in results) for s in ["pass","partial","not_proven","fail"]}
    avg_strength=round(sum(r.evidence_strength for r in results)/len(results),3) if results else 0.0
    linkage=release_linkage(files,repo)
    payload={"tool":"SSDF One","version":VERSION,"profile":profile,"repo":repo.as_posix(),"score":score_results(results),"counts":counts,"average_evidence_strength":avg_strength,"release_digest_linkage":linkage,"results":[asdict(r) for r in results]}
    payload["assessment_digest"]=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
    return payload


def write_assessment(data,out:Path):
    out.mkdir(parents=True,exist_ok=True)
    (out/"assessment.json").write_text(json.dumps(data,indent=2,sort_keys=True),encoding="utf-8")
    lines=[f"# SSDF One Assessment — {data['profile']}","",f"**Score:** {data['score']}/100",f"**Average evidence strength:** {data['average_evidence_strength']}",f"**Digest:** `{data['assessment_digest']}`",f"**Counts:** `{data['counts']}`","", "## Results",""]
    for r in data["results"]:
        ev=', '.join('`'+x+'`' for x in r["evidence"]) if r["evidence"] else '—'
        lines += [f"### {r['control_id']} — {r['title']}",f"- Status: **{r['status']}**",f"- Severity: {r['severity']}",f"- Evidence strength: {r['evidence_strength']}",f"- Confidence: {r['confidence']}",f"- Evidence: {ev}",f"- Rationale: {r['rationale']}",f"- Next step: {r['next_step']}",f"- Source refs: {', '.join(r['source_refs']) or '—'}",""]
    lines += ["## Boundary","","This is an evidence-oriented engineering assessment. It is not a certification, legal opinion, compliance attestation, or independent assurance report."]
    (out/"assessment.md").write_text("\n".join(lines),encoding="utf-8")


def load_findings(assessment):
    out=[]
    for r in assessment["results"]:
        if r["status"] in {"pass","not_applicable"}: continue
        out.append({"id":r["control_id"],"severity":r["severity"],"status":r["status"],"title":r["title"],"evidence":r["evidence"],"ssdf":r["ssdf"],"evidence_strength":r.get("evidence_strength",0)})
    return out


def assurance_priority(finding):
    """Transparent internal triage aid; not a replacement for CVSS/EPSS/SSVC."""
    base=float(finding.get("cvss_base",0) or 0)/10
    epss=max(0.0,min(1.0,float(finding.get("epss",0) or 0)))
    exploited=1.0 if finding.get("kev") or finding.get("actively_exploited") else 0.0
    internet=1.0 if finding.get("internet_exposed") else 0.0
    asset=max(1.0,min(5.0,float(finding.get("asset_criticality",3) or 3)))/5
    data=max(1.0,min(5.0,float(finding.get("data_sensitivity",3) or 3)))/5
    return round(100*(0.30*base+0.20*epss+0.20*exploited+0.10*internet+0.10*asset+0.10*data),1)


def vibration_report(history):
    by={}
    for snap in history:
        for r in snap.get("results",[]): by.setdefault(r["control_id"],[]).append(r["status"])
    hot=[]
    for cid,states in by.items():
        changes=sum(1 for a,b in zip(states,states[1:]) if a!=b)
        fails=sum(s=="fail" for s in states)
        if fails or changes>=2:
            hot.append({"control_id":cid,"observations":len(states),"fails":fails,"transitions":changes,"vibration":"high" if changes>=3 else ("medium" if changes else "low")})
    return sorted(hot,key=lambda x:(x["fails"],x["transitions"]),reverse=True)


def causal_graph(findings,hypotheses):
    nodes=[]; edges=[]; seen=set()
    for f in findings:
        fid="finding:"+f["id"]; nodes.append({"id":fid,"type":"finding","label":f["title"],"severity":f["severity"]}); seen.add(fid)
    for h in hypotheses:
        cid="cause:"+h["cluster"]; nodes.append({"id":cid,"type":"root_cause","label":h["hypothesis"],"confidence":h.get("confidence",0.0)})
        for fid0 in h["findings"]: edges.append({"from":"finding:"+fid0,"to":cid,"type":"supports"})
        for t in h["treatments"]:
            tid="treatment:"+t
            if tid not in seen: nodes.append({"id":tid,"type":"treatment","label":t}); seen.add(tid)
            edges.append({"from":cid,"to":tid,"type":"mitigated_by"})
    return {"nodes":nodes,"edges":edges}


def root_cause_hypotheses(findings, catalog=None):
    """Generate conservative causal hypotheses from catalog root-cause groups.
    Hypotheses are not asserted root causes; confidence is capped unless independently corroborated.
    """
    cat={c["id"]:c for c in (catalog or load_json(CATALOG)["controls"])}
    clusters={}
    for f in findings:
        meta=cat.get(f["id"],{})
        key=meta.get("root_cause_group") or meta.get("domain") or "unknown"
        clusters.setdefault(key,[]).append(f)
    templates={
      "credential-control failure":("Credential handling allowed secret material to enter a controlled artifact path.",["remove/rotate confirmed secret material using an approved secret mechanism","add prevention at commit/CI and history coverage","create a durable regression guard and verify recurrence prevention"]),
      "release-assurance integration gap":("Release assurance is fragmented so artifact identity, provenance, signing, and promotion policy are not jointly enforced.",["bind SBOM/provenance/signature to one artifact digest","verify identity and policy before promotion","make the evidence packet a release gate"]),
      "engineering-prevention gap":("Preventive engineering controls are insufficient or inconsistently connected to verification.",["translate failures into class-level secure coding/design constraints","add targeted SAST/SCA/fuzzing and security regression tests with triage quality","prefer safer primitives and memory-safe options where appropriate"]),
      "vulnerability feedback-loop gap":("Vulnerability intelligence is not reliably connected to risk semantics, ownership, remediation, deployment, and learning.",["preserve CVSS/EPSS/exploitation/environment signals separately","link findings to owner and verified remediation","feed validated root causes back into controls and regression tests"]),
      "learning-system gap":("Resolved findings are not yet consistently converted into validated preventive changes and recurrence controls.",["require CAPA-style corrective/preventive actions","create regression/guardrail artifacts for material fixes","measure recurrence and control effectiveness over time"]),
      "supply-chain":("Supplier and dependency assurance may not cover the complete trust chain from supplier to artifact.",["assess provenance/resilience/tiering/FOCI where applicable","bind supplier evidence to release artifacts","refresh supplier evidence according to risk"]),
      "environment":("Development/build environments may expose security-critical privilege or workflow paths.",["apply least privilege and hardened workflow permissions","pin mutable workflow dependencies to immutable references","separate untrusted inputs from privileged execution"]),
      "assurance":("Assurance decisions may lack sufficiently fresh, attributable, or integrity-bound evidence.",["record producer/scope/timestamp/freshness/integrity","reject stale or label-only evidence","make exceptions explicit and time-bound"]),
      "governance":("Governance and accountability signals are insufficiently explicit for reliable software assurance.",["define accountable owners and security objectives","connect requirements, risk acceptance, and metrics","review material exceptions and lessons learned"]),
      "source":("Source/change controls may allow security-sensitive modification without sufficient protection.",["enforce protected branches and review","protect secrets and ownership paths","verify authoritative platform settings rather than documentation alone"]),
      "engineering":("Engineering evidence may exist without proving that security requirements are implemented and verified.",["turn architecture requirements into tests","require security properties at key SDLC gates","verify residual risk explicitly"]),
      "release":("Release/update safeguards may not be tested end-to-end.",["test staged deployment, rollback and anti-downgrade behavior","bind release evidence to the deployed artifact","verify failure recovery paths"]),
      "operations":("Operational lifecycle evidence may not fully cover support and response boundaries.",["define support/EOL behavior","link lifecycle events to vulnerability response","measure operational security outcomes"]),
      "ai":("AI-specific development/use introduces additional provenance, evaluation, and abuse-testing gaps.",["track AI/model/data lineage","run targeted abuse and security evaluations","control promotion of AI artifacts and evidence"]),
    }
    hyps=[]
    for key,fs in sorted(clusters.items()):
        if key in templates: cause,treatments=templates[key]
        else:
            cause=f"Control cluster '{key}' indicates a systemic assurance hypothesis requiring corroboration."
            treatments=["define the accountable outcome and evidence","correlate findings across assets and process stages","validate the proposed corrective action and recurrence guard"]
        avg=sum(float(f.get("evidence_strength",0)) for f in fs)/len(fs) if fs else 0.0
        # Multiple findings increase signal, but do not convert a hypothesis into fact.
        confidence=min(0.85,0.45+0.10*min(3,max(0,len(fs)-1))+0.15*avg)
        hyps.append({"cluster":key,"findings":[f["id"] for f in fs],"hypothesis":cause,"treatments":treatments,"confidence":round(confidence,2),"interpretation":"hypothesis","corroboration_required":True})
    return hyps


def apply_safe_secret_fix(repo:Path, findings):
    changed=[]
    for f in findings:
        if f["id"]!="SRC-04": continue
        for evidence in f["evidence"]:
            if ":" not in evidence: continue
            relpath=evidence.split(":",1)[0]
            p=repo/relpath
            if p.suffix.lower()!=".py" or not p.exists(): continue
            s=p.read_text(encoding="utf-8")
            if "import os" not in s: s="import os\n"+s
            ns=re.sub(r"(?im)^(\s*)(password|passwd|secret|api[_-]?key|token)\s*=\s*(['\"]).+?\3\s*$", r"\1\2 = os.environ.get('\2.upper()')\n", s)
            if ns!=s:
                p.write_text(ns,encoding="utf-8"); changed.append(relpath)
    return sorted(set(changed))


def counterfactual_recurrence_probe(repo:Path, target_control, changed, profile="baseline"):
    """Reintroduce the same defect in a disposable copy to test that detection still fires."""
    tmp=Path(tempfile.mkdtemp(prefix="ssdf-one-recurrence-"))
    try:
        work=tmp/"repo"; shutil.copytree(repo,work)
        if target_control=="SRC-04" and changed:
            p=work/changed[0]
            if p.suffix.lower()==".py":
                with p.open("a",encoding="utf-8") as fh:
                    fh.write('\nAPI_KEY = "RECURRENCE-PROBE-ONLY-0123456789"\n')
        d=assess(work,profile)
        hit=next((r for r in d["results"] if r["control_id"]==target_control),None)
        return {"reintroduced":True,"detected":bool(hit and hit["status"]=="fail"),"status":hit["status"] if hit else None}
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


def heal(repo:Path, profile:str, out:Path, apply:bool, test_cmd:str|None):
    before=assess(repo,profile); findings=load_findings(before); hyps=root_cause_hypotheses(findings)
    scored=[{**f,"assurance_priority":assurance_priority(f)} for f in findings]
    capa=[{"cause":h["cluster"],"finding_ids":h["findings"],"cause_confidence":h["confidence"],"corrective_actions":[h["treatments"][0]],"preventive_actions":h["treatments"][1:],"verification_required":True} for h in hyps]
    packet={"tool":"SSDF One Healing Engine","version":VERSION,"mode":"apply" if apply else "plan","before_digest":before["assessment_digest"],"before_score":before["score"],"findings":scored,"root_causes":hyps,"causal_graph":causal_graph(scored,hyps),"capa":capa,"changes":[],"verification":{}}
    if not apply:
        out.mkdir(parents=True,exist_ok=True); (out/"healing.json").write_text(json.dumps(packet,indent=2,sort_keys=True),encoding="utf-8"); return packet
    tmp=Path(tempfile.mkdtemp(prefix="ssdf-one-heal-"))
    try:
        work=tmp/"repo"; shutil.copytree(repo,work,dirs_exist_ok=True)
        changed=apply_safe_secret_fix(work,findings); packet["changes"]=changed
        effective_test_cmd=test_cmd or "python -m compileall -q ."
        proc=subprocess.run(effective_test_cmd,shell=True,cwd=work,text=True,capture_output=True,timeout=300)
        packet["verification"]["test"]={"command":effective_test_cmd,"returncode":proc.returncode,"stdout":proc.stdout[-4000:],"stderr":proc.stderr[-4000:]}
        if proc.returncode!=0:
            packet["status"]="rolled_back"; return packet
        after=assess(work,profile)
        packet["verification"].update({"after_score":after["score"],"after_counts":after["counts"],"after_digest":after["assessment_digest"]})
        before_map={r["control_id"]:r for r in before["results"]}; after_map={r["control_id"]:r for r in after["results"]}
        target_resolved=[]
        if "SRC-04" in after_map and before_map.get("SRC-04",{}).get("status") in {"fail","partial"} and after_map["SRC-04"]["status"]=="pass": target_resolved.append("SRC-04")
        regressions=[cid for cid,br in before_map.items() if (after_map.get(cid) and STATUS_VALUE[after_map[cid]["status"]]<STATUS_VALUE[br["status"]])]
        recurrence=None
        if target_resolved:
            recurrence=counterfactual_recurrence_probe(work,target_resolved[0],changed,profile)
            packet["verification"]["counterfactual_recurrence"]=recurrence
        safe=bool(changed and target_resolved and not regressions and recurrence and recurrence["detected"])
        if safe:
            for relpath in changed:
                src=work/relpath; dst=repo/relpath; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
            packet["status"]="committed"
            packet["commit_reason"]="Targeted control resolved, tests passed, no assessed regression occurred, and counterfactual recurrence was detected."
            packet["verification"]["post_commit_file_hashes"]={p:file_sha256(repo/p) for p in changed if (repo/p).exists()}
        else:
            packet["status"]="no_safe_commit"
            packet["commit_reason"]="Safe promotion criteria were not all demonstrated."
        packet["target_resolved"]=target_resolved; packet["regressions"]=regressions
        return packet
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


def write_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(data,indent=2,sort_keys=True),encoding="utf-8")


def main(argv=None):
    ap=argparse.ArgumentParser(prog="ssdfx",description="SSDF One v1.2 secure software assurance, adversarial validation, and root-cause healing")
    sub=ap.add_subparsers(dest="cmd",required=True)
    a=sub.add_parser("assess"); a.add_argument("--repo",default="."); a.add_argument("--profile",choices=[p.stem for p in PROFILES.glob("*.json")],default="baseline"); a.add_argument("--out",default=".ssdfx"); a.add_argument("--fail-on",choices=list(FAIL_THRESHOLD),default="high")
    h=sub.add_parser("heal"); h.add_argument("--repo",default="."); h.add_argument("--profile",choices=[p.stem for p in PROFILES.glob("*.json")],default="baseline"); h.add_argument("--out",default=".ssdfx/healing"); h.add_argument("--apply",action="store_true"); h.add_argument("--test-cmd",default=None,help="Verification command; default: python -m compileall -q .")
    m=sub.add_parser("maintain"); m.add_argument("--repo",default="."); m.add_argument("--mode",choices=["TARGETED","SYSTEMATIC","FULL_RED_TEAM","CERTIFICATION","CONTINUOUS"],default="SYSTEMATIC"); m.add_argument("--out",default=".ssdfx-maintenance"); m.add_argument("--observation-hours",type=float,default=0.01)
    args=ap.parse_args(argv)
    if args.cmd=="assess":
        repo=Path(args.repo).resolve(); d=assess(repo,args.profile); write_assessment(d,Path(args.out)); print(json.dumps({k:d[k] for k in ["version","profile","score","counts","average_evidence_strength","assessment_digest"]},indent=2))
        threshold=FAIL_THRESHOLD[args.fail_on]; blocking=[] if args.fail_on=="never" else [r for r in d["results"] if r["status"]=="fail" and SEV_WEIGHT[r["severity"]]>=threshold]
        return 2 if blocking else 0
    if args.cmd=="heal":
        d=heal(Path(args.repo).resolve(),args.profile,Path(args.out),args.apply,args.test_cmd); write_json(Path(args.out)/"healing.json",d); print(json.dumps(d,indent=2)); return 0 if d.get("status") in {None,"committed"} else 3
    if args.cmd=="maintain":
        from maintenance.protocol import run_maintenance
        repo=Path(args.repo).resolve(); out=Path(args.out)
        d=run_maintenance(repo,args.mode,args.observation_hours)
        write_json(out/"maintenance-report.json",d)
        (out/"maintenance-report.md").write_text(json.dumps(d,indent=2,sort_keys=True),encoding="utf-8")
        print(json.dumps({"protocol_version":d["protocol_version"],"mode":d["mode"],"final_status":d["final_status"],"qualification":d["formal_qualification"]["status"],"protocol_digest":d["protocol_digest"]},indent=2))
        return 0 if d["final_status"]=="QUALIFIED" else 4
    return 1

if __name__=="__main__": sys.exit(main())
