from __future__ import annotations

import multiprocessing as mp
import os
import queue
import time
from dataclasses import asdict, dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class ExecutionResult:
    status: str
    output: Any = None
    error: str | None = None
    duration_ms: float = 0.0
    pid: int | None = None
    attestation: dict[str, Any] | None = None


def _worker(func: Callable[[dict[str, Any]], Any], payload: dict[str, Any], out_q) -> None:
    try:
        out_q.put(("ok", func(payload)))
    except BaseException as exc:  # worker boundary converts process errors into structured results
        out_q.put(("error", f"{type(exc).__name__}: {exc}"))


class ProcessExecutor:
    """Real OS-process execution boundary; not a hostile-code sandbox.

    Start-method policy (root-cause RC-0006):
    - On POSIX, default to *fork* for local process isolation of pure handlers.
      Concurrent ThreadPool submission of spawn workers was observed to produce
      non-deterministic worker exit-code-1 failures (bootstrap/reimport races),
      which is an executor topology defect, not a store/kernel concurrency bug.
    - Callers that require spawn (cross-platform freeze, hard-isolation testing)
      MUST pass start_method="spawn" explicitly.
    """

    def __init__(self, *, start_method: str | None = None) -> None:
        available = mp.get_all_start_methods()
        if start_method is not None:
            method = start_method
        elif "fork" in available:
            method = "fork"  # stable under concurrent local submissions
        elif "spawn" in available:
            method = "spawn"
        else:
            method = available[0]
        if method not in available:
            raise ValueError(f"start_method {method!r} not in {available}")
        self.ctx = mp.get_context(method)
        self.start_method = method
        self._processes: dict[str, mp.Process] = {}

    def execute(self, execution_id: str, func: Callable[[dict[str, Any]], Any], payload: dict[str, Any], *, timeout: float | None = None) -> ExecutionResult:
        out_q = self.ctx.Queue(maxsize=1)
        p = self.ctx.Process(target=_worker, args=(func, payload, out_q), daemon=True)
        start = time.monotonic()
        p.start()
        self._processes[execution_id] = p
        try:
            p.join(timeout)
            duration = (time.monotonic() - start) * 1000
            if p.is_alive():
                p.terminate()
                p.join(1)
                return ExecutionResult("TIMEOUT", error="execution deadline exceeded", duration_ms=duration, pid=p.pid)
            try:
                kind, value = out_q.get_nowait()
            except queue.Empty:
                kind, value = "error", (
                    f"worker exited with code {p.exitcode} "
                    f"(start_method={getattr(self, 'start_method', 'unknown')})"
                )
            if kind == "ok":
                return ExecutionResult("SUCCESS", output=value, duration_ms=duration, pid=p.pid)
            return ExecutionResult("FAILURE", error=str(value), duration_ms=duration, pid=p.pid)
        finally:
            self._processes.pop(execution_id, None)
            out_q.close()

    def cancel(self, execution_id: str) -> bool:
        p = self._processes.get(execution_id)
        if not p:
            return False
        if not p.is_alive():
            return False
        p.terminate()
        return True

    def inspect(self, execution_id: str) -> dict[str, Any]:
        p = self._processes.get(execution_id)
        return {"execution_id": execution_id, "running": bool(p and p.is_alive()), "pid": p.pid if p else None}


class HardIsolationKernelExecutor:
    """Kernel executor adapter that has exactly one execution mechanism: HardIsolationExecutor.

    Bindings are established by the governed Runtime after capability resolution and policy
    evaluation. A caller-supplied handler is never trusted as the authoritative implementation.
    """

    def __init__(self, *, authority, isolation=None) -> None:
        from .isolation import HardIsolationExecutor, ManifestAuthority
        from threading import RLock
        self.authority = authority or ManifestAuthority()
        self.isolation = isolation or HardIsolationExecutor(authority=self.authority)
        self._bindings: dict[str, tuple[Any, Any, Callable[[dict[str, Any]], Any]]] = {}
        self._lock = RLock()
        self.last_attestation: dict[str, Any] | None = None

    @property
    def available(self) -> bool:
        return bool(self.isolation.available)

    @property
    def block_reason(self) -> str | None:
        return self.isolation.block_reason

    def bind(self, *, execution_id: str, capability, contract_id: str, contract_version: str, handler: Callable[[dict[str, Any]], Any], permissions: set[str]):
        with self._lock:
            manifest = self.isolation.build_manifest(capability, contract_version, contract_id=contract_id, permissions=set(permissions), handler=handler)
            self._bindings[execution_id] = (capability, manifest, handler)
            return manifest

    def execute(self, execution_id: str, func: Callable[[dict[str, Any]], Any], payload: dict[str, Any], *, timeout: float | None = None) -> ExecutionResult:
        from .models import Execution
        with self._lock:
            binding = self._bindings.get(execution_id)
        if binding is None:
            return ExecutionResult("FAILURE", error="isolated_execution_binding_missing")
        capability, manifest, bound_handler = binding
        execution = Execution(execution_id=execution_id, input_data=payload, idempotency_key=f"idem-{execution_id}",
                              capability_ref={"id": capability.capability_id, "version": capability.semantic_version, "implementation_id": capability.implementation_id})
        attested = self.isolation.execute(execution=execution, capability=capability, handler=bound_handler,
                                           payload=payload, manifest=manifest, timeout=timeout)
        from .isolation import ResultAttestor
        attestation_dict = asdict(attested)
        self.last_attestation = attestation_dict
        if not ResultAttestor.verify_with_public_key(attested, self.isolation.attestor.public_key):
            return ExecutionResult("FAILURE", error="attestation_verification_failed", pid=attested.worker_pid, attestation=attestation_dict)
        return ExecutionResult(attested.status, output=attested.output, error=attested.error,
                              duration_ms=attested.duration_ms, pid=attested.worker_pid, attestation=attestation_dict)

    def cancel(self, execution_id: str) -> bool:
        return False

    def inspect(self, execution_id: str) -> dict[str, Any]:
        with self._lock:
            return {"execution_id": execution_id, "bound": execution_id in self._bindings, "isolated": True}

    def unbind(self, execution_id: str) -> None:
        with self._lock:
            self._bindings.pop(execution_id, None)
