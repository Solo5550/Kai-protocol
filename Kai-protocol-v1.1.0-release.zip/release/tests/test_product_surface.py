"""Product surface after radical proof/gate remediation."""

from __future__ import annotations

import tempfile
from datetime import datetime, timedelta, timezone

import pytest

from kai.product import (
    INVARIANT,
    GateDenial,
    KaiGate,
    KaiProductRuntime,
    generate_issuer_keypair,
    issue_receipt,
    verify_receipt,
)


def test_invariant_statement():
    assert "prove" in INVARIANT.lower()


def test_unsigned_mint_rejected_by_default():
    priv, pub, kid = generate_issuer_keypair()
    # forging without going through issue with key should fail gate
    with pytest.raises(ValueError, match="signed_receipt_requires_private_key"):
        issue_receipt(
            action="admin.wipe",
            contract_id="c",
            contract_version="1",
            execution_id="e",
            run_id="r",
            status="SUCCESS",
            output={"wiped": True},
            evidence={},
            decision="ACCEPTED",
            require_signature=True,
        )


def test_signed_receipt_roundtrip():
    priv, pub, kid = generate_issuer_keypair()
    r = issue_receipt(
        action="transfer",
        contract_id="c1",
        contract_version="1",
        execution_id="e1",
        run_id="r1",
        status="SUCCESS",
        output={"amount": 10},
        evidence={"ok": True},
        decision="ACCEPTED",
        tenant_id="t1",
        actor_id="a1",
        audience="gate",
        private_key=priv,
        key_id=kid,
    )
    assert r.signature and r.nonce and r.expires_at
    assert verify_receipt(r, public_keys={kid: pub}, require_signature=True)
    # wrong key
    _, pub2, kid2 = generate_issuer_keypair()
    assert not verify_receipt(r, public_keys={kid2: pub2}, require_signature=True)


def test_tamper_breaks_signature():
    priv, pub, kid = generate_issuer_keypair()
    r = issue_receipt(
        action="x", contract_id="c", contract_version="1", execution_id="e", run_id="r",
        status="SUCCESS", output={}, evidence={}, decision="ACCEPTED",
        private_key=priv, key_id=kid,
    )
    bad = r.to_dict()
    bad["output_digest"] = "0" * 64
    assert not verify_receipt(bad, public_keys={kid: pub}, require_signature=True)


def test_gate_replay_blocked():
    priv, pub, kid = generate_issuer_keypair()
    r = issue_receipt(
        action="x", contract_id="c", contract_version="1", execution_id="e", run_id="r",
        status="SUCCESS", output={}, evidence={}, decision="ACCEPTED",
        private_key=priv, key_id=kid,
    )
    g = KaiGate(public_keys={kid: pub}, single_use=True)
    assert g.admit(r).allowed
    assert g.admit(r).reason == "replay_detected"


def test_gate_rejects_allow_alias():
    priv, pub, kid = generate_issuer_keypair()
    with pytest.raises(ValueError):
        issue_receipt(
            action="x", contract_id="c", contract_version="1", execution_id="e", run_id="r",
            status="SUCCESS", output={}, evidence={}, decision="ALLOW",
            private_key=priv, key_id=kid,
        )


def test_gate_contract_binding():
    priv, pub, kid = generate_issuer_keypair()
    r = issue_receipt(
        action="x", contract_id="unknown", contract_version="1", execution_id="e", run_id="r",
        status="SUCCESS", output={}, evidence={}, decision="ACCEPTED",
        private_key=priv, key_id=kid,
    )
    g = KaiGate(public_keys={kid: pub}, allowed_contracts={"known"}, single_use=False)
    assert g.admit(r).reason == "contract_not_allowed"


def test_gate_blocks_side_effect_without_proof():
    g = KaiGate(require_signature=True, public_keys={}, single_use=True)
    called = {"n": 0}
    def act():
        called["n"] += 1
    with pytest.raises(GateDenial):
        g.guard(act, receipt=None)
    assert called["n"] == 0


def test_product_runtime_signed_flow():
    def double(p):
        return {"value": int(p["value"]) * 2}

    with tempfile.TemporaryDirectory() as td:
        rt = KaiProductRuntime(data_dir=td)
        rt.install("math.double", double)
        result = rt.act(
            capability_id="math.double",
            objective="double",
            input_data={"value": 21},
            expected_outcome={"value": 42},
            tenant_id="bank",
            actor_id="teller",
        )
        assert result.status == "SUCCESS"
        assert result.output == {"value": 42}
        assert result.receipt.signature
        assert rt.verify(result.receipt)
        assert rt.admit(result.receipt).allowed is True
        # replay
        assert rt.admit(result.receipt).allowed is False
        # untrusted gate
        g2 = KaiGate(require_signature=True, public_keys={}, single_use=False)
        assert g2.admit(result.receipt).allowed is False


def test_expired_receipt_rejected():
    priv, pub, kid = generate_issuer_keypair()
    r = issue_receipt(
        action="x", contract_id="c", contract_version="1", execution_id="e", run_id="r",
        status="SUCCESS", output={}, evidence={}, decision="ACCEPTED",
        issued_at="2000-01-01T00:00:00+00:00",
        expires_at="2000-01-01T01:00:00+00:00",
        private_key=priv, key_id=kid,
    )
    assert not verify_receipt(r, public_keys={kid: pub}, require_signature=True)
