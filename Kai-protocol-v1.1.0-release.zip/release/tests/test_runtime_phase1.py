from kai.runtime.models import Execution, ExecutionState, RuntimeEnvelope, to_primitive


def test_core_runtime_object_has_canonical_identity_and_versioning():
    e = Execution(object_id="obj-1", execution_id="exec-1", run_id="run-1", objective="demo")
    assert e.object_id == "obj-1"
    assert e.execution_id == "exec-1"
    assert e.schema_version == "0.6.0"
    assert e.version == "0.7.0"
    assert e.state is ExecutionState.CREATED


def test_runtime_envelope_carries_execution_identity_and_policy_context():
    env = RuntimeEnvelope(
        execution_id="exec-1", run_id="run-1", root_execution_id="exec-1", trace_id="t1",
        span_id="s1", policy_snapshot_ref="policy@1.1.0", idempotency_key="idem-1",
    )
    data = to_primitive(env)
    for key in ("execution_id", "run_id", "root_execution_id", "trace_id", "span_id", "policy_snapshot_ref", "idempotency_key"):
        assert data[key]


def test_primitive_serialization_is_machine_friendly():
    data = to_primitive(Execution(execution_id="e", run_id="r"))
    assert data["state"] == "CREATED"
    assert isinstance(data["created_at"], str)


def test_package_version_is_v0_8():
    import kai
    assert kai.__version__ == "1.1.0"
    assert kai.__language__ == "kai-lang/0.8"
